@file:OptIn(ExperimentalTime::class)

package com.iproov.identity.models

import com.iproov.identity.Logger
import com.iproov.identity.cryptography.EllipticCurvePublicKey
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.double
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.int
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long
import kotlinx.serialization.json.longOrNull
import org.multipaz.cbor.Bstr
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.CborArray
import org.multipaz.cbor.CborDouble
import org.multipaz.cbor.CborFloat
import org.multipaz.cbor.CborMap
import org.multipaz.cbor.DataItem
import org.multipaz.cbor.IndefLengthBstr
import org.multipaz.cbor.IndefLengthTstr
import org.multipaz.cbor.Nint
import org.multipaz.cbor.RawCbor
import org.multipaz.cbor.Simple
import org.multipaz.cbor.Tagged
import org.multipaz.cbor.Tstr
import org.multipaz.cbor.Uint
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.time.ExperimentalTime


@OptIn(ExperimentalEncodingApi::class)
@Serializable
data class Jwt(val compactString: String) {
    companion object {
        val base64 = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT)

        @OptIn(ExperimentalEncodingApi::class)
        fun create(
            publicKey: EllipticCurvePublicKey,
            payload: Map<String, JsonElement>,
            signingFunction: (ByteArray) -> ByteArray
        ): String {

            val header = Json.encodeToString(publicKey).encodeToByteArray()
            val headerB64 = base64.encode(header)

            val body = Json.encodeToString(payload).encodeToByteArray()
            val bodyB64 = base64.encode(body)

            val plainSignature = "$headerB64.$bodyB64".encodeToByteArray()
            val signature = signingFunction(plainSignature)
            val signatureB64 = base64.encode(signature)

            return "$headerB64.$bodyB64.$signatureB64"
        }
    }

    /**
     * Helper method to get the decoded header
     */
    val header: Map<String, *> by lazy {
        val headerB64 = compactString.split(".")[0]
        val header = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT).decode(headerB64)
        Json.decodeFromString<JsonObject>(header.decodeToString()).toNativeTypes() as Map<String, *>
    }

    /**
     * Helper method to get the decoded header
     */
    val signature: String by lazy {
        val headerBase64 = compactString.split(".")[2]
        Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT).decode(headerBase64)
            .decodeToString()
    }


    val body: JsonObject by lazy {
        val parts = compactString.split(".")
        val body = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT).decode(parts[1])
        Json.decodeFromString<JsonObject>(body.decodeToString())
    }

    val payload: JsonObject by lazy { body["payload"]!!.jsonObject }

    val name: String by lazy {
        body["credential"]!!.jsonObject["name"]!!.jsonPrimitive.content
    }

    val source: String by lazy {
        body["credential"]!!.jsonObject["source"]!!.jsonPrimitive.content
    }

    val value: Any? by lazy {
        try {
            body["credential"]!!.jsonObject["value"]?.toNativeTypes()
        } catch (e: Exception) {
            Logger.info("Exception thrown getting value. $e")
            null
        }
    }

    /**
     * When the JWT expires, seconds since epoch
     */
    val expires: Long by lazy {
        val exp = body["exp"]!!
        exp.jsonPrimitive.double.toLong()
    }

    override fun toString() = compactString
}


internal fun JsonElement.toNativeTypes(): Any? {
    return when (this) {
        is JsonPrimitive -> {
            when {
                this.isString -> this.jsonPrimitive.content
                this.intOrNull != null -> this.jsonPrimitive.int
                this.longOrNull != null -> this.jsonPrimitive.long
                this.booleanOrNull != null -> this.jsonPrimitive.boolean
                this.doubleOrNull != null -> this.jsonPrimitive.double
                else -> null
            }
        }

        is JsonObject -> return this.mapValues {
            it.value.toNativeTypes()
        }

        is JsonArray -> return this.map {
            it.toNativeTypes()
        }
    }

}

/**
 * Converts a CBOR DataItem to native Kotlin types.
 *
 * Purpose: Transforms CBOR data structures into standard Kotlin types for easier
 * interoperability with non-CBOR-aware code.
 *
 * Mapping:
 * - Bstr → ByteArray
 * - Tstr → String
 * - Uint/Nint → Long (to handle full CBOR integer range safely)
 * - CborDouble → Double
 * - CborFloat → Float
 * - CborArray → List<Any?>
 * - CborMap → Map<Any?, Any?> (keys preserved as native types)
 * - Simple(true/false) → Boolean
 * - Simple(null) → null
 * - Tagged → unwraps to inner value (tag number discarded)
 * - IndefLengthBstr → ByteArray (chunks combined)
 * - IndefLengthTstr → String (chunks combined)
 * - RawCbor → decoded and converted recursively
 *
 * Assumptions:
 * - Callers accept that tag semantics are lost during conversion
 * - Map key uniqueness is preserved from source DataItem
 * - Other Simple values (undefined, reserved) return null
 *
 * @return Native Kotlin representation, or null for null/undefined/unrepresentable values
 */
internal fun DataItem.toNativeTypes(): Any? {
    return when (this) {
        is Bstr -> value.copyOf() // Defensive copy to prevent mutation of internal state

        is Tstr -> value

        is Uint -> value.toLong()

        is Nint -> -value.toLong()

        is CborDouble -> value

        is CborFloat -> value

        is CborArray -> items.map { it.toNativeTypes() }

        is CborMap -> items.entries.associate { (key, value) ->
            key.toNativeTypes() to value.toNativeTypes()
        }

        is Simple -> when (value) {
            Simple.TRUE.value -> true
            Simple.FALSE.value -> false
            Simple.NULL.value -> null
            else -> null // Undefined and other simple values mapped to null
        }

        is Tagged -> taggedItem.toNativeTypes() // Unwrap tagged value, discard tag

        is IndefLengthBstr -> {
            // Combine all chunks into single ByteArray
            val totalSize = chunks.sumOf { it.size }
            val combined = ByteArray(totalSize)
            var offset = 0
            for (chunk in chunks) {
                chunk.copyInto(combined, offset)
                offset += chunk.size
            }
            combined
        }

        is IndefLengthTstr -> chunks.joinToString(separator = "")

        is RawCbor -> Cbor.decode(encodedCbor).toNativeTypes()
        else -> null // Fallback for any unhandled DataItem types
    }
}

/**
 * Converts native Kotlin types to JsonElement.
 *
 * This is the inverse of toNativeTypes() - it takes native Kotlin types
 * and converts them back to kotlinx.serialization JsonElement for JSON representation.
 *
 * Mapping:
 * - String → JsonPrimitive
 * - Number (Int, Long, Float, Double) → JsonPrimitive
 * - Boolean → JsonPrimitive
 * - null → JsonNull
 * - ByteArray → JsonPrimitive (base64 encoded)
 * - List<*> → JsonArray
 * - Map<*, *> → JsonObject (keys converted to strings)
 */
fun Any?.toJsonElement(): JsonElement {
    return when (this) {
        null -> JsonNull
        is String -> JsonPrimitive(this)
        is Number -> JsonPrimitive(this)
        is Boolean -> JsonPrimitive(this)
        is ByteArray -> JsonPrimitive(kotlin.io.encoding.Base64.encode(this))
        is List<*> -> JsonArray(this.map { it.toJsonElement() })
        is Map<*, *> -> JsonObject(this.entries.associate { (k, v) ->
            k.toString() to v.toJsonElement()
        })
        else -> JsonPrimitive(this.toString())
    }
}