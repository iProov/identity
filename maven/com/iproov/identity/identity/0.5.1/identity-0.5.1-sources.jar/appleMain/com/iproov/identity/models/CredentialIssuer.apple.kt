package com.iproov.identity.models

val CredentialIssuer.raw
    get() = raw.toNativeTypes()