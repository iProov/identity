package com.iproov.identity.api

import platform.UIKit.UIDevice

actual fun getUserAgent(): UserAgent = UserAgent(
    sdkVersion = "0.5.0",
    operatingSystem = "iOS",
    operatingSystemVersion = UIDevice.currentDevice.systemVersion,
    deviceModel = UIDevice.currentDevice.model
)
