package com.iproov.identity.attestation

import com.iproov.identity.api.ApiException
import com.iproov.identity.api.IdentityPlatformInterface
import kotlin.coroutines.cancellation.CancellationException


class AttestationNotSupportedException() : Exception("This device doesn't support attestation")
class AttestationKeyGenerationException(message: String) : Exception(message)
class AttestationException(message: String) : Exception(message)

internal interface AttestationService {
    @Throws(
        ApiException::class,
        CancellationException::class,
        AttestationNotSupportedException::class,
        AttestationKeyGenerationException::class,
        AttestationException::class,
        Exception::class
    )
    suspend fun getAttestationToken(): String
}

/**
 * This implementation of the attestation service allows a non-attestable device
 * to use the DEV environment such as a simulator, emulator or CLI.
 */
class SimplePasswordAttestationService : AttestationService {

    companion object {
        const val SIMPLE_PASSWORD = "sspba:HYbv00kS4StgVZm"
    }

    override suspend fun getAttestationToken(): String = SIMPLE_PASSWORD
}

/**
 * [SimplePasswordAttestationService] plus the server-side precondition it depends on, shared by the
 * simulator (iOS) and emulator (Android) paths.
 *
 * The server's `attestation_token` branch resolves a challenge it cached under
 * `(wid, sha256(signingkey), flavor)` and consumes it one-shot. With no cached entry it raises its
 * generic wallet error, which reaches the client as recovery code 9414 ("Wipe identity") and a
 * message blaming the wallet key — so the [getChallenge] call below is required, not optional, and
 * must be signed by the same key that then registers. This mirrors `Wallet.register()` in the
 * Python credential SDK, which also fetches a challenge immediately before registering.
 *
 * Note this priming cannot be hoisted into [com.iproov.identity.Wallet.register]: the real
 * attestation services fetch their own challenge while building an attestation nonce, and a second
 * call would overwrite the cached entry under the same key and break them.
 */
internal class PrimedSimplePasswordAttestationService(
    private val identityPlatformInterface: IdentityPlatformInterface,
) : AttestationService {

    override suspend fun getAttestationToken(): String {
        identityPlatformInterface.getChallenge(null)
        return SimplePasswordAttestationService.SIMPLE_PASSWORD
    }
}