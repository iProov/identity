package com.iproov.identity.attestation

import android.content.Context
import com.google.android.gms.common.util.Base64Utils
import com.google.android.gms.common.util.Hex
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import com.iproov.identity.KeyPairFactory
import com.iproov.identity.api.IdentityPlatformInterface
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

internal class AndroidAttestationService(
    private val identityPlatformInterface: IdentityPlatformInterface,
    private val keyPairFactory: KeyPairFactory,
    private val context: Context,
) : AttestationService {


    private val keyPair get() = keyPairFactory()

    companion object {
        const val GOOGLE_CLOUD_PROJECT_ID = 10923755181
    }

    override suspend fun getAttestationToken(): String {
        val challenge = identityPlatformInterface.getChallenge(null).challenge!!
        val publicKey = keyPair.getPublicKey()

        return getIntegrityToken(challenge, publicKey)
    }

    private suspend fun getIntegrityToken(challenge: ByteArray, publicKey: ByteArray): String {
        val challengeHex = Hex.bytesToStringLowercase(challenge)
        val publicKeyHashBase64Encoded = Base64Utils.encodeUrlSafeNoPadding(hash(publicKey))

        val hash = hash((challengeHex + publicKeyHashBase64Encoded).toByteArray())
        val nonce = Hex.bytesToStringLowercase(hash)

        val integrityManager = IntegrityManagerFactory.create(context)
        val integrityTokenResponse = integrityManager.requestIntegrityToken(
            IntegrityTokenRequest.builder()
                .setCloudProjectNumber(GOOGLE_CLOUD_PROJECT_ID)
                .setNonce(nonce)
                .build()
        )

        return integrityTokenResponse.await().token()
    }

}

private fun hash(data: ByteArray): ByteArray {
    val digest = MessageDigest.getInstance("SHA-256")
    return digest.digest(data)
}
