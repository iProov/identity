package com.iproov.identity.models

import com.iproov.identity.models.VerificationEvent
import com.iproov.identity.WalletFactory
import com.iproov.identity.WalletNotRegisteredException
import com.iproov.identity.api.ApiException
import com.iproov.kmp.api.IproovOptions
import kotlinx.coroutines.flow.Flow
import kotlin.coroutines.cancellation.CancellationException


open class LegacyCredential(
    val source: String,
    val claims: List<Claim>
) {
    companion object Companion {
        private val prefixToType = mapOf<String, (String, List<Claim>) -> LegacyCredential>(
            "iddoc" to { source, claims -> IdentityCredential.fromClaims(source, claims) },
            "sms" to { source, claims -> UriCredential.PhoneNumber(source, claims) },
            "mailto" to { source, claims -> UriCredential.EmailAddress(source, claims) },
        )

        fun fromClaims(source: String, claims: List<Claim>): LegacyCredential =
            prefixToType[source.substringBefore(":")]?.invoke(source, claims) ?: LegacyCredential(
                source,
                claims
            )
    }

    suspend fun delete() = WalletFactory.instance!!.deleteCredential(this)

    /**
     * Helper function to retrieve and cast a specific claim's value.
     * @param name The full name of the claim.
     * @return The claim's value cast to type T, or null if not found or type mismatch.
     */
    protected inline fun <reified T> getClaimValue(name: String): T? {
        return claims.find { it.name == name }?.value as? T
    }

    override fun equals(other: Any?): Boolean = other is LegacyCredential && other.source == source

    sealed class IdentityCredential(source: String, claims: List<Claim>) :
        LegacyCredential(source, claims) {

        companion object {
            private const val DTC_CLAIM_NAME = "com.svipe:dtc"
            private const val MRZ_CLAIM_NAME = "com.svipe:document_mrz"

            fun fromClaims(source: String, claims: List<Claim>): IdentityCredential = when {
                claims.any { it.name == DTC_CLAIM_NAME } && claims.any { it.name == MRZ_CLAIM_NAME } -> {
                    Mrtd(source, claims)
                }

                else -> Reference(source, claims)
            }
        }

        /**
         * Represents a machine readable travel document
         *
         * Must contain a DTC claim & MRZ claim
         */
        class Mrtd(source: String, claims: List<Claim>) : IdentityCredential(source, claims) {

            @Throws(
                WalletNotRegisteredException::class,
                ApiException::class,
                CancellationException::class
            )
            fun verifyFace(
                loginRequest: LoginRequest? = null,
                options: IproovOptions? = null
            ): Flow<VerificationEvent> =
                WalletFactory.instance!!.addFaceVerification(this, loginRequest, options)

            val dtc: Claim by lazy {
                claims.first { it.name == DTC_CLAIM_NAME }
            }

            val mrz: Claim by lazy {
                claims.first { it.name == MRZ_CLAIM_NAME }
            }
        }

        /**
         * Represents a reference to a digital identity
         *
         * Must contain a reference claim
         */
        class Reference(source: String, claims: List<Claim>) : IdentityCredential(source, claims)
    }

    sealed class UriCredential(source: String, claims: List<Claim>) :
        LegacyCredential(source, claims) {

        val url: String get() = source

        val value: String get() = url.substringAfter(":")

        class PhoneNumber(source: String, claims: List<Claim>) : UriCredential(source, claims)

        class EmailAddress(source: String, claims: List<Claim>) : UriCredential(source, claims)
    }

    override fun toString(): String {
        return "Credential(source='$source', claims=$claims)"
    }
}