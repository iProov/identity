package com.iproov.identity.models

/**
 * Apple-specific extensions for SdJwt that convert
 * kotlinx.serialization types to native Swift-compatible types.
 */

/**
 * Get the header as a native Swift dictionary.
 */
val SdJwt.headerNative: Map<String, Any?>
    get() = header.toMap().mapValues { it.value.toNativeTypes() }

/**
 * Get the payload as a native Swift dictionary.
 */
val SdJwt.payloadNative: Map<String, Any?>
    get() = payload.toMap().mapValues { it.value.toNativeTypes() }

/**
 * Get the confirmation key (cnf) as a native Swift dictionary.
 */
val SdJwt.confirmationKeyNative: Map<String, Any?>?
    get() = confirmationKey?.toMap()?.mapValues { it.value.toNativeTypes() }

/**
 * Get all claims resolved with disclosures as a native Swift dictionary.
 */
fun SdJwt.getAllClaimsNative(): Map<String, Any?> =
    getAllClaims().toMap().mapValues { it.value.toNativeTypes() }

/**
 * Get the claim value as a native Swift type.
 */
val Disclosure.claimValueNative: Any?
    get() = claimValue.toNativeTypes()
