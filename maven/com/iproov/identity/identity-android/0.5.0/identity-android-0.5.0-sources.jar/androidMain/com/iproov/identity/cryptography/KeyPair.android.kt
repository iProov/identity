package com.iproov.identity.cryptography

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.hardware.fingerprint.FingerprintManager
import android.os.Build
import android.os.CancellationSignal
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.iproov.identity.AppContext
import kotlinx.coroutines.suspendCancellableCoroutine
import java.math.BigInteger
import java.security.interfaces.ECPublicKey
import java.security.spec.ECParameterSpec
import java.util.Base64
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import com.iproov.identity.cryptography.KeyPair as SdkKeyPair


class AndroidDefaultKeyPair(
    private val context: Context,
    private val alias: String,
    private val accessPolicy: KeyPairAccessPolicy,
) : EncryptionKey, AttestableKeyPair {

    private var useStrongBox: Boolean = false

    /**
     * Creates a key pair that requests StrongBox backing where available.
     *
     * Kept as a secondary constructor so the original three-argument JVM constructor remains
     * binary-compatible for existing SDK consumers.
     */
    constructor(
        context: Context,
        alias: String,
        accessPolicy: KeyPairAccessPolicy,
        useStrongBox: Boolean,
    ) : this(context, alias, accessPolicy) {
        this.useStrongBox = useStrongBox
    }

    private val keyPair: AndroidKeystoreKeyPair get() = AndroidKeystoreKeyPair(context, alias, accessPolicy, useStrongBox)

    @Throws(Exception::class)
    override fun getJwk(): EllipticCurvePublicKey = keyPair.getJwk()

    @Throws(Exception::class)
    override fun getPublicKey(): ByteArray = keyPair.getPublicKey()

    @Throws(Exception::class)
    override fun getKeySecurityLevel(): String = keyPair.getKeySecurityLevel()

    @Throws(Exception::class)
    override fun sign(data: ByteArray): ByteArray = keyPair.sign(data)

    @Throws(Exception::class)
    override fun reset() = keyPair.reset()

    @Throws(Exception::class)
    override fun encrypt(data: ByteArray): ByteArray = keyPair.encrypt(data)

    @Throws(Exception::class)
    override fun decrypt(data: ByteArray): ByteArray = keyPair.decrypt(data)

    /**
     * Returns the platform certificate objects, preserving the Android API exposed by earlier SDK
     * versions. Multiplatform attestation uses [getKeyAttestationEvidence].
     */
    fun getAttestationCertificateChain(): Array<java.security.cert.Certificate>? =
        keyPair.getAttestationCertificateChain()

    @Throws(Exception::class)
    fun getAttestationCertificateChainDer(): List<ByteArray> =
        keyPair.getAttestationCertificateChain()?.map { it.encoded }.orEmpty()

    @Throws(Exception::class)
    fun getUserAuthenticationLevel(): String = when (accessPolicy) {
        is KeyPairAccessPolicy.CurrentBiometrics -> "iso_18045_high"
        is KeyPairAccessPolicy.AnyBiometrics -> "iso_18045_moderate"
        is KeyPairAccessPolicy.UserPresent -> "iso_18045_basic"
        is KeyPairAccessPolicy.DeviceUnlocked -> "iso_18045_basic"
        else -> "iso_18045_basic"
    }

    @Throws(Exception::class)
    override fun getKeyAttestationEvidence(): KeyAttestationEvidence? {
        val platformCertificateChain = getAttestationCertificateChainDer()
        if (platformCertificateChain.isEmpty()) return null
        val certificatesForX5c = if (platformCertificateChain.size > 1) {
            platformCertificateChain.dropLast(1)
        } else {
            platformCertificateChain
        }
        val securityLevel = getKeySecurityLevel()

        return KeyAttestationEvidence(
            certificateChainDer = certificatesForX5c,
            keyStorageLevel = mapSecurityLevelToIso18045(securityLevel),
            userAuthenticationLevel = getUserAuthenticationLevel(),
        )
    }

    suspend fun authenticate(
        activity: Activity,
        title: String = "Authentication Required",
        subtitle: String = "Please authenticate to access your key",
        cancellationSignal: CancellationSignal = CancellationSignal()
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            authenticateApi28(activity, title, subtitle, cancellationSignal)
        } else {
            // Fallback for API 26-27
            authenticateLegacy(activity, title, subtitle, cancellationSignal)
        }
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private suspend fun authenticateApi28(
        activity: Activity,
        title: String,
        subtitle: String,
        cancellationSignal: CancellationSignal
    ) = suspendCancellableCoroutine { cont ->
        val executor = ContextCompat.getMainExecutor(activity)

        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                if (cont.isActive) cont.resume(Unit)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                if (cont.isActive) {
                    // Check for User Cancellation (Back button, tapping outside) or Negative Button (Cancel)
                    if (errorCode == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED) {
                        cont.resumeWithException(KeyPairAuthenticationCanceled())
                    } else {
                        cont.resumeWithException(KeyPairAuthenticationError(errString.toString()))
                    }
                }
            }

        }

        val builder = BiometricPrompt.Builder(activity)
            .setTitle(accessPolicy.display.title)

        if (accessPolicy.display.subtitle != null) builder.setSubtitle(accessPolicy.display.subtitle)
        if (Build.VERSION.SDK_INT >= 29) builder.setConfirmationRequired(accessPolicy.display.confirmationRequired)
        if (accessPolicy.display.description != null) builder.setDescription(accessPolicy.display.description)

        var isDeviceCredentialAllowed = false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // API 30+: Use setAllowedAuthenticators
            builder.setAllowedAuthenticators(accessPolicy.allowedAuthenticators)
            isDeviceCredentialAllowed =
                (accessPolicy.allowedAuthenticators and BiometricManager.Authenticators.DEVICE_CREDENTIAL) != 0
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // API 29: setDeviceCredentialAllowed is available.
            // API 28: BiometricPrompt does not support device credential (PIN/Pattern/Password) directly in the prompt.
            // Note: 0x8000 is the value for DEVICE_CREDENTIAL.
            if ((accessPolicy.allowedAuthenticators and 0x8000) != 0) {
                isDeviceCredentialAllowed = true
                @Suppress("DEPRECATION")
                builder.setDeviceCredentialAllowed(true)
            }
        }

        if (!isDeviceCredentialAllowed) {
            builder.setNegativeButton("Cancel", executor) { _, _ ->
                // This triggers BIOMETRIC_ERROR_NEGATIVE_BUTTON in the callback
                cont.cancel()
            }
        }

        val prompt = builder.build()
        prompt.authenticate(cancellationSignal, executor, callback)

        cont.invokeOnCancellation {
            cancellationSignal.cancel()
        }
    }

    /**
     * Legacy authentication for API 26-27.
     * Attempts to use FingerprintManager + Custom Dialog.
     * If Fingerprint is unavailable, falls back to KeyguardManager (Device Credentials) if applicable.
     */
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private suspend fun authenticateLegacy(
        activity: Activity,
        title: String,
        subtitle: String,
        cancellationSignal: CancellationSignal
    ) = suspendCancellableCoroutine<Unit> { cont ->

        val fingerprintManager = activity.getSystemService(Context.FINGERPRINT_SERVICE) as? FingerprintManager
        val isFingerprintAvailable =
            fingerprintManager?.isHardwareDetected == true && fingerprintManager.hasEnrolledFingerprints()

        // If we are strictly checking Biometrics and they aren't available, fail fast.
        if (!isFingerprintAvailable && accessPolicy !is KeyPairAccessPolicy.DeviceUnlocked) {
            cont.resumeWithException(KeyPairAuthenticationError("Biometrics not available or enrolled on this device (API ${Build.VERSION.SDK_INT})."))
            return@suspendCancellableCoroutine
        }

        if (isFingerprintAvailable) {
            // Option 1: Use Fingerprint Manager with a Dialog
            val dialog = AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage("$subtitle\n\nPlace your finger on the sensor.")
                .setNegativeButton("Cancel") { _, _ ->
                    cancellationSignal.cancel()
                    if (cont.isActive) cont.resumeWithException(KeyPairAuthenticationCanceled())
                }
                .setOnCancelListener {
                    cancellationSignal.cancel()
                    if (cont.isActive) cont.resumeWithException(KeyPairAuthenticationCanceled())
                }
                .create()

            dialog.show()

            val callback = object : FingerprintManager.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: FingerprintManager.AuthenticationResult?) {
                    if (dialog.isShowing) dialog.dismiss()
                    if (cont.isActive) cont.resume(Unit)
                }


                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    // Always dismiss dialog on error
                    if (dialog.isShowing) dialog.dismiss()

                    if (cont.isActive) {
                        if (errorCode == FingerprintManager.FINGERPRINT_ERROR_USER_CANCELED ||
                            errorCode == FingerprintManager.FINGERPRINT_ERROR_CANCELED
                        ) {
                            cont.resumeWithException(KeyPairAuthenticationCanceled())
                        } else {
                            cont.resumeWithException(KeyPairAuthenticationError(errString.toString()))
                        }
                    }
                }

                override fun onAuthenticationFailed() {
                    // Fingerprint read but not recognized. Keep dialog open, maybe shake UI or update text.
                    // For simplicity in this snippet, we just log or update message if custom view used.
                }
            }

            fingerprintManager.authenticate(null, cancellationSignal, 0, callback, null)

            cont.invokeOnCancellation {
                cancellationSignal.cancel()
                if (dialog.isShowing) dialog.dismiss()
            }

        } else {
            // Option 2: Fallback to Keyguard (PIN/Pattern) for DeviceUnlocked policy
            // Note: This launches a new Activity. We cannot easily wait for the result in a suspend function
            // without hooking into onActivityResult.
            // Since we can't modify the Activity here, we attempt to launch it, but we can't `resume` automatically.
            // The user will have to re-trigger the action after unlocking.

            val keyguardManager = activity.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            val intent = keyguardManager.createConfirmDeviceCredentialIntent(title, subtitle)

            if (intent != null) {
                activity.startActivity(intent)
                // We have to throw to break the flow, as we can't await the result here.
                // The user will see the PIN screen, unlock, and return to the app.
                if (cont.isActive) {
                    cont.resumeWithException(KeyPairAuthenticationError("Please authenticate with device credentials and try again."))
                }
            } else {
                if (cont.isActive) cont.resumeWithException(KeyPairAuthenticationError("Secure lock screen not set up."))
            }
        }
    }
}

fun ecPublicKeyToJwk(publicKey: ECPublicKey): OnDeviceKeyPairJwk {
    // Extract curve parameters
    val params = publicKey.params
    val curveName = getCurveName(params)

    // Extract the public point coordinates
    val point = publicKey.w
    val affineX = point.affineX
    val affineY = point.affineY

    // Base64URL encode the parameters (JWK requires URL-safe encoding without padding)
    val encoder = Base64.getUrlEncoder().withoutPadding()
    val x = encoder.encodeToString(toUnsignedBytes(affineX, 32))
    val y = encoder.encodeToString(toUnsignedBytes(affineY, 32))

    // Construct the JWK
    val jwk = OnDeviceKeyPairJwk(
        curveName,
        "EC",
        x,
        y,
    )

    return jwk
}

// Helper function to get the curve name
fun getCurveName(params: ECParameterSpec): String {
    // Map the parameters to the standard curve names
    return when (params.order.bitLength()) {
        256 -> "P-256"
        384 -> "P-384"
        521 -> "P-521"
        else -> throw IllegalArgumentException("Unsupported curve")
    }
}

// Helper function to convert BigInteger to unsigned byte array with optional padding
fun toUnsignedBytes(value: BigInteger, length: Int = 0): ByteArray {
    var bytes = value.toByteArray()
    if (bytes.isNotEmpty() && bytes[0] == 0.toByte()) {
        bytes = bytes.sliceArray(1 until bytes.size)
    }

    if (length > 0) {
        if (bytes.size == length) return bytes
        if (bytes.size > length) return bytes.copyOfRange(bytes.size - length, bytes.size)
        // Pad with leading zeros
        val padded = ByteArray(length)
        System.arraycopy(bytes, 0, padded, length - bytes.size, bytes.size)
        return padded
    }
    return bytes
}

actual fun getDeviceBoundKeyPair(policy: KeyPairAccessPolicy, alias: String): SdkKeyPair =
    AndroidDefaultKeyPair(AppContext.get(), alias, policy)

/**
 * Maps [KeyPair.getKeySecurityLevel] to the ISO 18045 level for OID4VCI key attestation. Non-obvious
 * cases: API 26-30 hardware reports "secureElement" and API 31+ can report "UNKNOWN_SECURE" — both are
 * hardware-backed and map to moderate, not basic. Standalone + unit-tested so a level can't be
 * silently dropped again.
 */
internal fun mapSecurityLevelToIso18045(securityLevel: String): String = when {
    securityLevel.contains("STRONGBOX", ignoreCase = true) -> "iso_18045_high"
    securityLevel.contains("TRUSTED_ENVIRONMENT", ignoreCase = true) -> "iso_18045_moderate"
    securityLevel.contains("secureElement", ignoreCase = true) -> "iso_18045_moderate"
    securityLevel.contains("UNKNOWN_SECURE", ignoreCase = true) -> "iso_18045_moderate"
    else -> "iso_18045_basic"
}
