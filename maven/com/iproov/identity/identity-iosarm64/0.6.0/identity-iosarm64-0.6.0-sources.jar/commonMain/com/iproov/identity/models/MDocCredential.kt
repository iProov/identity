package com.iproov.identity.models

import io.ktor.util.sha1
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement

/**
 * Simplified representation of the usable MDoc data.
 */
@OptIn(ExperimentalObjCRefinement::class)
class MDocCredential(
    override val raw: String,
    override val body: JsonObject,
    val docType: String,
    val nameSpaces: Map<String, Map<String, Any?>>,
    val onCheckVerificationStatus: suspend (Credential) -> VerificationSummary,
    val validUntil: Long?, //MSO ValidityInfo.validUntil as epoch milliseconds - Null when built without an MSO
) : Credential {
    /** 0.5.2 signature: no MSO expiry. */
    constructor(
        raw: String,
        body: JsonObject,
        docType: String,
        nameSpaces: Map<String, Map<String, Any?>>,
        onCheckVerificationStatus: suspend (Credential) -> VerificationSummary,
    ) : this(raw, body, docType, nameSpaces, onCheckVerificationStatus, null)

    override val format = CredentialFormat.MDOC

    override val uuid: String by lazy {
        sha1(raw.encodeToByteArray()).decodeToString()
    }

    /**
     * For credentials built by [com.iproov.identity.persistence.MDocCredentialFactory], checked under the
     * wallet's [com.iproov.identity.TrustConfiguration]: `issuer_signature` or `issuer_trust` when the MSO's
     * signature, digests or issuer fail ISO 18013-5 §9.3.1, `expiry` or `valid_from` outside the MSO
     * validity, and otherwise a `status_list` result when the MSO carries a status reference. The status
     * list is only fetched for a credential that passes its own checks (Token Status List §8.3).
     */
    override suspend fun getVerificationSummary(): VerificationSummary = onCheckVerificationStatus(this)
}