@file:Suppress("DEPRECATION")

package com.iproov.identity

import com.iproov.identity.api.ApiException
import com.iproov.identity.api.DefaultOID4VCIOrchestrator
import com.iproov.identity.api.DefaultOID4VPOrchestrator
import com.iproov.identity.api.DocumentChallenge
import com.iproov.identity.api.DocumentChallengeResponder
import com.iproov.identity.api.IdentityPlatformInterface
import com.iproov.identity.api.OID4VCIOrchestrator
import com.iproov.identity.api.OID4VPOrchestrator
import com.iproov.identity.api.Responses
import com.iproov.identity.api.UriCredentialChallenge
import com.iproov.identity.api.UriCredentialChallengeResponder
import com.iproov.identity.attestation.AttestationService
import com.iproov.identity.cryptography.JWEFactory
import com.iproov.identity.cryptography.KeyPair
import com.iproov.identity.cryptography.getPlatformJWEFactory
import com.iproov.identity.dcapi.CredentialRegistrationInfo
import com.iproov.identity.dcapi.DCApiMatchResult
import com.iproov.identity.dcapi.DCApiOrchestrator
import com.iproov.identity.dcapi.DCApiResult
import com.iproov.identity.dcapi.DefaultDCApiOrchestrator
import com.iproov.identity.dcapi.createPlatformDCApiRegistrar
import com.iproov.identity.models.ActiveAuthentication
import com.iproov.identity.models.BacKey
import com.iproov.identity.models.Claim
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialSummary
import com.iproov.identity.models.Format
import com.iproov.identity.models.Gender
import com.iproov.identity.models.Jwt
import com.iproov.identity.models.LegacyCredential
import com.iproov.identity.models.LoginRequest
import com.iproov.identity.models.MrtdData
import com.iproov.identity.models.RespondableCredentialOffer
import com.iproov.identity.models.RespondableLoginRequest
import com.iproov.identity.models.RespondablePresentationRequest
import com.iproov.identity.models.ReverificationRequest
import com.iproov.identity.models.VerificationEvent
import com.iproov.identity.models.VerificationMethod
import com.iproov.identity.persistence.LocalStorage
import com.iproov.identity.persistence.Repository
import com.iproov.identity.proximity.DefaultProximityOrchestrator
import com.iproov.identity.proximity.DocumentRequest
import com.iproov.identity.proximity.ProximityConfig
import com.iproov.identity.proximity.ProximityNotSupportedException
import com.iproov.identity.proximity.ProximityOrchestrator
import com.iproov.identity.proximity.ProximityPresentationSession
import com.iproov.identity.proximity.ProximityRetrievalSession
import com.iproov.identity.proximity.ReaderSigningData
import com.iproov.kmp.api.Iproov
import com.iproov.kmp.api.IproovOptions
import com.iproov.kmp.api.IproovState
import io.ktor.http.HttpStatusCode
import io.ktor.http.URLParserException
import io.ktor.http.Url
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC
import kotlin.random.Random

class AppIdNotSupportedException() :
    Exception("This app has not been authorized to use the iProov Identity Platform. Please provide your App ID to our support team to enable access.")

class CredentialNotFoundException(id: String) : Exception("Credential with id: $id not found.")
class InvalidOpenIdServerConfiguration(message: String) : Exception(message)
class UnsupportedVerificationMethodException(message: String) : Exception(message)
class WalletNotRegisteredException : Exception("Your wallet has not been registered.")
class WalletAlreadyRegisteredException : Exception("You have already registered your wallet.")
class CredentialAlreadyExistsException(source: String) :
    Exception("Claims with source: $source already exist")

class RequiredClaimNotPresent(val claimName: String, message: String) : Exception(message)
class NoSupportedCredentialOffers() :
    Exception("Identity Platform didn't return any supported credential offers.")

internal typealias KeyPairFactory = () -> KeyPair

@OptIn(ExperimentalObjCRefinement::class)
class Wallet internal constructor(
    private val attestationService: AttestationService,
    val identityPlatformInterface: IdentityPlatformInterface,
    private val localStorage: LocalStorage,
    val repository: Repository,
    private val getKeyPair: KeyPairFactory,
    private val jweFactory: JWEFactory = getPlatformJWEFactory(),
    private val oid4vpOrchestrator: OID4VPOrchestrator = DefaultOID4VPOrchestrator(
        identityPlatformInterface.apiClient,
        repository = repository,
        keyPairFactory = getKeyPair,
        jweFactory = jweFactory,
    ),
    private val oid4vciOrchestrator: OID4VCIOrchestrator = DefaultOID4VCIOrchestrator(
        keyPairFactory = getKeyPair,
        repository = repository,
        networkClient = identityPlatformInterface.apiClient
    ),
    private val dcApiOrchestrator: DCApiOrchestrator = DefaultDCApiOrchestrator(
        repository = repository,
        keyPairFactory = getKeyPair,
        jweFactory = jweFactory,
        dcApiRegistrar = createPlatformDCApiRegistrar()
    ),
    private val proximityOrchestrator: ProximityOrchestrator = DefaultProximityOrchestrator()
) {
    companion object {
        const val DTC_CLAIM_NAME = "com.svipe:dtc"
    }

    private val keyPair: KeyPair get() = getKeyPair()

    @Throws(Exception::class)
    suspend fun register() {
        if (isRegistered()) throw WalletAlreadyRegisteredException()

        val attestationToken = attestationService.getAttestationToken()
        val jwts = try {
            identityPlatformInterface.registerWallet(attestationToken)
        } catch (e: ApiException.HttpError) {
            throw if (e.statusCode == HttpStatusCode.NotFound) AppIdNotSupportedException() else e
        }

        updateJwts(jwts)
        localStorage.setAttestationToken(attestationToken)
        getTranslations()
    }

    @Throws(Exception::class)
    suspend fun delete() {
        throwIfNotRegistered()

        try {
            identityPlatformInterface.deleteWallet()
        } catch (e: ApiException) {
            Logger.error("Unable to delete wallet: ${e.message}")
        } finally {
            destroy()
        }
    }

    @Throws(Exception::class)
    suspend fun destroy() {
        keyPair.reset()
        localStorage.deleteAll()
    }

    /**
     * Fetch all credentials stored issued to the wallet.
     */
    @Throws(Exception::class)
    suspend fun getCredentialMetadata(): List<CredentialMetadata> {
        throwIfNotRegistered()
        return repository.getCredentialMetadata()
    }

    /**
     * Fetch all credentials stored issued to the wallet.
     */
    @Throws(Exception::class)
    suspend fun getCredentials(): CredentialSummary = getCredentials(
        repository.getCredentialMetadata()
    )

    @Throws(Exception::class)
    suspend fun getCredential(metadata: CredentialMetadata): Credential {
        throwIfNotRegistered()
        val summary = repository.getCredential(metadata)
        return summary.credentials.values.firstOrNull() ?: throw Exception(
            summary.failures.values.first().error
        )
    }

    @Throws(Exception::class)
    suspend fun getCredentials(metadata: List<CredentialMetadata>): CredentialSummary {
        throwIfNotRegistered()
        return repository.getCredentials(metadata)
    }

    @Throws(Exception::class)
    suspend fun getPresentationRequest(uri: String): RespondablePresentationRequest {
        throwIfNotRegistered()
        return oid4vpOrchestrator.createPresentationRequest(uri)

    }

    /**
     * Retrieves a respondable credential offer over OID4VCI
     */
    @Throws(Exception::class)
    suspend fun addCredentialWithOffer(uri: String): RespondableCredentialOffer {
        throwIfNotRegistered()
        return oid4vciOrchestrator.addCredential(uri)
    }

    // ==================== DC API (Digital Credentials API) Methods ====================

    /**
     * Check if DC API (Digital Credentials API) is available on this platform.
     *
     * DC API is available on:
     * - Android 14+ (API 34) with CredentialManager
     * - iOS 26+ with IdentityDocumentServices framework
     *
     * On unsupported platforms, this returns false and DC API operations are no-ops.
     */
    fun isDCApiAvailable(): Boolean = dcApiOrchestrator.isAvailable()

    /**
     * Process a Digital Credentials API request from the OS credential manager.
     *
     * This is called when the wallet is invoked by the OS to handle a credential request
     * from a browser or native app using navigator.credentials.get() or equivalent API.
     *
     * @param requestJson The JSON request string from the DC API invocation
     * @return Result containing matching credentials or an error
     */
    @Throws(Exception::class)
    suspend fun processDCApiRequest(requestJson: String, callingOrigin: String): DCApiMatchResult {
        throwIfNotRegistered()
        return dcApiOrchestrator.processRequest(requestJson, callingOrigin)
    }

    /**
     * Build a DC API response for the selected credentials.
     *
     * After the user selects which credentials to present, call this method to
     * build the response to return to the browser/requester.
     *
     * @param matchResult The successful match result from processDCApiRequest
     * @param submission The user's credential selection
     * @return The response to return to the OS credential manager
     */
    @Throws(Exception::class)
    suspend fun buildDCApiResponse(
        matchResult: DCApiMatchResult.Success,
        submission: com.iproov.identity.persistence.CredentialSubmission
    ): DCApiResult {
        throwIfNotRegistered()
        return dcApiOrchestrator.buildResponse(matchResult, submission)
    }

    /**
     * Register a credential with the OS credential manager for DC API requests.
     *
     * This enables the credential to be discovered and presented when browsers or
     * apps request credentials via the Digital Credentials API.
     *
     * On platforms that don't support DC API (Android < 14, iOS < 26), this is a no-op.
     *
     * @param metadata The credential metadata to register
     */
    @Throws(Exception::class)
    suspend fun registerCredentialForDCApi(metadata: CredentialMetadata) {
        throwIfNotRegistered()
        dcApiOrchestrator.registerCredential(metadata)
    }

    /**
     * Register all credentials with the OS credential manager for DC API.
     * This replaces any existing registrations with the current credential set.
     * Call this on app startup to ensure all credentials are available for DC API requests.
     *
     * On platforms that don't support DC API (Android < 14, iOS < 26), this is a no-op.
     */
    @Throws(Exception::class)
    suspend fun registerAllCredentialsForDCApi() {
        throwIfNotRegistered()
        if (!isDCApiAvailable()) return

        val summary = getCredentials()
        val registrationInfos = summary.credentials.map { (metadata, credential) ->
            CredentialRegistrationInfo(metadata, credential)
        }
        dcApiOrchestrator.registerCredentials(registrationInfos)
    }

    /**
     * Unregister a credential from the OS credential manager.
     *
     * This removes the credential from DC API discovery. The credential itself
     * remains stored locally.
     *
     * On platforms that don't support DC API, this is a no-op.
     *
     * @param credentialId The ID of the credential to unregister
     */
    @Throws(Exception::class)
    suspend fun unregisterCredentialFromDCApi(credentialId: String) {
        throwIfNotRegistered()
        dcApiOrchestrator.unregisterCredential(credentialId)
    }

    /**
     * Check if a credential is registered with the OS credential manager for DC API requests.
     *
     * @param metadata The credential metadata to check
     * @return true if the credential is registered, false otherwise (including on unsupported platforms)
     */
    fun isCredentialRegisteredForDCApi(metadata: CredentialMetadata): Boolean {
        return dcApiOrchestrator.isCredentialRegistered(metadata.uuid)
    }

    /**
     * Check if a credential is registered with the OS credential manager for DC API requests.
     *
     * @param credentialId The ID of the credential to check
     * @return true if the credential is registered, false otherwise (including on unsupported platforms)
     */
    fun isCredentialRegisteredForDCApi(credentialId: String): Boolean {
        return dcApiOrchestrator.isCredentialRegistered(credentialId)
    }

    // ==================== End DC API Methods ====================

    // ==================== Proximity Methods ====================

    /**
     * The proximity orchestrator for ISO/IEC 18013-5 in-person presentation over
     * BLE and (when supported by the platform) NFC.
     *
     * Always non-null. Use [isProximityAvailable] — or the orchestrator's
     * [ProximityOrchestrator.isBleAvailable] / [ProximityOrchestrator.isNfcAvailable]
     * — to gate transport-specific calls so consumers don't receive a
     * [com.iproov.identity.proximity.BleEngagementUnavailableException] or
     * [com.iproov.identity.proximity.NfcEngagementUnavailableException] on
     * unsupported devices.
     */
    private val proximity: ProximityOrchestrator
        get() = proximityOrchestrator

    /**
     * Check if proximity (ISO 18013-5 BLE or NFC engagement) is available on
     * this platform.
     *
     * True when either BLE peripheral mode or NFC Host Card Emulation is
     * supported by the device. Equivalent to `proximity.isAvailable()`.
     */
    fun isProximityAvailable(): Boolean = proximityOrchestrator.isAvailable()

    suspend fun startProximityPresentation(
        config: ProximityConfig = ProximityConfig(),
    ): ProximityPresentationSession {
        throwIfNotRegistered()

        if (!proximityOrchestrator.isAvailable()) {
            throw ProximityNotSupportedException()
        }
        return ProximityPresentationSession(
            config = config,
            orchestrator = proximityOrchestrator,
            repository = repository,
            keyPair = keyPair
        )
    }

    fun startProximityRetrieval(
        uri: String,
        requestedDocuments: List<DocumentRequest>,
        createSigningData: (suspend () -> ReaderSigningData)? = null,
        config: ProximityConfig = ProximityConfig(),
    ): ProximityRetrievalSession {
        return ProximityRetrievalSession(
            uri = uri,
            requestedDocuments = requestedDocuments,
            createSigningData = createSigningData,
            orchestrator = proximityOrchestrator,
            config = config,
        )
    }

    // ==================== End Proximity Methods ====================

    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("getCredentials()")
    )
    @Throws(Exception::class)
    suspend fun getLegacyCredentials(): List<LegacyCredential> {
        throwIfNotRegistered()

        return repository.getAllCredentials()
    }

    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("getCredentials()")
    )
    @Throws(Exception::class)
    suspend fun getLegacyCredentials(source: String): LegacyCredential? {
        throwIfNotRegistered()

        val credentials = repository.getAllCredentials()
        return credentials.firstOrNull { credential -> credential.source == source }
    }


    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("getCredentials()")
    )
    @Throws(Exception::class)
    suspend fun getAllClaims(): List<Claim> {
        throwIfNotRegistered()
        return repository.getAllClaims()
    }

    @Throws(Exception::class)
    suspend fun createDemoMrtd(): MrtdData {
        throwIfNotRegistered()

        val gender = Gender.entries[Random.nextInt(Gender.entries.size)]

        return identityPlatformInterface.getDemo(gender, Format.BASE64)
    }

    @Throws(Exception::class)
    suspend fun addDocumentWithMrz(
        mrz: String, loginRequest: LoginRequest? = null,
        addLegacyCredential: Boolean = true,
    ): DocumentChallenge {
        val bacKey = BacKey.fromMrz(mrz)
        return addDocument(bacKey, loginRequest, addLegacyCredential)
    }

    /**
     * Add a document with fields
     * @param documentNumber
     * @param dateOfExpiry Expiration date of the document in DDMMYY format
     * @param dateOfBirth Date of birth on the document in DDMMYY format
     */
    @Throws(Exception::class)
    suspend fun addDocumentWithFields(
        documentNumber: String,
        dateOfBirth: String,
        dateOfExpiry: String,
        loginRequest: LoginRequest? = null,
        addLegacyCredential: Boolean = true,
    ): DocumentChallenge {
        val bacKey = BacKey.fromFields(documentNumber, dateOfBirth, dateOfExpiry)
        return addDocument(bacKey, loginRequest, addLegacyCredential)
    }

    /**
     * Add a document with reference
     * @param reference Reference to the identity
     */
    @OptIn(ExperimentalObjCRefinement::class)
    @Throws(Exception::class)
    @HiddenFromObjC
    fun addDocumentWithReference(
        reference: String,
        demoReferencePhoto: ByteArray? = null,
        loginRequest: LoginRequest? = null,
        options: IproovOptions? = null,
        addLegacyCredential: Boolean = true,
    ): Flow<VerificationEvent> {
        return verifyFace(
            target = reference,
            getVerificationMethod = { _, reverificationToken ->
                identityPlatformInterface.initDocReference(
                    reference,
                    reverificationToken,
                    demoReferencePhoto = demoReferencePhoto
                )
            },
            verifyFace = { token -> identityPlatformInterface.verifyReferenceDocument(token) },
            loginRequest = loginRequest,
            options = options,
            addLegacyCredential = addLegacyCredential
        )
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Throws(Exception::class)
    suspend fun getLoginRequest(uri: String, isNfcCapable: Boolean): RespondableLoginRequest {
        val url = try {
            Url(uri)
        } catch (e: URLParserException) {
            throw Exception("The URL provided is not a valid URL")
        }
        val responseUri = getLoginResponseUri(url);
        val code = url.segments[1]

        val presentationRequestJwt =
            identityPlatformInterface.getAuthRequest(responseUri, code, isNfcCapable)
        val translations = getTranslations()

        val request = LoginRequest(presentationRequestJwt, translations)
        val reverifications = request.acrs.map { ReverificationRequest.forAcr(it, request) }

        return RespondableLoginRequest.fromLoginRequest(
            loginRequest = request,
            reverifications,
            accept = @Throws(Exception::class) { jwts ->
                GlobalScope.async {
                    identityPlatformInterface.respondToAuthRequest(
                        responseUri,
                        request,
                        jwts,
                    )
                }
            },
            deny = @Throws(Exception::class) {
                GlobalScope.async {
                    identityPlatformInterface.respondToAuthRequest(
                        responseUri,
                        request,
                        emptyList()
                    )
                    return@async null
                }
            },
        )
    }

    @Throws(Exception::class)
    suspend fun deleteCredential(metadata: CredentialMetadata) {
        throwIfNotRegistered()
        repository.deleteCredential(metadata)
    }

    /**
     * Helper method for deleting a credential with and ID
     */
    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("deleteCredential(metadata)")
    )
    @Throws(Exception::class)
    suspend fun deleteCredential(source: String) {
        val credential = repository.getAllCredentials().find { it.source == source }
            ?: throw CredentialNotFoundException(source)
        deleteCredential(credential)
    }

    /**
     * Delete a credential from the wallet.
     */
    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("deleteCredential(metadata)")
    )
    @Throws(Exception::class)
    suspend fun deleteCredential(credential: LegacyCredential) {
        throwIfNotRegistered()
        repository.deleteJwts(credential.claims.map { it.jwt })
        // TOOD: Call API client to revoke credential from issuer.
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Throws(Exception::class)
    suspend fun addUriCredential(uri: String): UriCredentialChallenge {
        throwIfNotRegistered()

        val challenge = identityPlatformInterface.initUriCredential(uri)

        val responder = UriCredentialChallengeResponder @Throws(Exception::class) { token: String ->
            GlobalScope.async { verifyUriCredential(uri, token); null }
        }

        return UriCredentialChallenge(challenge, responder)
    }

    @Throws(Exception::class)
    suspend fun verifyUriCredential(uri: String, token: String) {
        throwIfNotRegistered()

        var verificationToken = token
        if (token.contains("/email/verify")) {
            verificationToken = token.split("/").last()
        }

        val jwts = identityPlatformInterface.verifyUriCredential(
            uri = uri,
            token = verificationToken,
        )

        updateJwts(jwts)
    }

    @Throws(Exception::class)
    private suspend fun getLoginResponseUri(uri: Url): String {
        val serverId = uri.segments[0]

        val openIdServers = identityPlatformInterface.getOidcServers()
        val openIdServer =
            openIdServers.firstOrNull { it["suffix"]?.jsonPrimitive?.content == "/$serverId/" }
                ?: throw InvalidOpenIdServerConfiguration("The OIDC server has not yet been configured for this base url.")

        val baseUrl = openIdServer["baseurl"]?.jsonPrimitive?.content
        val urlPath = openIdServer["urlpath"]?.jsonPrimitive?.content
        if (baseUrl !is String || urlPath !is String) {
            throw InvalidOpenIdServerConfiguration("both 'baseUrl' and 'urlpath' are expected to be present and of type String in OIDC server config")
        }

        return baseUrl + urlPath
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Throws(Exception::class)
    private suspend fun addDocument(
        bacKey: BacKey,
        loginRequest: LoginRequest? = null,
        addLegacyCredential: Boolean,
    ): DocumentChallenge {
        throwIfNotRegistered()

        val activeAuthentication = ActiveAuthentication.generateFromBacKey(bacKey)

        val challenge = identityPlatformInterface.initDoc(
            activeAuthentication.challenge,
            reverificationToken = loginRequest?.jwt?.compactString
        )

        val responder = DocumentChallengeResponder(
            usingMrtd = @Throws(Exception::class) { mrtd, accessControl, signature ->
                GlobalScope.async {
                    val response = identityPlatformInterface.verifyMrtd(
                        mrtd = mrtd,
                        challenge = challenge.challenge!!,
                        aaSignature = signature,
                        secret = activeAuthentication.secret,
                        accessControl = accessControl
                    )

                    // Legacy credential storage
                    if (addLegacyCredential) {
                        val jwts = response.jwts
                        val existingClaims = repository.getAllClaims()
                        val alreadyExists =
                            existingClaims.any { claim -> jwts.any { it.source == claim.source } }
                        if (alreadyExists && loginRequest == null) throw CredentialAlreadyExistsException(
                            jwts.first().source
                        )
                        updateJwts(jwts)
                    }

                    Logger.info("Received VCI offers: ${json.encodeToString(response.oidcVCIOffers)}")

                    val latestSupportedOffer =
                        getLatestCredentialOffer(response) ?: throw NoSupportedCredentialOffers()
                    return@async oid4vciOrchestrator.addCredential(latestSupportedOffer)
                }
            },
        )

        return DocumentChallenge(bacKey.key, responder, challenge)
    }

    /**
     * @param credential The credential that contains a portrait being verified
     */
    @Throws(Exception::class)
    @OptIn(ExperimentalObjCRefinement::class)
    @HiddenFromObjC
    fun addFaceVerification(
        credential: LegacyCredential,
        loginRequest: LoginRequest? = null,
        options: IproovOptions? = null,
    ): Flow<VerificationEvent> {

        val dtc = credential.claims.find { claim -> claim.name == DTC_CLAIM_NAME }
            ?: throw RequiredClaimNotPresent(
                DTC_CLAIM_NAME,
                "A DTC claim is required to perform a face verification"
            )

        return verifyFace(
            target = credential,
            getVerificationMethod = { _, reverificationToken ->
                identityPlatformInterface.initFace(
                    dtc,
                    reverificationToken
                )
            },
            verifyFace = { token -> identityPlatformInterface.verifyFace(token) },
            loginRequest = loginRequest,
            options = options,
            addLegacyCredential = true,
        )
    }

    /**
     * @param getVerificationMethod Function to get a request to pass to the iProov Biometrics SDK to launch the face capture, this token in the request can then be used as a reference to that capture.
     * @param verifyFace Callback function for when the iProov Biometrics SDK has captured the face successfully, providing the request token.
     * @param completion Callback function for when the verification has bene completed.
     * @param loginRequest A login request that this verification relates to
     */
    @Throws(Exception::class)
    private fun <T> verifyFace(
        target: T,
        getVerificationMethod: suspend (target: T, verificationToken: String?) -> VerificationMethod,
        verifyFace: suspend (token: String) -> Responses.OfferedCredentialResponse,
        completion: (() -> Unit)? = null,
        loginRequest: LoginRequest? = null,
        options: IproovOptions? = null,
        addLegacyCredential: Boolean,
    ) = flow {
        throwIfNotRegistered()
        emit(VerificationEvent.Started)

        when (val verificationMethod =
            getVerificationMethod(target, loginRequest?.jwt?.compactString)) {
            is VerificationMethod.Skip -> {
                emit(VerificationEvent.Loading)

                val response = verifyFace(verificationMethod.token)

                val latestSupportedOffer = getLatestCredentialOffer(response)

                if (addLegacyCredential) {
                    updateJwts(response.jwts, loginRequest)
                }

                val responder = latestSupportedOffer?.let {
                    oid4vciOrchestrator.addCredential(it)
                }

                completion?.invoke()
                emit(VerificationEvent.Completed(responder))
                return@flow
            }

            is VerificationMethod.IProov -> {
                runCatching { Iproov.cancelSession() } // Since Iproov is a single object, cancel any existing sessions before launching.

                Iproov.launchSession(
                    verificationMethod.url,
                    verificationMethod.token,
                    options ?: IproovOptions()
                )

                Iproov.sessionState.collect { event ->
                    when (event) {
                        is IproovState.Canceled -> emit(VerificationEvent.Canceled)
                        is IproovState.Failure -> emit(
                            VerificationEvent.Error(
                                event.failureResult.reasons.joinToString(
                                    separator = " "
                                ) { it.description })
                        )

                        is IproovState.Error -> emit(
                            VerificationEvent.Error(
                                event.exception.message ?: "Verification failed."
                            )
                        )

                        is IproovState.Success -> {
                            emit(VerificationEvent.Loading)

                            val response = verifyFace(verificationMethod.token)

                            val latestSupportedOffer = getLatestCredentialOffer(response)

                            if (addLegacyCredential) {
                                updateJwts(response.jwts, loginRequest)
                            }

                            val responder = latestSupportedOffer?.let {
                                oid4vciOrchestrator.addCredential(it)
                            }

                            completion?.invoke()
                            emit(VerificationEvent.Completed(responder))
                        }

                        else -> emit(VerificationEvent.Loading)
                    }
                }
            }
        }
    }

    suspend fun updateJwts(jwts: List<Jwt>, loginRequest: LoginRequest? = null): List<Jwt> {
        var jwtsToUpdate = jwts
        if (loginRequest != null) {
            val presentJwts = jwtsToUpdate.filter { it.name.endsWith("_present") }
            loginRequest.reverificationJwts.addAll(presentJwts);

            // remove the _present JWTs
            jwtsToUpdate = jwtsToUpdate.filterNot { presentJwts.contains(it) }
        }

        return repository.addOrUpdateJwts(jwtsToUpdate)
    }

    @Throws(Exception::class)
    suspend fun throwIfNotRegistered() {
        if (isRegistered()) return

        throw WalletNotRegisteredException()
    }

    @Throws(Exception::class)
    suspend fun refresh(credentials: List<LegacyCredential>) {
        throwIfNotRegistered()
        val jwts: MutableList<Jwt> = mutableListOf()

        // refresh uris
        val uriCredentials = credentials.filterIsInstance<LegacyCredential.UriCredential>()
        jwts += identityPlatformInterface.refreshClaims(
            uris = uriCredentials
        ).jwts

        // refresh the documents
        val documents = credentials.filterIsInstance<LegacyCredential.IdentityCredential.Mrtd>()
        jwts += documents.map {
            identityPlatformInterface.refreshClaims(
                document = it
            ).jwts
        }.flatten()

        repository.addOrUpdateJwts(jwts)
    }

    @Throws(Exception::class)
    suspend fun refreshExpiredCredentials(isExpiredFromEpochSecondsOverride: Long) {
        val credentials = getLegacyCredentials().filter {
            it.claims.any { claim -> isExpiredFromEpochSecondsOverride > claim.expires }
        }

        return refresh(credentials)
    }

    private suspend fun getTranslations(): Map<String, String?> {
        val storedTranslations = localStorage.getTranslations()
        if (storedTranslations != null) return storedTranslations

        val translations = identityPlatformInterface.getTranslations()
        localStorage.setTranslations(translations)
        return translations
    }

    @Throws(Exception::class)
    @HiddenFromObjC
    suspend fun isRegistered(): Boolean = localStorage.getAttestationToken() != null

    val json = Json { prettyPrint = true }
    private fun getLatestCredentialOffer(response: Responses.OfferedCredentialResponse): JsonObject? {
        // VCI Offer
        val supportedOffers =
            response.oidcVCIOffers.filter { it.key <= 1.0 }

        Logger.debug("Received supported offers:  ${json.encodeToString(supportedOffers)}")
        if (supportedOffers.isEmpty()) {
            return null
        }

        val latestSupportedOffer = supportedOffers.maxBy { it.key }.value
        Logger.debug("Latest supported offer: ${json.encodeToString(latestSupportedOffer)}")

        return latestSupportedOffer
    }
}
