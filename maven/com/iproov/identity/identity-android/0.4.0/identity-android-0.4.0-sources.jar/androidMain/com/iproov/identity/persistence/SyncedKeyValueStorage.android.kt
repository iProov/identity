package com.iproov.identity.persistence

import android.app.backup.BackupAgentHelper
import android.app.backup.BackupDataInput
import android.app.backup.BackupDataOutput
import android.app.backup.FileBackupHelper
import android.content.Context
import android.os.ParcelFileDescriptor
import com.iproov.identity.AppContext

class BackedUpKeyValueStorage(context: Context) : SyncedKeyValueStorage, BackupAgentHelper() {

    companion object {

        const val FILE_NAME = "com.iproov.identity.BACKED_UP_KEY_VALUE_STORAGE"
        val mutex = Any()
    }

    private val fileStorage = FileStorage(context, FILE_NAME)

    override fun read(key: String): String? {
        val bytes = fileStorage.read()
        val dict = fileStorage.unarchiveData(bytes)
        return dict[key]
    }

    override fun write(key: String, value: String?) {
        val bytes = fileStorage.read()
        val dict = fileStorage.unarchiveData(bytes)
        dict[key] = value
        val archivedData = fileStorage.archiveDictionary(dict)
        fileStorage.write(archivedData)
    }

    override fun onCreate() {

        // This takes in a list of file urls to backup
        FileBackupHelper(this, FILE_NAME).also {

            // This here is an identifier for the files that are being backed up here.
            addHelper(FILE_NAME, it)
        }
    }

    override fun onBackup(oldState: ParcelFileDescriptor, data: BackupDataOutput, newState: ParcelFileDescriptor) =
        synchronized(mutex) { super.onBackup(oldState, data, newState) }

    override fun onRestore(data: BackupDataInput?, appVersionCode: Int, newState: ParcelFileDescriptor?) =
        synchronized(mutex) { super.onRestore(data, appVersionCode, newState) }
}

actual fun getSyncedKeyValueStorage(): SyncedKeyValueStorage = BackedUpKeyValueStorage(AppContext.get())