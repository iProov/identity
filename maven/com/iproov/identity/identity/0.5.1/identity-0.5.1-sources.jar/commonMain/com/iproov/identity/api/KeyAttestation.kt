package com.iproov.identity.api

import com.iproov.identity.Base64Utils.encodeToBase64
import com.iproov.identity.Base64Utils.encodeToBase64Url
import com.iproov.identity.cryptography.AttestableKeyPair
import com.iproov.identity.cryptography.KeyAttestationEvidence
import com.iproov.identity.cryptography.KeyPair
import com.iproov.identity.cryptography.signRs
import com.iproov.identity.models.CredentialDescriptor
import com.iproov.identity.models.RequiredKeyAttestationUnavailableException
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlin.time.Clock

internal data class AvailableKeyAttestation(
    val keyPair: AttestableKeyPair,
    val evidence: KeyAttestationEvidence,
)

/** Applies the fail-closed decision gate for an issuer-required key attestation. */
internal fun requireKeyAttestation(
    keyPair: KeyPair,
    credentialConfigurationId: String,
): AvailableKeyAttestation {
    val attestableKey = keyPair as? AttestableKeyPair
        ?: throw RequiredKeyAttestationUnavailableException(
            credentialConfigurationId = credentialConfigurationId,
            message = "Credential configuration '$credentialConfigurationId' requires OID4VCI " +
                "key attestation, but the configured signing key does not implement " +
                "AttestableKeyPair. Implement that interface and return KeyAttestationEvidence.",
        )

    val evidence = attestableKey.getKeyAttestationEvidence()
        ?: throw RequiredKeyAttestationUnavailableException(
            credentialConfigurationId = credentialConfigurationId,
            message = "Credential configuration '$credentialConfigurationId' requires OID4VCI " +
                "key attestation, but getKeyAttestationEvidence() returned null.",
        )

    if (evidence.certificateChainDer.isEmpty()) {
        throw RequiredKeyAttestationUnavailableException(
            credentialConfigurationId = credentialConfigurationId,
            message = "Credential configuration '$credentialConfigurationId' requires OID4VCI " +
                "key attestation, but KeyAttestationEvidence.certificateChainDer was empty.",
        )
    }
    if (evidence.certificateChainDer.any(ByteArray::isEmpty)) {
        throw RequiredKeyAttestationUnavailableException(
            credentialConfigurationId = credentialConfigurationId,
            message = "Credential configuration '$credentialConfigurationId' requires OID4VCI " +
                "key attestation, but its DER certificate chain contained an empty certificate.",
        )
    }
    if (evidence.userAuthenticationLevel !in supportedAttackResistanceLevels) {
        throw RequiredKeyAttestationUnavailableException(
            credentialConfigurationId = credentialConfigurationId,
            message = "Credential configuration '$credentialConfigurationId' requires OID4VCI " +
                "key attestation, but userAuthenticationLevel '${evidence.userAuthenticationLevel}' " +
                "is not an ISO 18045 value supported by the SDK. Use one of " +
                supportedAttackResistanceLevels.joinToString() + ".",
        )
    }
    if (evidence.keyStorageLevel !in supportedAttackResistanceLevels) {
        throw RequiredKeyAttestationUnavailableException(
            credentialConfigurationId = credentialConfigurationId,
            message = "Credential configuration '$credentialConfigurationId' requires OID4VCI " +
                "key attestation, but keyStorageLevel '${evidence.keyStorageLevel}' is not an " +
                "ISO 18045 value supported by the SDK. Use one of " +
                supportedAttackResistanceLevels.joinToString() + ".",
        )
    }

    return AvailableKeyAttestation(attestableKey, evidence)
}

/** True when the credential metadata advertises a required JWT key-attestation object. */
internal fun CredentialDescriptor.requiresKeyAttestation(): Boolean {
    val proofTypes = raw["proof_types_supported"] as? JsonObject ?: return false
    val jwt = proofTypes["jwt"] as? JsonObject ?: return false
    return "key_attestations_required" in jwt
}

/** Builds the key-attestation JWT consumed by both platform OID4VCI implementations. */
internal fun buildKeyAttestationJwt(
    attestation: AvailableKeyAttestation,
    nonce: String?,
    issuerIdentifier: String,
): String {
    val keyPair = attestation.keyPair
    val evidence = attestation.evidence
    val publicKey = keyPair.getJwk()

    val header = buildJsonObject {
        put("alg", "ES256")
        put("typ", "key-attestation+jwt")
        put(
            "x5c",
            JsonArray(evidence.certificateChainDer.map { JsonPrimitive(it.encodeToBase64()) }),
        )
    }
    val attestedKey = buildJsonObject {
        put("kty", "EC")
        put("crv", "P-256")
        put("x", publicKey.jwk.x)
        put("y", publicKey.jwk.y)
    }

    val now = Clock.System.now().epochSeconds
    val payload = buildJsonObject {
        put("aud", issuerIdentifier)
        put("iat", now)
        put("exp", now + 300)
        put("attested_keys", JsonArray(listOf(attestedKey)))
        put("key_storage", JsonArray(listOf(JsonPrimitive(evidence.keyStorageLevel))))
        put(
            "user_authentication",
            JsonArray(listOf(JsonPrimitive(evidence.userAuthenticationLevel))),
        )
        nonce?.let { put("nonce", it) }
    }

    val headerBase64 = header.toString().encodeToByteArray().encodeToBase64Url()
    val payloadBase64 = payload.toString().encodeToByteArray().encodeToBase64Url()
    val signingInput = "$headerBase64.$payloadBase64".encodeToByteArray()
    val signature = keyPair.signRs(signingInput).encodeToBase64Url()
    return "$headerBase64.$payloadBase64.$signature"
}

private val supportedAttackResistanceLevels = listOf(
    "iso_18045_high",
    "iso_18045_moderate",
    "iso_18045_enhanced-basic",
    "iso_18045_basic",
)
