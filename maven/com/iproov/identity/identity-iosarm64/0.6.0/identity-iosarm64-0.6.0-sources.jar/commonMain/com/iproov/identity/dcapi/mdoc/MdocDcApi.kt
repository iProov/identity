package com.iproov.identity.dcapi.mdoc

import at.asitplus.signum.indispensable.ECCurve
import at.asitplus.signum.indispensable.ECPoint
import com.iproov.identity.Base64Utils.base64UrlDecode
import com.iproov.identity.api.sha256
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.multipaz.cbor.Bstr
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.Simple
import org.multipaz.cbor.Tstr
import org.multipaz.cbor.buildCborArray
import org.multipaz.cbor.buildCborMap
import org.multipaz.cose.CoseKey
import org.multipaz.crypto.EcCurve
import org.multipaz.crypto.EcPublicKeyDoubleCoordinate

/**
 * Annex C - retrieval of a mdoc through a Digital Credentials API.
 * Annex C does not define the browser API; it defines what travels through one.
 *
 * It reuses the ISO/IEC 18013-5 `DeviceRequest` / `DeviceResponse` structures and adds its own session
 * transcript and HPKE encryption.
 *
 * Ref: ISO/IEC TS 18013-7
 */

internal const val MDOC_DC_API_PROTOCOL = "org-iso-mdoc"

private const val DCAPI_LABEL = "dcapi"
private const val MIN_NONCE_BYTES = 16

internal class MdocDcApiException(message: String) : Exception(message)

/** Converts multipaz CBOR/JSON accessor failures into a named, actionable error. */
internal inline fun <T> requireField(jsonField: String, block: () -> T): T =
    try {
        block()
    } catch (e: Exception) {
        throw MdocDcApiException("Malformed or missing '$jsonField': ${e.message}")
    }

internal data class MdocDcApiRequest(
    val deviceRequestB64: String,
    val encryptionInfoB64: String,
) {
    fun decodedDeviceRequest(): ByteArray = deviceRequestB64.base64UrlDecode()

    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        fun parse(requestJson: String): MdocDcApiRequest {
            val obj = requireField("request") { json.parseToJsonElement(requestJson).jsonObject }
            return MdocDcApiRequest(
                deviceRequestB64 = obj.string("deviceRequest"),
                encryptionInfoB64 = obj.string("encryptionInfo"),
            )
        }

        private fun JsonObject.string(field: String): String =
            this[field]?.jsonPrimitive?.contentOrNull
                ?: throw MdocDcApiException("Request is missing '$field'")
    }
}

internal class MdocDcApiEncryptionInfo(
    val nonce: ByteArray,
    val readerPublicKey: ByteArray,
) {
    companion object {
        fun parse(encryptionInfoB64: String): MdocDcApiEncryptionInfo {
            val info = requireField("encryptionInfo") {
                Cbor.decode(encryptionInfoB64.base64UrlDecode()).asArray
            }
            if (info.size != 2) {
                throw MdocDcApiException("EncryptionInfo must be a 2-element array")
            }

            val protocol = requireField("protocol") { info[0].asTstr }
            if (protocol != DCAPI_LABEL) {
                throw MdocDcApiException("Unknown protocol '$protocol'; \"$DCAPI_LABEL\" expected")
            }

            val params = info[1]
            val nonce = requireField("nonce") { params["nonce"].asBstr }
            if (nonce.size < MIN_NONCE_BYTES) {
                throw MdocDcApiException("Nonce is ${nonce.size} bytes; $MIN_NONCE_BYTES+ expected")
            }

            val key = requireField("recipientPublicKey") {
                CoseKey.fromDataItem(params["recipientPublicKey"]).ecPublicKey
            }
            val point = key as? EcPublicKeyDoubleCoordinate
            if (point == null || point.curve != EcCurve.P256) {
                throw MdocDcApiException("Reader key must be P-256, got ${key.curve}")
            }
            // The COSE key only names the curve; the curve equation proves the coordinates are a point on it.
            requireField("recipientPublicKey") {
                ECPoint.fromUncompressed(
                    ECCurve.SECP_256_R_1,
                    point.x,
                    point.y
                )
            }

            return MdocDcApiEncryptionInfo(nonce, point.asUncompressedPointEncoding)
        }
    }
}

internal fun mdocDcApiSessionTranscript(
    encryptionInfoB64: String,
    origin: String,
): ByteArray {
    val dcapiInfo = Cbor.encode(
        buildCborArray {
            add(Tstr(encryptionInfoB64))
            add(Tstr(origin))
        }
    )
    return Cbor.encode(
        buildCborArray {
            add(Simple.NULL)
            add(Simple.NULL)
            add(buildCborArray { add(Tstr(DCAPI_LABEL)); add(Bstr(sha256(dcapiInfo))) })
        }
    )
}

/**
 * Mapping for what `ISO18013MobileDocumentResponse(responseData:)`
 * expects the OS to add the surrounding JSON envelope.
 */
internal fun encodeMdocDcApiEncryptedResponse(enc: ByteArray, cipherText: ByteArray): ByteArray =
    Cbor.encode(
        buildCborArray {
            add(Tstr(DCAPI_LABEL))
            add(buildCborMap { put("enc", Bstr(enc)); put("cipherText", Bstr(cipherText)) })
        }
    )


internal fun serializeOrigin(scheme: String, host: String, port: Int?): String {
    val normalizedScheme = scheme.lowercase()
    val defaultPort = when (normalizedScheme) {
        "https" -> 443
        "http" -> 80
        else -> null
    }
    val normalizedHost =
        if (host.contains(':')) "[${host.trim('[', ']').lowercase()}]" else host.lowercase()
    return if (port != null && port != defaultPort) {
        "$normalizedScheme://$normalizedHost:$port"
    } else {
        "$normalizedScheme://$normalizedHost"
    }
}
