package com.iproov.identity.proximity

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal actual object NfcEngagementRegistry {

    private val mutex = Mutex()
    private var active: NfcEngagementHandler? = null

    actual suspend fun publish(handle: NfcEngagementHandler) = mutex.withLock {
        val current = active
        require(current == null || current.isComplete) {
            "Another NFC engagement is already active. Wait for it to complete or call abort() first."
        }
        active = handle
    }

    actual suspend fun current(): NfcEngagementHandler? = mutex.withLock { active }
}