package com.iproov.identity.proximity

import org.multipaz.asn1.ASN1
import org.multipaz.asn1.ASN1Boolean
import org.multipaz.asn1.ASN1ObjectIdentifier
import org.multipaz.asn1.ASN1Sequence
import org.multipaz.asn1.OID
import org.multipaz.crypto.X509Cert
import org.multipaz.crypto.X509KeyUsage

/**
 * Shared X.509 certificate chain validation
 *
 * Used by both issuer trust ([ProximityRetrievalSession.verifyIssuerTrust],
 * and reader trust ([ReaderAuthVerifier]
 *
 * Callers are responsible for any spec-section-specific checks layered on top
 * (e.g. MSO signedAt validity, IACA / reader-CA trust anchor resolution,
 * country / state name matching with appropriate error messaging).
 */
internal object CertTrust {

    fun verifyCertValidityPeriods(chain: List<X509Cert>, context: String) {
        val now = kotlin.time.Clock.System.now()
        for ((i, cert) in chain.withIndex()) {
            if (now < cert.validityNotBefore || now > cert.validityNotAfter) {
                throw Exception(
                    "$context: certificate at index $i has expired " +
                            "(valid ${cert.validityNotBefore} - ${cert.validityNotAfter})"
                )
            }
        }
    }

    fun verifyCaConstraints(chain: List<X509Cert>, context: String) {
        for (i in 1 until chain.size) {
            val caCert = chain[i]
            verifyBasicConstraintsCA(context, caCert, i)
            if (!caCert.keyUsage.contains(X509KeyUsage.KEY_CERT_SIGN)) {
                throw Exception(
                    "$context: certificate at index $i missing keyCertSign key usage"
                )
            }
        }
    }

    fun verifyChainSignatures(chain: List<X509Cert>, context: String) {
        for (i in 0 until chain.size - 1) {
            try {
                chain[i].verify(chain[i + 1].ecPublicKey)
            } catch (e: Exception) {
                throw Exception(
                    "$context: certificate chain signature failed at index $i", e
                )
            }
        }
    }

    private fun verifyBasicConstraintsCA(context: String, cert: X509Cert, index: Int) {
        val bcBytes = cert.getExtensionValue(OID.X509_EXTENSION_BASIC_CONSTRAINTS.oid)
            ?: throw Exception("$context: certificate at index $index missing basicConstraints")
        val bcSeq = ASN1.decode(bcBytes) as? ASN1Sequence
            ?: throw Exception("$context: certificate at index $index has malformed basicConstraints")
        val caFlag = (bcSeq.elements.firstOrNull() as? ASN1Boolean)?.value ?: false
        if (!caFlag) {
            throw Exception("$context: certificate at index $index has basicConstraints CA=false")
        }
    }

    fun requireExtendedKeyUsage(cert: X509Cert, requiredOid: String, context: String) {
        val ekuBytes = cert.getExtensionValue("2.5.29.37")
            ?: throw Exception("$context: missing extendedKeyUsage extension")
        val ekuSeq = ASN1.decode(ekuBytes) as? ASN1Sequence
            ?: throw Exception("$context: malformed extendedKeyUsage")
        val oids = ekuSeq.elements.mapNotNull { (it as? ASN1ObjectIdentifier)?.oid }
        if (requiredOid !in oids) {
            throw Exception(
                "$context: extendedKeyUsage does not include required OID $requiredOid " +
                        "(found: ${oids.joinToString()})"
            )
        }
    }
}
