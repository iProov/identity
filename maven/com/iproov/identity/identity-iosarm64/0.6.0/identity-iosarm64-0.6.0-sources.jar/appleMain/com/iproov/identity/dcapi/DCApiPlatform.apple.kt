package com.iproov.identity.dcapi

import com.iproov.identity.DCApiRegistrationBridge
import com.iproov.identity.Logger
import kotlinx.cinterop.ExperimentalForeignApi

/** Production deployment requires Apple entitlement approval. */
@Suppress("UNUSED_PARAMETER")
internal actual fun createPlatformDCApiRegistrar(
    currentCredentials: suspend () -> List<CredentialRegistrationInfo>,
): DCApiRegistrar? =
    if (isDCApiPlatformAvailable()) AppleDCApiRegistrar() else {
        Logger.debug("DC API requires iOS 26 or later")
        null
    }

@OptIn(ExperimentalForeignApi::class)
actual fun isDCApiPlatformAvailable(): Boolean = DCApiRegistrationBridge.isOSSupported()
