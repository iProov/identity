package com.iproov.identity

enum class LogLevel {
    DEBUG,
    INFO,
    ERROR,
    NONE,
}

internal object Logger {

    var isEnabled: Boolean = false

    /**
     * Helper method for ERROR logging
     */
    fun error(message: String) = output(LogLevel.ERROR, message)

    /**
     * Helper method for INFO logging
     */
    fun info(message: String) = output(LogLevel.INFO, message)

    /**
     * Helper method for DEBUG logging
     */
    fun debug(message: String) = output(LogLevel.DEBUG, message)


    private fun output(logLevel: LogLevel, message: String) {
        if (!isEnabled) return

        println("iProov Identity ${logLevel.name}: $message")
    }
}

/**
 * multipaz logs on its own and prints debug output by default. With logging off, keep only its warnings and errors,
 * as identity-components does; with logging on, leave it as configured.
 */
internal fun quietMultipazUnlessLogging(isLoggingEnabled: Boolean) {
    org.multipaz.util.Logger.isDebugEnabled = isLoggingEnabled
    if (!isLoggingEnabled) {
        if (org.multipaz.util.Logger.logPrinter !== quietMultipazPrinter) {
            multipazPrinterBeforeQuieting = org.multipaz.util.Logger.logPrinter
            org.multipaz.util.Logger.logPrinter = quietMultipazPrinter
        }
    } else if (org.multipaz.util.Logger.logPrinter === quietMultipazPrinter) {
        org.multipaz.util.Logger.logPrinter = multipazPrinterBeforeQuieting
        multipazPrinterBeforeQuieting = null
    }
}

private var multipazPrinterBeforeQuieting: org.multipaz.util.Logger.LogPrinter? = null

private val quietMultipazPrinter = org.multipaz.util.Logger.LogPrinter { level, tag, msg, throwable ->
    if (level >= org.multipaz.util.Logger.LogPrinter.Level.WARNING) println("$level $tag: $msg${throwable?.let { " ($it)" } ?: ""}")
}
