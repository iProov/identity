package com.iproov.identity

import platform.Foundation.NSBundle
import platform.Foundation.version
import platform.UIKit.UIDevice


class ApplePlatform(instanceId: String) : Platform {

    override val isVirtual: Boolean = false // TODO: Check whether the device is a simulator or not.

    override val target: Platform.Target by lazy { Platform.Target.IOS }

    override val appInfo: AppInfo = AppInfo(
        NSBundle.mainBundle.bundleIdentifier
            ?: throw IllegalStateException("Failed to get bundle identifier"),
        NSBundle.version().toString(),
    )

    override val deviceInfo: DeviceInfo = DeviceInfo(
        manufacturer = "Apple",
        model = UIDevice.currentDevice.model,
        osversion = UIDevice.currentDevice.systemVersion,
        os = "iOS",
        instanceId = instanceId
    )

}

