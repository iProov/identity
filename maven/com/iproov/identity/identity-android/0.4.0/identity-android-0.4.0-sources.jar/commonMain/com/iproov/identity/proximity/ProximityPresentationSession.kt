package com.iproov.identity.proximity

import com.iproov.identity.Logger
import com.iproov.identity.api.SessionTranscriptProximity
import com.iproov.identity.cryptography.KeyPair
import com.iproov.identity.models.ClaimQuery
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.DeviceResponse
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.vpCompliantCbor
import com.iproov.identity.persistence.Repository
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.ExperimentalSerializationApi
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.DataItem
import org.multipaz.crypto.Crypto
import org.multipaz.crypto.EcCurve
import org.multipaz.crypto.EcPrivateKey
import org.multipaz.crypto.EcPublicKey
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethodBle
import org.multipaz.mdoc.request.DeviceRequest
import org.multipaz.mdoc.role.MdocRole
import org.multipaz.mdoc.sessionencryption.SessionEncryption
import org.multipaz.mdoc.transport.MdocTransport
import org.multipaz.mdoc.transport.MdocTransportFactory
import org.multipaz.util.Constants
import org.multipaz.util.toBase64Url
import kotlin.coroutines.cancellation.CancellationException
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC


interface IProximityPresentationSession {
    @OptIn(ExperimentalObjCRefinement::class)
    @HiddenFromObjC
    val events: Flow<ProximityPresentationEvent>
    suspend fun close()
}

class ProximityPresentationSession(
    private val config: ProximityConfig,
    private val orchestrator: ProximityOrchestrator,
    private val repository: Repository,
    private val keyPair: KeyPair
) : IProximityPresentationSession {

    companion object {
        private const val MDOC_STRING_PREFIX = "mdoc:"
        // BLE transport options live in Proximity.kt (MDOC_TRANSPORT_OPTIONS) so the
        // presenter and reader can't drift apart.
    }


    private var transport: MdocTransport? = null
    private val transportMutex = Mutex()

    @OptIn(ExperimentalObjCRefinement::class, ExperimentalSerializationApi::class)
    @HiddenFromObjC
    override val events: Flow<ProximityPresentationEvent> = channelFlow {
        var eDeviceKey: EcPrivateKey? = null //The ephemeral key for the session we are generating
        var eReaderPublicKey: EcPublicKey? = null
        lateinit var sessionEncryption: SessionEncryption
        lateinit var sessionTranscript: DataItem
        lateinit var encodedSessionTranscript: ByteArray
        lateinit var proximityTranscript: SessionTranscriptProximity
        var sessionInitialized = false
        // After presentation has been concluded (terminal error or completed) we don't want to send any further
        var presentationConcluded = false

        try {
            if (!orchestrator.isBleAvailable()) {
                throw IllegalStateException("BLE is required for proximity session")
            }
            send(ProximityPresentationEvent.GeneratingEngagement)

            eDeviceKey = Crypto.createEcPrivateKey(EcCurve.P256)
            val deviceEngagement = orchestrator.presentProximityEngagement(eDeviceKey.publicKey, config)

            val ble = deviceEngagement.connectionMethods
                .filterIsInstance<MdocConnectionMethodBle>()
                .first()

            val deviceEngagementBytes = Cbor.encode(deviceEngagement.toDataItem())
            val mdocUri = MDOC_STRING_PREFIX + deviceEngagementBytes.toBase64Url()
            Logger.debug("Created mDoc Uri: $mdocUri")

            send(ProximityPresentationEvent.QrEngagementReady(QrEngagementPayload(mdocUri)))

            val mdocTransport = MdocTransportFactory.Default.createTransport(
                connectionMethod = ble,
                role = MdocRole.MDOC,
                options = MDOC_TRANSPORT_OPTIONS,
            )
            transportMutex.withLock { transport = mdocTransport }

            send(ProximityPresentationEvent.Connecting)

            withTimeout(config.engagementTimeout) {
                mdocTransport.advertise()
                mdocTransport.open(eDeviceKey.publicKey)
                Logger.debug("Transport session opened")
            }

            send(ProximityPresentationEvent.Connected)
            Logger.debug("Transport session connected")

            while (true) {
                val sessionData = withTimeout(config.sessionInactivityTimeout) {
                    mdocTransport.waitForMessage()
                }

                if (sessionData.isEmpty()) break

                if (!sessionInitialized) {
                    send(ProximityPresentationEvent.CreatingSession)

                    val eReaderKey =
                        withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_CBOR_DECODING) {
                            SessionEncryption.getEReaderKey(sessionData)
                        }

                    eReaderPublicKey = eReaderKey.publicKey

                    proximityTranscript = SessionTranscriptProximity(
                        deviceEngagementBytes = deviceEngagementBytes,
                        eReaderKeyBytes = eReaderKey.encodedCoseKey,
                    )
                    encodedSessionTranscript = vpCompliantCbor.encodeToByteArray(
                        SessionTranscriptProximity.serializer(),
                        proximityTranscript,
                    )
                    sessionTranscript = Cbor.decode(encodedSessionTranscript)

                    sessionEncryption =
                        withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_SESSION_ENCRYPTION) {
                            SessionEncryption(
                                role = MdocRole.MDOC,
                                eSelfKey = eDeviceKey,
                                remotePublicKey = eReaderPublicKey,
                                encodedSessionTranscript = encodedSessionTranscript,
                            )
                        }

                    sessionInitialized = true

                    send(ProximityPresentationEvent.SessionCreated)
                }

                val (decryptedMsgResponse, status) = withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_SESSION_ENCRYPTION) {
                    sessionEncryption.decryptMessage(sessionData)
                }

                if (status == Constants.SESSION_DATA_STATUS_SESSION_TERMINATION) {
                    break
                }
                if (status != null) {
                    throw IllegalStateException("Reader reported unexpected status: $status")
                }

                if (decryptedMsgResponse == null) throw IllegalStateException("Decrypted request payload was null")

                val deviceRequest = withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_CBOR_DECODING) {
                    DeviceRequest.fromDataItem(Cbor.decode(decryptedMsgResponse))
                }

                val readerAuthResult = when (
                    val outcome = ReaderAuthVerifier.verify(
                        deviceRequest = deviceRequest,
                        sessionTranscript = sessionTranscript,
                        trustedRoots = config.trustedReaderCertificates,
                        policy = config.readerTrust,
                    )
                ) {
                    is ReaderAuthVerifier.VerificationOutcome.Accepted -> outcome.result
                    is ReaderAuthVerifier.VerificationOutcome.Rejected -> {
                        terminateTransport()
                        send(
                            ProximityPresentationEvent.Failure(
                                outcome.reason,
                                IllegalStateException(outcome.reason),
                            )
                        )
                        return@channelFlow
                    }
                }

                val docRequests = deviceRequest.toRespondable()
                val respondable = RespondableProximityRequest(
                    docRequests = docRequests,
                    readerAuth = readerAuthResult,
                    responseHandler = { disclosed ->
                        val outcome = try {
                            val documents = disclosed.map { (docRequest, item) ->
                                item.credential to buildClaims(docRequest, item)
                            }
                            val requestedDocTypes = docRequests.map { it.docType }.toSet()
                            val fulfilledDocTypes = disclosed.keys.map { it.docType }.toSet()
                            val unfulfilled =
                                (requestedDocTypes - fulfilledDocTypes).associateWith { 0 }

                            val responseBytes = DeviceResponse.buildForProximity(
                                documents = documents,
                                deviceKeyPair = keyPair,
                                sessionTranscript = proximityTranscript,
                                documentErrors = unfulfilled,
                            )

                            val encrypted = withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_SESSION_ENCRYPTION) {
                                sessionEncryption.encryptMessage(
                                    messagePlaintext = responseBytes,
                                    statusCode = null,
                                )
                            }

                            mdocTransport.sendMessage(encrypted)
                            ProximityResponseOutcome.Sent()
                        } catch (e: SessionDataStatusError) {
                            terminateTransport(e.statusCode)
                            ProximityResponseOutcome.Failure(e.cause ?: e)
                        } catch (e: Exception) {
                            terminateTransport()
                            ProximityResponseOutcome.Failure(e)
                        }

                        when (outcome) {
                            is ProximityResponseOutcome.Sent ->
                                send(ProximityPresentationEvent.PresentationSent)

                            is ProximityResponseOutcome.Failure ->
                                send(
                                    ProximityPresentationEvent.Failure(
                                        outcome.cause.message ?: "send failed", outcome.cause
                                    )
                                )
                        }

                        presentationConcluded = true
                        return@RespondableProximityRequest outcome
                    },
                    matchHandler = { matchCredentials(docRequests) },
                )
                send(ProximityPresentationEvent.RequestReceived(respondable))
            }
            send(ProximityPresentationEvent.Disconnected)

        } catch (e: SessionDataStatusError) {
            terminateTransport(e.statusCode)
            send(
                ProximityPresentationEvent.Failure(
                    e.cause?.message ?: "session error",
                    e.cause ?: e
                )
            )
        } catch (e: TimeoutCancellationException) {
            terminateTransport()
            // After a delivered response, an idle reader tripping the inactivity timeout
            // is a normal end-of-session, not a failure — don't surface it over the success.
            if (!presentationConcluded) {
                send(ProximityPresentationEvent.Failure("Session timed out", e))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            terminateTransport()
            // Likewise, a transport teardown after the response was handled is expected.
            if (!presentationConcluded) {
                val errorMsg = e.message
                    ?: e.cause?.message
                    ?: (e::class.simpleName ?: "Unknown error")
                send(ProximityPresentationEvent.Failure(errorMsg, e))
            }
        } finally {
            eDeviceKey?.d?.fill(0)
            terminateTransport()
        }
    }

    override suspend fun close() {
        terminateTransport()
    }

    private suspend fun terminateTransport(
        code: Long = Constants.SESSION_DATA_STATUS_SESSION_TERMINATION,
    ) {
        transportMutex.withLock {
            transport?.let { t ->
                runCatching { t.sendMessage(SessionEncryption.encodeStatus(code)) }
                runCatching { t.close() }
                transport = null
            }
        }
    }

    private suspend fun matchCredentials(
        docRequests: List<DocRequest>,
    ): Map<DocRequest, List<DisclosedDocument>> {
        val credentialMetadata: List<CredentialMetadata> = repository.getCredentialMetadata()
        if (credentialMetadata.isEmpty()) return docRequests.associateWith { emptyList() }

        val walletMdocs = repository.getCredentials(
            credentialMetadata.filter { it.format == "mso_mdoc" }
        ).credentials.values.filterIsInstance<MDocCredential>()

        return docRequests.associateWith { request ->
            walletMdocs
                .filter { it.docType == request.docType }
                .map { DisclosedDocument(it) }
        }
    }

    private fun buildClaims(docRequest: DocRequest, item: DisclosedDocument): List<ClaimQuery> {
        val plan: Map<String, Set<String>> = item.disclosedItems
            ?: docRequest.requestedItems.mapValues { (_, items) ->
                items.map { it.elementIdentifier }.toSet()
            }
        return plan.flatMap { (ns, elements) ->
            elements.map { ClaimQuery(path = listOf(ns, it)) }
        }
    }

    private fun DeviceRequest.toRespondable(): List<DocRequest> {
        return docRequests.map { req ->
            DocRequest(
                docType = req.docType,
                requestedItems = req.nameSpaces.mapValues { (_, items) ->
                    items.map { (id, intentToRetain) -> RequestedItem(id, intentToRetain) }
                },
            )
        }
    }

    private inline fun <T> withFailureStatus(statusCode: Long, block: () -> T): T =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            throw SessionDataStatusError(statusCode, e)
        }


}

private class SessionDataStatusError(val statusCode: Long, cause: Throwable) : Exception(cause)