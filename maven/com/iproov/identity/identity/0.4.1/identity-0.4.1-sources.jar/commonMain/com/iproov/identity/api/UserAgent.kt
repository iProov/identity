package com.iproov.identity.api

import kotlinx.serialization.Serializable


@Serializable
data class UserAgent(
    val sdkVersion: String,
    val operatingSystem: String,
    val operatingSystemVersion: String,
    val deviceModel: String
) {

    /**
     * Header that's sent to the identity backend to identify the device and SDK.
     */
    val header: String get() = "Identity-SDK/$sdkVersion ($operatingSystem; $operatingSystemVersion; $deviceModel)"
}

expect fun getUserAgent(): UserAgent

