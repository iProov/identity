package com.iproov.identity.models

import kotlinx.serialization.Serializable

@Serializable
enum class VerificationStatus {
    VALID,
    EXPIRED,
    REVOKED,
    NOT_YET_VALID,
    ISSUER_UNTRUSTED, // e.g There is no certificate / public key to verify this against
    SIGNATURE_INVALID,
    MALFORMED,
    INDETERMINATE, // e.g., offline or status endpoint unreachable or verification method unsupported
}

@Serializable
data class VerificationResult(
    val check: String,                       // e.g., "jwt.structure"
    val status: VerificationStatus,
    val reason: String? = null,
    val details: Map<String, String> = emptyMap()
)

@Serializable
data class VerificationSummary(
    val results: List<VerificationResult>,
) {
    val concluded: VerificationStatus =
        results.map { it.status }.let { statuses ->
            // Reduce in priority order (fail beats pass)
            when {
                statuses.any { it == VerificationStatus.MALFORMED } -> VerificationStatus.MALFORMED
                statuses.any { it == VerificationStatus.SIGNATURE_INVALID } -> VerificationStatus.SIGNATURE_INVALID
                statuses.any { it == VerificationStatus.REVOKED } -> VerificationStatus.REVOKED
                statuses.any { it == VerificationStatus.EXPIRED } -> VerificationStatus.EXPIRED
                statuses.all { it == VerificationStatus.VALID } -> VerificationStatus.VALID
                else -> VerificationStatus.INDETERMINATE
            }
        }

    companion object {
        fun start() = VerificationSummary(emptyList())
    }

    operator fun plus(r: VerificationResult) = copy(results = results + r)
}