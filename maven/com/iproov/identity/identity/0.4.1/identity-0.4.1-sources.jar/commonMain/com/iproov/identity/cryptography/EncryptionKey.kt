package com.iproov.identity.cryptography

interface EncryptionKey {
    fun encrypt(data: ByteArray): ByteArray

    fun decrypt(data: ByteArray): ByteArray
}