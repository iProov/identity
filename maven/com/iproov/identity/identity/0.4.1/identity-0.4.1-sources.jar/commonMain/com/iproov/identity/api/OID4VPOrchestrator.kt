package com.iproov.identity.api

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.api.OID4VPError.ConstraintNotSatisfiable
import com.iproov.identity.api.OID4VPError.FailedToFetchPresentationRequest
import com.iproov.identity.api.OID4VPError.InvalidAuthorizationRequest
import com.iproov.identity.api.OID4VPError.InvalidAuthorizationRequestDescriptor
import com.iproov.identity.api.OID4VPError.ResponseRejected
import com.iproov.identity.api.OID4VPError.SubmissionFailed
import com.iproov.identity.cryptography.JWEFactory
import com.iproov.identity.encodeToJsonObject
import com.iproov.identity.models.AuthorizationRequest
import com.iproov.identity.models.AuthorizationRequestDescriptor
import com.iproov.identity.models.ClaimQuery
import com.iproov.identity.models.ClientIdType
import com.iproov.identity.models.CredentialSetQuery
import com.iproov.identity.models.DcqlQuery
import com.iproov.identity.models.Jwk
import com.iproov.identity.models.KeyUse
import com.iproov.identity.models.MDocSupportedAlgorithm
import com.iproov.identity.models.OID4VPCapabilities
import com.iproov.identity.models.PresentationOutcome
import com.iproov.identity.models.PresentationRequest
import com.iproov.identity.models.Query
import com.iproov.identity.models.RespondablePresentationRequest
import com.iproov.identity.models.ResponseMode
import com.iproov.identity.models.SupportedVPFormat
import com.iproov.identity.models.Verifier
import com.iproov.identity.models.VerifierDisplayProperties
import com.iproov.identity.persistence.CredentialSubmission
import com.iproov.identity.persistence.DCQLMatcher
import com.iproov.identity.persistence.Repository
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import io.ktor.http.parameters
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlin.uuid.ExperimentalUuidApi

sealed class OID4VPError(message: String, cause: Throwable? = null) : Exception(message, cause) {

    class IncompatibleVerifier(
        message: String,
        cause: Throwable
    ) : OID4VPError(message, cause)

    class FailedToFetchPresentationRequest(
        val uri: String,
        message: String,
        cause: Throwable
    ) : OID4VPError(message, cause)

    class InvalidAuthorizationRequestDescriptor(
        message: String,
        val raw: String,
    ) : OID4VPError(message, cause = null)


    class InvalidAuthorizationRequest(
        message: String,
        val raw: Map<String, Any>,
    ) : OID4VPError(message, cause = null)

    object InvalidOrExpiredRequest : OID4VPError("Authorization request invalid or expired")
    object UnsupportedResponseMode : OID4VPError("Response mode not supported by SDK")
    class ConstraintNotSatisfiable(val details: String) : OID4VPError(details)
    class SubmissionFailed(val httpStatus: Int, val body: String?) :
        OID4VPError("direct_post submission failed")

    class ResponseRejected(val code: String, val description: String?) :
        OID4VPError("verifier rejected response")

}

/**
 * An orchestrator of the OID4VP flow
 */
interface OID4VPOrchestrator {

    /**
     * Create a presentation request from the authorization request found at the URI provided
     */
    suspend fun createPresentationRequest(uri: String): RespondablePresentationRequest

//    suspend fun decodePresentationRequest(uriEncodedPresentationRequest: String): RespondablePresentationRequest
}

@OptIn(ExperimentalUuidApi::class)
class DefaultOID4VPOrchestrator(
    val networkClient: NetworkClient,
    val repository: Repository,
    val keyPairFactory: KeyPairFactory,
    val jweFactory: JWEFactory,
) : OID4VPOrchestrator {

    val dcqlMatcher = DCQLMatcher(repository)

    val vpTokenFactory by lazy {
        VPTokenFactory(keyPairFactory)
    }

    companion object {
        const val ISO_IEC_18013_5_1_MDOC_DOCTYPE = "org.iso.18013.5.1.mDL"
        const val ISO_IEC_18013_5_1_NAMESPACE = "org.iso.18013.5.1"

        enum class SupportedResponseModes(val mode: String) {
            DIRECT_POST("direct_post"),
            DIRECT_POST_JWT("direct_post.jwt"),
            DC_API("dc_api"),
            DC_API_JWT("dc_api.jwt");
        }

        enum class SupportedResponseFormats(val format: String) {
            MDOC("mso_mdoc");
        }

        enum class SupportedObjectSigningAlgorithms(val alg: String) {
            ES256("ES256");
        }

        enum class SupportedClientIdPrefixes(val prefix: String) {
            PRE_REGISTERED("pre-registered"),
            X509_SAN_DNS("x509_san_dns"),
            X509_HASH("x509_hash");
        }

    }

    /**
     * TODO: Move this to a trust register or something similar
     * Credential format -> Credential ID -> Claims
     */
    val mandatoryCredentialQueries by lazy {
        mapOf(
            "mso_mdoc" to mapOf(
                // ISO_IEC_18013-5 DL/ID Spec mandatory claims:
                // family_name, given_name, birth_date, issue_date, expiry_date, issuing_country, issuing_authority, document_number, portrait, driving_privileges, un_distinguishing_sign
                ISO_IEC_18013_5_1_MDOC_DOCTYPE to listOf(
                    "family_name",
                    "given_name",
                    "birth_date",
                    "issue_date",
                    "expiry_date",
                    "issuing_country",
                    "issuing_authority",
                    "document_number",
                    "portrait",
                    "driving_privileges",
                    "un_distinguishing_sign"
                ).map { ClaimQuery(it, listOf(ISO_IEC_18013_5_1_NAMESPACE, it)) }
            )
        )
    }

    val walletVPCapabilities = OID4VPCapabilities(
        requestObjectSigningAlgValuesSupported = listOf(
            SupportedObjectSigningAlgorithms.ES256.alg
        ),
        responseTypesSupported = listOf("vp_token"),
        responseModesSupported = SupportedResponseModes.entries.map { it.mode },
        clientIdPrefixesSupported = SupportedClientIdPrefixes.entries.map { it.prefix },
        supportedVPFormat = SupportedVPFormat(
            mdoc = SupportedVPFormat.MDoc(
                issuerAuthAlgorithm = listOf(MDocSupportedAlgorithm.HMAC_256_ECDH_P_256)
            )
        ),
    )

    /**
     * Known scopes that the wallet can use instead of the DCQL query
     */
    val scopes = mapOf<String, DcqlQuery>()

    override suspend fun createPresentationRequest(uri: String): RespondablePresentationRequest {
        val authorizationRequestDescriptor = retrieveAuthorizationRequestDescriptor(uri)
        val isValid = verifyRelyingParty(authorizationRequestDescriptor)
        if (!isValid) throw InvalidAuthorizationRequestDescriptor(
            "Authorization request integrity is not valid.",
            raw = authorizationRequestDescriptor.raw
        )

        Logger.debug("Authorization Request Descriptor verified for RP")
        val authorizationRequest = authorizationRequestDescriptor.retrieveAuthorizationRequest(
            networkClient, walletVPCapabilities,
        )
        Logger.debug("Authorization Request retrieved: ${authorizationRequest}")
        Logger.debug("Authorization Request (raw): ${authorizationRequest.raw}")

        validateAuthorizationRequest(authorizationRequest)

        val presentationRequest = constructPresentationRequest(authorizationRequest)
        return RespondablePresentationRequest(presentationRequest) { submission ->
            runCatching {
                validateCredentialSubmission(submission, presentationRequest.query.definition.credentialSets)
                present(presentationRequest, submission)
            }.fold(
                onSuccess = { it },
                onFailure = { failure ->
                    failure.printStackTrace()
                    Logger.error("Presentation failed: ${describeFailure(failure)}")
                    mapPresentationFailureToOutcome(failure)
                }
            )
        }
    }

    fun retrieveAuthorizationRequestDescriptor(uri: String): AuthorizationRequestDescriptor =
        try {
            AuthorizationRequestDescriptor.fromHttpParameters(uri).also {
                Logger.debug("Authorization Request Descriptor retrieved: $it")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Logger.error("Failed to retrieve authorization request from verifier")
            throw FailedToFetchPresentationRequest(uri, e.message ?: e.toString(), e)
        }

    /**
     * Here we are verifying the relying party is actually who they say they are.
     */
    suspend fun verifyRelyingParty(authorizationRequest: AuthorizationRequestDescriptor): Boolean {
        val clientId = authorizationRequest.clientIdType
        return when (clientId) {
            ClientIdType.PreRegistered -> true

            ClientIdType.RedirectUri -> throw InvalidAuthorizationRequestDescriptor(
                "Redirect URI client IDs are not yet supported, please use one of the following: [pre_registered,x509_san_dns]",
                raw = authorizationRequest.raw,
            )

            ClientIdType.DID -> throw InvalidAuthorizationRequestDescriptor(
                "DID client IDs are not yet supported, please use one of the following: [pre_registered,x509_san_dns]",
                raw = authorizationRequest.raw,
            )

            ClientIdType.VerifierAttestation -> throw InvalidAuthorizationRequestDescriptor(
                "Verifier attestation client IDs are not yet supported, please use one of the following: [pre_registered,x509_san_dns]",
                raw = authorizationRequest.raw,
            )

            ClientIdType.X509_SAN_DNS -> verifyX509CertificateForRP(authorizationRequest)
            ClientIdType.X509_HASH -> verifyX509HashForRP(authorizationRequest)

            ClientIdType.OpenIDFederation -> throw InvalidAuthorizationRequestDescriptor(
                "Open ID Federation client IDs are not yet supported, please use one of the following: [pre_registered, x509_san_dns]",
                raw = authorizationRequest.raw,
            )
        }
    }

    /**
     * If a X509 SAN DNS is used then we do know that the client metadata has been provided.
     */
    suspend fun verifyX509CertificateForRP(
        authorizationRequest: AuthorizationRequestDescriptor,
    ): Boolean {
        return true
    }

    suspend fun verifyX509HashForRP(
        authorizationRequest: AuthorizationRequestDescriptor,
    ): Boolean {
        return true
    }

    /**
     * Following the standard check that required properties exist in the request
     */
    fun validateAuthorizationRequest(authorizationRequest: AuthorizationRequest) {

        // Check that if the X509 SAN DNS client ID type is used then client metadata must be present
        when (authorizationRequest.clientIdType) {
            ClientIdType.X509_SAN_DNS, ClientIdType.X509_HASH -> {
                if (authorizationRequest.clientMetadata == null) {
                    throw InvalidAuthorizationRequest(
                        "Client metadata must be provided for X509 based client IDs",
                        authorizationRequest.encodeToJsonObject()
                    )
                }
            }

            else -> {
                // No action needed for other client ID types
            }
        }

        // Check that the response mode is supported
        if (authorizationRequest.responseType != "vp_token") {
            throw InvalidAuthorizationRequest(
                "Only 'vp_token' response type is supported",
                authorizationRequest.encodeToJsonObject()
            )
        }

        val supportedResponseModes = listOf(
            ResponseMode.DIRECT_POST,
            ResponseMode.DIRECT_POST_JWT,
            ResponseMode.DC_API,
            ResponseMode.DC_API_JWT
        )
        if (!supportedResponseModes.contains(authorizationRequest.responseMode)) {
            throw InvalidAuthorizationRequest(
                "Unsupported response mode. Supported: direct_post, direct_post.jwt, dc_api, dc_api.jwt",
                authorizationRequest.encodeToJsonObject()
            )
        }

        // response_uri is required for direct_post modes, not for DC API modes
        val requiresResponseUri = authorizationRequest.responseMode in listOf(
            ResponseMode.DIRECT_POST,
            ResponseMode.DIRECT_POST_JWT
        )
        if (requiresResponseUri && authorizationRequest.responseUri == null) {
            throw InvalidAuthorizationRequest(
                "response_uri must be provided for direct_post response mode",
                authorizationRequest.encodeToJsonObject()
            )
        }
    }

    fun constructPresentationRequest(authorizationRequest: AuthorizationRequest) =
        PresentationRequest(
            raw = authorizationRequest.encodeToJsonObject(),
            verifier = Verifier(
                clientId = authorizationRequest.clientId,
                display = VerifierDisplayProperties(
                    logoUri = null,//authorizationRequest.clientMetadata?.let { it["logo_uri"] },
                    displayName = null,//authorizationRequest.clientMetadata?.clientName,
                    userHint = null,//authorizationRequest.userHint
                ),
                jwks = null,
            ),
            request = authorizationRequest,
            query = buildQuery(authorizationRequest),
        )

    fun buildQuery(authorizationRequest: AuthorizationRequest): Query {
        var query = authorizationRequest.scope?.let {
            scopes[it]
        } ?: authorizationRequest.dcqlQuery ?: throw InvalidAuthorizationRequest(
            "No recognised scope or DCQL query was provided",
            authorizationRequest.encodeToJsonObject()
        )

        query = addClaimsForKnownCredentials(query)

        return Query(
            raw = authorizationRequest.dcqlQuery.encodeToJsonObject(),
            definition = query,
        ) { dcqlMatcher.match(query) }
    }

    /**
     * If claims is absent, the Verifier is requesting no claims that are selectively disclosable;
     * the Wallet MUST return only the claims that are mandatory to present
     * (e.g., SD-JWT and Key Binding JWT for a Credential of format IETF SD-JWT VC).
     *
     * Effectively meaning when 'claims' is not provided in the credential query, there is nothing
     * optional, whats being asked for is the credentials mandatory claims only.
     *
     * These mandatory claims are defined in the credential type spec.
     */
    fun addClaimsForKnownCredentials(dcqlQuery: DcqlQuery): DcqlQuery {
        val populatedQueries = dcqlQuery.credentials.map { query ->

            // As noted above the wallet should only populate mandatory claims when none are provided
            val walletShouldPopulate = query.claims.isNullOrEmpty()

            if (walletShouldPopulate) when (query.format) {
                "mso_mdoc" -> {
                    Logger.debug("Adding mandatory claims for mso_mdoc credential query")

                    // For an mso_mdoc the doctype can be found in the metadata.
                    val docType = query.meta?.get("doctype_value")?.jsonPrimitive?.contentOrNull

                    docType.let {
                        val mandatoryClaims = mandatoryCredentialQueries["mso_mdoc"]?.get(it)
                        query.copy(claims = mandatoryClaims)
                    }
                }

                else -> {
                    Logger.debug("No known mandatory claims for credential format: ${query.format}")
                    query
                }

            } else query
        }

        return dcqlQuery.copy(credentials = populatedQueries)
    }

    /**
     * This function handles the submission of the data to the verifier, before this happens
     * the submitted information is validated against the query.
     */
    suspend fun present(
        presentationRequest: PresentationRequest, submission: CredentialSubmission
    ): PresentationOutcome = when (presentationRequest.request.responseMode) {
        ResponseMode.FRAGMENT -> throw InvalidAuthorizationRequest(
            "Fragment response mode is not yet supported",
            presentationRequest.raw.encodeToJsonObject()
        )

        ResponseMode.QUERY -> throw InvalidAuthorizationRequest(
            "Query response mode is not yet supported",
            presentationRequest.raw.encodeToJsonObject()
        )

        ResponseMode.DIRECT_POST -> {
            val vpToken = vpTokenFactory.build(presentationRequest, submission)
            presentDirectPostVPTokenForMDoc(presentationRequest, vpToken)
        }

        ResponseMode.DIRECT_POST_JWT -> {
            val encryptionKey = selectKeyForEncryption(
                presentationRequest.request
            ) ?: throw InvalidAuthorizationRequest(
                "No suitable encryption key found in verifier JWKS",
                presentationRequest.raw.encodeToJsonObject()
            )

            // Per OID4VP spec B.2.6.1:
            // "If the response is encrypted, e.g., using direct_post.jwt, the third element MUST be
            // the JWK SHA-256 Thumbprint as defined in [RFC7638], encoded as a Byte String,
            // of the Verifier's public key used to encrypt the response."
            val (keyMgmtAlg, encAlg, verifierEncryptionJwk) = encryptionKey

            // Log the full JWK for debugging thumbprint computation
            Logger.debug("=== Verifier Encryption JWK for Thumbprint ===")
            Logger.debug("  kid: ${verifierEncryptionJwk.kid}")
            Logger.debug("  kty: ${verifierEncryptionJwk.kty}")
            Logger.debug("  crv: ${verifierEncryptionJwk.crv}")
            Logger.debug("  x: ${verifierEncryptionJwk.x}")
            Logger.debug("  y: ${verifierEncryptionJwk.y}")
            Logger.debug("  alg: ${verifierEncryptionJwk.alg}")
            Logger.debug("  use: ${verifierEncryptionJwk.use}")
            Logger.debug("=== End JWK ===")

            val jwkThumbprint = verifierEncryptionJwk.computeThumbprint()
            Logger.debug("Computed JWK Thumbprint of Verifier's encryption key for session transcript: ${jwkThumbprint.toHexString()}")

            val vpToken = vpTokenFactory.build(presentationRequest, submission, jwkThumbprint = jwkThumbprint)
            presentDirectJwtPostVPTokenForMDoc(presentationRequest, vpToken, encryptionKey)
        }

        ResponseMode.DC_API -> {
            // DC API response mode - return VP Token directly without HTTP POST
            // This path is typically invoked via DCApiOrchestrator, but can also be
            // used when processing a presentation request that specifies dc_api mode
            val vpToken = vpTokenFactory.build(presentationRequest, submission)
            PresentationOutcome.DCApiResponse(vpToken = vpToken, state = presentationRequest.request.state)
        }

        ResponseMode.DC_API_JWT -> {
            // DC API with encrypted JWT response
            val encryptionKey = selectKeyForEncryption(
                presentationRequest.request
            ) ?: throw InvalidAuthorizationRequest(
                "No suitable encryption key found in verifier JWKS for dc_api.jwt",
                presentationRequest.raw.encodeToJsonObject()
            )

            // Per OID4VP spec B.2.6.2:
            // "For the Response Mode dc_api.jwt, the third element MUST be the JWK SHA-256 Thumbprint
            // as defined in [RFC7638], encoded as a Byte String, of the Verifier's public key
            // used to encrypt the response."
            val (keyManagementAlgorithm, encryptionAlgorithm, verifierEncryptionJwk) = encryptionKey
            val jwkThumbprint = verifierEncryptionJwk.computeThumbprint()
            Logger.debug("Computed JWK Thumbprint of Verifier's encryption key for dc_api.jwt: ${jwkThumbprint.toHexString()}")

            val vpToken = vpTokenFactory.build(presentationRequest, submission, jwkThumbprint = jwkThumbprint)

            // Build and encrypt the response
            val payload = buildJsonObject {
                put("vp_token", Json.decodeFromString(JsonObject.serializer(), vpToken))
                presentationRequest.request.state?.let {
                    put("state", JsonPrimitive(it))
                }
            }
            val payloadBytes = Json {}.encodeToString(payload).encodeToByteArray()

            val jwe = jweFactory.create(
                payload = payloadBytes,
                recipientPublicKey = verifierEncryptionJwk,
                alg = keyManagementAlgorithm,
                encToUse = encryptionAlgorithm,
            )

            PresentationOutcome.DCApiResponse(vpToken = jwe, state = presentationRequest.request.state, encrypted = true)
        }
    }

    suspend fun presentDirectJwtPostVPTokenForMDoc(
        presentationRequest: PresentationRequest, vpToken: String,
        encryptionKey: Triple<String, String, Jwk>,
    ): PresentationOutcome {
        val (keyManagementAlgorithm, encryptionAlgorithm, jwk) = encryptionKey
        Logger.debug(
            "Using algorithms\nKey Management: $keyManagementAlgorithm / Encryption: $encryptionAlgorithm"
        )

        val payload = buildJsonObject {
            put("vp_token", Json.decodeFromString(JsonObject.serializer(), vpToken))
            presentationRequest.request.state?.let {
                put("state", JsonPrimitive(it))
            }
        }

        Logger.debug("Payload before encryption: $payload")

        val payloadBytes = Json {}.encodeToString(payload).encodeToByteArray()
        Logger.debug("Payload after utf8 encoding: $payload")

        val jwe = jweFactory.create(
            payload = payloadBytes,
            recipientPublicKey = jwk,
            alg = keyManagementAlgorithm,
            encToUse = encryptionAlgorithm,
        )

        Logger.debug("Responding to the initial authorization request with JWE VP Token: $jwe")

        val response = networkClient.submitForm(
            presentationRequest.request.responseUri!!,
            params = parameters {
                append("response", jwe)
            }
        )

        val responseBody = runCatching { response.bodyAsText() }.getOrNull()
        if (response.status.isSuccess()) {
            Logger.debug("VP Token successfully submitted via direct_post_jwt")
            return buildSuccessOutcome(presentationRequest, responseBody)
        }

        Logger.error(
            "direct_post_jwt submission failed: HTTP ${response.status.value} ${
                responseBody ?: "<empty body>"
            }"
        )
        handleSubmissionFailure(response.status.value, responseBody)
    }

    fun selectKeyForEncryption(
        request: AuthorizationRequest
    ): Triple<String, String, Jwk>? {
        val metadata = request.clientMetadata
        require(metadata?.jwks != null) {
            "Cannot present JWT VP Token without verifier JWKS which have not been provided"
        }

        val verifierSupportedAlgs = metadata.encryptedResponseSupportedAlgorithms
            .orEmpty()

        Logger.debug("Verifier supported encryption algorithms: $verifierSupportedAlgs")

        val supportedPublicKeys = metadata.jwks.keys.firstNotNullOfOrNull { jwk ->
            if (jwk.alg == null || jwk.use != KeyUse.ENC) null // Only encryption keys
            else {
                val supportedEncryptionAlgs = verifierSupportedAlgs.filter {
                    jweFactory.supportedEncryptionAlgorithms.contains(it)
                }.ifEmpty { null } ?: listOf("A128GCM") // Default per OpenID4VP

                // should then go onto decide the preferred encryption method, for now lets
                // stick with the first
                val encryptionAlg = supportedEncryptionAlgs.first()

                if (!jweFactory.supportedKeyManagementAlgorithms.contains(jwk.alg)) null
                else Triple(jwk.alg, encryptionAlg, jwk)
            }
        }

        if (supportedPublicKeys == null) throw InvalidAuthorizationRequest(
            "No suitable encryption key found in verifier JWKS",
            request.raw.encodeToJsonObject()
        )

        return supportedPublicKeys.also {
            Logger.debug("Using verifier JWK with kid: ${it.third.kid} for encrypting VP Token")
        }

    }

    suspend fun presentDirectPostVPTokenForMDoc(
        presentationRequest: PresentationRequest, vpToken: String
    ): PresentationOutcome {
        val response = networkClient.submitForm(
            presentationRequest.request.responseUri!!,
            params = parameters {
                append("vp_token", vpToken)
                presentationRequest.request.state?.let {
                    append("state", it)
                }
            }
        )
        val responseBody = runCatching { response.bodyAsText() }.getOrNull()
        if (response.status.isSuccess()) {
            Logger.debug("VP Token successfully submitted via direct_post")
            return buildSuccessOutcome(presentationRequest, responseBody)
        }

        Logger.error(
            "direct_post submission failed: HTTP ${response.status.value} ${
                responseBody ?: "<empty body>"
            }"
        )
        handleSubmissionFailure(response.status.value, responseBody)
    }

    private fun validateCredentialSubmission(
        submission: CredentialSubmission,
        credentialSets: List<CredentialSetQuery>? = null
    ) {
        try {
            dcqlMatcher.validateSubmission(submission, credentialSets)
        } catch (e: IllegalArgumentException) {
            throw ConstraintNotSatisfiable(
                e.message ?: "Submitted credentials do not satisfy the verifier's request"
            )
        } catch (e: IllegalStateException) {
            throw ConstraintNotSatisfiable(
                e.message ?: "Submitted credentials do not satisfy the verifier's request"
            )
        }
    }

    private fun buildSuccessOutcome(
        presentationRequest: PresentationRequest,
        responseBody: String?
    ): PresentationOutcome.Success {
        val redirectUri =
            extractRedirectUri(responseBody) ?: presentationRequest.request.redirectUri
        return PresentationOutcome.Success(redirectUri)
    }

    private fun extractRedirectUri(responseBody: String?): String? {
        val json = parseJsonObject(responseBody) ?: return null
        return json["redirect_uri"]?.jsonPrimitive?.contentOrNull
    }

    private fun handleSubmissionFailure(statusCode: Int, responseBody: String?): Nothing {
        val rejection = parseVerifierRejection(responseBody)
        if (rejection != null) throw ResponseRejected(rejection.first, rejection.second)
        val trimmedBody = responseBody?.takeIf { it.isNotBlank() }?.take(256)
        throw SubmissionFailed(statusCode, trimmedBody)
    }

    private fun parseVerifierRejection(responseBody: String?): Pair<String, String?>? {
        val json = parseJsonObject(responseBody) ?: return null
        val code = json["error"]?.jsonPrimitive?.contentOrNull ?: return null
        val description = json["error_description"]?.jsonPrimitive?.contentOrNull
        return code to description
    }

    private fun parseJsonObject(body: String?): JsonObject? {
        if (body.isNullOrBlank()) return null
        return runCatching { Json.decodeFromString(JsonObject.serializer(), body) }.getOrNull()
    }

    private fun mapPresentationFailureToOutcome(error: Throwable): PresentationOutcome =
        when (error) {
            is ResponseRejected -> PresentationOutcome.Rejected(error.code, error.description)
            is ConstraintNotSatisfiable -> PresentationOutcome.Declined(error.details)
            is SubmissionFailed -> {
                val detail = error.body?.takeIf { it.isNotBlank() }
                    ?: "HTTP ${error.httpStatus}"
                PresentationOutcome.Declined("direct_post submission failed: $detail")
            }

            is ApiException.TimeoutError -> PresentationOutcome.Declined(
                "Timed out waiting for verifier to accept the presentation."
            )

            is ApiException.NetworkError -> PresentationOutcome.Declined(
                "Network error while sending the presentation: ${error.cause?.message ?: "unknown error"}"
            )

            is ApiException.HttpError -> PresentationOutcome.Declined(
                "Verifier rejected the presentation with HTTP ${error.statusCode.value}: ${error.message ?: error.statusCode.description}"
            )

            is ApiException.SerializationError -> PresentationOutcome.Declined(
                "Unable to serialise verifier response."
            )

            is OID4VPError -> PresentationOutcome.Declined(error.message)
            else -> PresentationOutcome.Declined(
                error.message ?: "Unexpected error during presentation"
            )
        }

    private fun describeFailure(error: Throwable): String = when (error) {
        is ResponseRejected -> "Verifier rejected response (${error.code}) ${error.description.orEmpty()}"
        is SubmissionFailed -> "Submission failed (HTTP ${error.httpStatus}) ${error.body.orEmpty()}"
        is ApiException -> "Network call failed: ${error.message}"
        else -> error.message ?: error::class.simpleName ?: "unknown error"
    }
}
