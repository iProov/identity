package com.iproov.identity.proximity

import com.iproov.identity.Logger
import com.iproov.identity.api.NfcHandover
import com.iproov.identity.cryptography.KeyPair
import com.iproov.identity.models.ClaimQuery
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.DeviceResponse
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.persistence.Repository
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.ExperimentalSerializationApi
import org.multipaz.cbor.Bstr
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.CborArray
import org.multipaz.cbor.DataItem
import org.multipaz.cbor.Simple
import org.multipaz.cbor.Tagged
import org.multipaz.cbor.buildCborArray
import org.multipaz.crypto.Crypto
import org.multipaz.crypto.EcCurve
import org.multipaz.crypto.EcPrivateKey
import org.multipaz.crypto.EcPublicKey
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethodBle
import org.multipaz.mdoc.request.DeviceRequest
import org.multipaz.mdoc.role.MdocRole
import org.multipaz.mdoc.sessionencryption.SessionEncryption
import org.multipaz.mdoc.transport.MdocTransport
import org.multipaz.mdoc.transport.MdocTransportFactory
import org.multipaz.util.Constants
import org.multipaz.util.toBase64Url
import kotlin.coroutines.cancellation.CancellationException
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC


class ProximityPresentationSession internal constructor(
    private val presentationMethod: PresentationMethod,
    private val config: ProximityConfig,
    private val orchestrator: ProximityOrchestrator,
    private val repository: Repository,
    private val keyPair: KeyPair
) {

    companion object {
        private const val MDOC_STRING_PREFIX = "mdoc:"
    }


    private var transport: MdocTransport? = null
    private val transportMutex = Mutex()

    @OptIn(ExperimentalObjCRefinement::class, ExperimentalSerializationApi::class)
    @HiddenFromObjC
    val events: Flow<ProximityPresentationEvent> = channelFlow {
        var eDeviceKey: EcPrivateKey? = null //The ephemeral key for the session we are generating

        var eReaderPublicKey: EcPublicKey? = null

        var sessionInitialized = false
        // After presentation has been concluded (terminal error or completed) we don't want to send any further
        var presentationConcluded = false

        val bleConnectionMethod: MdocConnectionMethodBle

        val nfcHandover: NfcHandover?    // null for QR; populated for NFC

        lateinit var sessionEncryption: SessionEncryption
        lateinit var sessionTranscript: DataItem
        lateinit var encodedSessionTranscript: ByteArray
        lateinit var deviceEngagementBytes: ByteArray

        try {
            if (!orchestrator.isBleAvailable()) {
                throw IllegalStateException("BLE is required for proximity session")
            }
            send(ProximityPresentationEvent.Engagement.Generating)

            eDeviceKey = Crypto.createEcPrivateKey(EcCurve.P256)

            when (presentationMethod) {
                PresentationMethod.QrPresentation -> {
                    val deviceEngagement =
                        orchestrator.presentProximityEngagement(eDeviceKey.publicKey, config)
                    bleConnectionMethod = deviceEngagement.connectionMethods
                        .filterIsInstance<MdocConnectionMethodBle>()
                        .firstOrNull()
                        ?: throw IllegalStateException(
                            "Internal error: QR engagement was built without a BLE connection method."
                        )
                    deviceEngagementBytes = Cbor.encode(deviceEngagement.toDataItem())
                    val mdocUri = MDOC_STRING_PREFIX + deviceEngagementBytes.toBase64Url()
                    nfcHandover = null //QR Handover Null As per spec
                    send(ProximityPresentationEvent.Engagement.Qr.Ready(QrEngagementPayload(mdocUri)))
                }

                PresentationMethod.NfcPresentation -> {
                    val handler = NfcEngagementHandler(
                        eDeviceKey = eDeviceKey,
                        //Currently we only support Proximity over BLE - so for now, if its not offered by the reader, we throw
                        negotiatedPicker = { offered ->
                            offered.firstOrNull { it is MdocConnectionMethodBle }
                                ?: throw IllegalStateException(
                                    "No mutually-supported carrier — holder requires BLE for retrieval " +
                                            "but reader did not offer it (offered: " +
                                            "${offered.map { it::class.simpleName }})"
                                )
                        }

                    )
                    NfcEngagementRegistry.publish(handler)

                    try {
                        send(ProximityPresentationEvent.Engagement.Nfc.Ready)

                        when (val result =
                            withTimeout(config.engagementTimeout) { handler.awaitHandover() }) {
                            is NfcHandoverResult.Complete -> {
                                send(ProximityPresentationEvent.Engagement.Nfc.Completed)
                                bleConnectionMethod =
                                    result.methods.filterIsInstance<MdocConnectionMethodBle>()
                                        .firstOrNull()
                                        ?: throw IllegalStateException(
                                            "No BLE connection method established" +
                                                    "(got: ${result.methods.map { it::class.simpleName }})"
                                        )
                                deviceEngagementBytes = result.encodedDeviceEngagement.toByteArray()
                                nfcHandover = extractNfcHandover(result.handover)
                            }

                            is NfcHandoverResult.Error -> throw result.cause
                        }
                    } finally {
                        if (!handler.isComplete) {
                            handler.abort(CancellationException("Session Finalised"))
                        }
                    }
                }
            }

            val mdocTransport = MdocTransportFactory.Default.createTransport(
                connectionMethod = bleConnectionMethod,
                role = MdocRole.MDOC,
                options = MDOC_TRANSPORT_OPTIONS,
            )
            transportMutex.withLock { transport = mdocTransport }

            send(ProximityPresentationEvent.Connecting)

            withTimeout(config.engagementTimeout) {
                mdocTransport.advertise()
                mdocTransport.open(eDeviceKey.publicKey)
                Logger.debug("Transport session opened")
            }

            send(ProximityPresentationEvent.Connected)
            Logger.debug("Transport session connected")

            while (true) {
                val sessionData = withTimeout(config.sessionInactivityTimeout) {
                    mdocTransport.waitForMessage()
                }

                if (sessionData.isEmpty()) break

                if (!sessionInitialized) {
                    send(ProximityPresentationEvent.CreatingSession)

                    val eReaderKey =
                        withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_CBOR_DECODING) {
                            SessionEncryption.getEReaderKey(sessionData)
                        }

                    eReaderPublicKey = eReaderKey.publicKey

                    sessionTranscript = buildCborArray {
                        add(Tagged(Tagged.ENCODED_CBOR, Bstr(deviceEngagementBytes)))
                        add(Tagged(Tagged.ENCODED_CBOR, Bstr(eReaderKey.encodedCoseKey)))
                        add(
                            when (val h = nfcHandover) {
                                null -> Simple.NULL
                                else -> buildCborArray {
                                    add(Bstr(h.handoverSelect))
                                    add(h.handoverRequest?.let { Bstr(it) } ?: Simple.NULL)
                                }
                            }
                        )
                    }
                    encodedSessionTranscript = Cbor.encode(sessionTranscript)

                    sessionEncryption =
                        withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_SESSION_ENCRYPTION) {
                            SessionEncryption(
                                role = MdocRole.MDOC,
                                eSelfKey = eDeviceKey,
                                remotePublicKey = eReaderPublicKey,
                                encodedSessionTranscript = encodedSessionTranscript,
                            )
                        }

                    sessionInitialized = true

                    send(ProximityPresentationEvent.SessionCreated)
                }

                val (decryptedMsgResponse, status) = withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_SESSION_ENCRYPTION) {
                    sessionEncryption.decryptMessage(sessionData)
                }

                if (status == Constants.SESSION_DATA_STATUS_SESSION_TERMINATION) {
                    break
                }
                if (status != null) {
                    throw IllegalStateException("Reader reported unexpected status: $status")
                }

                if (decryptedMsgResponse == null) throw IllegalStateException("Decrypted request payload was null")

                val deviceRequest =
                    withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_CBOR_DECODING) {
                        DeviceRequest.fromDataItem(Cbor.decode(decryptedMsgResponse))
                    }

                val readerAuthResult = when (
                    val outcome = ReaderAuthVerifier.verify(
                        deviceRequest = deviceRequest,
                        sessionTranscript = sessionTranscript,
                        trustedRoots = config.trustedReaderCertificates,
                        policy = config.readerTrust,
                    )
                ) {
                    is ReaderAuthVerifier.VerificationOutcome.Accepted -> outcome.result
                    is ReaderAuthVerifier.VerificationOutcome.Rejected -> {
                        terminateTransport()
                        send(
                            ProximityPresentationEvent.Failure(
                                outcome.reason,
                                IllegalStateException(outcome.reason),
                            )
                        )
                        return@channelFlow
                    }
                }

                val docRequests = deviceRequest.toRespondable()
                val respondable = RespondableProximityRequest(
                    docRequests = docRequests,
                    readerAuth = readerAuthResult,
                    responseHandler = { disclosed ->
                        val outcome = try {
                            val documents = disclosed.map { (docRequest, item) ->
                                item.credential to buildClaims(docRequest, item)
                            }
                            val requestedDocTypes = docRequests.map { it.docType }.toSet()
                            val fulfilledDocTypes = disclosed.keys.map { it.docType }.toSet()
                            val unfulfilled =
                                (requestedDocTypes - fulfilledDocTypes).associateWith { 0 }

                            val responseBytes = DeviceResponse.buildForProximity(
                                documents = documents,
                                deviceKeyPair = keyPair,
                                encodedSessionTranscript = encodedSessionTranscript,
                                documentErrors = unfulfilled,
                            )

                            val encrypted =
                                withFailureStatus(Constants.SESSION_DATA_STATUS_ERROR_SESSION_ENCRYPTION) {
                                    sessionEncryption.encryptMessage(
                                        messagePlaintext = responseBytes,
                                        statusCode = null,
                                    )
                                }

                            mdocTransport.sendMessage(encrypted)
                            ProximityResponseOutcome.Sent()
                        } catch (e: SessionDataStatusError) {
                            terminateTransport(e.statusCode)
                            ProximityResponseOutcome.Failure(e.cause ?: e)
                        } catch (e: Exception) {
                            terminateTransport()
                            ProximityResponseOutcome.Failure(e)
                        }

                        when (outcome) {
                            is ProximityResponseOutcome.Sent ->
                                send(ProximityPresentationEvent.PresentationSent)

                            is ProximityResponseOutcome.Failure ->
                                send(
                                    ProximityPresentationEvent.Failure(
                                        outcome.cause.message ?: "send failed", outcome.cause
                                    )
                                )
                        }

                        presentationConcluded = true
                        return@RespondableProximityRequest outcome
                    },
                    matchHandler = { matchCredentials(docRequests) },
                )
                send(ProximityPresentationEvent.RequestReceived(respondable))
            }
            send(ProximityPresentationEvent.Disconnected)

        } catch (e: SessionDataStatusError) {
            terminateTransport(e.statusCode)
            send(
                ProximityPresentationEvent.Failure(
                    e.cause?.message ?: "session error",
                    e.cause ?: e
                )
            )
        } catch (e: TimeoutCancellationException) {
            terminateTransport()
            // After a delivered response, an idle reader tripping the inactivity timeout
            // is a normal end-of-session, not a failure — don't surface it over the success.
            if (!presentationConcluded) {
                send(ProximityPresentationEvent.Failure("Session timed out", e))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            terminateTransport()
            // Likewise, a transport teardown after the response was handled is expected.
            if (!presentationConcluded) {
                val errorMsg = e.message
                    ?: e.cause?.message
                    ?: (e::class.simpleName ?: "Unknown error")
                send(ProximityPresentationEvent.Failure(errorMsg, e))
            }
        } finally {
            eDeviceKey?.d?.fill(0)
            terminateTransport()
        }
    }

    suspend fun close() {
        terminateTransport()
    }

    private suspend fun terminateTransport(
        code: Long = Constants.SESSION_DATA_STATUS_SESSION_TERMINATION,
    ) {
        transportMutex.withLock {
            transport?.let { t ->
                runCatching { t.sendMessage(SessionEncryption.encodeStatus(code)) }
                runCatching { t.close() }
                transport = null
            }
        }
    }

    private suspend fun matchCredentials(
        docRequests: List<DocRequest>,
    ): Map<DocRequest, List<DisclosedDocument>> {
        val credentialMetadata: List<CredentialMetadata> = repository.getCredentialMetadata()
        if (credentialMetadata.isEmpty()) return docRequests.associateWith { emptyList() }

        val mdocPairs: List<Pair<CredentialMetadata, MDocCredential>> =
            repository.getCredentials(credentialMetadata.filter { it.format == "mso_mdoc" })
                .credentials
                .mapNotNull { (meta, cred) ->
                    (cred as? MDocCredential)?.let { meta to it }
                }

        return docRequests.associateWith { request ->
            mdocPairs
                .filter { (_, cred) -> cred.docType == request.docType }
                .map { (meta, cred) -> DisclosedDocument(credential = cred, metadata = meta) }
        }
    }

    private fun buildClaims(docRequest: DocRequest, item: DisclosedDocument): List<ClaimQuery> {
        val plan: Map<String, Set<String>> = item.disclosedItems
            ?: docRequest.requestedItems.mapValues { (_, items) ->
                items.map { it.elementIdentifier }.toSet()
            }
        return plan.flatMap { (ns, elements) ->
            elements.map { ClaimQuery(path = listOf(ns, it)) }
        }
    }

    private fun DeviceRequest.toRespondable(): List<DocRequest> {
        return docRequests.map { req ->
            DocRequest(
                docType = req.docType,
                requestedItems = req.nameSpaces.mapValues { (_, items) ->
                    items.map { (id, intentToRetain) -> RequestedItem(id, intentToRetain) }
                },
            )
        }
    }

    private fun extractNfcHandover(handover: DataItem): NfcHandover {
        // Multipaz may return negotiated handover as [select, request] and static handover
        // as either [select] or [select, null]. We normalize later when building
        // SessionTranscript so static handover is signed as [select, null].
        val array = (handover as? CborArray)?.items
            ?: throw IllegalStateException("Expected handover to be a CBOR array, got ${handover::class.simpleName}")

        require(array.size in 1..2) { "Unexpected handover array size: ${array.size}" }

        val select = (array[0] as? Bstr)?.value
            ?: throw IllegalStateException("handoverSelect: expected Bstr at array[0], got ${array[0]::class.simpleName}")

        val request = array.getOrNull(1)?.let { item ->
            when (item) {
                Simple.NULL -> null
                is Bstr -> item.value
                else -> throw IllegalStateException(
                    "handoverRequest: expected Bstr or null at array[1], got ${item::class.simpleName}"
                )
            }
        }
        return NfcHandover(handoverSelect = select, handoverRequest = request)
    }

    private inline fun <T> withFailureStatus(statusCode: Long, block: () -> T): T =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            throw SessionDataStatusError(statusCode, e)
        }
}

private class SessionDataStatusError(val statusCode: Long, cause: Throwable) : Exception(cause)
