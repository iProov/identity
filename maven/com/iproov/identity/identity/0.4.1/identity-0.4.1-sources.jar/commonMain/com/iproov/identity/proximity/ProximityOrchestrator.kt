package com.iproov.identity.proximity

import com.iproov.identity.Base64Utils.decodeFromBase64Url
import kotlinx.serialization.ExperimentalSerializationApi
import org.multipaz.cbor.Cbor
import org.multipaz.crypto.EcPublicKey
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethodBle
import org.multipaz.mdoc.engagement.DeviceEngagement
import org.multipaz.mdoc.engagement.buildDeviceEngagement
import org.multipaz.util.UUID

/**
 * Internal abstraction over the platform proximity machinery (BLE + NFC HCE per
 * ISO 18013-5 §8). Owned by [com.iproov.identity.Wallet]; consumers interact via Wallet methods.
 */
internal interface ProximityOrchestrator {

    /** True if the device supports BLE for proximity (ISO 18013-5 §8.3.3.1.1). */
    fun isBleAvailable(): Boolean

    /** True if the device supports NFC HCE (ISO 18013-5 §8.2.2.1). */
    fun isNfcHceAvailable(): Boolean

    /** True if NFC is currently enabled in user settings (vs hardware availability above). */
    fun isNfcHceEnabled(): Boolean

    /** True if the device can perform reader-side NFC scanning (ISO 18013-5 §8.2.2 reader side). */
    fun isNfcReaderAvailable(): Boolean

    /**
     * The platform NFC engagement handle. Throws [NfcEngagementUnavailableException]
     * on platforms without HCE support (currently every iOS device).
     */
    fun nfcEngagement(): NfcEngagement

    suspend fun retrieveProximityEngagement(uri: String): DeviceEngagement

    suspend fun presentProximityEngagement(
        publicKey: EcPublicKey,
        config: ProximityConfig
    ): DeviceEngagement
}

/**
 * Internal NFC HCE lifecycle (ISO 18013-5 §8.2.2.1). Driven by the host activity via
 * [com.iproov.identity.Wallet.enableNfcEngagement] / [com.iproov.identity.Wallet.disableNfcEngagement].
 */
internal interface NfcEngagement {

    /** True while [enable] has been called and not [disable]d. */
    val isEnabled: Boolean

    /**
     * True if this app declares an IsoMdocHceService HostApduService for the mdoc NDEF
     * AID under category 'other'. When false, reader taps never route to the SDK, so an
     * NFC presentation would hang until the engagement timeout rather than failing fast.
     */
    val isServiceRegistered: Boolean

    /** Activate NFC card emulation. Call from the host activity's `onResume`. */
    fun enable(): Boolean

    /** Deactivate NFC card emulation. Call from the host activity's `onPause`. */
    fun disable()
}

/**
 * Default [ProximityOrchestrator] backed by platform expect/actuals — BLE checks via
 * [isProximityPlatformAvailable], NFC HCE via [createPlatformNfcEngagement].
 */
internal class DefaultProximityOrchestrator() : ProximityOrchestrator {

    /** Lazy so the NFC factory's throw is deferred to first access — the orchestrator
     * itself constructs cleanly on platforms without HCE. */
    private val nfcLazy: Lazy<NfcEngagement> = lazy { createPlatformNfcEngagement() }

    override fun isBleAvailable(): Boolean = isProximityPlatformAvailable()

    override fun isNfcHceAvailable(): Boolean = com.iproov.identity.proximity.isNfcHceAvailable()

    override fun isNfcHceEnabled(): Boolean = isNfcAdapterEnabled()

    override fun isNfcReaderAvailable(): Boolean =
        com.iproov.identity.proximity.isNfcReaderAvailable()

    @OptIn(ExperimentalSerializationApi::class)
    override suspend fun presentProximityEngagement(
        publicKey: EcPublicKey,
        config: ProximityConfig,
    ): DeviceEngagement {
        return buildDeviceEngagement(publicKey) {
            addConnectionMethod(createBleConnectionMethod(config))
        }
    }

    /**
     * Parses an `mdoc:<base64url(CBOR DeviceEngagement)>` URI per ISO 18013-5 §8.2.2.3
     * (single colon, no `//`, RFC 4648 base64url-without-padding).
     */
    @OptIn(ExperimentalSerializationApi::class)
    override suspend fun retrieveProximityEngagement(uri: String): DeviceEngagement {
        val colonIndex = uri.indexOf(':')
        if (colonIndex < 0 || uri.substring(0, colonIndex).lowercase() != MDOC_STRING_PREFIX) {
            throw Exception("Invalid URI: expected mdoc: scheme")
        }

        val payload = uri.substring(colonIndex + 1)

        val bytes = payload.decodeFromBase64Url()
        val dataItem = Cbor.decode(bytes)

        val engagement = DeviceEngagement.fromDataItem(dataItem)

        // Right now we only support -5 (offline sharing)
        if (engagement.version != SUPPORTED_VERSION) {
            throw Exception("Only offline proximity sharing is supported.")
        }

        return engagement
    }

    override fun nfcEngagement(): NfcEngagement = nfcLazy.value

    private fun createBleConnectionMethod(config: ProximityConfig): MdocConnectionMethodBle {
        // Size of bleRoles is enforced to be exactly 1 by ProximityConfig.init.
        return when (config.bleRoles.single()) {
            ProximityBLERole.PeripheralServer -> {
                if (!isBleAvailable()) {
                    throw BleEngagementUnavailableException(
                        "BLE peripheral mode requested but not supported on this device"
                    )
                }
                MdocConnectionMethodBle(
                    supportsPeripheralServerMode = true,
                    supportsCentralClientMode = false,
                    peripheralServerModeUuid = UUID.randomUUID(),
                    centralClientModeUuid = null,
                )
            }

            ProximityBLERole.CentralClient -> MdocConnectionMethodBle(
                supportsPeripheralServerMode = false,
                supportsCentralClientMode = true,
                peripheralServerModeUuid = null,
                centralClientModeUuid = UUID.randomUUID(),
            )
        }
    }

    companion object {
        private val MDOC_STRING_PREFIX = "mdoc"
        private val SUPPORTED_VERSION = "1.0"
    }

}

sealed class ProximityException(message: String) : Exception(message)

/**
 * Thrown when BLE peripheral mode isn't supported (ISO 18013-5 §8.3.3.1.1).
 * Gate calls with [com.iproov.identity.Wallet.isBleAvailable].
 */
class BleEngagementUnavailableException(message: String) : ProximityException(message)

/**
 * Thrown when NFC HCE is unavailable (no hardware, no `FEATURE_NFC_HOST_CARD_EMULATION`,
 * or NFC disabled). Gate with [com.iproov.identity.Wallet.isNfcHceAvailable] + [com.iproov.identity.Wallet.isNfcHceEnabled].
 */
class NfcEngagementUnavailableException(message: String) : ProximityException(message)

/** Thrown when neither BLE nor NFC HCE is available on the device. */
class ProximityNotSupportedException(
    message: String = "Proximity is not supported on this device (no BLE peripheral mode or NFC HCE)."
) : ProximityException(message)

/**
 * QR engagement URI per ISO 18013-5 §8.2.2.3: `mdoc:<base64url-without-padding(CBOR DeviceEngagement)>`.
 * Render via platform QR libraries.
 */
data class QrEngagementPayload(val mdocUri: String)
