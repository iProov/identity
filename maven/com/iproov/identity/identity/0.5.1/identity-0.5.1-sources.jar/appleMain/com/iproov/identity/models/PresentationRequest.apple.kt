package com.iproov.identity.models

val PresentationRequest.raw get() = this.raw.toNativeTypes()