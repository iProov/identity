package com.iproov.identity.models

val MDocCredential.body: Map<String, Any?> get() = body.toMap().mapValues { it.value.toNativeTypes() }