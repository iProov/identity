package com.iproov.identity.models

import kotlinx.coroutines.Deferred
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

class InvalidLoginRequestFormatException(message: String) : Exception(message)

open class LoginRequest protected constructor(
    val translations: Map<String, String?>,
    val claims: List<RequestedClaim>,
    val acrs: List<String>,
    val relyingParty: LegacyRelyingParty,
    val json: JsonObject,
    val jwt: Jwt // Add the jwt to the primary constructor
) {
    val reverificationJwts: MutableList<Jwt> = mutableListOf()

    constructor(jwt: Jwt, translations: Map<String, String?>) : this(
        translations = translations,
        claims = parseClaims(jwt, translations),
        acrs = parseAcrs(jwt),
        relyingParty = parseRelyingParty(jwt),
        json = jwt.body,
        jwt = jwt
    )

    companion object {
        private fun parseClaims(
            jwt: Jwt,
            translations: Map<String, String?>
        ): List<RequestedClaim> {
            val jsonClaims = jwt.body["claims"]?.jsonObject
                ?: throw InvalidLoginRequestFormatException("Login request should have claims of type Map in body but doesn't.")

            return jsonClaims.entries.filter { it.key != "acr" }.map { entry ->
                val claimObject = entry.value.jsonObject
                RequestedClaim(
                    entry.key,
                    translations[entry.key],
                    isEssential = claimObject["essential"]?.jsonPrimitive?.booleanOrNull == true,
                    values = claimObject["values"]?.jsonArray?.map { it.jsonPrimitive.content }
                        ?: emptyList()
                )
            }
        }

        private fun parseAcrs(jwt: Jwt): List<String> {
            val claims = jwt.body["claims"]?.jsonObject
                ?: throw InvalidLoginRequestFormatException("Login request should have claims of type Map in body but doesn't.")
            val acr = (claims["acr"]?.jsonObject)?.get("values")?.jsonArray
                ?: throw InvalidLoginRequestFormatException("No list of acr in the login request")
            return acr.map { it.jsonPrimitive.content }
        }

        private fun parseRelyingParty(jwt: Jwt): LegacyRelyingParty {
            val rp = jwt.body["relyingPartyRequest"]?.jsonObject
                ?: throw InvalidLoginRequestFormatException("Login request should have relying party of type Map in body but doesn't")
            val withUnknownKeys = Json {
                ignoreUnknownKeys = true
            }
            return withUnknownKeys.decodeFromJsonElement<LegacyRelyingParty>(rp)
        }
    }

    override fun toString(): String {
        return json.toString()
    }
}


data class RequestedClaim(
    val name: String,
    val displayName: String?,
    val isEssential: Boolean,
    val values: List<String>?
)

class RespondableLoginRequest private constructor(
    jwt: Jwt,
    translations: Map<String, String?>,
    var reverifications: List<ReverificationRequest>,
    private val onAccept: (List<Jwt>) -> Deferred<LoginResponse>,
    private val onDeny: () -> Deferred<Nothing?>,
) : LoginRequest(jwt, translations) {

    companion object {
        fun fromLoginRequest(
            loginRequest: LoginRequest,
            reverifications: List<ReverificationRequest>,
            accept: (List<Jwt>) -> Deferred<LoginResponse>,
            deny: () -> Deferred<Nothing?>,
        ): RespondableLoginRequest =
            RespondableLoginRequest(
                loginRequest.jwt,
                loginRequest.translations,
                reverifications,
                accept,
                deny
            )
    }

    @Throws(Exception::class)
    suspend fun deny(): Nothing? = onDeny().await()

    @Throws(Exception::class)
    suspend fun accept(claims: List<Claim>): LoginResponse =
        onAccept(claims.map { it.jwt } + reverificationJwts).await()
}

@Serializable
data class LegacyRelyingParty(
    @SerialName("logo_uri") val logoUri: String,
    val name: String,
    val description: String,
    val reason: String
)

@Serializable
data class LoginResponse(@SerialName("redirect_uri") val redirectUri: String? = null)