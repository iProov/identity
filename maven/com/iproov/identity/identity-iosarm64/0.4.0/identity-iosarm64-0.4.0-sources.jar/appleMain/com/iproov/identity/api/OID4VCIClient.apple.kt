package com.iproov.identity.api

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.OID4VCIAuthorizationPreparation
import com.iproov.identity.OID4VCICredentialConfiguration
import com.iproov.identity.OID4VCIDisplayProperties
import com.iproov.identity.OID4VCIPublicKeyInfo
import com.iproov.identity.OID4VCIResolvedOffer
import com.iproov.identity.OID4VCIStepCreatingAccessToken
import com.iproov.identity.OID4VCIStepResolvingOfferedCredentials
import com.iproov.identity.OID4VCIStepRetrievingBatchCredentials
import com.iproov.identity.OID4VCIStepRetrievingCredentialOffer
import com.iproov.identity.OID4VCIStepRetrievingCredentials
import com.iproov.identity.OID4VCIStepRetrievingIssuerMetadata
import com.iproov.identity.cryptography.signRs
import com.iproov.identity.cryptography.toByteArray
import com.iproov.identity.cryptography.toNSData
import com.iproov.identity.models.CredentialDescriptor
import com.iproov.identity.models.CredentialIssuer
import com.iproov.identity.models.CredentialOffer
import com.iproov.identity.models.DisplayProperties
import com.iproov.identity.models.GrantDetails
import com.iproov.identity.models.OID4VCICredentialError
import com.iproov.identity.models.OID4VCIException
import com.iproov.identity.models.TxCode
import com.iproov.identity.models.TxInputMode
import com.iproov.identity.models.credentialConfigurationIds
import com.iproov.identity.models.resolveOfferedCredentials
import com.iproov.identity.models.toNativeTypes
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import platform.Foundation.NSData
import platform.Foundation.NSError
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import com.iproov.identity.OID4VCIClient as SwiftOID4VCIClient
import com.iproov.identity.OID4VCICredentialError as SwiftOID4VCICredentialError
import com.iproov.identity.OID4VCIIssuanceResult as SwiftIssuanceResult

/**
 * Apple platform implementation of OID4VCIClient using the EU Digital Identity library via Swift bridge.
 */
@OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
internal class AppleOID4VCIClient(
    private val keyPairFactory: KeyPairFactory,
    private val networkClient: NetworkClient
) : OID4VCIClient {

    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    // Cache the resolved offer for use in issuance
    private var cachedResolvedOffer: OID4VCIResolvedOffer? = null

    // Cached state for authorization code flow (needed across prepare → issue steps)
    private var cachedKeyPair: com.iproov.identity.cryptography.KeyPair? = null

    init {
        SwiftOID4VCIClient.setIsLoggingEnabled(Logger.isEnabled)
    }

    @Throws(Exception::class)
    override suspend fun resolveOffer(uri: String): CredentialOffer {
        Logger.info("Resolving credential offer from URI via Swift bridge")

        return suspendCancellableCoroutine { continuation ->
            SwiftOID4VCIClient.resolveOfferWithUri(uri) @Throws(Exception::class) { resolvedOffer, error ->
                if (error != null) {
                    val exception = mapNSErrorToException(error)
                    continuation.resumeWithException(exception)
                } else if (resolvedOffer != null) {
                    cachedResolvedOffer = resolvedOffer
                    val offer = mapResolvedOfferToCredentialOffer(resolvedOffer)
                    continuation.resume(offer)
                } else {
                    continuation.resumeWithException(
                        OID4VCIException.RetrievingCredentialOffer(
                            "Unknown error",
                            "Resolution returned null without error",
                            Exception("Null result")
                        )
                    )
                }
            }
        }
    }

    @Throws(Exception::class)
    override suspend fun resolveOffer(json: JsonObject): CredentialOffer {
        Logger.info("Resolving credential offer from JSON via Swift bridge")
        Logger.debug("[resolveOffer] Credential offer JSON: $json")
        val jsonString = Json.encodeToString(json)
        Logger.debug("[resolveOffer] Credential offer JSON STRING: $jsonString")

        return suspendCancellableCoroutine { continuation ->
            SwiftOID4VCIClient.resolveOfferFromJsonWithJsonString(jsonString) @Throws(Exception::class) { resolvedOffer, error ->
                if (error != null) {
                    val exception = mapNSErrorToException(error)
                    Logger.error("[resolveOffer] Error resolving offer: ${exception.message}")
                    continuation.resumeWithException(exception)
                } else if (resolvedOffer != null) {
                    cachedResolvedOffer = resolvedOffer
                    val offer = mapResolvedOfferToCredentialOffer(resolvedOffer)
                    continuation.resume(offer)
                } else {
                    Logger.error("[resolveOffer] Resolution returned null without error")
                    continuation.resumeWithException(
                        OID4VCIException.RetrievingCredentialOffer(
                            "Unknown error",
                            "Resolution returned null without error",
                            Exception("Null result")
                        )
                    )
                }
            }
        }
    }

    @Throws(Exception::class)
    override suspend fun issueCredentials(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
        transactionCode: String?
    ): OID4VCIIssuanceResult {
        Logger.info("Issuing ${credentials.size} credentials via Swift bridge")

        Logger.info("Requesting ${credentials.map { it.raw.toNativeTypes() }} credentials ")

        val resolvedOffer = cachedResolvedOffer ?: throw OID4VCIException.RetrievingCredential(
            url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
            error = "invalid_state",
            description = "No cached resolved offer found. Call resolveOffer first."
        )

        // Get public key info from key pair
        val keyPair = keyPairFactory()
        val publicKey = keyPair.getJwk()
        val publicKeyInfo = OID4VCIPublicKeyInfo(
            kty = publicKey.jwk.kty,
            crv = publicKey.jwk.crv,
            x = publicKey.jwk.x,
            y = publicKey.jwk.y,
            alg = publicKey.alg,
            keyId = publicKey.jwk.keyId
        )

        // Create credential config IDs list
        val configIds = credentials.map { it.id }

        // Create signer callback that bridges to Kotlin signing
        val signerCallback: (NSData?, ((NSData?, NSError?) -> Unit?)?) -> Unit =
            { dataToSign, completion ->
                try {
                    Logger.debug("Signing request received from Swift (alg: ${publicKey.alg})")
                    val dataBytes = dataToSign?.toByteArray()
                    val signature = keyPair.signRs(dataBytes ?: ByteArray(0))
                    completion?.invoke(signature.toNSData(), null)
                } catch (e: Exception) {
                    Logger.error("Signing failed: ${e.message}")
                    val nsError = NSError.errorWithDomain(
                        "com.iproov.identity.signing",
                        code = -1,
                        userInfo = mapOf("NSLocalizedDescriptionKey" to (e.message ?: "Signing failed"))
                    )
                    completion?.invoke(null, nsError)
                }
            }

        return suspendCancellableCoroutine { continuation ->
            SwiftOID4VCIClient.issueCredentialsWithOffer(
                offer = resolvedOffer,
                credentialConfigIds = configIds,
                transactionCode = transactionCode,
                publicKeyInfo = publicKeyInfo,
                signerCallback = signerCallback
            ) @Throws(Exception::class) { result, error ->
                if (error != null) {
                    val exception = mapNSErrorToException(error)
                    continuation.resumeWithException(exception)
                } else if (result != null) {
                    val issuanceResult = mapSwiftIssuanceResult(credentials, result)
                    continuation.resume(issuanceResult)
                } else {
                    continuation.resumeWithException(
                        OID4VCIException.RetrievingCredential(
                            url = offer.issuer.credentialEndpoint ?: "",
                            error = "unknown_error",
                            description = "Issuance returned null without error"
                        )
                    )
                }
            }
        }
    }

    @Throws(Exception::class)
    override suspend fun prepareAuthorizationRequest(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
    ): AuthorizationPreparation {
        Logger.info("Preparing authorization request via Swift bridge")

        val resolvedOffer = cachedResolvedOffer ?: throw OID4VCIException.RetrievingCredential(
            url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
            error = "invalid_state",
            description = "No cached resolved offer found. Call resolveOffer first."
        )

        // Cache key pair for reuse in issueCredentialsWithAuthCode to ensure the same
        // cryptographic key is used for both DPoP binding and credential proof-of-possession
        val keyPair = keyPairFactory()
        cachedKeyPair = keyPair

        val publicKey = keyPair.getJwk()
        val publicKeyInfo = OID4VCIPublicKeyInfo(
            kty = publicKey.jwk.kty,
            crv = publicKey.jwk.crv,
            x = publicKey.jwk.x,
            y = publicKey.jwk.y,
            alg = publicKey.alg,
            keyId = publicKey.jwk.keyId
        )
        val configIds = credentials.map { it.id }

        return suspendCancellableCoroutine { continuation ->
            SwiftOID4VCIClient.prepareAuthorizationRequestWithOffer(
                offer = resolvedOffer,
                credentialConfigIds = configIds,
                publicKeyInfo = publicKeyInfo,
                signerCallback = createSignerCallback(keyPair)
            ) @Throws(Exception::class) { preparation, error ->
                if (error != null) {
                    val exception = mapNSErrorToException(error)
                    continuation.resumeWithException(exception)
                } else if (preparation != null) {
                    continuation.resume(
                        AuthorizationPreparation(
                            authorizationUrl = preparation.authorizationUrl(),
                            platformState = preparation,
                        )
                    )
                } else {
                    continuation.resumeWithException(
                        OID4VCIException.CreatingAccessToken(
                            "unknown_error",
                            "Authorization preparation returned null without error"
                        )
                    )
                }
            }
        }
    }

    @Throws(Exception::class)
    override suspend fun issueCredentialsWithAuthCode(
        offer: CredentialOffer,
        authorizationCode: String,
        preparation: AuthorizationPreparation,
        credentials: List<CredentialDescriptor>,
    ): OID4VCIIssuanceResult {
        Logger.info("Issuing ${credentials.size} credentials with authorization code via Swift bridge")

        val resolvedOffer = cachedResolvedOffer ?: throw OID4VCIException.RetrievingCredential(
            url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
            error = "invalid_state",
            description = "No cached resolved offer found. Call resolveOffer first."
        )

        val swiftPreparation = preparation.platformState as? OID4VCIAuthorizationPreparation
            ?: throw OID4VCIException.RetrievingCredential(
                url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
                error = "invalid_state",
                description = "Expected OID4VCIAuthorizationPreparation but got ${
                    preparation.platformState::class.simpleName ?: "unknown"
                }. Ensure the same client instance is used for prepare and issue."
            )

        // Reuse the key pair from prepareAuthorizationRequest() to ensure the same
        // cryptographic key is used for DPoP binding and credential proof-of-possession
        val keyPair = cachedKeyPair ?: throw OID4VCIException.RetrievingCredential(
            url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
            error = "invalid_state",
            description = "No cached key pair found. Call prepareAuthorizationRequest first."
        )

        val publicKey = keyPair.getJwk()
        val publicKeyInfo = OID4VCIPublicKeyInfo(
            kty = publicKey.jwk.kty,
            crv = publicKey.jwk.crv,
            x = publicKey.jwk.x,
            y = publicKey.jwk.y,
            alg = publicKey.alg,
            keyId = publicKey.jwk.keyId
        )

        val configIds = credentials.map { it.id }

        try {
            return suspendCancellableCoroutine { continuation ->
                SwiftOID4VCIClient.issueCredentialsWithAuthCodeWithOffer(
                    offer = resolvedOffer,
                    authorizationCode = authorizationCode,
                    preparation = swiftPreparation,
                    credentialConfigIds = configIds,
                    publicKeyInfo = publicKeyInfo,
                    signerCallback = createSignerCallback(keyPair)
                ) @Throws(Exception::class) { result, error ->
                    if (error != null) {
                        val exception = mapNSErrorToException(error)
                        continuation.resumeWithException(exception)
                    } else if (result != null) {
                        val issuanceResult = mapSwiftIssuanceResult(credentials, result)
                        continuation.resume(issuanceResult)
                    } else {
                        continuation.resumeWithException(
                            OID4VCIException.RetrievingCredential(
                                url = offer.issuer.credentialEndpoint ?: "",
                                error = "unknown_error",
                                description = "Auth code issuance returned null without error"
                            )
                        )
                    }
                }
            }
        } finally {
            cachedKeyPair = null
        }
    }

    private fun createSignerCallback(
        keyPair: com.iproov.identity.cryptography.KeyPair
    ): (NSData?, ((NSData?, NSError?) -> Unit?)?) -> Unit = { dataToSign, completion ->
        try {
            val dataBytes = dataToSign?.toByteArray()
            val signature = keyPair.signRs(dataBytes ?: ByteArray(0))
            completion?.invoke(signature.toNSData(), null)
        } catch (e: Exception) {
            Logger.error("Signing failed: ${e.message}")
            val nsError = NSError.errorWithDomain(
                "com.iproov.identity.signing",
                code = -1,
                userInfo = mapOf("NSLocalizedDescriptionKey" to (e.message ?: "Signing failed"))
            )
            completion?.invoke(null, nsError)
        }
    }

    private fun mapResolvedOfferToCredentialOffer(resolved: OID4VCIResolvedOffer): CredentialOffer {
        val rawOffer = parseJsonOrEmpty(resolved.rawOfferJson())

        // Map issuer
        val issuerInfo = resolved.issuer()
        val issuer = CredentialIssuer(
            raw = parseJsonOrEmpty(issuerInfo.rawMetadataJson()),
            name = issuerInfo.identifier(),
            tokenEndpoint = issuerInfo.tokenEndpoint(),
            credentialEndpoint = issuerInfo.credentialEndpoint(),
            jwksEndpoint = null,
            display = mapDisplayProperties(issuerInfo.displayProperties() as? List<OID4VCIDisplayProperties>),
            tokenSupportedSigningAlgorithms = if (issuerInfo.supportsDPoP()) {
                issuerInfo.dpopSigningAlgorithms().filterIsInstance<String>().toSet()
            } else null,
            tokenSupportedAuthenticationMethods = null
        )

        // Map credentials
        val availableCredentials = (resolved.credentialConfigurations() as? List<OID4VCICredentialConfiguration>)
            ?.map { config ->
                CredentialDescriptor(
                    id = config.configurationId(),
                    raw = parseJsonOrEmpty(config.rawJson()),
                    format = config.format(),
                    scope = config.scope(),
                    display = mapDisplayProperties(config.displayProperties() as? List<OID4VCIDisplayProperties>)
                )
            } ?: emptyList()
        val offeredConfigurationIds = rawOffer.credentialConfigurationIds()
        val credentials = if (offeredConfigurationIds.isNotEmpty()) {
            resolveOfferedCredentials(
                offeredConfigurationIds = offeredConfigurationIds,
                availableCredentials = availableCredentials,
            )
        } else {
            availableCredentials
        }

        // Map transaction code details
        val txCode = resolved.transactionCodeDetails()?.let { details ->
            TxCode(
                inputMode = when (details.inputMode()) {
                    com.iproov.identity.OID4VCITxInputModeNumeric -> TxInputMode.numeric
                    com.iproov.identity.OID4VCITxInputModeText -> TxInputMode.text
                    else -> TxInputMode.numeric
                },
                length = details.length()?.intValue,
                description = details.descriptionText()
            )
        }

        // Map grants
        val grantsMap = resolved.grants() as? Map<String, String>
        val grants = if (grantsMap != null) {
            buildMap {
                grantsMap["urn:ietf:params:oauth:grant-type:pre-authorized_code"]?.let { preAuthCode ->
                    put(
                        "urn:ietf:params:oauth:grant-type:pre-authorized_code",
                        GrantDetails(preAuthorizedCode = preAuthCode)
                    )
                }
                if (grantsMap.containsKey("authorization_code")) {
                    put(
                        "authorization_code",
                        GrantDetails(issuerState = grantsMap["authorization_code"]?.takeIf { it.isNotEmpty() })
                    )
                }
            }
        } else if (resolved.preAuthorizedCode() != null) {
            mapOf(
                "urn:ietf:params:oauth:grant-type:pre-authorized_code" to GrantDetails(
                    preAuthorizedCode = resolved.preAuthorizedCode()
                )
            )
        } else {
            emptyMap()
        }

        return CredentialOffer(
            raw = rawOffer,
            preAuthorizedCode = resolved.preAuthorizedCode(),
            transactionCodeDetails = txCode,
            grants = grants,
            credentials = credentials,
            issuer = issuer,
        )
    }

    private fun mapSwiftIssuanceResult(
        offeredCredential: List<CredentialDescriptor>,
        result: SwiftIssuanceResult,
    ): OID4VCIIssuanceResult {
        // Map issued credentials — iterate all items per configuration, not just the first
        val credentials = result.credentials().flatMap { (configIdAny, issuedAny) ->
            Logger.debug("Mapping issued credential for configId: $configIdAny, issued: $issuedAny")
            val configId = configIdAny as? String ?: return@flatMap emptyList()
            val issuedList = issuedAny as? List<*> ?: return@flatMap emptyList()

            issuedList.mapNotNull { issuedItem ->
                val issued = issuedItem as? com.iproov.identity.OID4VCIIssuedCredential
                    ?: return@mapNotNull null

                if (issued.rawCredential() == null) {
                    Logger.debug("Skipping issued credential for configId: $configId due to missing rawCredential")
                    return@mapNotNull null
                }

                val format = issued.format() ?: offeredCredential.find { it.id == configId }?.format

                IssuedCredentialData(
                    configurationId = configId,
                    credentialIdentifier = issued.credentialIdentifier(),
                    format = format ?: return@mapNotNull null,
                    rawCredential = issued.rawCredential()!!,
                    isDeferred = issued.isDeferred(),
                    notificationId = issued.notificationId()
                )
            }
        }

        val errors = result.errors().mapNotNull { (configIdAny, errorAny) ->
            Logger.debug("Mapping issuance error for configId: $configIdAny, error: $errorAny")
            val configId = configIdAny as? String ?: return@mapNotNull null
            val error = errorAny as? SwiftOID4VCICredentialError ?: return@mapNotNull null

            IssuanceError(
                configurationId = configId,
                error = OID4VCICredentialError(
                    error = error.error(),
                    description = error.errorDescription()
                )
            )
        }

        return OID4VCIIssuanceResult(
            credentials = credentials,
            errors = errors,
            cNonce = result.cNonce()
        )
    }

    private fun mapDisplayProperties(
        properties: List<OID4VCIDisplayProperties>?
    ): Map<String?, DisplayProperties> {
        return properties?.associate { prop ->
            prop.locale() to DisplayProperties(
                name = prop.name(),
                locale = prop.locale(),
                description = prop.descriptionText(),
                backgroundColor = prop.backgroundColor(),
                textColor = prop.textColor(),
                logoUrl = prop.logoUrl(),
                logoAltText = prop.logoAltText(),
                additionalData = emptyMap()
            )
        } ?: emptyMap()
    }

    private fun mapNSErrorToException(error: NSError): OID4VCIException {
        val description = error.localizedDescription
        val stepRaw = (error.userInfo["step"] as? Number)?.toInt() ?: 0
        val errorCode = (error.userInfo["errorCode"] as? String) ?: "unknown"

        return when (stepRaw) {

            OID4VCIStepRetrievingCredentialOffer.toInt() ->
                OID4VCIException.RetrievingCredentialOffer(errorCode, description, Exception(description))

            OID4VCIStepRetrievingIssuerMetadata.toInt() ->
                OID4VCIException.RetrievingIssuerMetadata(errorCode, description, Exception(description))

            OID4VCIStepResolvingOfferedCredentials.toInt() ->
                OID4VCIException.RetrievingOfferedCredentialFormats(errorCode, description, Exception(description))

            OID4VCIStepCreatingAccessToken.toInt() ->
                OID4VCIException.CreatingAccessToken(errorCode, description)

            OID4VCIStepRetrievingCredentials.toInt(),
            OID4VCIStepRetrievingBatchCredentials.toInt() -> {
                val url = (error.userInfo["detail_url"] as? String) ?: ""
                OID4VCIException.RetrievingCredential(url, errorCode, description)
            }

            else -> OID4VCIException.RetrievingCredentialOffer(errorCode, description, Exception(description))
        }
    }

    private fun parseJsonOrEmpty(jsonString: String?): JsonObject {
        return try {
            jsonString?.let { json.decodeFromString<JsonObject>(it) } ?: JsonObject(emptyMap())
        } catch (e: Exception) {
            Logger.error("Failed to parse JSON: ${e.message}")
            JsonObject(emptyMap())
        }
    }
}

/**
 * Factory function implementation for Apple platform.
 */
actual fun createOID4VCIClient(
    keyPairFactory: KeyPairFactory,
    networkClient: NetworkClient
): OID4VCIClient = AppleOID4VCIClient(keyPairFactory, networkClient)
