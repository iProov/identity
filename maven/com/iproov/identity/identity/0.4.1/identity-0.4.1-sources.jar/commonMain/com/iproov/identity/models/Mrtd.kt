package com.iproov.identity.models

import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.native.HiddenFromObjC


@OptIn(ExperimentalEncodingApi::class)
object ByteArrayAsBase64Serializer : KSerializer<ByteArray> {
    private val base64 = Base64.Default.withPadding(Base64.PaddingOption.ABSENT)

    override val descriptor: SerialDescriptor
        get() = PrimitiveSerialDescriptor(
            "ByteArrayAsBase64Serializer",
            PrimitiveKind.STRING
        )

    override fun serialize(encoder: Encoder, value: ByteArray) {
        val base64Encoded = base64.encode(value)
        encoder.encodeString(base64Encoded)
    }

    override fun deserialize(decoder: Decoder): ByteArray {
        val base64Decoded = decoder.decodeString()
        return base64.decode(base64Decoded)
    }
}

typealias Base64ByteArray = @Serializable(with = ByteArrayAsBase64Serializer::class) ByteArray

internal val _dtcVcDgTags = mapOf<String, String>(
    "80" to "SOD",
    "81" to "DG1",
    "82" to "DG2",
    "83" to "DG3",
    "84" to "DG4",
    "85" to "DG5",
    "86" to "DG6",
    "87" to "DG7",
    "88" to "DG8",
    "89" to "DG9",
    "8A" to "DG10",
    "8B" to "DG11",
    "8C" to "DG12",
    "8D" to "DG13",
    "8E" to "DG14",
    "8F" to "DG15",
    "90" to "DG16",
    "96" to "SecurityInfo",
    "97" to "OtherInfos",
    "71" to "DTCVC"
)

@OptIn(ExperimentalObjCRefinement::class)
@Serializable()
open class MrtdData(
    @HiddenFromObjC @SerialName("SOD") open val sod: Base64ByteArray,
    @HiddenFromObjC @SerialName("DG1") val dg1: Base64ByteArray,
    @HiddenFromObjC @SerialName("DG2") val dg2: Base64ByteArray,
    @HiddenFromObjC @SerialName("DG3") val dg3: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG4") val dg4: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG5") val dg5: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG6") val dg6: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG7") val dg7: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG8") val dg8: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG9") val dg9: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG10") val dg10: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG11") val dg11: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG12") val dg12: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG13") val dg13: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG14") val dg14: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG15") val dg15: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG16") val dg16: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG17") val dg17: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG18") val dg18: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("DG19") val dg19: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("COM") val com: Base64ByteArray? = null,
    @HiddenFromObjC @SerialName("CVCA") val cvca: Base64ByteArray? = null,
) {
    val mrz: String by lazy { (dg1.copyOfRange(5, dg1.size)).decodeToString() }

    companion object {
        @OptIn(ExperimentalObjCRefinement::class)
        @HiddenFromObjC
        fun fromDtcVc(dtcVc: ByteArray): MrtdData = decodeDtc(dtcVc)
    }

    override fun toString(): String {
        val builder = StringBuilder()
        builder.append(
            "Mrtd(" +
                    "sod=$sod, dg1=$dg1, dg2=$dg2," +
                    "dg3=$dg3, dg4=$dg4, dg5=$dg5, " +
                    "dg6=$dg6, dg7=$dg7, dg8=$dg8," +
                    "dg9=$dg9, dg10=$dg10, dg11=$dg11," +
                    "dg12=$dg12, dg13=$dg13, dg14=$dg14," +
                    "dg15=$dg15, dg16=$dg16, dg17=$dg17," +
                    "dg18=$dg18, dg19=$dg19," +
                    "com=$com, cvca=$cvca" +
                    ")"
        )
        return builder.toString()
    }
}


enum class Gender {
    MALE,
    FEMALE;

    val value: String
        get() = if (this == MALE) "M" else "F"
}

enum class Format {
    BASE64,
    HEX;

    val value: String
        get() = name.lowercase()
}

internal fun decodeDtc(byteArray: ByteArray): MrtdData {
    throw NotImplementedError("DTC-VC parsing is not implemented yet. This is a placeholder for future implementation.")
//    val parsed = Asn1Element.parseAll(byteArray)
//    val sequence = parsed[0].asSequence()
//
//    // Validate version
//    val version = (sequence.children[0].asPrimitive().decodeToInt())
//    if (version != 1) {
//        throw IllegalArgumentException("Invalid DTC-VC version. Must be 1")
//    }
//
//    val dgs = mutableMapOf<String, ByteArray>()
//    val dgParser = parsed[1].asOctetString()
//
//
//    for (dataGroup in dgParser.children) {
//        val asn1Encodable = dataGroup.asExplicitlyTagged()
//        val tag = asn1Encodable.tag.tagValue.toString(16).uppercase()
//        val key = _dtcVcDgTags[tag]
//        if (key != null) {
//            dgs[key] = asn1Encodable.asPrimitive().derEncoded
//        }
//    }
//
//    return MrtdData(
//        dgs["SOD"]!!,
//        dgs["DG1"]!!,
//        dgs["DG2"]!!,
//        dgs["DG3"],
//        dgs["DG4"],
//        dgs["DG5"],
//        dgs["DG6"],
//        dgs["DG7"],
//        dgs["DG8"],
//        dgs["DG9"],
//        dgs["DG10"],
//        dgs["DG11"],
//        dgs["DG12"],
//        dgs["DG13"],
//        dgs["DG14"],
//        dgs["DG15"],
//        dgs["DG16"],
//        dgs["DG17"],
//        dgs["DG18"],
//        dgs["DG19"],
//        dgs["COM"],
//    )
}