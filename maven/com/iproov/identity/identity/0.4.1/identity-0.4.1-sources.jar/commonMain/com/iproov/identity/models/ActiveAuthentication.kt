package com.iproov.identity.models

import io.ktor.utils.io.charsets.Charsets
import io.ktor.utils.io.core.toByteArray
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@OptIn(ExperimentalObjCRefinement::class)
open class ActiveAuthentication(
    @HiddenFromObjC val challenge: ByteArray,
    @HiddenFromObjC val secret: ByteArray
) {
    companion object {

        fun generateFromBacKey(bacKey: BacKey): ActiveAuthentication {
            val secret = generateRandomBytes(16)
            val keyBytes = bacKey.key.toByteArray(Charsets.UTF_8)
            val concatenatedBytes = keyBytes + secret
            val challenge = hash(concatenatedBytes)
            return ActiveAuthentication(challenge, secret)
        }
    }

    override fun toString(): String {
        return "ActiveAuthentication(challenge=${challenge.contentToString()}, secret=${secret.contentToString()})"
    }
}


expect fun generateRandomBytes(length: Int): ByteArray

expect fun hash(data: ByteArray): ByteArray