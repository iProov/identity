package com.iproov.identity.persistence

import com.iproov.identity.Logger
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCObjectVar
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.value
import platform.Foundation.NSApplicationSupportDirectory
import platform.Foundation.NSData
import platform.Foundation.NSDataWritingAtomic
import platform.Foundation.NSDictionary
import platform.Foundation.NSError
import platform.Foundation.NSFileManager
import platform.Foundation.NSKeyedArchiver
import platform.Foundation.NSKeyedUnarchiver
import platform.Foundation.NSNull
import platform.Foundation.NSString
import platform.Foundation.NSURL
import platform.Foundation.NSUTF8StringEncoding
import platform.Foundation.NSUserDomainMask
import platform.Foundation.dataWithContentsOfURL
import platform.Foundation.writeToURL

class FileStorage(private val fileName: String) {

    private val fileUrl
        get() :NSURL {
            val urls = NSFileManager.defaultManager.URLsForDirectory(
                directory = NSApplicationSupportDirectory,
                inDomains = NSUserDomainMask,
            ) as List<NSURL>
            return urls.first().URLByAppendingPathComponent(fileName)!!
        }


    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    fun read(): NSData = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>()
        val fileContent = NSData.dataWithContentsOfURL(fileUrl, NSUTF8StringEncoding, error.ptr) ?: return NSData()
        if (error.value != null) {
            Logger.info("Failed to read contents of file ${error.value}")
            return NSData()
        }
        return fileContent

    }

    /**
     * Archives the provided NSDictionary into NSData using NSKeyedArchiver with secure coding.
     *
     * It enforces secure coding (`requiringSecureCoding = true`)
     * and wraps potential `NSError` results or `nil` returns in a `StorageException`.
     * Primarily used to serialize data before encryption or persistence.
     *
     * @param data The NSDictionary instance originating from or bridged for iOS.
     * @return NSData containing the securely archived representation of the input dictionary.
     * @throws StorageException if `NSKeyedArchiver` fails during serialization.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    fun archiveDictionary(data: NSDictionary): NSData = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>() // For NSError** pattern

        // Call Foundation's keyed archiver via interop
        val archivedData = NSKeyedArchiver.archivedDataWithRootObject(
            data,
            requiringSecureCoding = true, // Enforce NSSecureCoding conformance
            error = error.ptr
        )
        // Handle nil return from the archiver method
            ?: throw StorageException("NSKeyedArchiver returned nil data during encoding.")

        // Check for NSError population
        error.value?.let { nsError ->
            throw StorageException("NSKeyedArchiver failed during encoding: $nsError")
        }

        return@memScoped archivedData
    }

    /**
     * Unarchives NSData into an NSDictionary using the secure NSKeyedUnarchiver.
     *
     * Includes checks for `NSError` population (specifically if the result is nil) and
     * explicitly verifies the returned root object is non-null and of the expected
     * `NSDictionary` type. Wraps various failure conditions in a `StorageException`.
     *
     * @param data The NSData containing the output of a corresponding NSKeyedArchiver process
     * (using compatible classes and secure coding).
     * @return The successfully unarchived NSDictionary.
     * @throws StorageException If unarchiving fails due to decoding errors, nil return,
     * `NSError` being set, or the root object having an unexpected type.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    fun unarchiveData(data: NSData): NSDictionary = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>() // For NSError** pattern

        // Use secure un-archiving, specifying allowed classes.
        val result: Any? = NSKeyedUnarchiver.unarchivedObjectOfClasses(
            // Explicitly list allowed classes for security.
            classes = setOf(NSDictionary, NSString, NSNull),
            fromData = data,
            error = error.ptr
        )

        if (result == null) {
            // If null, check the NSError for a specific reason.
            val errorDetails = error.value?.let { ": $it" } ?: ": Reason unknown (result was nil)"
            throw StorageException("Failed to unarchive data${errorDetails}")
        }

        if (result !is NSDictionary) {
            throw StorageException("Expected unarchived data to be NSDictionary but was ${result::class.simpleName ?: "Unknown Type"}")
        }

        return@memScoped result
    }

    /**
     * Ensures the parent directory for the member `fileUrl` exists, creating it if necessary.
     *
     * Uses `NSFileManager.createDirectoryAtURL` with `withIntermediateDirectories = true`
     *
     * Handles potential `NSError` and wraps failures in a `StorageException`.
     * Assumes `fileUrl` is initialized and has a parent path.
     *
     * @throws StorageException if the parent directory cannot be determined or created.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(StorageException::class)
    internal fun ensureDirectoryExists() = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>()

        // Safely get the parent directory URL from the member fileUrl
        val directoryUrl = fileUrl.URLByDeletingLastPathComponent
            ?: throw StorageException("Cannot determine parent directory for URL: $fileUrl")

        NSFileManager.defaultManager.createDirectoryAtURL(
            url = directoryUrl,
            withIntermediateDirectories = true, // Create missing parent directories recursively
            attributes = null, // Use default directory attributes
            error = error.ptr // Capture potential NSError
        )

        // Check for NSError population after the directory creation attempt
        error.value?.let { nsError ->
            throw StorageException("Failed to create directory $directoryUrl: $nsError")
        }
    }


    /**
     * Writes the provided NSData to the member `fileUrl` atomically.
     *
     * Ensures the target directory exists by calling `ensureDirectoryExists()` first.
     * Uses `NSData.writeToURL` with the `NSDataWritingAtomic` option for safer writes
     * (writes to a temporary file then renames).
     *
     * Handles potential `NSError` and wraps failures in a `StorageException`.
     * Assumes `fileUrl` is an initialized member variable.
     *
     * @param data The NSData to write to disk.
     * @throws StorageException if the directory cannot be created or the file write fails.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(StorageException::class)
    fun write(data: NSData): Unit = memScoped {
        // Ensure the parent directory exists before attempting to write the file.
        ensureDirectoryExists()

        val error = alloc<ObjCObjectVar<NSError?>>()

        // NSDataWritingAtomic ensures the original file isn't corrupted if the write fails mid-way.
        val success = data.writeToURL(url = fileUrl, options = NSDataWritingAtomic, error = error.ptr)

        // Check for failure (either writeToURL returned false or NSError was populated)
        if (!success || error.value != null) {
            val errorDetails = error.value?.let { ": $it" } ?: ""
            // Improved error message for write failure
            throw StorageException("Failed to write data to URL ${fileUrl}${errorDetails}")
        }
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(StorageException::class)
    fun delete() = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>() // For NSError** pattern
        NSFileManager.defaultManager.removeItemAtURL(fileUrl, error.ptr)
        if (error.value != null) throw StorageException("Failed to delete all storage: ${error.value}")
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    val fileHasBeenCreated: Boolean = memScoped {

        NSFileManager.defaultManager.fileExistsAtPath(fileUrl.path!!)
//        val error = alloc<ObjCObjectVar<NSError?>>()
//        fileUrl.checkResourceIsReachableAndReturnError(error.ptr)
//        error.value == null
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    fun preventBackup() = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>()
        fileUrl.setResourceValues(mapOf("isExcludedFromBackup" to true), error.ptr)

        if (error.value != null) throw StorageException("Failed to prevent backup: ${error.value}")
    }
}