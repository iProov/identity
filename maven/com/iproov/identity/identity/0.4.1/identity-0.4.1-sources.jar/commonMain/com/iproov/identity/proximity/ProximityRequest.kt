package com.iproov.identity.proximity

/**
 * Parsed `DeviceRequest` from the reader (ISO 18013-5 §8.3.2.1.2.1). Emitted via
 * [ProximityPresentationEvent.RequestReceived]; call [respond] to share or close the session to decline.
 */
class RespondableProximityRequest internal constructor(
    val docRequests: List<DocRequest>,
    val matchHandler: suspend () -> Map<DocRequest, List<DisclosedDocument>>,
    val readerAuth: ReaderAuth,
    private val responseHandler: suspend (Map<DocRequest, DisclosedDocument>) -> ProximityResponseOutcome,
) {
    /**
     * Build, sign, encrypt and send the DeviceResponse with the user's disclosure choices.
     * Suspends until sent or failed; the session also emits PresentationSent / Failure.
     */
    suspend fun respond(disclosed: Map<DocRequest, DisclosedDocument>): ProximityResponseOutcome =
        responseHandler(disclosed)

    /** Resolves which locally-stored credentials can satisfy each [DocRequest]. */
    suspend fun match(): Map<DocRequest, List<DisclosedDocument>> = matchHandler()

    override fun toString(): String {
        val builder = StringBuilder()

        builder.append("RespondableProximityRequest(")
        builder.append("readerAuth=").append(readerAuth)
        builder.append(", requested documents:")
        for (request in docRequests) {
            builder.append("\n  ").append(request.docType)
            for ((namespace, items) in request.requestedItems) {
                builder.append("\n    ").append(namespace).append(':')
                for (item in items) {
                    builder.append("\n      ").append(item.elementIdentifier)
                    if (item.intentToRetain) builder.append(" (intent to retain)")
                }
            }
        }
        builder.append("\n)")
        return builder.toString()
    }
}

/**
 * One document the reader is asking for (ISO 18013-5 §8.3.2.1.2.1).
 * @property docType e.g. "org.iso.18013.5.1.mDL"
 * @property requestedItems namespace → requested elements
 */
data class DocRequest(
    val docType: String,
    val requestedItems: Map<String, List<RequestedItem>>,
)

/**
 * A single data element the reader requested.
 * @property intentToRetain reader-signalled intent to retain after the transaction (surface in consent UI).
 */
data class RequestedItem(
    val elementIdentifier: String,
    val intentToRetain: Boolean,
)

/**
 * Reader-authentication verification result (ISO 18013-5 §9.1.4).
 * [Absent]: no reader auth in the request. [SignatureInvalid]: present but failed verification.
 * [Untrusted]: signature valid, chain not trusted by policy. [Trusted]: verified and trusted.
 */
sealed interface ReaderAuth {
    data object Absent : ReaderAuth
    data object SignatureInvalid : ReaderAuth
    data class Untrusted(val commonName: String?) : ReaderAuth
    data class Trusted(val commonName: String) : ReaderAuth
}

internal fun List<ReaderAuth>.aggregate(): ReaderAuth {
    val present = filterNot { it == ReaderAuth.Absent }
    if (present.isEmpty()) return ReaderAuth.Absent
    present.firstOrNull { it is ReaderAuth.SignatureInvalid }?.let { return it }
    present.firstOrNull { it is ReaderAuth.Untrusted }?.let { return it }

    return present.first() // all present are Trusted
}