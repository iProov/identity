package com.iproov.identity.models

import com.iproov.identity.AppIdNotSupportedException
import com.iproov.identity.RequiredClaimNotPresent
import com.iproov.identity.WalletNotRegisteredException
import com.iproov.identity.api.ApiException
import com.iproov.identity.wrap
import com.iproov.kmp.api.IproovOptions
import kotlinx.coroutines.MainScope
import kotlin.coroutines.cancellation.CancellationException
import kotlin.experimental.ExperimentalObjCName

@OptIn(ExperimentalObjCName::class)
@Throws(
    WalletNotRegisteredException::class,
    RequiredClaimNotPresent::class,
    ApiException::class,
    CancellationException::class,
    AppIdNotSupportedException::class,
    Exception::class,
)
@ObjCName("verify")
fun FaceReverificationRequest.verifyFlowWrapper(
    credential: LegacyCredential.IdentityCredential.Mrtd,
    options: IproovOptions? = null
) = verify(credential, options).wrap(scope = MainScope())
