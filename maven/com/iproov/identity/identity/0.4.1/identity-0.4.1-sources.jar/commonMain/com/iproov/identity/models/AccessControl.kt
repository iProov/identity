package com.iproov.identity.models

enum class AccessControl {
    bac,
    pace
}