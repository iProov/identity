package com.iproov.identity.models

val LoginRequest.json: Any? get() = this.json.toNativeTypes()