package com.iproov.identity.api

import com.iproov.identity.AppInfo
import com.iproov.identity.DeviceInfo
import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Platform
import com.iproov.identity.attestation.SimplePasswordAttestationService
import com.iproov.identity.encodeToJsonObject
import com.iproov.identity.models.Jwt

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.encodeToJsonElement
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

@Serializable
data class RegisterAppleWalletPayload(
    val device: DeviceInfo,
    val app: AppInfo,
    /**
     * Only set for the simple-password (simulator/dev) attestation path, where the token travels
     * in the body rather than being proven by an App Attest assertion header. Omitted entirely on
     * the real App Attest path so the server dispatches to its iOS assertion branch as before —
     * see [omitNullsJson] for why the key is absent rather than null.
     */
    @SerialName("attestation_token") val attestationToken: String? = null,
)

@Serializable
data class RegisterAppleAttestationPayload(
    @SerialName("key_identifier") val keyId: String,
    @SerialName("attestation_string") val attestationObjectB64: String
)

internal class AppleIdentityPlatformInterface(
    keyPairFactory: KeyPairFactory,
    private val platform: Platform,
    apiClient: ApiClient,
) : IdentityPlatformInterface(apiClient, keyPairFactory) {

    object AppleRoutes {
        const val REGISTER_APPLE_ATTESTATION = "/v2/register/iosappattest"
    }

    override suspend fun registerWallet(attestationToken: String): List<Jwt> {
        val isSimplePassword =
            attestationToken == SimplePasswordAttestationService.SIMPLE_PASSWORD

        val request = RegisterAppleWalletPayload(
            device = platform.deviceInfo,
            app = platform.appInfo,
            attestationToken = attestationToken.takeIf { isSimplePassword },
        ).encodeToJsonObject(omitNullsJson)

        val payload = apiClient.signAndPost(
            Routes.Wallet.REGISTER,
            request,
            emptyMap(),
            // Withheld on the simple-password path: a non-null keyId produces an x-ios-assertion
            // header, which the server prioritises over the body token and routes to App Attest.
            keyId = attestationToken.takeUnless { isSimplePassword }
        )

        platformAttestationKeyId = attestationToken

        return getClaims(payload)
    }


    @OptIn(ExperimentalEncodingApi::class)
    suspend fun registerIosAttestation(keyId: String, attestationObject: ByteArray) {
        val request = Json.encodeToJsonElement(
            RegisterAppleAttestationPayload(
                keyId,
                Base64.Default.withPadding(Base64.PaddingOption.ABSENT).encode(attestationObject)
            )
        ).jsonObject

        apiClient.signAndPost(AppleRoutes.REGISTER_APPLE_ATTESTATION, request, keyId = keyId)
    }
}
