package com.iproov.identity.dcapi.mdoc

import com.iproov.identity.cryptography.KeyPair
import com.iproov.identity.models.ClaimQuery
import com.iproov.identity.models.DeviceResponse
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.buildClaims
import com.iproov.identity.models.matchCredentials
import com.iproov.identity.models.toDocRequests
import com.iproov.identity.persistence.Repository
import com.iproov.identity.proximity.DisclosedDocument
import com.iproov.identity.proximity.DocRequest
import com.iproov.identity.proximity.ReaderAuth
import com.iproov.identity.proximity.ReaderAuthVerifier
import com.iproov.identity.proximity.ReaderTrustPolicy
import org.multipaz.cbor.Cbor
import org.multipaz.mdoc.request.DeviceRequest

private const val ERROR_DATA_NOT_RETURNED = 0

internal class MdocDcApiSealingInputs(
    val readerPublicKey: ByteArray,
    val deviceResponse: ByteArray,
    val sessionTranscript: ByteArray,
)

internal class MdocDcApiSession private constructor(
    private val readerPublicKey: ByteArray,
    private val keyPair: KeyPair,
    private val repository: Repository,
    private val sessionTranscript: ByteArray,
    val raw: String,
    val docRequests: List<DocRequest>,
    val origin: String,
    val readerAuth: ReaderAuth,
) {

    suspend fun match(): Map<DocRequest, List<DisclosedDocument>> {
        return matchCredentials(repository, docRequests)
    }

    companion object {
        /**
         * @throws MdocDcApiException if the request or its EncryptionInfo is malformed, or if
         * [com.iproov.identity.TrustConfiguration.readerTrust] refuses the reader. Everything needed to answer is validated here,
         * before claim selection. Apple's initial authorization precedes access to the raw request.
         */
        suspend fun create(
            requestJson: String,
            origin: String,
            repository: Repository,
            keyPair: KeyPair,
            readerTrust: ReaderTrustPolicy,
        ): MdocDcApiSession {
            val request = MdocDcApiRequest.parse(requestJson)
            val encryptionInfo = MdocDcApiEncryptionInfo.parse(request.encryptionInfoB64)
            val deviceRequest = requireField("deviceRequest") {
                DeviceRequest.fromDataItem(Cbor.decode(request.decodedDeviceRequest()))
            }
            if (deviceRequest.docRequests.isEmpty()) {
                throw MdocDcApiException("deviceRequest.docRequests must contain at least one document request")
            }
            val sessionTranscript = mdocDcApiSessionTranscript(request.encryptionInfoB64, origin)

            val readerAuth = when (
                val outcome = ReaderAuthVerifier.verify(
                    deviceRequest = deviceRequest,
                    sessionTranscript = Cbor.decode(sessionTranscript),
                    policy = readerTrust,
                )
            ) {
                is ReaderAuthVerifier.VerificationOutcome.Accepted -> outcome.result
                is ReaderAuthVerifier.VerificationOutcome.Rejected ->
                    throw MdocDcApiException(outcome.reason)
            }

            return MdocDcApiSession(
                readerPublicKey = encryptionInfo.readerPublicKey,
                keyPair = keyPair,
                repository = repository,
                sessionTranscript = sessionTranscript,
                raw = requestJson,
                docRequests = deviceRequest.toDocRequests(),
                origin = origin,
                readerAuth = readerAuth,
            )
        }
    }

    /**
     * Signs the selected documents and returns them sealed
     *
     * @throws MdocDcApiException if a selection names a credential that cannot satisfy its request.
     */
    fun prepare(disclosed: Map<DocRequest, DisclosedDocument>): MdocDcApiSealingInputs {
        val documents = mutableListOf<Pair<MDocCredential, List<ClaimQuery>>>()
        val documentErrors = mutableMapOf<String, Int>()

        docRequests.forEachIndexed { _, docRequest ->
            val selection = disclosed[docRequest]
            if (selection == null) {
                // Say nothing and the reader cannot tell a declined document from a broken wallet.
                documentErrors[docRequest.docType] = ERROR_DATA_NOT_RETURNED
                return@forEachIndexed
            }


            if (selection.credential.docType != docRequest.docType) {
                throw MdocDcApiException(
                    "Credential for '${docRequest.docType}' is a '${selection.credential.docType}'"
                )
            }
            documents += selection.credential to buildClaims(docRequest, selection)
        }

        // Two requests can share a docType; drop the error if any of them was fulfilled.
        documentErrors.keys.removeAll(documents.map { it.first.docType }.toSet())

        return MdocDcApiSealingInputs(
            readerPublicKey = readerPublicKey,
            deviceResponse = DeviceResponse.buildDeviceResponse(
                documents = documents,
                deviceKeyPair = keyPair,
                encodedSessionTranscript = sessionTranscript,
                documentErrors = documentErrors,
            ),
            sessionTranscript = sessionTranscript,
        )
    }
}
