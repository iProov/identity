package com.iproov.identity.api

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.models.CredentialDescriptor
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialOffer
import com.iproov.identity.models.CredentialRecord
import com.iproov.identity.models.IssuanceResult
import com.iproov.identity.models.IssuanceSummary
import com.iproov.identity.models.OID4VCICredentialError
import com.iproov.identity.models.RespondableCredentialOffer
import com.iproov.identity.models.TransactionCodeChallenge
import com.iproov.identity.persistence.Repository
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

interface OID4VCIOrchestrator {
    @Throws(Exception::class)
    suspend fun addCredential(uri: String): RespondableCredentialOffer

    @Throws(Exception::class)
    suspend fun addCredential(offer: JsonObject): RespondableCredentialOffer
}

internal class DefaultOID4VCIOrchestrator(
    /**
     * A way to sign data to create the PoP when retrieving credentials
     * (should not be a reference to a single keypair itself, in case the keypair is destroyed when
     * the wallet instance is deleted)
     */
    val keyPairFactory: KeyPairFactory,

    /**
     * The repository is used to store the credentials & metadata
     */
    val repository: Repository,

    /**
     * The networking client is used to communicate with the issuer during the protocol
     */
    val networkClient: NetworkClient

) : OID4VCIOrchestrator {

    private val client: OID4VCIClient by lazy {
        createOID4VCIClient(keyPairFactory, networkClient)
    }

    private val json = Json { }

    override suspend fun addCredential(uri: String): RespondableCredentialOffer {
        Logger.debug("Resolving credential offer from URI: $uri")
        val offer = client.resolveOffer(uri)
        return processCredentialOffer(offer)
    }

    override suspend fun addCredential(offer: JsonObject): RespondableCredentialOffer {
        val resolvedOffer = client.resolveOffer(offer)
        return processCredentialOffer(resolvedOffer)
    }

    /**
     * Process a credential offer through the full issuance flow.
     * Handles transaction code requirements, authorization code flow, and credential storage.
     */
    private fun processCredentialOffer(offer: CredentialOffer) =
        RespondableCredentialOffer.fromCredentialOffer(
            offer = offer,
            onAccept = @Throws(Exception::class) { credentials ->
                when {
                    credentials.isEmpty() -> IssuanceResult.Empty

                    offer.transactionCodeDetails == null -> {
                        Logger.info("No transaction code required, proceeding with credential issuance")
                        val summary = issueAndStoreCredentials(offer, credentials, transactionCode = null)
                        IssuanceResult.Immediate(summary)
                    }

                    else -> {
                        Logger.info("Transaction code required: ${json.encodeToString(offer.transactionCodeDetails)}")
                        val challenge = TransactionCodeChallenge(
                            details = offer.transactionCodeDetails!!,
                            onRespond = @Throws(Exception::class) { txCode ->
                                issueAndStoreCredentials(offer, credentials, transactionCode = txCode)
                            }
                        )
                        IssuanceResult.TransactionCodeRequired(challenge)
                    }
                }
            },
            onAuthorize = @Throws(Exception::class) { credentials ->
                when {
                    credentials.isEmpty() -> IssuanceResult.Empty

                    else -> {
                        Logger.info("Preparing authorization code flow")
                        val preparation = client.prepareAuthorizationRequest(offer, credentials)
                        Logger.info("Authorization URL: ${preparation.authorizationUrl}")

                        IssuanceResult.AuthorizationRequired(
                            authorizationUrl = preparation.authorizationUrl,
                            onAuthorizationCode = @Throws(Exception::class) { authorizationCode ->
                                Logger.info("Received authorization code, issuing credentials")
                                val result = client.issueCredentialsWithAuthCode(
                                    offer = offer,
                                    authorizationCode = authorizationCode,
                                    preparation = preparation,
                                    credentials = credentials,
                                )
                                processIssuanceResult(offer, credentials, result)
                            }
                        )
                    }
                }
            },
        )

    /**
     * Issue credentials using the pre-authorized code flow and store them in the repository.
     */
    private suspend fun issueAndStoreCredentials(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
        transactionCode: String?
    ): IssuanceSummary {
        Logger.info("Issuing ${credentials.size} credential(s)")
        val result = client.issueCredentials(offer, credentials, transactionCode)
        return processIssuanceResult(offer, credentials, result)
    }

    /**
     * Process an issuance result: store credentials in the repository and build an IssuanceSummary.
     * Shared by both pre-authorized code and authorization code flows.
     */
    private suspend fun processIssuanceResult(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
        result: OID4VCIIssuanceResult,
    ): IssuanceSummary {
        val descriptorsByConfigId = credentials.associateBy { it.id }
        val credentialsAdded = mutableListOf<CredentialMetadata>()
        val errors = mutableMapOf<CredentialMetadata, OID4VCICredentialError>()

        // Process successfully issued credentials
        for (issuedData in result.credentials) {
            val descriptor = descriptorsByConfigId[issuedData.configurationId]

            Logger.debug("Processing credential '${issuedData.configurationId}': format=${issuedData.format}, deferred=${issuedData.isDeferred}")

            val metadata = buildMetadata(offer, descriptor, issuedData.format)

            if (issuedData.isDeferred) {
                errors[metadata] = OID4VCICredentialError(
                    error = "deferred_not_supported",
                    description = "Deferred credential issuance is not yet supported"
                )
            } else {
                val record = CredentialRecord(format = issuedData.format, data = issuedData.rawCredential)
                repository.addCredentialRecord(metadata, record)
                credentialsAdded.add(metadata)
                Logger.info("Stored credential: ${metadata.format}" + (issuedData.credentialIdentifier?.let { " (identifier: $it)" } ?: ""))
            }
        }

        // Process errors returned by the issuer
        for (issuanceError in result.errors) {
            Logger.error("Credential '${issuanceError.configurationId}' failed: ${issuanceError.error.error} - ${issuanceError.error.description}")

            val descriptor = descriptorsByConfigId[issuanceError.configurationId]
            val metadata = buildMetadata(offer, descriptor, descriptor?.format ?: "unknown")
            errors[metadata] = issuanceError.error
        }

        return IssuanceSummary(credentialsAdded, errors)
    }

    private fun buildMetadata(
        offer: CredentialOffer,
        descriptor: CredentialDescriptor?,
        format: String,
    ) = CredentialMetadata(
        issuer = offer.issuer,
        offer = descriptor?.raw ?: JsonObject(emptyMap()),
        format = format,
        display = descriptor?.display?.values?.toList() ?: emptyList()
    )
}
