package com.iproov.identity.models

val Credential.body: Map<String, Any?> get() = this.body.mapValues { it.value.toNativeTypes() }