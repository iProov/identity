package com.iproov.identity.proximity

/** Lifecycle events emitted by a [ProximityPresentationSession] */
sealed class ProximityPresentationEvent(val isFinal: Boolean) {

    /** Generating the wallet's ephemeral key + DeviceEngagement; QR not yet ready. */
    data object GeneratingEngagement : ProximityPresentationEvent(false)

    /** Engagement built. [payload]'s mdoc URI is ready to render as a QR for the reader. */
    data class QrEngagementReady(val payload: QrEngagementPayload) :
        ProximityPresentationEvent(false)

    data object Connecting : ProximityPresentationEvent(false)

    data object Connected : ProximityPresentationEvent(false)

    /** A reader has been detected; the BLE handshake is in progress. */
    data object CreatingSession : ProximityPresentationEvent(false)

    /** The BLE channel is open and session encryption keys are derived; awaiting the request. */
    data object SessionCreated : ProximityPresentationEvent(false)

    /** The reader sent a DeviceRequest; show consent UI and call `ProximitySession.respond`. */
    data class RequestReceived(val request: RespondableProximityRequest) :
        ProximityPresentationEvent(false)

    data object PresentationSent : ProximityPresentationEvent(false)

    /** Either side closed the connection cleanly. */
    data object Disconnected : ProximityPresentationEvent(true)

    /** Terminal: an unrecoverable error occurred. */
    data class Failure(val error: String, val cause: Throwable) : ProximityPresentationEvent(true)
}


