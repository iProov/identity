package com.iproov.identity.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

private val json = Json { ignoreUnknownKeys = true; prettyPrint = true; explicitNulls = false }

/**
 * The full set of Authorization Request fields the wallet cares about
 * after resolving the request object, whether by value or by reference.
 *
 * Keep fields OPTIONAL unless the spec marks them REQUIRED.
 * (Some are conditionally required based on response_type/mode.)
 */
@Serializable
data class AuthorizationRequest(
    // === Issuance / audience (present in signed Request Objects) ===
    val iss: String? = null,
    val aud: String? = null,

    // === Who’s asking ===
    @SerialName("client_id")
    val clientId: String? = null, // DC-AIP
    val clientIdType: ClientIdType = ClientIdType.infer(clientId ?: ""),

    // === How the wallet should respond ===
    @SerialName("response_type")
    val responseType: String, // REQUIRED: e.g., "vp_token", "vp_token id_token", "code"
    @SerialName("response_mode")
    val responseMode: ResponseMode,

    @SerialName("redirect_uri")
    val redirectUri: String? = null,   // REQUIRED if using redirect response modes
    @SerialName("response_uri")
    val responseUri: String? = null,   // REQUIRED if using direct_post modes

    // === Security & state ===
    val nonce: String,
    val state: String? = null,         // RECOMMENDED (REQUIRED if holder binding disabled)

    // === What to present (DCQL) ===
    @SerialName("dcql_query")
    val dcqlQuery: DcqlQuery? = null,  // REQUIRED unless `scope` implies a pre-defined query
    val scope: String? = null,         // Optional: SIOPv2 (“openid”) or pre-defined DCQL query keys

    // === Advanced / optional ===
    @SerialName("client_metadata")
    val clientMetadata: AuthorizationRequestClientMetadata? = null,

    @SerialName("transaction_data")
    val transactionData: List<String>? = null,
    @SerialName("verifier_attestations")
    val verifierAttestations: List<String>? = null,

    // === SIOPv2 integration ===
    @SerialName("id_token_type")
    val idTokenType: String? = null,

    // === DC API specific (from signed requests) ===
    @SerialName("expected_origins")
    val expectedOrigins: List<String>? = null,

    val raw: String,
) {
    companion object {
        /** Accepts a signed Request Object (JWT) *or* plain JSON string. */
        fun fromRequestJwtOrJson(request: String): AuthorizationRequest {
            return if (looksLikeJwt(request)) {
                val payload = decodeJwtPayload(request)
                val map = json.decodeFromString(JsonObject.serializer(), payload).toMutableMap()
                map.put("raw", JsonPrimitive(request))
                json.decodeFromJsonElement(serializer(), JsonObject(map))
            } else {
                val map = json.decodeFromString(JsonObject.serializer(), request).toMutableMap()
                map.put("raw", JsonPrimitive(request))
                json.decodeFromJsonElement(serializer(), JsonObject(map))
            }
        }
    }
}


/* ---------------------------- helpers ---------------------------- */

private fun looksLikeJwt(s: String) = s.count { it == '.' } == 2

private fun decodeJwtPayload(compactString: String): String {
    val jwt = Jwt(compactString)
    return json.encodeToString(jwt.body)

}

private fun padB64(b64: String): String {
    val pad = (4 - b64.length % 4) % 4
    return b64 + "=".repeat(pad)
}