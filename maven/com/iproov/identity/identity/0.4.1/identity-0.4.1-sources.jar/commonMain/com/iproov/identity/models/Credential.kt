package com.iproov.identity.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@Serializable
enum class CredentialFormat(val value: String) {
    @SerialName("jwt_vc_json-ld")
    JWT_VC_JSON_LD("jwt_vc_json-ld"),

    @SerialName("mso_mdoc")
    MDOC("mso_mdoc"),

    @SerialName("dc+sd-jwt")
    SD_JWT_VC("dc+sd-jwt"),
}

/**
 * A base for all verifiable credentials that the wallet will store.
 *
 * The raw credential received through the issuance flow is always what's stored, never an abstraction.
 */
@OptIn(ExperimentalObjCRefinement::class)
@Serializable
sealed interface Credential {

    /**
     * A unique identifier for the credential
     */
    val uuid: String

    /**
     * Raw credential received from the issuer.
     */
    val raw: String

    /**
     * JSON object that represents the credential
     */
    @HiddenFromObjC
    val body: JsonObject

    /**
     * The format of the credential
     */
    val format: CredentialFormat

    /**
     * Function to derive the verification status of the credential
     */
    fun getVerificationSummary(): VerificationSummary = VerificationSummary.start()
}
