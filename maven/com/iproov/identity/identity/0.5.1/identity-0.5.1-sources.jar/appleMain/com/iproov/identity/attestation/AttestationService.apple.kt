package com.iproov.identity.attestation

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.api.AppleIdentityPlatformInterface
import com.iproov.identity.persistence.toByteArray
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.convert
import kotlinx.cinterop.usePinned
import kotlinx.coroutines.suspendCancellableCoroutine
import platform.CoreCrypto.CC_SHA256
import platform.CoreCrypto.CC_SHA256_DIGEST_LENGTH
import platform.DeviceCheck.DCAppAttestService

import platform.DeviceCheck.DCDevice
import platform.Foundation.NSData
import platform.Foundation.dataWithBytes
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal class AppleAttestationService(
    private val identityPlatformInterface: AppleIdentityPlatformInterface,
    private val keyPairFactory: KeyPairFactory,
) : AttestationService {

    override suspend fun getAttestationToken(): String {
        if (!DCDevice.currentDevice.isSupported()) throw AttestationNotSupportedException()

        val keyId = generateKeyId()
        val hash = getChallengeHash(keyId)
        val attestationObject = attestKey(keyId, hash)

        identityPlatformInterface.registerIosAttestation(keyId, attestationObject)

        return keyId
    }

    @OptIn(ExperimentalStdlibApi::class)
    private suspend fun getChallengeHash(keyId: String): ByteArray {
        val challenge = identityPlatformInterface.getChallenge(keyId)
        val challengeHex = challenge.challenge!!.toHexString().encodeToByteArray()
        return hash(challengeHex);
    }

    private suspend fun generateKeyId(): String = suspendCancellableCoroutine { continuation ->
        DCAppAttestService.sharedService.generateKeyWithCompletionHandler { attestationKey, error ->
            if (error != null) {
                // Resume with an exception if an error occurs
                continuation.resumeWithException(AttestationKeyGenerationException(error.localizedDescription))
            } else if (attestationKey != null) {
                // Resume with the result if successful
                continuation.resume(attestationKey)
            } else {
                // Handle unexpected null results gracefully
                continuation.resumeWithException(AttestationException("Unexpected null key and no error"))
            }
        }
    }

    private suspend fun attestKey(keyId: String, hashedChallenge: ByteArray): ByteArray =
        suspendCancellableCoroutine { continuation ->
            DCAppAttestService.sharedService.attestKey(keyId, hashedChallenge.toNSData()) { attestationKey, error ->
                if (error != null) {
                    // Resume with an exception if an error occurs
                    continuation.resumeWithException(AttestationException(error.localizedDescription))
                } else if (attestationKey != null) {
                    // Resume with the result if successful
                    continuation.resume(attestationKey.toByteArray())
                } else {
                    // Handle unexpected null results gracefully
                    continuation.resumeWithException(AttestationException("Unexpected null key and no error"))
                }
            }
        }
}

@OptIn(ExperimentalForeignApi::class)
fun ByteArray.toNSData(): NSData {
    this.usePinned { pinned ->
        return NSData.dataWithBytes(pinned.addressOf(0), this.size.toULong())
    }
}

@OptIn(ExperimentalForeignApi::class)
fun hash(input: ByteArray): ByteArray {
    val hashBytes = UByteArray(CC_SHA256_DIGEST_LENGTH)
    hashBytes.usePinned { hashPinned ->
        input.usePinned { inputPinned ->
            // Perform SHA-256 hashing
            CC_SHA256(
                inputPinned.addressOf(0),
                input.size.convert(),
                hashPinned.addressOf(0)
            )
        }
    }

    // Convert hash to hexadecimal string
    return hashBytes.toByteArray()
}