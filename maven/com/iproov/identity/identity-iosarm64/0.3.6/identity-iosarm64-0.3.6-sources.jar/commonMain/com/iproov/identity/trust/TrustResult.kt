package com.iproov.identity.trust

/**
 * Result of a trust evaluation against configured [TrustMaterial] sources.
 *
 * The SDK treats [Indeterminate] as failure (fail-closed) for verifier trust,
 * meaning the presentation request is rejected. For issuer trust, [Indeterminate]
 * is returned to the consumer via [RespondableCredentialOffer.verifyIssuer] so
 * they can decide how to handle it.
 */
sealed class TrustResult {

    /**
     * The certificate chain is trusted for the requested [VerificationContext].
     *
     * @param details Optional description of which trust material matched
     *   (e.g., "X.509 direct trust match", "ETSI LoTE at https://...").
     */
    data class Trusted(val details: String? = null) : TrustResult()

    /**
     * The certificate chain is explicitly not trusted. All configured trust
     * materials for the requested context were checked and none matched.
     *
     * @param reason Description of why trust failed.
     */
    data class Untrusted(val reason: String) : TrustResult()

    /**
     * Trust could not be determined. This may be due to:
     * - No trust materials configured for the requested context
     * - Network failure fetching a LoTE
     * - No credential context mapping found for auto-detection
     * - An exception in a predicate trust material
     *
     * @param reason Description of why trust could not be determined.
     * @param cause The underlying exception, if any.
     */
    data class Indeterminate(val reason: String, val cause: Throwable? = null) : TrustResult()
}
