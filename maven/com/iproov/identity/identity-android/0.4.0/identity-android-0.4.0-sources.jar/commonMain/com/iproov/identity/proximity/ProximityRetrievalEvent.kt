package com.iproov.identity.proximity

sealed class ProximityRetrievalEvent(val isFinal: Boolean) {
    data object Decoding : ProximityRetrievalEvent(false)
    data object Connecting : ProximityRetrievalEvent(false)
    data object SendingRequest : ProximityRetrievalEvent(false)
    data object WaitingForResponse : ProximityRetrievalEvent(false)
    data object ProcessingResponse : ProximityRetrievalEvent(false)
    data class Completed(val response: ProximityRetrievalResponse) : ProximityRetrievalEvent(true)

    data class Error(val message: String, val cause: Throwable? = null) :
        ProximityRetrievalEvent(true)
}
