package com.iproov.identity.cryptography

import com.iproov.identity.Logger

/** Raised when a storage [EncryptionKey] does not satisfy the contract the SDK relies on. */
class EncryptionKeyException(message: String) : CryptographyException(message)

/**
 * Encrypts and decrypts the wallet's persisted local data using caller-owned key material.
 *
 * The persisted data includes verifiable credentials and token/key material, so an implementation
 * MUST provide **authenticated encryption (AEAD)** — e.g. AES-256-GCM or ChaCha20-Poly1305 — with:
 *
 *  - **Confidentiality + integrity:** [decrypt] MUST throw (not return corrupted plaintext) when the
 *    input was modified or was produced by a different key. The SDK relies on this to fail closed
 *    on tampered storage and to detect a changed key rather than silently corrupting the wallet.
 *  - **A unique nonce/IV per [encrypt] call** (or a nonce-misuse-resistant AEAD such as AES-GCM-SIV).
 *    Reusing a GCM nonce with the same key is catastrophic.
 *  - **Self-contained framing:** [encrypt] returns the *complete* value to persist (version, nonce,
 *    ciphertext, tag); the SDK writes those bytes verbatim and hands them back to [decrypt]. It adds
 *    no framing of its own.
 *  - **Arbitrary (non-empty) payload sizes** — the SDK only ever encrypts non-empty values.
 *  - **Stable key material across factory calls.** The [EncryptionKeyFactory] is invoked repeatedly
 *    (on every read/write/teardown); every instance MUST be able to decrypt what a previous instance
 *    produced. Rotating the key makes previously-written data permanently unreadable — there is no
 *    key versioning.
 *
 * A key backed by hardware/OS storage (Keystore / Secure Enclave / Keychain) tied to device unlock or
 * user authentication is strongly recommended. Optionally implement [ResettableKey] so wallet teardown
 * can crypto-erase the key.
 *
 * Use [validateEncryptionKey] / [validateEncryptionKeyFactory] to check an implementation against the
 * behavioural parts of this contract.
 */
interface EncryptionKey {
    /** Encrypts [data] into the complete representation that should be written to storage. */
    @Throws(Throwable::class)
    fun encrypt(data: ByteArray): ByteArray

    /** Decrypts a complete value previously returned by [encrypt]; throws if it was tampered with. */
    @Throws(Throwable::class)
    fun decrypt(data: ByteArray): ByteArray
}

/** Supplies the storage-encryption key. Integrators may return their own [EncryptionKey]. */
typealias EncryptionKeyFactory = () -> EncryptionKey

/**
 * Behavioural self-test of a caller [EncryptionKey]; throws [EncryptionKeyException] on failure.
 * Checks round-trip, that [encrypt] isn't a no-op, and that [decrypt] rejects a tampered ciphertext
 * (the practical AEAD signal — unauthenticated schemes return corrupted plaintext instead of failing).
 * Can't prove cipher/key-length/nonce policy. Intended for integrators' own tests; calls [decrypt], so
 * an auth-gated key may prompt.
 */
@Throws(EncryptionKeyException::class)
fun validateEncryptionKey(key: EncryptionKey) {
    val sample = "iproov.identity storage-encryption self-test".encodeToByteArray()

    val ciphertext = roundTrip(key, sample)
    assertRealCiphertext(ciphertext, sample)

    // Catch Throwable so a native Error-type rejection also counts as "tamper detected".
    val tampered = ciphertext.copyOf().also {
        it[it.size - 1] = (it[it.size - 1].toInt() xor 0x01).toByte()
    }
    val rejected = try {
        key.decrypt(tampered)
        false
    } catch (_: Throwable) {
        true
    }
    if (!rejected) {
        throw EncryptionKeyException(
            "decrypt() accepted a tampered ciphertext; storage requires authenticated encryption " +
                "(AEAD, e.g. AES-GCM or ChaCha20-Poly1305) so modified data is rejected."
        )
    }
}

/**
 * Cheap, auth-free runtime guard: confirms [encrypt] isn't a no-op. Deliberately skips [decrypt] so it
 * never prompts on the write path; full AEAD/round-trip checks live in [validateEncryptionKey].
 */
@Throws(EncryptionKeyException::class)
internal fun assertEncryptionKeyProducesCiphertext(key: EncryptionKey) {
    val sample = "iproov.identity storage-encryption runtime check".encodeToByteArray()
    // Let the key's own exceptions (e.g. auth) propagate rather than mislabelling them as a violation.
    assertRealCiphertext(key.encrypt(sample), sample)
}

/** Asserts [ciphertext] is real output for [plaintext] — non-empty and not the plaintext itself. */
private fun assertRealCiphertext(ciphertext: ByteArray, plaintext: ByteArray) {
    if (ciphertext.isEmpty()) {
        throw EncryptionKeyException("encrypt() returned no output.")
    }
    if (ciphertext.contentEquals(plaintext)) {
        throw EncryptionKeyException(
            "encrypt() returned the plaintext unchanged; storage requires real encryption."
        )
    }
}

/**
 * Resets the key's material if (and only if) it opts into [ResettableKey]. Best-effort: failures are
 * logged and swallowed, since teardown must still delete local data. Shared by both storage engines.
 */
internal fun EncryptionKey.resetBestEffort() {
    try {
        (this as? ResettableKey)?.reset()
    } catch (e: Throwable) {
        Logger.error("Storage key reset during deleteAll failed: ${e.message}")
    }
}

/**
 * Validates [factory] the same way as [validateEncryptionKey], and additionally verifies that the key
 * material is **stable across factory invocations** — a value encrypted by one instance must decrypt
 * with another. An unstable factory silently makes previously-written wallet data unrecoverable.
 */
@Throws(EncryptionKeyException::class)
fun validateEncryptionKeyFactory(factory: EncryptionKeyFactory) {
    validateEncryptionKey(factory())

    val sample = "iproov.identity storage key-stability self-test".encodeToByteArray()
    val restored = try {
        factory().decrypt(factory().encrypt(sample))
    } catch (e: Exception) {
        throw EncryptionKeyException(
            "the encryption-key factory is not stable across calls: a value encrypted by one " +
                "instance could not be decrypted by another (${e.message}). Return a key backed by " +
                "the same material on every call."
        )
    }
    if (!restored.contentEquals(sample)) {
        throw EncryptionKeyException(
            "the encryption-key factory is not stable across calls: cross-instance decrypt returned " +
                "different data. Return a key backed by the same material on every call."
        )
    }
}

private fun roundTrip(key: EncryptionKey, plaintext: ByteArray): ByteArray {
    val ciphertext: ByteArray
    val restored: ByteArray
    try {
        ciphertext = key.encrypt(plaintext)
        restored = key.decrypt(ciphertext)
    } catch (e: Throwable) {
        throw EncryptionKeyException(
            "encrypt()/decrypt() round-trip threw for a ${plaintext.size}-byte value: ${e.message}"
        )
    }
    if (!restored.contentEquals(plaintext)) {
        throw EncryptionKeyException(
            "decrypt(encrypt(x)) did not return x for a ${plaintext.size}-byte value."
        )
    }
    return ciphertext
}
