package com.iproov.identity.persistence

import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialRecord
import com.iproov.identity.models.Jwt
import kotlinx.serialization.json.Json

class LocalStorage(private val storageEngine: StorageEngine) {

    private enum class StorageKey(val key: String) {
        TRANSLATION("translations"),
        JWTS("jwts"),
        ATTESTATION_TOKEN("attestationToken"),
        CREDENTIAL_RECORDS("credentials"),
        CREDENTIAL_METADATA("credentials_metadata")
    }

    private val json = Json {
        ignoreUnknownKeys = true
    }

    // -- Public API --

    @Throws(Exception::class)
    suspend fun getAttestationToken(): String? =
        storageEngine.read(StorageKey.ATTESTATION_TOKEN.key)

    @Throws(Exception::class)
    suspend fun setAttestationToken(value: String?) =
        storageEngine.write(StorageKey.ATTESTATION_TOKEN.key, value)

    /**
     * mapped as List<String> to ensure clean serialization of the compact string
     */
    @Throws(Exception::class)
    suspend fun getJwts(): List<Jwt> =
        readJson<List<String>>(StorageKey.JWTS)
            ?.map { Jwt(it) }
            ?: emptyList()

    @Throws(Exception::class)
    suspend fun setJwts(value: List<Jwt>) =
        writeJson(StorageKey.JWTS, value.map { it.compactString })

    @Throws(Exception::class)
    suspend fun getTranslations(): Map<String, String?>? =
        readJson(StorageKey.TRANSLATION)

    @Throws(Exception::class)
    suspend fun setTranslations(value: Map<String, String?>) =
        writeJson(StorageKey.TRANSLATION, value)

    /**
     * Maps metadata uuid -> record
     */
    @Throws(Exception::class)
    suspend fun getCredentials(): Map<String, CredentialRecord> =
        readJson(StorageKey.CREDENTIAL_RECORDS) ?: emptyMap()

    @Throws(Exception::class)
    suspend fun setCredentials(value: Map<String, CredentialRecord>) =
        writeJson(StorageKey.CREDENTIAL_RECORDS, value)

    @Throws(Exception::class)
    suspend fun getCredentialMetadata(): List<CredentialMetadata> =
        readJson(StorageKey.CREDENTIAL_METADATA) ?: emptyList()

    @Throws(Exception::class)
    suspend fun setCredentialMetadata(value: List<CredentialMetadata>) =
        writeJson(StorageKey.CREDENTIAL_METADATA, value)

    @Throws(Exception::class)
    suspend fun deleteAll() = storageEngine.deleteAll()

    // -- Private Helpers --

    /*
     * Reads string from engine and deserializes to T
     */
    private suspend inline fun <reified T> readJson(key: StorageKey): T? =
        storageEngine.read(key.key)?.let { json.decodeFromString(it) }

    /*
     * Serializes T to string and writes to engine
     */
    private suspend inline fun <reified T> writeJson(key: StorageKey, value: T) =
        storageEngine.write(key.key, json.encodeToString(value))
}