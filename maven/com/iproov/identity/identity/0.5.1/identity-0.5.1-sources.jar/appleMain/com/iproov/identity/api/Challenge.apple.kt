package com.iproov.identity.api

import com.iproov.identity.models.AccessControl
import com.iproov.identity.models.MrtdData
import com.iproov.identity.models.RespondableCredentialOffer
import com.iproov.identity.persistence.toByteArray
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.usePinned
import platform.Foundation.NSData
import platform.Foundation.NSDate
import platform.Foundation.create
import platform.Foundation.dateWithTimeIntervalSince1970
import platform.darwin.NSUInteger

@OptIn(ExperimentalForeignApi::class)
val Challenge.challenge: NSData?
    get() {
        val bytes = this.challenge ?: return null

        return bytes.usePinned { pinned ->
            NSData.create(
                bytes = pinned.addressOf(0),
                length = bytes.size.toULong() as NSUInteger,
            )
        }
    }


val Challenge.expires: NSDate
    get() {
        val secondsSince1970 = this.expires.toEpochMilliseconds() / 1000.0
        return NSDate.dateWithTimeIntervalSince1970(secondsSince1970)
    }

suspend fun DocumentChallengeResponder.withMrtd(
    mrtd: MrtdData,
    accessControl: AccessControl,
    signature: NSData?
): RespondableCredentialOffer? = withMrtd(
    mrtd, accessControl, signature?.toByteArray()
)
