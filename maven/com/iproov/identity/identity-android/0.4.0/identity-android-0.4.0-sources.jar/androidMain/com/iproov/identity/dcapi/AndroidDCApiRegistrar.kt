package com.iproov.identity.dcapi

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import androidx.credentials.ExperimentalDigitalCredentialApi
import androidx.credentials.registry.digitalcredentials.mdoc.MdocEntry
import androidx.credentials.registry.digitalcredentials.mdoc.MdocField
import androidx.credentials.registry.digitalcredentials.openid4vp.OpenId4VpRegistry
import androidx.credentials.registry.digitalcredentials.sdjwt.SdJwtClaim
import androidx.credentials.registry.digitalcredentials.sdjwt.SdJwtEntry
import androidx.credentials.registry.provider.ClearCredentialRegistryRequest
import androidx.credentials.registry.provider.RegistryManager
import androidx.credentials.registry.provider.digitalcredentials.DigitalCredentialRegistry
import androidx.credentials.registry.provider.digitalcredentials.VerificationEntryDisplayProperties
import androidx.credentials.registry.provider.digitalcredentials.VerificationFieldDisplayProperties
import com.iproov.identity.Logger
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.SdJwtVcCredential
import com.iproov.identity.models.id

/**
 * Android implementation of DCApiRegistrar using the AndroidX Credentials Registry API.
 *
 * This class registers credentials with Android's system credential picker so they can be
 * discovered and presented when apps/browsers request credentials via the Digital Credentials API.
 *
 * Requirements:
 * - Android 14+ (API 34)
 * - Google Play Services with credentials support
 * - openid4vp_matcher.wasm in the app's assets folder
 *
 * The registration uses the AndroidX RegistryManager which makes credentials visible in the
 * system credential picker UI, allowing users to select credentials across wallet apps.
 *
 * Note: The consumer app must declare the CredentialProviderService in their AndroidManifest.xml
 * for DC API to work. This SDK provides the implementation classes.
 */
@OptIn(ExperimentalDigitalCredentialApi::class)
class AndroidDCApiRegistrar(private val context: Context) : DCApiRegistrar {

    companion object {
        private const val MATCHER_ASSET = "openid4vp_matcher.wasm"
        private const val REGISTRY_ID_SDJWT = "openid4vp-sdjwt"
        private const val REGISTRY_ID_MDOC = "openid4vp-mdoc"

        // Standard document types
        private const val DOCTYPE_MDL = "org.iso.18013.5.1.mDL"
        private const val DOCTYPE_EU_PID = "eu.europa.ec.eudi.pid.1"

        // Namespaces
        private const val NAMESPACE_MDL = "org.iso.18013.5.1"
        private const val NAMESPACE_EU_PID = "eu.europa.ec.eudi.pid.1"
    }

    private val registryManager by lazy {
        RegistryManager.create(context)
    }

    // In-memory tracking of registered credential IDs (non-persistent)
    private val registeredCredentialIds = mutableSetOf<String>()

    /**
     * Register a single credential with the system credential manager.
     * Note: For proper registration with claim values, use registerCredentialWithData() instead.
     * Single-credential registration is not supported — use [registerCredentials] with
     * [CredentialRegistrationInfo] instead, which provides the credential data needed
     * for claim values in the system credential picker.
     */
    override suspend fun registerCredential(metadata: CredentialMetadata) {
        if (!isAvailable()) {
            Logger.debug("DC API not available on this Android version, skipping registration")
            return
        }

        Logger.debug("registerCredential(metadata) is a no-op — use registerCredentials(List<CredentialRegistrationInfo>) for full DC API registration with claim values.")
    }

    /**
     * Register multiple credentials with the system credential manager.
     * This replaces any existing registrations with the provided list.
     *
     * @param credentials List of credential registration info containing both metadata and credential data
     */
    override suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>) {
        if (!isAvailable()) {
            Logger.debug("DC API not available on this Android version, skipping registration")
            return
        }

        if (credentials.isEmpty()) {
            Logger.debug("No credentials to register, clearing registry")
            clearRegistry()
            return
        }

        val matcherBytes = loadMatcher()
        if (matcherBytes.isEmpty()) {
            Logger.error("Cannot register credentials: OpenID4VP matcher not found in assets")
            return
        }

        val defaultIcon = getDefaultIcon()

        // Separate credentials by type
        val sdJwtCredentials = credentials.filter { it.credential is SdJwtVcCredential }
        val mdocCredentials = credentials.filter { it.credential is MDocCredential }

        // Register SD-JWT credentials
        if (sdJwtCredentials.isNotEmpty()) {
            registerSdJwtCredentials(sdJwtCredentials, matcherBytes, defaultIcon)
        }

        // Register mDoc credentials
        if (mdocCredentials.isNotEmpty()) {
            registerMdocCredentials(mdocCredentials, matcherBytes, defaultIcon)
        }

        // Update tracking
        registeredCredentialIds.clear()
        registeredCredentialIds.addAll(credentials.map { it.metadata.id })

        Logger.info("Registered ${credentials.size} credentials (${sdJwtCredentials.size} SD-JWT, ${mdocCredentials.size} mDoc)")
    }

    private suspend fun registerSdJwtCredentials(
        credentials: List<CredentialRegistrationInfo>,
        matcherBytes: ByteArray,
        defaultIcon: Bitmap
    ) {
        val entries = credentials.mapNotNull { info ->
            buildSdJwtEntry(info, defaultIcon)
        }

        if (entries.isEmpty()) return

        val registry = OpenId4VpRegistry(
            credentialEntries = entries,
            id = REGISTRY_ID_SDJWT,
        )

        registryManager.registerCredentials(
            object : DigitalCredentialRegistry(
                id = registry.id,
                credentials = registry.credentials,
                matcher = matcherBytes,
            ) {}
        )

        Logger.debug("Registered ${entries.size} SD-JWT credentials:")
        entries.filterIsInstance<SdJwtEntry>().forEach { entry ->
            Logger.debug(
                "  SD-JWT entry id=${entry.id} (len=${entry.id.length}) vct=${entry.verifiableCredentialType} claims=${
                    entry.claims.map {
                        it.path.joinToString(
                            "."
                        )
                    }
                }"
            )
        }
    }

    private suspend fun registerMdocCredentials(
        credentials: List<CredentialRegistrationInfo>,
        matcherBytes: ByteArray,
        defaultIcon: Bitmap
    ) {
        val entries = credentials.mapNotNull { info ->
            buildMdocEntry(info, defaultIcon)
        }

        if (entries.isEmpty()) return

        val registry = OpenId4VpRegistry(
            credentialEntries = entries,
            id = REGISTRY_ID_MDOC,
        )

        registryManager.registerCredentials(
            object : DigitalCredentialRegistry(
                id = registry.id,
                credentials = registry.credentials,
                matcher = matcherBytes,
            ) {}
        )

        Logger.debug("Registered ${entries.size} mDoc credentials:")
        entries.filterIsInstance<MdocEntry>().forEach { entry ->
            Logger.debug("  mDoc entry id=${entry.id} (len=${entry.id.length}) docType=${entry.docType} fields=${entry.fields.map { "${it.namespace}/${it.identifier}" }}")
        }
    }

    override suspend fun unregisterCredential(credentialId: String) {
        if (!isAvailable()) {
            Logger.debug("DC API not available on this Android version, skipping unregistration")
            return
        }

        registeredCredentialIds.remove(credentialId)
        Logger.info("Removed credential $credentialId from tracking. Call registerCredentials() with remaining credentials to update the registry.")
    }

    /**
     * Clear all credential registrations from the system.
     */
    suspend fun clearRegistry() {
        if (!isAvailable()) return

        try {
            registryManager.clearCredentialRegistry(ClearCredentialRegistryRequest(isDeleteAll = true))
            registeredCredentialIds.clear()
            Logger.info("Cleared all credential registrations")
        } catch (e: Exception) {
            Logger.error("Failed to clear registry: ${e.message}")
        }
    }

    override fun isAvailable(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE
    }

    override fun isCredentialRegistered(credentialId: String): Boolean {
        if (!isAvailable()) return false
        return credentialId in registeredCredentialIds
    }

    /**
     * Build an SdJwtEntry for the given credential.
     */
    private fun buildSdJwtEntry(info: CredentialRegistrationInfo, icon: Bitmap): SdJwtEntry? {
        val credential = info.credential as? SdJwtVcCredential ?: return null
        val metadata = info.metadata
        val vct = credential.vct

        val firstDisplay = metadata.display.firstOrNull()
        val displayName = firstDisplay?.name ?: "Credential"
        val displayDescription = firstDisplay?.description ?: ""

        // Build claims from the credential body
        val claims = credential.body.keys.map { claimName ->
            val claimValue = credential.body[claimName]
            SdJwtClaim(
                path = listOf(claimName),
                value = claimValue?.toString(),
                fieldDisplayPropertySet = setOf(
                    VerificationFieldDisplayProperties(
                        displayName = formatClaimDisplayName(claimName),
                        displayValue = claimValue?.toString(),
                    )
                ),
                isSelectivelyDisclosable = claimName in credential.disclosableClaimNames,
            )
        }

        return SdJwtEntry(
            verifiableCredentialType = vct,
            claims = claims,
            entryDisplayPropertySet = setOf(
                VerificationEntryDisplayProperties(
                    icon = icon,
                    title = displayName,
                    subtitle = displayDescription,
                )
            ),
            id = metadata.id,
        )
    }

    /**
     * Build an MdocEntry for the given credential.
     */
    private fun buildMdocEntry(info: CredentialRegistrationInfo, icon: Bitmap): MdocEntry? {
        val credential = info.credential as? MDocCredential ?: return null
        val metadata = info.metadata
        val docType = credential.docType

        val firstDisplay = metadata.display.firstOrNull()
        val displayName = firstDisplay?.name ?: "Credential"
        val displayDescription = firstDisplay?.description ?: ""

        // Build fields from the credential's namespaced data
        val fields = mutableListOf<MdocField>()

        credential.nameSpaces.forEach { (namespace, elements) ->
            elements.forEach { (identifier, value) ->
                fields.add(
                    MdocField(
                        namespace = namespace,
                        identifier = identifier,
                        fieldValue = value,
                        fieldDisplayPropertySet = setOf(
                            VerificationFieldDisplayProperties(
                                displayName = formatClaimDisplayName(identifier),
                                displayValue = value?.toString(),
                            )
                        ),
                    )
                )
            }
        }

        return MdocEntry(
            docType = docType,
            fields = fields,
            entryDisplayPropertySet = setOf(
                VerificationEntryDisplayProperties(
                    icon = icon,
                    title = displayName,
                    subtitle = displayDescription,
                )
            ),
            id = metadata.id,
        )
    }

    /**
     * Load the OpenID4VP matcher WASM from assets.
     */
    private fun loadMatcher(): ByteArray {
        return try {
            context.assets.open(MATCHER_ASSET).use { it.readBytes() }.also {
                Logger.debug("Loaded matcher WASM (${it.size} bytes)")
            }
        } catch (e: Exception) {
            Logger.error("Failed to load OpenID4VP matcher from assets: ${e.message}")
            byteArrayOf()
        }
    }

    /**
     * Get a default icon bitmap for credentials.
     */
    private fun getDefaultIcon(): Bitmap {
        return try {
            val appIcon = context.packageManager.getApplicationIcon(context.packageName)
            val bitmap = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            appIcon.setBounds(0, 0, 48, 48)
            appIcon.draw(canvas)
            bitmap
        } catch (e: Exception) {
            Logger.debug("Failed to get app icon, using default")
            Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
        }
    }

    /**
     * Format a claim name for display (e.g., "family_name" -> "Family Name").
     */
    private fun formatClaimDisplayName(claimName: String): String {
        return claimName
            .replace("_", " ")
            .split(" ")
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
    }
}
