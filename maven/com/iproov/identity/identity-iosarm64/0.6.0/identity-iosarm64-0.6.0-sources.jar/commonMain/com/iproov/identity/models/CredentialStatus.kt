package com.iproov.identity.models

/**
 * A credential's status in its IETF Token Status List (draft-ietf-oauth-status-list-21 §7.1), as
 * returned by [com.iproov.identity.Wallet.resolveStatus]. The cases match the EUDI wallet libraries'.
 */
sealed class CredentialStatus {
    /** 0x00: valid. */
    data object Valid : CredentialStatus()

    /** 0x01: revoked by the issuer. */
    data object Invalid : CredentialStatus()

    /** 0x02: temporarily invalid. */
    data object Suspended : CredentialStatus()

    /** 0x03 or 0x0C to 0x0F: defined by the issuer's ecosystem. */
    data class ApplicationSpecific(val value: UByte) : CredentialStatus()

    /** Any other value, reserved by the specification for future use. */
    data class Reserved(val value: UByte) : CredentialStatus()
}

/**
 * Why [com.iproov.identity.Wallet.resolveStatus] could not establish a credential's status. It never
 * means the credential is valid. [details] carries the same machine-readable fields as the
 * `status_list` result in a [VerificationSummary], such as `cause`, `step`, `uri` and `httpStatus`.
 */
sealed class CredentialStatusException(
    message: String,
    val details: Map<String, String>,
    cause: Throwable? = null,
) : Exception(message, cause) {

    /** The credential carries no status reference, so its issuer publishes no status for it. */
    class NoStatusReference internal constructor() : CredentialStatusException("Credential has no status reference", mapOf("cause" to "no_status"))

    /** The credential format or its status mechanism is not supported. */
    class Unsupported internal constructor(message: String, details: Map<String, String>) :
        CredentialStatusException(message, details)

    /**
     * The credential failed its own validation (signature, digests, issuer trust or validity period),
     * so its status was not checked (Token Status List §8.3). [verificationStatus] and `details["check"]`
     * say which.
     */
    class InvalidCredential internal constructor(val verificationStatus: VerificationStatus, message: String, check: String) :
        CredentialStatusException(message, mapOf("cause" to "invalid_credential", "check" to check))

    /** The status list could not be fetched: a network error, a timeout or an HTTP error. */
    class RetrievalFailed internal constructor(message: String, details: Map<String, String>, cause: Throwable? = null) :
        CredentialStatusException(message, details, cause)

    /** The status list was fetched but failed verification of its signer, signature, claims or format. */
    class VerificationFailed internal constructor(message: String, details: Map<String, String>, cause: Throwable? = null) :
        CredentialStatusException(message, details, cause)

    /** The credential's index is outside the status list, which therefore makes no statement (§8.3 step 6). */
    class IndexOutOfBounds internal constructor(details: Map<String, String>) :
        CredentialStatusException("Status index is outside the status list", details)
}
