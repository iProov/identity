package com.iproov.identity.models

val CredentialDescriptor.raw get() = raw.toNativeTypes()