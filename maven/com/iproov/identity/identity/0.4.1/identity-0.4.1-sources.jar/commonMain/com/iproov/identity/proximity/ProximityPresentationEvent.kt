package com.iproov.identity.proximity

/**
 * Lifecycle events emitted by a [ProximityPresentationSession] (ISO 18013-5 §6 + §8).
 * Collect until [isFinal] is true; terminal states are [Disconnected] and [Failure].
 */
sealed class ProximityPresentationEvent(val isFinal: Boolean) {

    sealed class Engagement : ProximityPresentationEvent(false) {

        /** Building the ephemeral key + DeviceEngagement; no engagement method picked yet. */
        data object Generating : Engagement()

        /** Engagement via QR code */
        sealed class Qr : Engagement() {
            /** `mdoc:<base64url-DeviceEngagement>` URI is ready — render as QR. */
            data class Ready(val payload: QrEngagementPayload) : Qr()
        }

        /** Engagement via NFC NDEF Type 4 tag */
        sealed class Nfc : Engagement() {
            /** HCE service primed with the engagement; awaiting a reader tap. */
            data object Ready : Nfc()

            /** Reader is in field; APDU / NDEF handover exchange in progress. */
            data object Engaging : Nfc()

            /** Handover bytes exchanged; about to open the retrieval transport. */
            data object Completed : Nfc()
        }
    }

    data object Connecting : ProximityPresentationEvent(false)

    data object Connected : ProximityPresentationEvent(false)

    /** A reader has been detected; the BLE handshake is in progress. */
    data object CreatingSession : ProximityPresentationEvent(false)

    /** The BLE channel is open and session encryption keys are derived; awaiting the request. */
    data object SessionCreated : ProximityPresentationEvent(false)

    /** The reader sent a DeviceRequest; show consent UI and call `ProximitySession.respond`. */
    data class RequestReceived(val request: RespondableProximityRequest) :
        ProximityPresentationEvent(false)

    data object PresentationSent : ProximityPresentationEvent(false)

    /** Either side closed the connection cleanly. */
    data object Disconnected : ProximityPresentationEvent(true)

    /** Terminal: an unrecoverable error occurred. */
    data class Failure(val error: String, val cause: Throwable) : ProximityPresentationEvent(true)
}


