package com.iproov.identity.dcapi

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.WalletFactory
import com.iproov.identity.api.VPTokenFactory
import com.iproov.identity.cryptography.JWEFactory
import com.iproov.identity.encodeToJsonObject
import com.iproov.identity.models.AuthorizationRequest
import com.iproov.identity.models.AuthorizationRequestClientMetadata
import com.iproov.identity.models.ClaimQuery
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialQuery
import com.iproov.identity.models.DcqlQuery
import com.iproov.identity.models.Jwk
import com.iproov.identity.models.Jwks
import com.iproov.identity.models.KeyUse
import com.iproov.identity.models.PresentationRequest
import com.iproov.identity.models.Query
import com.iproov.identity.models.ResponseMode
import com.iproov.identity.models.Verifier
import com.iproov.identity.models.VerifierDisplayProperties
import com.iproov.identity.persistence.CredentialSubmission
import com.iproov.identity.persistence.DCQLMatchResult
import com.iproov.identity.persistence.DCQLMatcher
import com.iproov.identity.persistence.Repository
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/**
 * Orchestrator for processing Digital Credentials API requests.
 *
 * This interface handles DC API requests from OS-level credential managers (Android CredentialManager,
 * iOS IdentityDocumentServices) and coordinates credential presentation without HTTP responses.
 */
interface DCApiOrchestrator {

    /**
     * Process a DC API request and find matching credentials.
     *
     * @param requestJson The JSON request from navigator.credentials.get()
     * @return Information about matching credentials and the query
     */
    suspend fun processRequest(requestJson: String, callingOrigin: String): DCApiMatchResult

    /**
     * Build a credential response for the selected credentials.
     *
     * @param matchResult The result from processRequest containing the query context
     * @param submission The user's credential selection
     * @return The DC API response to return to the browser
     */
    suspend fun buildResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission,
    ): DCApiResult

    /**
     * Register a credential with the OS credential manager for DC API requests.
     * On unsupported platforms, this is a no-op.
     *
     * @param metadata The credential metadata to register
     */
    suspend fun registerCredential(metadata: CredentialMetadata)

    /**
     * Register multiple credentials with the OS credential manager.
     * This replaces any existing registrations with the provided list.
     * On unsupported platforms, this is a no-op.
     *
     * @param credentials The list of credentials to register
     */
    suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>)

    /**
     * Unregister a credential from the OS credential manager.
     * On unsupported platforms, this is a no-op.
     *
     * @param credentialId The ID of the credential to unregister
     */
    suspend fun unregisterCredential(credentialId: String)

    /**
     * Check if DC API is available on this platform/OS version.
     */
    fun isAvailable(): Boolean

    /**
     * Check if a specific credential is registered with the OS credential manager.
     *
     * @param credentialId The ID of the credential to check
     * @return true if the credential is registered, false otherwise
     */
    fun isCredentialRegistered(credentialId: String): Boolean
}

/**
 * Result of processing a DC API request to find matching credentials.
 */
sealed class DCApiMatchResult {
    /**
     * Found matching credentials that can satisfy the request.
     */
    data class Success(
        val presentationRequest: PresentationRequest,
        val matchResult: DCQLMatchResult,
        val dcApiRequest: DCApiRequest,
        val browserHandoverInfo: BrowserHandoverInfo?,
    ) : DCApiMatchResult()

    /**
     * No credentials match the request.
     */
    data class NoMatch(
        val message: String,
    ) : DCApiMatchResult()

    /**
     * The request is invalid or uses an unsupported protocol.
     */
    data class InvalidRequest(
        val code: String,
        val message: String,
    ) : DCApiMatchResult()
}

/**
 * Default implementation of DCApiOrchestrator.
 *
 * This implementation reuses existing VP Token generation logic while adapting
 * the transport layer for DC API (no HTTP POST, direct response return).
 */
class DefaultDCApiOrchestrator(
    private val repository: Repository,
    private val keyPairFactory: KeyPairFactory,
    private val jweFactory: JWEFactory,
    private val dcApiRegistrar: DCApiRegistrar? = null,
) : DCApiOrchestrator {

    private val dcqlMatcher = DCQLMatcher(repository)
    private val vpTokenFactory by lazy { VPTokenFactory(keyPairFactory) }
    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun processRequest(requestJson: String, callingOrigin: String): DCApiMatchResult {
        Logger.debug("Processing DC API request: $requestJson")

        // Parse the DC API request
        val dcApiRequest = try {
            DCApiRequest.fromJson(requestJson)
        } catch (e: Exception) {
            Logger.error("Failed to parse DC API request: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid DC API request format: ${e.message}"
            )
        }

        // Find supported provider
        val provider = dcApiRequest.findSupportedProvider()
            ?: return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.UNSUPPORTED_PROTOCOL,
                message = "No supported protocol found. Supported: ${DCApiProtocol.OPENID4VP}, ${DCApiProtocol.ISO_MDOC}"
            )

        return when (provider.protocol) {
            DCApiProtocol.OPENID4VP -> processOpenID4VPRequest(provider, dcApiRequest, callingOrigin)
            DCApiProtocol.ISO_MDOC -> processIsoMDocRequest(provider, dcApiRequest, callingOrigin)
            else -> DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.UNSUPPORTED_PROTOCOL,
                message = "Unsupported protocol: ${provider.protocol}"
            )
        }
    }

    private suspend fun processOpenID4VPRequest(
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String
    ): DCApiMatchResult {
        Logger.debug("Processing OpenID4VP DC API request (signed=${provider.isSignedRequest})")

        // Handle signed vs unsigned requests differently
        return if (provider.isSignedRequest) {
            processSignedOpenID4VPRequest(provider, dcApiRequest, origin)
        } else {
            processUnsignedOpenID4VPRequest(provider, dcApiRequest, origin)
        }
    }

    /**
     * Process a signed OpenID4VP DC API request (JAR format).
     * The request data contains {"request": "<JWT>"} where the JWT contains the authorization parameters.
     */
    private suspend fun processSignedOpenID4VPRequest(
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String
    ): DCApiMatchResult {
        Logger.debug("Processing signed OpenID4VP DC API request")

        // Extract JWT from data.request
        val requestJwt = try {
            provider.request.jsonObject["request"]?.jsonPrimitive?.content
                ?: return DCApiMatchResult.InvalidRequest(
                    code = DCApiErrorCode.INVALID_REQUEST,
                    message = "Signed request missing 'request' field containing JWT"
                )
        } catch (e: Exception) {
            Logger.error("Failed to extract JWT from signed request: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid signed request format: ${e.message}"
            )
        }

        Logger.debug("Extracted JWT from signed request")

        // Use existing AuthorizationRequest.fromRequestJwtOrJson() to decode the JWT
        val authorizationRequest = try {
            AuthorizationRequest.fromRequestJwtOrJson(requestJwt)
        } catch (e: Exception) {
            Logger.error("Failed to parse signed authorization request JWT: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid signed authorization request: ${e.message}"
            )
        }

        Logger.debug("Decoded authorization request from JWT: clientId=${authorizationRequest.clientId}")

        // TODO: Verify JWT signature using x5c certificate chain
        // For now, we trust the request but signature verification should be added
        // The x5c header contains the certificate chain for verification

        return buildMatchResult(authorizationRequest, provider, dcApiRequest, origin)
    }

    /**
     * Process an unsigned OpenID4VP DC API request.
     * The request data contains the authorization parameters directly as JSON.
     */
    private suspend fun processUnsignedOpenID4VPRequest(
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String
    ): DCApiMatchResult {
        Logger.debug("Processing unsigned OpenID4VP DC API request")

        val oid4vpRequest = try {
            OpenID4VPDCApiRequest.fromJsonElement(provider.request)
        } catch (e: Exception) {
            Logger.error("Failed to parse OpenID4VP DC API request: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid OpenID4VP request: ${e.message}"
            )
        }
        // Determine response mode
        val responseMode = when (oid4vpRequest.responseMode) {
            "dc_api" -> ResponseMode.DC_API
            "dc_api.jwt" -> ResponseMode.DC_API_JWT
            else -> ResponseMode.DC_API // Default to dc_api
        }

        Logger.debug("Response mode: $responseMode")
        // Build DCQL query
        val dcqlQuery = if (oid4vpRequest.dcqlQuery != null) {
            try {
                json.decodeFromJsonElement(DcqlQuery.serializer(), oid4vpRequest.dcqlQuery)
            } catch (e: Exception) {
                Logger.error("Failed to parse DCQL query: ${e.message}")
                return DCApiMatchResult.InvalidRequest(
                    code = DCApiErrorCode.INVALID_REQUEST,
                    message = "Invalid DCQL query: ${e.message}"
                )
            }
        } else {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "DCQL query is required for OpenID4VP DC API requests"
            )
        }

        Logger.debug("DCQL: $dcqlQuery")
        // Parse client metadata if present
        val clientMetadata = oid4vpRequest.clientMetadata?.let {
            try {
                json.decodeFromJsonElement(AuthorizationRequestClientMetadata.serializer(), it)
            } catch (e: Exception) {
                Logger.debug("Could not parse client metadata: ${e.message}")
                null
            }
        }


        // Build AuthorizationRequest for reuse with existing VP Token factory
        val authorizationRequest = AuthorizationRequest(
            clientId = oid4vpRequest.clientId,
            nonce = requireNotNull(oid4vpRequest.nonce) {
                "Nonce is required for OpenID4VP DC API requests"
            },
            responseType = "vp_token",
            responseMode = responseMode,
            responseUri = null, // DC API doesn't use response_uri
            redirectUri = null,
            dcqlQuery = dcqlQuery,
            scope = null,
            state = null,
            clientMetadata = clientMetadata,
            raw = json.encodeToString(provider.request.jsonObject),
        )

        Logger.debug("AuthorizationRequest: $authorizationRequest")

        return buildMatchResult(authorizationRequest, provider, dcApiRequest, origin)
    }

    /**
     * Build the match result from an authorization request.
     * Shared by both signed and unsigned request processing.
     */
    private suspend fun buildMatchResult(
        authorizationRequest: AuthorizationRequest,
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String,
    ): DCApiMatchResult {
        val dcqlQuery = authorizationRequest.dcqlQuery
            ?: return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "DCQL query is required for OpenID4VP DC API requests"
            )

        // Determine origin for browser handover
        // For signed requests, use expected_origins from JWT; for unsigned, use origin field
        val origin = origin ?: authorizationRequest.expectedOrigins?.firstOrNull()

        // Create browser handover info for session transcript
        val browserHandoverInfo = origin?.let {
            BrowserHandoverInfo(
                origin = it,
                nonce = authorizationRequest.nonce,
                requesterKeyHash = null // Would be populated if requester provides a key
            )
        }

        Logger.debug("BrowserHandoverInfo: $browserHandoverInfo")

        // Get client metadata from authorization request
        val clientMetadata = authorizationRequest.clientMetadata

        // Build presentation request
        val presentationRequest = PresentationRequest(
            raw = if (provider.request is JsonNull) JsonObject(emptyMap()) else provider.request.jsonObject,
            verifier = Verifier(
                clientId = authorizationRequest.clientId,
                display = VerifierDisplayProperties(
                    logoUri = null,
                    displayName = clientMetadata?.clientName,
                    userHint = null
                ),
                jwks = if (clientMetadata == null || clientMetadata.jwks == null) null else clientMetadata.jwks.encodeToJsonObject(),
            ),
            request = authorizationRequest,
            query = Query(
                raw = dcqlQuery.encodeToJsonObject(),
                definition = dcqlQuery
            ) { dcqlMatcher.match(dcqlQuery) }
        )

        Logger.debug("PresentationRequest: $presentationRequest")

        // Find matching credentials
        val matchResult = dcqlMatcher.match(dcqlQuery)
        if (matchResult.isEmpty) {
            return DCApiMatchResult.NoMatch(
                message = "No credentials match the requested criteria"
            )
        }

        return DCApiMatchResult.Success(
            presentationRequest = presentationRequest,
            matchResult = matchResult,
            dcApiRequest = dcApiRequest,
            browserHandoverInfo = browserHandoverInfo
        )
    }

    private suspend fun processIsoMDocRequest(
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String,
    ): DCApiMatchResult {

        Logger.debug("Processing ISO MDoc DC API request")

        val mdocRequest = try {
            IsoMDocDCApiRequest.fromJsonElement(provider.request)
        } catch (e: Exception) {
            Logger.error("Failed to parse ISO mDoc DC API request: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid ISO mDoc request: ${e.message}"
            )
        }

        // Build DCQL query from mDoc request
        val claims = mdocRequest.nameSpaces?.flatMap { (namespace, elements) ->
            elements.filter { it.value }.map { (element, _) ->
                ClaimQuery(
                    id = element,
                    path = listOf(namespace, element)
                )
            }
        }

        val credentialQuery = CredentialQuery(
            id = "mdoc_request",
            format = "mso_mdoc",
            meta = buildJsonObject {
                put("doctype_value", mdocRequest.docType)
            },
            claims = claims
        )

        val dcqlQuery = DcqlQuery(credentials = listOf(credentialQuery))

        // Build a pseudo AuthorizationRequest for compatibility
        val authorizationRequest = AuthorizationRequest(
            clientId = mdocRequest.origin ?: "unknown",
            nonce = mdocRequest.nonce ?: "",
            responseType = "vp_token",
            responseMode = ResponseMode.DC_API,
            responseUri = null,
            redirectUri = null,
            dcqlQuery = dcqlQuery,
            scope = null,
            state = null,
            clientMetadata = null,
            raw = json.encodeToString(provider.request.jsonObject),
        )

        val browserHandoverInfo = mdocRequest.origin?.let { origin ->
            BrowserHandoverInfo(
                origin = origin,
                nonce = mdocRequest.nonce ?: "",
                requesterKeyHash = null
            )
        }

        val presentationRequest = PresentationRequest(
            raw = provider.request.jsonObject,
            verifier = Verifier(
                clientId = mdocRequest.origin ?: "unknown",
                display = VerifierDisplayProperties(null, null, null),
                jwks = null
            ),
            request = authorizationRequest,
            query = Query(
                raw = provider.request.jsonObject,
                definition = dcqlQuery
            ) { dcqlMatcher.match(dcqlQuery) }
        )

        val matchResult = dcqlMatcher.match(dcqlQuery)
        if (matchResult.isEmpty) {
            return DCApiMatchResult.NoMatch(
                message = "No mDoc credentials match docType: ${mdocRequest.docType}"
            )
        }

        return DCApiMatchResult.Success(
            presentationRequest = presentationRequest,
            matchResult = matchResult,
            dcApiRequest = dcApiRequest,
            browserHandoverInfo = browserHandoverInfo
        )
    }

    override suspend fun buildResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission,
    ): DCApiResult {
        Logger.debug("Building DC API response for submission: $submission")

        return try {
            when (val responseMode = matchResult.presentationRequest.request.responseMode) {
                ResponseMode.DC_API -> buildPlainResponse(matchResult, submission)
                ResponseMode.DC_API_JWT -> buildEncryptedResponse(matchResult, submission)
                else -> DCApiResult.Error(
                    code = DCApiErrorCode.INTERNAL_ERROR,
                    message = "Unexpected response mode for DC API: $responseMode"
                )
            }
        } catch (e: Exception) {
            Logger.error("Failed to build DC API response: ${e.message}")
            DCApiResult.Error(
                code = DCApiErrorCode.SIGNING_FAILED,
                message = "Failed to build credential response: ${e.message}",
                cause = e
            )
        }
    }

    private suspend fun buildPlainResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission,
    ): DCApiResult {
        // Build VP Token using existing factory with DC API session transcript
        val vpToken = vpTokenFactory.buildForDCApi(
            matchResult.presentationRequest,
            submission,
            matchResult.browserHandoverInfo
        )

        val provider = matchResult.dcApiRequest.findSupportedProvider()!!
        val response = when (provider.protocol) {
            DCApiProtocol.OPENID4VP -> DCApiResponse.forOpenID4VP(
                vpToken = vpToken,
                state = matchResult.presentationRequest.request.state
            )

            DCApiProtocol.ISO_MDOC -> DCApiResponse.forIsoMDoc(
                deviceResponse = vpToken
            )

            else -> return DCApiResult.Error(
                code = DCApiErrorCode.UNSUPPORTED_PROTOCOL,
                message = "Unsupported protocol: ${provider.protocol}"
            )
        }

        return DCApiResult.Success(response)
    }

    private suspend fun buildEncryptedResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission,
    ): DCApiResult {
        // For dc_api.jwt, we need to encrypt the response
        val clientMetadata = matchResult.presentationRequest.request.clientMetadata
        val jwks = clientMetadata?.jwks
            ?: return DCApiResult.Error(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Client JWKS required for dc_api.jwt response mode"
            )

        // Find suitable encryption key
        val encryptionKey = selectEncryptionKey(clientMetadata, jwks)
            ?: return DCApiResult.Error(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "No suitable encryption key found in client JWKS"
            )

        val (alg, enc, jwk) = encryptionKey
        val jwkThumbprint = jwk.computeThumbprint()

        // Build VP Token with JWK thumbprint for device binding
        val vpToken = vpTokenFactory.buildForDCApi(
            matchResult.presentationRequest,
            submission,
            matchResult.browserHandoverInfo,
            jwkThumbprint
        )

        // Build payload to encrypt
        val payload = buildJsonObject {
            put("vp_token", json.parseToJsonElement(vpToken))
            matchResult.presentationRequest.request.state?.let {
                put("state", it)
            }
        }

        // Encrypt the payload
        val jwe = jweFactory.create(
            payload = json.encodeToString(JsonObject.serializer(), payload).encodeToByteArray(),
            recipientPublicKey = jwk,
            alg = alg,
            encToUse = enc
        )

        val response = DCApiResponse.forOpenID4VPJWT(
            jwe = jwe,
            state = matchResult.presentationRequest.request.state
        )

        return DCApiResult.Success(response)
    }

    /**
     * Select an encryption key from the client's JWKS for encrypting the Authorization Response.
     *
     * Key selection follows RFC 7517 (JWK) and RFC 7516 (JWE) requirements:
     * - 'use' parameter is OPTIONAL per RFC 7517 Section 4.2; accept if absent or "enc"
     * - 'alg' parameter is OPTIONAL per RFC 7517 Section 4.4; infer from key type if absent
     * - Content encryption algorithm defaults to A128GCM per OpenID4VP spec
     *
     * @return Triple of (keyManagementAlg, contentEncryptionAlg, jwk) or null if no suitable key found
     */
    private fun selectEncryptionKey(
        metadata: AuthorizationRequestClientMetadata,
        jwks: Jwks,
    ): Triple<String, String, Jwk>? {
        // Determine supported content encryption algorithms
        // Per OpenID4VP: default is A128GCM if not specified
        val supportedEncs = metadata.encryptedResponseSupportedAlgorithms
            ?.filter { jweFactory.supportedEncryptionAlgorithms.contains(it) }
            ?.ifEmpty { null }
            ?: listOf("A128GCM").filter { jweFactory.supportedEncryptionAlgorithms.contains(it) }

        if (supportedEncs.isEmpty()) {
            Logger.error("No supported content encryption algorithms available")
            return null
        }

        return jwks.keys.firstNotNullOfOrNull { jwk ->
            // Per RFC 7517 Section 4.2: 'use' is OPTIONAL
            // Accept if absent (key can be used for any purpose) or if explicitly 'enc'
            val useAcceptable = jwk.use == null || jwk.use == KeyUse.ENC
            if (!useAcceptable) {
                Logger.debug("JWK kid=${jwk.kid} has use=${jwk.use}, skipping (not suitable for encryption)")
                return@firstNotNullOfOrNull null
            }

            // Per RFC 7517 Section 4.4: 'alg' is OPTIONAL
            // If absent, infer from key type per RFC 7518
            val keyAlg = jwk.alg ?: inferKeyManagementAlgorithm(jwk)
            if (keyAlg == null) {
                Logger.debug("Cannot determine key management algorithm for JWK kid=${jwk.kid}, kty=${jwk.kty}, crv=${jwk.crv}")
                return@firstNotNullOfOrNull null
            }

            if (!jweFactory.supportedKeyManagementAlgorithms.contains(keyAlg)) {
                Logger.debug("JWK kid=${jwk.kid} uses unsupported key management algorithm: $keyAlg")
                return@firstNotNullOfOrNull null
            }

            Triple(keyAlg, supportedEncs.first(), jwk)
        }
    }

    /**
     * Infer key management algorithm from JWK parameters when 'alg' is not specified.
     * Per RFC 7518 (JSON Web Algorithms):
     * - EC keys with P-256/P-384/P-521 curves use ECDH-ES (Section 4.6)
     * - RSA keys default to RSA-OAEP (Section 4.3)
     */
    private fun inferKeyManagementAlgorithm(jwk: Jwk): String? {
        return when (jwk.kty) {
            "EC" -> when (jwk.crv) {
                "P-256", "P-384", "P-521" -> "ECDH-ES"
                else -> null
            }

            "RSA" -> "RSA-OAEP"
            else -> null
        }
    }

    override suspend fun registerCredential(metadata: CredentialMetadata) {
        dcApiRegistrar?.registerCredentials(
            listOf(
                CredentialRegistrationInfo(
                    metadata = metadata,
                    WalletFactory.instance!!.getCredential(metadata)
                )
            )
        )
    }

    override suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>) {
        dcApiRegistrar?.registerCredentials(credentials)
    }

    override suspend fun unregisterCredential(credentialId: String) {
        dcApiRegistrar?.unregisterCredential(credentialId)
    }

    override fun isAvailable(): Boolean {
        return dcApiRegistrar?.isAvailable() ?: false
    }

    override fun isCredentialRegistered(credentialId: String): Boolean {
        return dcApiRegistrar?.isCredentialRegistered(credentialId) ?: false
    }
}


/**
 * Data class combining credential metadata with the actual credential for DC API registration.
 */
data class CredentialRegistrationInfo(
    val metadata: CredentialMetadata,
    val credential: Credential,
)


/**
 * Platform-specific interface for registering credentials with OS credential managers.
 * Implemented separately for Android and iOS.
 */
interface DCApiRegistrar {
    /**
     * Register a credential with the OS credential manager.
     */
    suspend fun registerCredential(metadata: CredentialMetadata)

    suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>)

    /**
     * Unregister a credential from the OS credential manager.
     */
    suspend fun unregisterCredential(credentialId: String)

    /**
     * Check if DC API registration is available on this platform.
     */
    fun isAvailable(): Boolean

    /**
     * Check if a specific credential is registered with the OS credential manager.
     */
    fun isCredentialRegistered(credentialId: String): Boolean
}
