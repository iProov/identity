package com.iproov.identity

import com.iproov.identity.cryptography.KeyPairAccessPolicy
import com.iproov.identity.cryptography.asCustomerManaged
import com.iproov.identity.cryptography.asSdkManaged
import com.iproov.identity.cryptography.getDeviceBoundKeyPair
import com.iproov.identity.cryptography.validateSigningKey
import com.iproov.identity.persistence.CredentialDeserializer
import com.iproov.identity.persistence.LegacyCredentialDeserializer
import com.iproov.identity.persistence.StorageEngine
import com.iproov.identity.persistence.getDeviceBoundStorageEngine

object WalletFactory {
    var instance: Wallet? = null

    fun getInstance(
        baseUrl: String,
        isLoggingEnabled: Boolean = false, // Keep default for Boolean here too for consistency if called from Kotlin
        storageEngine: StorageEngine = getDeviceBoundStorageEngine(KeyPairAccessPolicy.DeviceUnlocked),
        signingKeyPairFactory: KeyPairFactory = {
            getDeviceBoundKeyPair(
                KeyPairAccessPolicy.DeviceUnlocked, "com.iproov.identity"
            ).asSdkManaged()
        },
        credentialDeserializer: CredentialDeserializer = CredentialDeserializer(),
        legacyCredentialDeserializer: LegacyCredentialDeserializer = LegacyCredentialDeserializer()
    ): Wallet {
        val validatedSigningKeyPairFactory: KeyPairFactory = {
            signingKeyPairFactory()
                .asCustomerManaged()
                .also(::validateSigningKey)
        }

        // This is the main implementation function where the instance is created
        val actualInstance = getWalletInstance(
            baseUrl,
            isLoggingEnabled,
            storageEngine,
            validatedSigningKeyPairFactory,
            legacyCredentialDeserializer,
            credentialDeserializer,
        )

        instance = actualInstance
        return actualInstance
    }
}

internal expect fun getWalletInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
    legacyCredentialDeserializer: LegacyCredentialDeserializer, // Remove when when legacy credentials have been removed
    credentialDeserializer: CredentialDeserializer,
): Wallet
