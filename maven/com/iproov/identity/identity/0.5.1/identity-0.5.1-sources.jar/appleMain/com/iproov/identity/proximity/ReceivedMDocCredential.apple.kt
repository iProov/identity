package com.iproov.identity.proximity

import com.iproov.identity.cryptography.toNSData
import platform.Foundation.NSData

fun ReceivedMDocCredential.getClaimDataValue(namespace: String, name: String): NSData? {
    val value = nameSpaces[namespace]?.get(name) ?: return null
    return (value as? ByteArray)?.toNSData()
}

val ReceivedMDocCredential.issuerCertificateChain
    get(): List<NSData> {
        return issuerCertificateChain.map { it.toNSData() }
    }
