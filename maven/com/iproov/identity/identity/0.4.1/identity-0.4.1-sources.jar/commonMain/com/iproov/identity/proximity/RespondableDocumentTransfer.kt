package com.iproov.identity.proximity

import kotlinx.serialization.Serializable

typealias Namespace = String

@Serializable
data class ClaimToRequest(
    // Name of the item / claim in the namespace
    val name: String,

    // Whether you intend to keep this information after the transaction
    val intentToRetain: Boolean
)

@Serializable
data class DocumentRequest(
    val docType: String,
    val itemsToRequest: Map<Namespace, List<ClaimToRequest>>
) {
    internal fun toItemsMap(): Map<String, Map<String, Boolean>> {
        return itemsToRequest.mapValues { it.value.associate { claim -> claim.name to claim.intentToRetain } }
    }
}