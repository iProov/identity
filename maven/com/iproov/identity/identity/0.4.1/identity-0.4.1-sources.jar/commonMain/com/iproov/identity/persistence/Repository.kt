package com.iproov.identity.persistence

import com.iproov.identity.Logger
import com.iproov.identity.models.Claim
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialRecord
import com.iproov.identity.models.CredentialRetrievalFailure
import com.iproov.identity.models.CredentialSummary
import com.iproov.identity.models.Jwt
import com.iproov.identity.models.LegacyCredential

class Repository(
    private val localStorage: LocalStorage,
    private val legacyCredentialDeserializer: LegacyCredentialDeserializer = LegacyCredentialDeserializer(),
    private val credentialDeserializer: CredentialDeserializer = CredentialDeserializer()
) {

    suspend fun getAllCredentials(): List<LegacyCredential> {
        val claims = getAllClaims()
        val distinctClaims = claims.groupBy { it.jwt.source }

        return distinctClaims.map { legacyCredentialDeserializer.deserialize(it.key, it.value) }
    }

    suspend fun getAllClaims(): List<Claim> {
        val translations = localStorage.getTranslations() ?: emptyMap()
        return localStorage.getJwts().map {
            Claim.fromJwt(it, translations)
        }
    }

    suspend fun addOrUpdateJwts(jwts: List<Jwt>): List<Jwt> {
        // Remove duplicates using isSameAs:
        val uniqueJwts = jwts.distinctBy { newJwt ->
            jwts.firstOrNull { it.isSameAs(newJwt) } ?: newJwt
        }

        // Get existing JWTs from local storage:
        val existingJwts = localStorage.getJwts().toMutableList()

        // Identify existing JWTs that need to be replaced:
        val existingJwtsToBeDeleted = existingJwts.filter { existingJwt ->
            uniqueJwts.any { it.isSameAs(existingJwt) }
        }

        // Remove duplicates and add new JWTs:
        existingJwts.removeAll(existingJwtsToBeDeleted)
        existingJwts.addAll(uniqueJwts)

        // Update local storage:
        localStorage.setJwts(existingJwts)
        return existingJwts
    }

    suspend fun deleteJwts(jwtsToDelete: List<Jwt>) {
        // Get existing JWTs from local storage:
        val existingJwts = localStorage.getJwts().toMutableList()

        // Identify existing JWTs that match the ones to be deleted:
        val jwtsToRemove = existingJwts.filter { existingJwt ->
            jwtsToDelete.any { it.isSameAs(existingJwt) }
        }

        // Remove the matching JWTs:
        existingJwts.removeAll(jwtsToRemove)

        // Update local storage:
        localStorage.setJwts(existingJwts)
    }

    suspend fun getCredentialMetadata() = localStorage.getCredentialMetadata()

    suspend fun getCredential(metadata: CredentialMetadata): CredentialSummary =
        getCredentials(listOf(metadata))

    suspend fun getCredentials(metadata: List<CredentialMetadata>): CredentialSummary {
        val storedCredentials = localStorage.getCredentials()
        val credentials = mutableMapOf<CredentialMetadata, Credential>()
        val failed = mutableMapOf<CredentialMetadata, CredentialRetrievalFailure>()


        for (credentialMetadata in metadata) {
            val record: CredentialRecord = storedCredentials[credentialMetadata.uuid] ?: continue
            try {
                val vc = credentialDeserializer.deserialize(record)
                if (vc == null) {
                    failed[credentialMetadata] = CredentialRetrievalFailure.UnsupportedFormat(
                        record.format
                    )
                    continue
                }

                credentials[credentialMetadata] = vc
            } catch (e: Exception) {
                e.printStackTrace()
                Logger.error("Failed to deserialize credential from raw.\nRecord: $record\nException: ${e.message}\nStackTrace: ${e.printStackTrace()}")
                failed[credentialMetadata] = CredentialRetrievalFailure.SerializationFailed(
                    error = "Failed to de-serialize credential",
                    description = e.message ?: e.toString(),
                    cause = e,
                )
            }
        }

        return CredentialSummary(credentials, failed)
    }

    suspend fun addCredentialRecord(
        metadata: CredentialMetadata, record: CredentialRecord
    ): Pair<CredentialMetadata, CredentialRecord> {
        val updatedCredentials = localStorage.getCredentials().toMutableMap().apply {
            set(metadata.uuid, record)
        }

        localStorage.setCredentials(updatedCredentials)

        // Insert the metadata into storage
        localStorage.setCredentialMetadata(
            localStorage.getCredentialMetadata().toMutableList().apply { add(metadata) }
        )


        return metadata to record
    }

    suspend fun deleteCredential(metadata: CredentialMetadata) {
        localStorage.setCredentials(localStorage.getCredentials().toMutableMap().apply {
            remove(metadata.uuid)
        })

        localStorage.setCredentialMetadata(
            localStorage.getCredentialMetadata().toMutableList().apply { remove(metadata) }
        )
    }
}

// Replace the following logic with your own comparison logic:
fun Jwt.isSameAs(other: Jwt): Boolean = this.name == other.name && this.source == other.source