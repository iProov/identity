package com.iproov.identity.api

import com.iproov.identity.AppInfo
import com.iproov.identity.DeviceInfo
import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Platform
import com.iproov.identity.encodeToJsonObject

import com.iproov.identity.models.Jwt
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlin.coroutines.cancellation.CancellationException

internal class AndroidIdentityPlatformInterface(
    apiClient: ApiClient,
    private val platform: Platform,
    keyPairFactory: KeyPairFactory
) : IdentityPlatformInterface(apiClient, keyPairFactory) {
    object Requests {
        @Serializable
        data class RegisterWallet(
            @SerialName("device")
            val deviceInfo: DeviceInfo,
            @SerialName("app")
            val appInfo: AppInfo,
            @SerialName("keytype")
            val keySecurityLevel: String,
            @SerialName("playintegrity")
            val playIntegrity: String
        )
    }

    private val keyPair get() = keyPairFactory()
    override var platformAttestationKeyId: String? = null


    @Throws(ApiException::class, CancellationException::class)
    override suspend fun registerWallet(attestationToken: String): List<Jwt> {
        val request = Requests.RegisterWallet(
            platform.deviceInfo,
            platform.appInfo,
            keyPair.getKeySecurityLevel(),
            attestationToken,
        ).encodeToJsonObject()

        val response = apiClient.signAndPost(Routes.Wallet.REGISTER, request)

        return getClaims(response)
    }
}