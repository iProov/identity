package com.iproov.identity.models

val CredentialMetadata.offer
    get() = this.offer.toNativeTypes()