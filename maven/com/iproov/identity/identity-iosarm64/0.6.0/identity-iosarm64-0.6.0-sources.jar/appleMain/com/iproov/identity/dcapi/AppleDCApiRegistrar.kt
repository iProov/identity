package com.iproov.identity.dcapi

import com.iproov.identity.AppleKeychainSharing
import com.iproov.identity.DCApiRegistrationBridge
import com.iproov.identity.DCApiRegistrationStatusAuthorized
import com.iproov.identity.DCApiRegistrationStatusNotAuthorized
import com.iproov.identity.DCApiRegistrationStatusNotDetermined
import com.iproov.identity.DCApiRegistrationStatusNotSupported
import com.iproov.identity.DCApiRegistrationStatusUnsupportedOSVersion
import com.iproov.identity.Logger
import com.iproov.identity.attestation.toNSData
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.docType
import com.iproov.identity.models.id
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import platform.Foundation.NSDate
import platform.Foundation.dateWithTimeIntervalSince1970
import kotlin.concurrent.Volatile
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Apple/iOS implementation of DCApiRegistrar using IdentityDocumentServices framework.
 *
 * This class registers credentials with iOS so they can be discovered and presented
 * when apps/browsers request credentials via the Digital Credentials API.
 *
 * iOS 26+. Requires the com.apple.developer.identity-document-services.document-provider.mobile-document-types
 * entitlement, and the consumer app must ship an Identity Document Provider extension.
 *
 * Note: The consumer app must create an "Identity Document Provider" app extension.
 * This SDK provides Swift classes the extension can call.
 */

enum class DCApiStatus {
    AUTHORIZED,
    NOT_DETERMINED,
    NOT_AUTHORIZED,
    NOT_SUPPORTED,
    UNSUPPORTED_OS_VERSION,

    /** The SDK storage engine was built without a keychain access group, so nothing is shared with an extension. */
    NOT_CONFIGURED,
}

@OptIn(ExperimentalForeignApi::class)
class AppleDCApiRegistrar : DCApiRegistrar {
    /** Each operation snapshots the store before changing it, so they must not interleave. */
    private val registrationMutex = Mutex()

    /** Registrations made through this instance; the store itself answers only asynchronously. Replaced as a
     *  whole, so the unsynchronised reader in [isCredentialRegistered] always sees a consistent set. */
    @Volatile
    private var registeredIds: Set<String> = emptySet()

    /** The SDK engine opts in through its keychain group; a custom engine shares its own file. Read live, so it
     *  follows the engine most recently constructed rather than whichever one was first asked about. */
    private val sharingConfigured: Boolean
        get() = AppleKeychainSharing.appGroupIdentifier == null || AppleKeychainSharing.accessGroup != null

    override suspend fun registerCredential(info: CredentialRegistrationInfo) = registrationMutex.withLock {
        ensureKeysShared()
        val metadata = info.metadata

        val docType = (info.credential as? MDocCredential)?.docType ?: metadata.docType
        ?: throw DCApiRegistrationException(
            "Cannot register ${metadata.id} for DC API: not an mdoc credential " +
                    "(format=${metadata.format})"
        )

        if (metadata.id !in registrations()) {
            addRegistration(
                documentIdentifier = metadata.id,
                docType = docType,
                invalidationDate = expiryOfCredential(info)
            )
        }
        registeredIds += metadata.id
    }

    /**
     * Reconciles against what iOS already holds rather than blind-adding, then removes
     * registrations for credentials no longer in the wallet.
     *
     * Attempts every credential and aggregates failures, so a partial failure keeps the
     * successes and still reports exactly what went wrong.
     */
    override suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>) = registrationMutex.withLock {
        val desired = credentials
            .filter { ((it.credential as? MDocCredential)?.docType ?: it.metadata.docType) != null }
            .map { it.metadata.id }
            .toSet()
        if (desired.isEmpty()) {
            // iOS refuses the store to an app without the document-provider entitlement or the user's permission,
            // so clearing can't act; the next authorized registration removes anything left from a revoked permission.
            val status = status()
            if (status in setOf(DCApiStatus.NOT_AUTHORIZED, DCApiStatus.NOT_DETERMINED, DCApiStatus.NOT_SUPPORTED)) {
                Logger.debug("DC API: no registrations to clear ($status)")
                return@withLock
            }
        }
        if (desired.isNotEmpty()) ensureKeysShared()
        val existing = registrations().toSet()
        val failures = mutableListOf<Pair<String, Throwable>>()

        credentials.forEach { info ->
            val metadata = info.metadata
            val docType = (info.credential as? MDocCredential)?.docType ?: metadata.docType
            if (docType == null) {
                Logger.info(
                    "DC API: skipping ${metadata.id} — not an mdoc credential " +
                            "(format=${metadata.format})"
                )
                return@forEach
            }
            if (metadata.id in existing) return@forEach
            runCatching {
                addRegistration(
                    metadata.id,
                    docType,
                    invalidationDate = expiryOfCredential(info)
                )
            }.onFailure {
                if (it is CancellationException) throw it
                failures += metadata.id to it
            }
        }

        (existing - desired).forEach { stale ->
            runCatching { removeRegistration(stale) }
                .onFailure {
                    if (it is CancellationException) throw it
                    failures += stale to it
                }
        }
        registeredIds = registrations().toSet()

        if (failures.isNotEmpty()) {
            throw DCApiRegistrationException(
                "Failed to register ${failures.size} of ${credentials.size} credentials: " +
                        failures.joinToString("; ") { "${it.first}: ${it.second.message}" }
            )
        }
    }

    /** Refuse to advertise documents the extension could not present: an unshared key fails here, not at presentment. */
    private fun ensureKeysShared() {
        AppleKeychainSharing.shareExistingKeys()
        val unshared = AppleKeychainSharing.unsharedKeys()
        if (unshared.isNotEmpty()) {
            throw DCApiRegistrationException(
                "Keys $unshared are not reachable through keychain access group " +
                        "'${AppleKeychainSharing.accessGroup}'. Check both targets share the group."
            )
        }
    }

    override suspend fun unregisterCredential(credentialId: String) = registrationMutex.withLock {
        removeRegistration(credentialId)
    }

    /** The store call itself; callers hold [registrationMutex]. */
    private suspend fun removeRegistration(credentialId: String) {
        suspendCancellableCoroutine<Unit> { continuation ->
            DCApiRegistrationBridge.removeRegistrationWithDocumentIdentifier(
                documentIdentifier = credentialId
            ) { error ->
                if (error != null) {
                    continuation.resumeWithException(
                        DCApiRegistrationException(error.localizedDescription)
                    )
                } else {
                    Logger.info("DC API: unregistered $credentialId")
                    continuation.resume(Unit)
                }
            }
        }
        registeredIds -= credentialId
    }

    /** OS support only (iOS 26+); authorization is reported by [status]. */
    override fun isAvailable(): Boolean = DCApiRegistrationBridge.isOSSupported() && sharingConfigured

    override fun isCredentialRegistered(credentialId: String): Boolean =
        credentialId in registeredIds

    /** Full authorization state — richer than [isAvailable], and the value worth surfacing. */
    suspend fun status(): DCApiStatus {
        if (DCApiRegistrationBridge.isOSSupported() && !sharingConfigured) return DCApiStatus.NOT_CONFIGURED
        return suspendCancellableCoroutine { continuation ->
            DCApiRegistrationBridge.statusWithCompletion { raw ->
                continuation.resume(
                    when (raw) {
                        DCApiRegistrationStatusAuthorized -> DCApiStatus.AUTHORIZED
                        DCApiRegistrationStatusNotDetermined -> DCApiStatus.NOT_DETERMINED
                        DCApiRegistrationStatusNotAuthorized -> DCApiStatus.NOT_AUTHORIZED
                        DCApiRegistrationStatusNotSupported -> DCApiStatus.NOT_SUPPORTED
                        DCApiRegistrationStatusUnsupportedOSVersion -> DCApiStatus.UNSUPPORTED_OS_VERSION
                        else -> DCApiStatus.NOT_SUPPORTED
                    }
                )
            }
        }
    }

    private suspend fun addRegistration(
        documentIdentifier: String,
        docType: String,
        // Deliberately empty: reader trust is enforced per request via the TrustConfiguration.readerTrust of the
        // wallet the extension builds, so the trust list has to be in the extension. Populating this at
        // registration would need it in the app as well.
        authorityKeyIdentifiers: List<ByteArray> = emptyList(),
        invalidationDate: NSDate? = null,
    ): Unit = suspendCancellableCoroutine { continuation ->
        DCApiRegistrationBridge.addRegistrationWithDocType(
            docType = docType,
            authorityKeyIdentifiers = authorityKeyIdentifiers.map { it.toNSData() },
            documentIdentifier = documentIdentifier,
            invalidationDate = invalidationDate,
        ) { error ->
            if (error != null) {
                continuation.resumeWithException(
                    DCApiRegistrationException(error.localizedDescription)
                )
            } else {
                Logger.info("DC API: registered $documentIdentifier ($docType)")
                continuation.resume(Unit)
            }
        }
    }

    private suspend fun registrations(): List<String> =
        suspendCancellableCoroutine { continuation ->
            DCApiRegistrationBridge.registrationsWithCompletion { ids, error ->
                if (error != null) {
                    continuation.resumeWithException(
                        DCApiRegistrationException(error.localizedDescription)
                    )
                } else {
                    continuation.resume(ids?.map { it as String } ?: emptyList())
                }
            }
        }

    private fun expiryOfCredential(info: CredentialRegistrationInfo): NSDate? =
        (info.credential as? MDocCredential)?.validUntil?.let {
            NSDate.dateWithTimeIntervalSince1970(it / 1000.0)
        }
}

class DCApiRegistrationException(message: String) : Exception(message)
