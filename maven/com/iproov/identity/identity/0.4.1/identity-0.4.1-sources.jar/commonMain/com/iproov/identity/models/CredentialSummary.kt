package com.iproov.identity.models

sealed interface CredentialRetrievalFailure {
    val error: String
    val description: String


    data class UnsupportedFormat(
        val format: String,
        override val error: String = "Unsupported Credential Format",
        override val description: String = "No serializers found for the format: $format",
    ) : CredentialRetrievalFailure

    data class SerializationFailed(
        override val error: String = "Credential Serialization Failure",
        override val description: String = "An error occurred whilst serializing the stored credential",
        val cause: Throwable,
    ) : CredentialRetrievalFailure
}

data class CredentialSummary(
    val credentials: Map<CredentialMetadata, Credential>,
    val failures: Map<CredentialMetadata, CredentialRetrievalFailure>,
)