package com.iproov.identity

// Simulator slice — see the expect declaration in Platform.apple.kt.
internal actual val isSimulatorBuild: Boolean = true
