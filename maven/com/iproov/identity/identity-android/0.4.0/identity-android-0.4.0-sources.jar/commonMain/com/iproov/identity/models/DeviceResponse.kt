@file:OptIn(ExperimentalSerializationApi::class)

package com.iproov.identity.models

import com.iproov.identity.Logger
import com.iproov.identity.api.SessionTranscript
import com.iproov.identity.api.SessionTranscriptDCAPI
import com.iproov.identity.api.SessionTranscriptProximity
import com.iproov.identity.api.sha256
import com.iproov.identity.cryptography.KeyPair
import com.iproov.identity.cryptography.derEcdsaToConcat
import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.cbor.ByteString
import kotlinx.serialization.cbor.CborArray
import kotlinx.serialization.cbor.CborLabel
import kotlinx.serialization.cbor.CborTag
import kotlinx.serialization.cbor.ValueTags
import kotlinx.serialization.encodeToByteArray
import kotlinx.serialization.encodeToHexString
import net.orandja.obor.codec.Cbor
import net.orandja.obor.data.CborMap
import net.orandja.obor.data.CborMapEntry
import net.orandja.obor.data.CborObject
import net.orandja.obor.data.CborPositive
import net.orandja.obor.data.CborText
import org.multipaz.cbor.Bstr
import org.multipaz.cbor.DataItem
import org.multipaz.cbor.Tagged
import org.multipaz.cose.CoseSign1
import org.multipaz.cbor.Cbor as MultipazCbor
import org.multipaz.cbor.CborArray as MultipazCborArray


@Serializable
@CborArray
private data class SigStructure(
    val context: String,                             // "Signature1"
    @ByteString val bodyProtected: ByteArray,        // bstr of protected header map
    @ByteString val externalAad: ByteArray,          // empty bstr
    @ByteString val payload: ByteArray               // bstr of payload bytes (here: tag24(DeviceAuthentication))
)

@Serializable
private data class UnprotectedHeaders(
    // x5chain (label 33) is an array of bstr certificates (raw DER bytes).
    // Use NEVER mode to ensure null values are not encoded (produces empty map a0)
    @EncodeDefault(EncodeDefault.Mode.NEVER)
    @CborLabel(33) val x5chain: List<ByteArray>? = null,
    // kid (label 4) is a bstr.
    @EncodeDefault(EncodeDefault.Mode.NEVER)
    @CborLabel(4) @ByteString val kid: ByteArray? = null
)

@Serializable
private data class ProtectedHeader(
    @EncodeDefault @CborLabel(1) val alg: Int = -7                  // {1:-7} (ES256).
)

@Serializable
@CborArray
private data class CoseSign1Array(
    @ByteString val protected_: ByteArray,       // protected header map as bstr
    val unprotected: UnprotectedHeaders,         // header map (numeric labels)
    @ByteString val payload: ByteArray?,         // bstr or null (detached)
    @ByteString val signature: ByteArray         // signature bstr (R||S for ES256)
)

@Serializable
@CborArray
private data class CoseMac0Array(
    @ByteString val protected_: ByteArray,
    val unprotected: UnprotectedHeaders,
    @ByteString val payload: ByteArray?,         // may be null if detached
    @ByteString val tag: ByteArray
)


/** DeviceAuthentication = ["DeviceAuthentication", SessionTranscript, docType, (optional) DeviceNameSpacesBytes] */
@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
internal data class DeviceAuthenticationArray(
    @EncodeDefault val context: String = "DeviceAuthentication",
    val sessionTranscript: SessionTranscript,
    val docType: String,
    // If you actually disclose device-signed elements, pass Tag-24(bstr.cbor(DeviceNameSpaces)) here.
    // Otherwise keep it null (omit the 4th array element).
    @ValueTags(CborTag.CBOR_ENCODED_DATA) @ByteString val deviceNameSpaces: ByteArray? = null
)

@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
internal data class DeviceAuthenticationDCAPIArray(
    @EncodeDefault val context: String = "DeviceAuthentication",
    val sessionTranscript: SessionTranscriptDCAPI,
    val docType: String,
    // If you actually disclose device-signed elements, pass Tag-24(bstr.cbor(DeviceNameSpaces)) here.
    // Otherwise keep it null (omit the 4th array element).
    @ValueTags(CborTag.CBOR_ENCODED_DATA) @ByteString val deviceNameSpaces: ByteArray? = null
)

@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
internal data class DeviceAuthenticationProximityArray(
    @EncodeDefault val context: String = "DeviceAuthentication",
    val sessionTranscript: SessionTranscriptProximity,
    val docType: String,
    @ValueTags(CborTag.CBOR_ENCODED_DATA) @ByteString val deviceNameSpaces: ByteArray? = null,
)

@Serializable
data class DocumentResponse(
    val docType: String,

    /**
     * The subset of the issuer-signed items that have been disclosed in this response.
     */
    val issuerSigned: IssuerSigned,

    /**
     * The device-signed authentication items proving possession of the device
     * bound to this credential.
     */
    val deviceSigned: DeviceSigned? = null,
)


@Serializable
data class IssuerSigned(
    val nameSpaces: Map<String, List<ByteArray>>,
    val issuerAuth: ByteArray,
)

@Serializable
data class DeviceSigned(
    // From the original mDoc:
    val nameSpaces: ByteArray,
    val deviceAuth: DeviceAuth
)

/**
 * Device authentication structure within device-signed portion of mDoc.
 *
 * Either deviceSignature OR deviceMac will be present.
 */
@Serializable
data class DeviceAuth(
    val deviceSignature: ByteArray? = null,
    val deviceMac: ByteArray? = null
)

/**
 * OpenID4VP Handover structure per OID4VP spec appendix B.2.6.
 * CBOR array: ["OpenID4VPHandover", SHA-256(OpenID4VPHandoverData)]
 */
@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
data class OpenID4VPHandover(
    @EncodeDefault val name: String = "OpenID4VPHandover",
    @ByteString val hash: ByteArray
)

/**
 * OpenID4VP Handover structure per OID4VP spec appendix B.2.6.
 * CBOR array: ["OpenID4VPHandover", SHA-256(OpenID4VPHandoverData)]
 */
@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
data class OpenID4VPDCAPIHandover(
    @EncodeDefault val name: String = "OpenID4VPDCAPIHandover",
    @ByteString val hash: ByteArray
)


@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
data class OpenID4VPDCAPIHandoverInfo(
    val origin: String,
    val nonce: String,
    @ByteString val jwkThumbprint: ByteArray?,
)

/**
 * OpenID4VP Handover Info structure per OpenID4VP spec appendix B.2.6.
 * CBOR array: [client_id, nonce, jwkThumbprint, response_uri]
 *
 * This matches the WaltID `id.walt.mdoc.objects.handover.OpenID4VPHandoverInfo` class
 * exactly, which was verified to work with the EU EUDI verifier.
 *
 * IMPORTANT: Field order matters for CBOR array encoding!
 */
@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
data class OpenID4VPHandoverInfo(
    val clientId: String,
    val nonce: String,
    @ByteString val jwkThumbprint: ByteArray?,
    val responseUri: String?
)

/**
 * Browser Handover structure for DC API (Digital Credentials API) per ISO 18013-7 Annex C.
 *
 * When credentials are requested via the browser's Digital Credentials API, a different
 * handover structure is used in the SessionTranscript compared to direct_post mode.
 *
 * BrowserHandover = ["BrowserHandover", SHA-256(BrowserHandoverInfo)]
 */
@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
data class BrowserHandover(
    @EncodeDefault val name: String = "BrowserHandover",
    @ByteString val hash: ByteArray
)

/**
 * Browser Handover Info structure for DC API SessionTranscript.
 *
 * Per ISO 18013-7 Annex C, the BrowserHandoverInfo contains:
 * - origin: The web origin that initiated the request
 * - nonce: The nonce from the credential request
 * - requesterKeyHash: Hash of the requester's public key (optional)
 *
 * CBOR array: [origin, nonce, requesterKeyHash (or null)]
 *
 * Note: @EncodeDefault ensures nullable fields with defaults are explicitly encoded
 * as CBOR null (0xF6) rather than omitted, which is required for correct hash computation.
 */
@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
data class BrowserHandoverInfoCbor(
    val origin: String,
    @EncodeDefault val nonce: String? = null,
    @EncodeDefault @ByteString val requesterKeyHash: ByteArray? = null
)

@Serializable
data class DeviceResponse(
    val version: String,
    val documents: List<DocumentResponse>,
    val status: Long = 0L,
    val documentErrors: List<Map<String, Int>>? = null,
) {

    companion object {
        /**
         * Build a presentation response for this mDoc credential based on the provided
         * session transcript and claims to be disclosed.
         *
         * https://openid.net/specs/openid-4-verifiable-presentations-1_0.html#name-presentation-response-3
         */
        @OptIn(ExperimentalSerializationApi::class)
        fun build(
            authorizationRequest: AuthorizationRequest,
            credential: MDocCredential,
            claims: List<ClaimQuery>,
            deviceKeyPair: KeyPair,
            jwkThumbprint: ByteArray? = null
        ): ByteArray {            // Parse the raw credential using multipaz
            val (nameSpacesDataItem, issuerAuthDataItem) = parseIssuerSigned(credential.raw)

            // Build minimal issuerSigned subset (only requested elements)
            // The key is to preserve the original serialized bytes of each IssuerSignedItem
            val issuerNamespacesMap: Map<String, List<ByteArray>> =
                filterNameSpaces(nameSpacesDataItem, claims)

            val deviceNsTagged24 = TAGGED_EMPTY_CBOR_MAP_BYTES

            // For direct_post/direct_post_jwt modes, these fields are required for session transcript
            // jwkThumbprint should be the base64url-decoded `apu` value from the JWE if present, or null
            Logger.debug("Building session transcript with: clientId=${authorizationRequest.clientId}, nonce=${authorizationRequest.nonce}, responseUri=${authorizationRequest.responseUri}, jwkThumbprint=${jwkThumbprint?.toHexString()}")

            val sessionTranscript = buildOpenID4VPSessionTranscript(
                clientId = requireNotNull(authorizationRequest.clientId) {
                    "client_id is required for OpenID4VP session transcript"
                },
                nonce = requireNotNull(authorizationRequest.nonce) {
                    "nonce is required for OpenID4VP session transcript"
                },
                responseUri = requireNotNull(authorizationRequest.responseUri) {
                    "response_uri is required for OpenID4VP direct_post"
                },
                jwkThumbprint = jwkThumbprint
            )

            val signature = buildDeviceAuthentication(
                sessionTranscript = sessionTranscript,
                docType = credential.docType,
                deviceNameSpacesBytes = deviceNsTagged24,
                keyPair = deviceKeyPair,
            )

            val deviceAuth = DeviceAuth(deviceSignature = signature)

            val deviceSigned = DeviceSigned(
                nameSpaces = deviceNsTagged24,
                deviceAuth = deviceAuth
            )

            // Encode issuerAuth from multipaz CoseSign1 to CBOR bytes
            val issuerAuthBytes = encodeCoseSign1ToCborBytes(
                CoseSign1.fromDataItem(issuerAuthDataItem)
            )
            Logger.debug("Issuer Auth Bytes: ${issuerAuthBytes.toHexString()}")

            val issuerSigned = IssuerSigned(
                nameSpaces = issuerNamespacesMap,
                issuerAuth = issuerAuthBytes,
            )

            val response = DeviceResponse(
                version = "1.0",
                documents = listOf(
                    DocumentResponse(
                        docType = credential.docType,
                        issuerSigned = issuerSigned,
                        deviceSigned = deviceSigned
                    )
                ),
                status = 0L
            )

            Logger.debug("Built DeviceResponse Object: $response")
            return encodeDeviceResponseToCborBytes(response)
        }

        /**
         * Parse the IssuerSigned structure from raw credential data.
         * Returns the nameSpaces DataItem and the issuerAuth DataItem.
         */
        private fun parseIssuerSigned(raw: String): Pair<DataItem, DataItem> {
            val signedBytes = if (raw.isHex()) raw.hexToByteArray() else decodeBase64Url(raw)
            val issuerSignedMap = MultipazCbor.decode(signedBytes).asMap

            val nameSpacesDataItem = issuerSignedMap.getByKey("nameSpaces")
                ?: error("IssuerSigned missing 'nameSpaces' field")
            val issuerAuthDataItem = issuerSignedMap.getByKey("issuerAuth")
                ?: error("IssuerSigned missing 'issuerAuth' field")

            return nameSpacesDataItem to issuerAuthDataItem
        }

        /**
         * Filter nameSpaces to only include requested claims, preserving original bytes.
         *
         * Each IssuerSignedItem in the array is a Tagged(24, Bstr) where the Bstr contains
         * the CBOR-encoded IssuerSignedItem map. We extract the inner bytes and wrap them
         * with Tag 24 to preserve the exact encoding.
         */
        private fun filterNameSpaces(
            nameSpacesDataItem: DataItem,
            claims: List<ClaimQuery>
        ): Map<String, List<ByteArray>> {
            val result = mutableMapOf<String, List<ByteArray>>()

            val nameSpacesMap = nameSpacesDataItem.asMap

            for ((nsKeyItem, nsValueItem) in nameSpacesMap.entries) {
                val namespace = nsKeyItem.asTstr

                // Check if this namespace has any requested claims
                val requestedClaimsInNs = claims.filter { it.path.firstOrNull() == namespace }
                if (requestedClaimsInNs.isEmpty()) continue

                // Get the array of Tagged IssuerSignedItems
                val itemsArray = nsValueItem as MultipazCborArray
                val filteredItems = mutableListOf<ByteArray>()

                for (item in itemsArray.items) {
                    // Each item is Tagged(24, Bstr(IssuerSignedItem CBOR))
                    val tagged = item as? Tagged ?: continue
                    if (tagged.tagNumber != 24L) continue

                    // Get the inner Bstr which contains the serialized IssuerSignedItem
                    val innerBstr = tagged.taggedItem as? Bstr ?: continue
                    val serializedItem = innerBstr.value

                    // Decode just to get the elementIdentifier for filtering
                    val innerMap = MultipazCbor.decode(serializedItem).asMap
                    val elementIdentifier = innerMap.getByKey("elementIdentifier")?.asTstr
                        ?: continue

                    // Check if this element is requested
                    val isRequested = requestedClaimsInNs.any { cq ->
                        cq.path.size >= 2 && cq.path[1] == elementIdentifier
                    }

                    if (isRequested) {
                        // Wrap the original serialized bytes with Tag 24
                        // This matches what WaltID's e.serialized provided
                        filteredItems.add(wrapWithTag24(serializedItem))
                    }
                }

                if (filteredItems.isNotEmpty()) {
                    result[namespace] = filteredItems
                }
            }

            return result
        }

        /** Helper to find a value in a CBOR map by its text string key */
        private fun Map<DataItem, DataItem>.getByKey(key: String): DataItem? =
            entries.find { (k, _) -> k.asTstr == key }?.value

        private fun String.isHex(): Boolean {
            if (isEmpty() || length % 2 != 0) return false
            return all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }
        }

        private fun decodeBase64Url(s: String): ByteArray =
            kotlin.io.encoding.Base64.UrlSafe.withPadding(
                kotlin.io.encoding.Base64.PaddingOption.ABSENT_OPTIONAL
            ).decode(s)

        /**
         * Constructs the OpenID4VPHandover-based SessionTranscript.
         *
         * OpenID4VPHandoverInfo per OID4VP spec:
         *   [ client_id, nonce, jwkThumbprint (or null), response_uri ]
         *
         * This field order matches WaltID's OpenID4VPHandoverInfo class which was verified
         * to work with the EU EUDI verifier.
         *
         * https://openid.net/specs/openid-4-verifiable-presentations-1_0.html#appendix-B.2.6
         */
        @OptIn(ExperimentalSerializationApi::class)
        fun buildOpenID4VPSessionTranscript(
            clientId: String,
            nonce: String,
            responseUri: String,
            jwkThumbprint: ByteArray?
        ): SessionTranscript /* CBOR of SessionTranscript */ {
            // Log all input values for debugging
            Logger.debug("=== Building OpenID4VP Session Transcript ===")
            Logger.debug("  clientId: $clientId")
            Logger.debug("  nonce: $nonce")
            Logger.debug("  responseUri: $responseUri")
            Logger.debug("  jwkThumbprint: ${jwkThumbprint?.toHexString() ?: "null"}")

            val info = OpenID4VPHandoverInfo(
                clientId = clientId,
                nonce = nonce,
                jwkThumbprint = jwkThumbprint,
                responseUri = responseUri
            )
            // Use handoverInfoCbor (matches WaltID's MdocCbor config) for the hash computation
            val infoCbor = handoverInfoCbor.encodeToByteArray(info)
            Logger.debug("OpenID4VPHandoverInfo CBOR hex: ${infoCbor.toHexString()}")

            // Log CBOR structure breakdown for debugging
            Logger.debug(
                "  CBOR first byte: 0x${
                    infoCbor[0].toUByte().toString(16)
                } (should be 0x84 for 4-element array)"
            )

            val infoHash = sha256(infoCbor)                               // 32-byte hash
            Logger.debug("OpenID4VPHandoverInfo hash: ${infoHash.toHexString()}")
            val handover = OpenID4VPHandover(hash = infoHash) // CBOR array
            return SessionTranscript(null, null, handover).also {
                Logger.debug("Built session transcript: ${vpCompliantCbor.encodeToHexString(it)}")
                Logger.debug("=== End Session Transcript ===")
            }
        }

        fun buildOpenID4VPDCAPISessionTranscript(
            origin: String,
            nonce: String,
            jwkThumbprint: ByteArray?
        ): SessionTranscriptDCAPI {
            val info = OpenID4VPDCAPIHandoverInfo(
                origin = origin,
                nonce = nonce,
                jwkThumbprint = jwkThumbprint
            )
            // Use handoverInfoCbor (matches WaltID's config) for the hash computation
            val infoCbor = handoverInfoCbor.encodeToByteArray(info)
            Logger.debug("OpenID4VPDCAPIHandoverInfo CBOR hex: ${infoCbor.toHexString()}")
            val infoHash = sha256(infoCbor)
            Logger.debug("OpenID4VPDCAPIHandoverInfo hash: ${infoHash.toHexString()}")
            val handover = OpenID4VPDCAPIHandover(hash = infoHash)
            return SessionTranscriptDCAPI(null, null, handover).also {
                Logger.debug(
                    "Built OpenID4VP DC API session transcript: ${
                        vpCompliantCbor.encodeToHexString(
                            it
                        )
                    }"
                )
            }
        }

        /**
         * Build a presentation response for DC API (Digital Credentials API) requests.
         *
         * DC API uses a different SessionTranscript structure per ISO 18013-7 Annex C
         * with BrowserHandover instead of OpenID4VPHandover.
         */
        @OptIn(ExperimentalSerializationApi::class)
        fun buildForDCApi(
            authorizationRequest: AuthorizationRequest,
            credential: MDocCredential,
            claims: List<ClaimQuery>,
            deviceKeyPair: KeyPair,
            browserHandoverInfo: com.iproov.identity.dcapi.BrowserHandoverInfo,
        ): ByteArray {

            val (nameSpacesDataItem, issuerAuthDataItem) = parseIssuerSigned(credential.raw)

            // Build minimal issuerSigned subset (only requested elements)
            // The key is to preserve the original serialized bytes of each IssuerSignedItem
            val issuerNamespacesMap: Map<String, List<ByteArray>> =
                filterNameSpaces(nameSpacesDataItem, claims)

            val deviceNsTagged24 = TAGGED_EMPTY_CBOR_MAP_BYTES

            // For direct_post/direct_post_jwt modes, these fields are required for session transcript
            // jwkThumbprint should be the base64url-decoded `apu` value from the JWE if present, or null
            Logger.debug("Building session transcript with: origin=${browserHandoverInfo.origin}, nonce=${authorizationRequest.nonce}, jwkThumbprint=${browserHandoverInfo.requesterKeyHash?.toHexString()}")

            val sessionTranscript = buildOpenID4VPDCAPISessionTranscript(
                origin = browserHandoverInfo.origin,
                nonce = browserHandoverInfo.nonce,
                jwkThumbprint = browserHandoverInfo.requesterKeyHash
            )

            val signature = buildDeviceAuthentication(
                sessionTranscript = sessionTranscript,
                docType = credential.docType,
                deviceNameSpacesBytes = deviceNsTagged24,
                keyPair = deviceKeyPair,
            )

            val deviceAuth = DeviceAuth(deviceSignature = signature)

            val deviceSigned = DeviceSigned(
                nameSpaces = deviceNsTagged24,
                deviceAuth = deviceAuth
            )

            // Encode issuerAuth from multipaz CoseSign1 to CBOR bytes
            val issuerAuthBytes = encodeCoseSign1ToCborBytes(
                CoseSign1.fromDataItem(issuerAuthDataItem)
            )
            Logger.debug("Issuer Auth Bytes: ${issuerAuthBytes.toHexString()}")

            val issuerSigned = IssuerSigned(
                nameSpaces = issuerNamespacesMap,
                issuerAuth = issuerAuthBytes,
            )

            val response = DeviceResponse(
                version = "1.0",
                documents = listOf(
                    DocumentResponse(
                        docType = credential.docType,
                        issuerSigned = issuerSigned,
                        deviceSigned = deviceSigned
                    )
                ),
                status = 0L
            )

            Logger.debug("Built DC API DeviceResponse Object: $response")
            return encodeDeviceResponseToCborBytes(response)
        }

        @OptIn(ExperimentalSerializationApi::class)
        fun buildForProximity(
            documents: List<Pair<MDocCredential, List<ClaimQuery>>>,
            deviceKeyPair: KeyPair,
            sessionTranscript: SessionTranscriptProximity,
            documentErrors: Map<String, Int> = emptyMap()
        ): ByteArray {
            val deviceNsTagged24 = TAGGED_EMPTY_CBOR_MAP_BYTES

            val docResponses = documents.map { (credential, claims) ->
                val (nameSpacesDataItem, issuerAuthDataItem) = parseIssuerSigned(credential.raw)
                val issuerNamespacesMap = filterNameSpaces(nameSpacesDataItem, claims)

                val signature = buildDeviceAuthentication(
                    sessionTranscript = sessionTranscript,
                    docType = credential.docType,
                    deviceNameSpacesBytes = deviceNsTagged24,
                    keyPair = deviceKeyPair,
                )
                val issuerAuthBytes =
                    encodeCoseSign1ToCborBytes(CoseSign1.fromDataItem(issuerAuthDataItem))

                DocumentResponse(
                    docType = credential.docType,
                    issuerSigned = IssuerSigned(
                        nameSpaces = issuerNamespacesMap,
                        issuerAuth = issuerAuthBytes
                    ),
                    deviceSigned = DeviceSigned(
                        nameSpaces = deviceNsTagged24,
                        deviceAuth = DeviceAuth(deviceSignature = signature),
                    ),
                )
            }

            return encodeDeviceResponseToCborBytes(
                DeviceResponse(
                    version = "1.0",
                    documents = docResponses,
                    status = 0L,
                    documentErrors = documentErrors.takeIf { it.isNotEmpty() }?.let { listOf(it) },
                )
            )
        }

        /**
         * Constructs a BrowserHandover-based SessionTranscript for DC API requests.
         *
         * Per ISO 18013-7 Annex C, browser-initiated requests use:
         * SessionTranscript = [null, null, BrowserHandover]
         * BrowserHandover = ["BrowserHandover", SHA-256(BrowserHandoverInfo)]
         * BrowserHandoverInfo = [origin, nonce, requesterKeyHash]
         */
        @OptIn(ExperimentalSerializationApi::class)
        fun buildDCApiSessionTranscript(
            origin: String,
            nonce: String?,
            requesterKeyHash: ByteArray?
        ): DCApiSessionTranscript {
            val info = BrowserHandoverInfoCbor(
                origin = origin,
                nonce = nonce,
                requesterKeyHash = requesterKeyHash
            )
            // Use handoverInfoCbor (matches WaltID's config) for the hash computation
            val infoCbor = handoverInfoCbor.encodeToByteArray(info)
            Logger.debug("BrowserHandoverInfo CBOR hex: ${infoCbor.toHexString()}")
            val infoHash = sha256(infoCbor)
            Logger.debug("BrowserHandoverInfo hash: ${infoHash.toHexString()}")
            val handover = BrowserHandover(hash = infoHash)
            return DCApiSessionTranscript(null, null, handover).also {
                Logger.debug(
                    "Built DC API session transcript: ${
                        vpCompliantCbor.encodeToHexString(
                            it
                        )
                    }"
                )
            }
        }
    }
}

/**
 * SessionTranscript variant for DC API with BrowserHandover.
 * Used for browser-initiated credential requests via Digital Credentials API.
 */
@OptIn(ExperimentalSerializationApi::class)
@CborArray
@Serializable
data class DCApiSessionTranscript(
    val deviceEngagementBytes: ByteArray?,
    val eReaderKeyBytes: ByteArray?,
    val handover: BrowserHandover
)


fun buildDeviceAuthentication(
    sessionTranscript: SessionTranscriptDCAPI,
    docType: String,
    deviceNameSpacesBytes: ByteArray,
    keyPair: KeyPair,
): ByteArray {

// deviceNameSpacesBytes could legitimately be an empty map encoded and tagged, e.g., d8 18 41 a0
    require(deviceNameSpacesBytes.size > 3 && deviceNameSpacesBytes[0] == 0xd8.toByte() && deviceNameSpacesBytes[1] == 0x18.toByte()) {
        "deviceNameSpacesBytes does not appear to be a tagged (#6.24) CBOR byte string"
    }

    // Log the device public key for debugging key binding issues
    val deviceJwk = keyPair.getJwk()
    Logger.debug("Device signing key JWK: x=${deviceJwk.jwk.x}, y=${deviceJwk.jwk.y}")

    val deviceAuthenticationArray = DeviceAuthenticationDCAPIArray(
        context = "DeviceAuthentication",
        sessionTranscript = sessionTranscript,
        docType = docType,
        deviceNameSpaces = stripTag24(deviceNameSpacesBytes),
    )

    val deviceAuthBytes = vpCompliantCbor.encodeToByteArray(
        DeviceAuthenticationDCAPIArray.serializer(), deviceAuthenticationArray
    )
    Logger.debug("DeviceAuthentication CBOR: ${deviceAuthBytes.toHexString()}")

    // Wrap the DeviceAuthentication array in tag 24 (payload for Sig_structure).
    val deviceAuthenticationBytes = wrapAsTag24(deviceAuthBytes)

    // Protected header map {1:-7} encoded to bytes, then wrapped as bstr in Sig_structure.
    val protectedBytes =
        vpCompliantCbor.encodeToByteArray(ProtectedHeader.serializer(), ProtectedHeader())

    // external_aad is empty bstr.
    val externalAad = byteArrayOf()

    val sigStruct = SigStructure(
        context = "Signature1",
        bodyProtected = protectedBytes,
        externalAad = externalAad,
        payload = deviceAuthenticationBytes
    )
    val sigStructureBytes = vpCompliantCbor.encodeToByteArray(SigStructure.serializer(), sigStruct)
    Logger.debug("Sig_structure CBOR: ${sigStructureBytes.toHexString()}")

    val der = keyPair.sign(sigStructureBytes)
    val rs = derEcdsaToConcat(der, 32)
    Logger.debug("Device signature (R||S): ${rs.toHexString()}")

    // Assemble COSE_Sign1 as an array (protected bstr, unprotected map, payload=null, signature bstr).
    val coseSign1 = CoseSign1Array(
        protected_ = protectedBytes,
        unprotected = UnprotectedHeaders(), // empty
        payload = null,                      // detached
        signature = rs
    )
    return vpCompliantCbor.encodeToByteArray(CoseSign1Array.serializer(), coseSign1)
}

/**
 * Creates the DeviceAuthentication COSE_Sign1 structure (DeviceSignature) as defined in
 * ISO/IEC 18013-5:2021 section 9.1.3.6.
 *
 * This function performs the following steps according to the standard:
 * 1. Constructs the `DeviceAuthentication` array.
 * 2. CBOR encodes the `DeviceAuthentication` array and wraps it in a tagged CBOR byte string (#6.24)
 * to create `DeviceAuthenticationBytes`.
 * 3. Constructs the `Sig_structure` array for signing. This includes:
 * - The context string "Signature1".
 * - CBOR-encoded protected headers containing the algorithm identifier (ES256 -> -7).
 * - An empty byte string for external authenticated data.
 * - The `DeviceAuthenticationBytes` as the payload.
 * 4. CBOR encodes the `Sig_structure`.
 * 5. Signs the encoded `Sig_structure` using the provided KeyPair's private key (SHA256withECDSA).
 * 6. Converts the DER-encoded signature from Android Keystore to the required R||S format for COSE ES256.
 * 7. Constructs the final `COSE_Sign1` array containing:
 * - The CBOR-encoded protected headers (same as in `Sig_structure`).
 * - An empty CBOR map for unprotected headers.
 * - `null` for the detached payload.
 * - The R||S signature bytes.
 * 8. CBOR encodes the final `COSE_Sign1` array and returns the bytes.
 *
 * @param sessionTranscript The CBOR-encoded SessionTranscript (#6.24(bstr.cbor SessionTranscript))
 * as defined in section 9.1.5.1.
 * @param docType The document type string (e.g., "org.iso.18013.5.1.mDL").
 * @param deviceNameSpacesBytes The CBOR-encoded DeviceNameSpaces structure wrapped in a tagged CBOR
 * byte string (#6.24(bstr.cbor DeviceNameSpaces)) as defined in
 * section 8.3.2.1.2.2.
 * @param keyPair The KeyPair instance containing the ES256 private key for signing.
 * @return The CBOR-encoded COSE_Sign1 structure (DeviceSignature) as ByteArray.
 * @throws Exception if signing or CBOR encoding fails.
 */
fun buildDeviceAuthentication(
    sessionTranscript: SessionTranscript,
    docType: String,
    deviceNameSpacesBytes: ByteArray,
    keyPair: KeyPair,
): ByteArray {
    // deviceNameSpacesBytes could legitimately be an empty map encoded and tagged, e.g., d8 18 41 a0
    require(deviceNameSpacesBytes.size > 3 && deviceNameSpacesBytes[0] == 0xd8.toByte() && deviceNameSpacesBytes[1] == 0x18.toByte()) {
        "deviceNameSpacesBytes does not appear to be a tagged (#6.24) CBOR byte string"
    }

    // Log the device public key for debugging key binding issues
    val deviceJwk = keyPair.getJwk()
    Logger.debug("Device signing key JWK: x=${deviceJwk.jwk.x}, y=${deviceJwk.jwk.y}")

    val deviceAuthenticationArray = DeviceAuthenticationArray(
        context = "DeviceAuthentication",
        sessionTranscript = sessionTranscript,
        docType = docType,
        deviceNameSpaces = stripTag24(deviceNameSpacesBytes),
    )

    val deviceAuthBytes = vpCompliantCbor.encodeToByteArray(
        DeviceAuthenticationArray.serializer(), deviceAuthenticationArray
    )
    Logger.debug("DeviceAuthentication CBOR: ${deviceAuthBytes.toHexString()}")

    // Wrap the DeviceAuthentication array in tag 24 (payload for Sig_structure).
    val deviceAuthenticationBytes = wrapAsTag24(deviceAuthBytes)

    // Protected header map {1:-7} encoded to bytes, then wrapped as bstr in Sig_structure.
    val protectedBytes =
        vpCompliantCbor.encodeToByteArray(ProtectedHeader.serializer(), ProtectedHeader())

    // external_aad is empty bstr.
    val externalAad = byteArrayOf()

    val sigStruct = SigStructure(
        context = "Signature1",
        bodyProtected = protectedBytes,
        externalAad = externalAad,
        payload = deviceAuthenticationBytes
    )
    val sigStructureBytes = vpCompliantCbor.encodeToByteArray(SigStructure.serializer(), sigStruct)
    Logger.debug("Sig_structure CBOR: ${sigStructureBytes.toHexString()}")

    val der = keyPair.sign(sigStructureBytes)
    val rs = derEcdsaToConcat(der, 32)
    Logger.debug("Device signature (R||S): ${rs.toHexString()}")

    // Assemble COSE_Sign1 as an array (protected bstr, unprotected map, payload=null, signature bstr).
    val coseSign1 = CoseSign1Array(
        protected_ = protectedBytes,
        unprotected = UnprotectedHeaders(), // empty
        payload = null,                      // detached
        signature = rs
    )
    return vpCompliantCbor.encodeToByteArray(CoseSign1Array.serializer(), coseSign1)
}

fun buildDeviceAuthentication(
    sessionTranscript: SessionTranscriptProximity,
    docType: String,
    deviceNameSpacesBytes: ByteArray,
    keyPair: KeyPair
): ByteArray {
    require(deviceNameSpacesBytes.size > 3 && deviceNameSpacesBytes[0] == 0xd8.toByte() && deviceNameSpacesBytes[1] == 0x18.toByte()) {
        "deviceNameSpacesBytes does not appear to be a tagged (#6.24) CBOR byte string"
    }

    val deviceJwk = keyPair.getJwk()
    Logger.debug("Device signing key JWK: x=${deviceJwk.jwk.x}, y=${deviceJwk.jwk.y}")

    val deviceAuthenticationArray = DeviceAuthenticationProximityArray(
        context = "DeviceAuthentication",
        sessionTranscript = sessionTranscript,
        docType = docType,
        deviceNameSpaces = stripTag24(deviceNameSpacesBytes),
    )

    val deviceAuthBytes = vpCompliantCbor.encodeToByteArray(
        DeviceAuthenticationProximityArray.serializer(), deviceAuthenticationArray
    )
    Logger.debug("DeviceAuthentication CBOR: ${deviceAuthBytes.toHexString()}")

    val deviceAuthenticationBytes = wrapAsTag24(deviceAuthBytes)

    val protectedBytes =
        vpCompliantCbor.encodeToByteArray(ProtectedHeader.serializer(), ProtectedHeader())
    val sigStruct = SigStructure(
        context = "Signature1",
        bodyProtected = protectedBytes,
        externalAad = byteArrayOf(),
        payload = deviceAuthenticationBytes,
    )
    val sigStructureBytes = vpCompliantCbor.encodeToByteArray(SigStructure.serializer(), sigStruct)
    Logger.debug("Sig_structure CBOR: ${sigStructureBytes.toHexString()}")

    val der = keyPair.sign(sigStructureBytes)
    val rs = derEcdsaToConcat(der, 32)
    Logger.debug("Device signature (R||S): ${rs.toHexString()}")

    val coseSign1 = CoseSign1Array(
        protected_ = protectedBytes,
        unprotected = UnprotectedHeaders(),
        payload = null,
        signature = rs,
    )
    return vpCompliantCbor.encodeToByteArray(CoseSign1Array.serializer(), coseSign1)

}

fun encodeCoseSign1ToCborBytes(coseSign1: CoseSign1): ByteArray {
    // Use multipaz's built-in encoding via toDataItem()
    return MultipazCbor.encode(coseSign1.toDataItem())
}

val TAGGED_EMPTY_CBOR_MAP_BYTES = byteArrayOf(
    0xd8.toByte(), // Tag major type 6
    0x18.toByte(), // Tag value 24
    0x41.toByte(), // Byte string header (major type 2), length 1
    0xa0.toByte()  // The single byte for an empty map (major type 5, length 0)
)

fun encodeDeviceResponseToCborBytes(response: DeviceResponse): ByteArray {
    val documentsArray = mutableListOf<CborObject>()

    response.documents.forEach { doc ->
        val document = mutableListOf<CborMapEntry>()
        document.add(CborMapEntry(CborText("docType"), CborText(doc.docType)))

        val issuerSignedMap = mutableListOf<CborMapEntry>()
        val issuerSignedNameSpaces = mutableListOf<CborMapEntry>()
        for (entry in doc.issuerSigned.nameSpaces) {
            val items = mutableListOf<CborObject>()

            for (taggedBytes in entry.value) {
                items.add(Cbor.decodeFromByteArray(CborObject.serializer(), taggedBytes))
            }
            issuerSignedNameSpaces.add(
                CborMapEntry(
                    CborText(entry.key),
                    net.orandja.obor.data.CborArray(items, false)
                )
            )
        }
        issuerSignedMap.add(
            CborMapEntry(
                CborText("nameSpaces"),
                CborMap(issuerSignedNameSpaces, false)
            )
        )

        issuerSignedMap.add(
            CborMapEntry(
                CborText("issuerAuth"),
                Cbor.decodeFromByteArray(CborObject.serializer(), doc.issuerSigned.issuerAuth)
            )
        )
        document.add(CborMapEntry(CborText("issuerSigned"), CborMap(issuerSignedMap, false)))

        doc.deviceSigned?.let {
            val deviceSignedMap = mutableListOf<CborMapEntry>()
            deviceSignedMap.add(
                CborMapEntry(
                    CborText("nameSpaces"),
                    Cbor.decodeFromByteArray(CborObject.serializer(), doc.deviceSigned.nameSpaces)
                )
            )

            val deviceAuthMap = mutableListOf<CborMapEntry>()
            it.deviceAuth.deviceSignature?.let { sigBytes ->
                deviceAuthMap.add(
                    CborMapEntry(
                        CborText("deviceSignature"),
                        Cbor.decodeFromByteArray(CborObject.serializer(), sigBytes)
                    )
                )
            }

            it.deviceAuth.deviceMac?.let { macBytes ->
                deviceAuthMap.add(
                    CborMapEntry(
                        CborText("deviceMac"),
                        Cbor.decodeFromByteArray(CborObject.serializer(), macBytes)
                    )
                )
            }
            deviceSignedMap.add(CborMapEntry(CborText("deviceAuth"), CborMap(deviceAuthMap, false)))
            document.add(CborMapEntry(CborText("deviceSigned"), CborMap(deviceSignedMap, false)))
        }

        documentsArray.add(CborMap(document, false))
    }


    val responseMap = mutableListOf<CborMapEntry>()
    responseMap.add(CborMapEntry(CborText("version"), CborText(response.version)))
    if (documentsArray.isNotEmpty()) {
        responseMap.add(
            CborMapEntry(
                CborText("documents"),
                net.orandja.obor.data.CborArray(documentsArray, false)
            )
        )
    }

    //Used to tighten the encoder to ensure no callers misuse
    val nonEmptyDocErrors = response.documentErrors?.filter { it.isNotEmpty() }

    if (!nonEmptyDocErrors.isNullOrEmpty()) {
        val errorMaps = nonEmptyDocErrors.mapTo(mutableListOf<CborObject>()) { errorMap ->
            CborMap(
                errorMap.mapTo(mutableListOf()) { (docType, code) ->

                    /**
                     *  Just a note regarding the {require(code >= 0)} line in the below snippet
                     *  CborPositive only encodes non-negative integers. The CDDL says ErrorCode = int (signed),
                     *  so in theory negative codes are legal. In practice the only registered code is 0, and application codes live in the 10000+
                     *  range — all non-negative.
                     *
                     *  We're the omly caller so can fail loudly and prevent silent CBOR corruption is someone later tried to encode -1.
                     *
                     */

                    require(code >= 0) { "ErrorCode must be non-negative" }
                    CborMapEntry(CborText(docType), CborPositive(code.toULong()))
                },
                false,
            )
        }
        responseMap.add(
            CborMapEntry(
                CborText("documentErrors"),
                net.orandja.obor.data.CborArray(errorMaps, false),
            )
        )
    }


    responseMap.add(CborMapEntry(CborText("status"), CborPositive(response.status.toULong())))

    return CborMap(responseMap, false).cbor
}
