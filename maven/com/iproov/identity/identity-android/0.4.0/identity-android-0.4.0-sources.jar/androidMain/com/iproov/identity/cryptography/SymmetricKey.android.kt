package com.iproov.identity.cryptography

import com.iproov.identity.Logger
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

// --- Actual Platform Helper Implementations for Android/JVM ---
internal actual fun generateSecureRandomBytes(size: Int): ByteArray {
    return ByteArray(size).apply {
        SecureRandom().nextBytes(this)
    }
}


// --- Actual SymmetricKey Implementation for Android/JVM ---
actual class SymmetricKey {
    // Store the SecretKeySpec, created once.
    private val secretKeySpec: SecretKeySpec
    private val keyBytesInternal: ByteArray // Store original bytes for getKeyBytes()

    // Cipher configuration
    private val cipherAlgorithm = "AES/CBC/PKCS5Padding" // PKCS5 is compatible with PKCS7 for AES

    // Actual primary constructor
    actual constructor(keyBytes: ByteArray) {
        require(keyBytes.size == AES_KEY_SIZE_BYTES) {
            "Invalid key size. Expected $AES_KEY_SIZE_BYTES bytes for AES-256, got ${keyBytes.size}."
        }
        this.keyBytesInternal = keyBytes.copyOf() // Store a copy
        this.secretKeySpec = SecretKeySpec(this.keyBytesInternal, "AES") // Use the copy
    }

    // Actual secondary constructor (delegates to primary)
    @OptIn(ExperimentalEncodingApi::class)
    actual constructor(keyString: String) : this(Base64.decode(keyString))

    actual fun encrypt(plainData: ByteArray): ByteArray? {
        return try {
            val cipher = Cipher.getInstance(cipherAlgorithm)
            val ivBytes = generateSecureRandomBytes(AES_BLOCK_SIZE_BYTES)
            val ivSpec = IvParameterSpec(ivBytes)
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivSpec) // Use stored spec
            val encryptedBytes = cipher.doFinal(plainData)
            ivBytes + encryptedBytes // Prepend IV
        } catch (e: Exception) {
            Logger.info("Encryption failed: ${e.message}")
            null
        }
    }

    actual fun decrypt(encryptedData: ByteArray): ByteArray? {
        return try {
            if (encryptedData.size < AES_BLOCK_SIZE_BYTES) return null // Data too short for IV

            val cipher = Cipher.getInstance(cipherAlgorithm)
            val ivBytes = encryptedData.copyOfRange(0, AES_BLOCK_SIZE_BYTES)
            val ciphertextBytes = encryptedData.copyOfRange(AES_BLOCK_SIZE_BYTES, encryptedData.size)
            val ivSpec = IvParameterSpec(ivBytes)
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivSpec) // Use stored spec
            cipher.doFinal(ciphertextBytes)
        } catch (e: Exception) {
            Logger.info("Decryption failed: ${e.message}") // Often indicates bad key or padding error
            null
        }
    }

    actual fun getKeyBytes(): ByteArray = keyBytesInternal.copyOf() // Return a copy

    @OptIn(ExperimentalEncodingApi::class)
    actual fun getKeyString(): String = Base64.encode(keyBytesInternal)

    // Actual companion object implementation
    actual companion object {
        actual fun new(): SymmetricKey {
            val randomBytes = generateSecureRandomBytes(AES_KEY_SIZE_BYTES)
            return SymmetricKey(randomBytes) // Calls primary constructor
        }
    }
}