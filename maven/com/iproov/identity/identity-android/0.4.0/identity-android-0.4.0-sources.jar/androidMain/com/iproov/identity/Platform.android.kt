package com.iproov.identity

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build


@SuppressLint("HardwareIds")
class AndroidPlatform(private val context: Context, private val instanceId: String) : Platform {

    override val isVirtual: Boolean by lazy {
        false
    }

    override val target: Platform.Target by lazy {
        Platform.Target.Android
    }

    override val appInfo: AppInfo by lazy {
        val packageManager = context.packageManager
        val info = packageManager.getPackageInfo(context.packageName, 0)

        AppInfo(
            client = context.packageName,
            version = info.versionName
        )
    }

    override val deviceInfo: DeviceInfo
        get() = DeviceInfo(
            manufacturer = Build.MANUFACTURER,
            os = "Android",
            instanceId = instanceId,
            model = Build.MODEL,
            osversion = Build.VERSION.RELEASE,
        )
}
