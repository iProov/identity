package com.iproov.identity.persistence

import com.iproov.identity.cryptography.EncryptionKeyFactory
import com.iproov.identity.cryptography.KeyPairAccessPolicy

class StorageException(message: String) : Exception(message)
interface StorageEngine {
    @Throws(Throwable::class)
    suspend fun read(key: String): String?

    @Throws(Throwable::class)
    suspend fun write(key: String, value: String?)

    @Throws(Throwable::class)
    suspend fun deleteAll()
}

/**
 * The credentials are encrypted using the public / private key pair in the secure enclave.
 *
 * They are stored in a file in the NSApplicationSupport directory on apple and stored using encrypted shared preferences on Android.
 *
 */
expect fun getDeviceBoundStorageEngine(
    accessPolicy: KeyPairAccessPolicy,
): StorageEngine

/**
 * Creates device-bound storage whose encrypted payloads are handled by a caller-supplied key.
 *
 * This overload intentionally has no default for [encryptionKeyFactory], preserving the original
 * one-argument function in the binary and in the generated Apple framework.
 */
expect fun getDeviceBoundStorageEngine(
    accessPolicy: KeyPairAccessPolicy,
    encryptionKeyFactory: EncryptionKeyFactory,
): StorageEngine

class InMemoryStorageEngine() : StorageEngine {
    private var data = mutableMapOf<String, String?>()

    override suspend fun read(key: String): String? = data[key]

    override suspend fun write(key: String, value: String?) {
        data[key] = value
    }

    override suspend fun deleteAll() {
        data = mutableMapOf()
    }
}
