package com.iproov.identity.models

import com.iproov.identity.Logger
import java.io.ByteArrayInputStream
import java.security.KeyStore
import java.security.cert.CertPathValidator
import java.security.cert.CertificateFactory
import java.security.cert.PKIXParameters
import java.security.cert.TrustAnchor
import java.security.cert.X509Certificate

internal actual object PlatformX509CertVerifier {
    actual suspend fun verifyCertTrustChain(
        chain: List<ByteArray>,
        additionalAnchors: List<ByteArray>,
    ): Boolean {
        if (chain.isEmpty()) return false

        return try {
            val certFactory = CertificateFactory.getInstance("X.509")
            fun parse(der: ByteArray) =
                certFactory.generateCertificate(ByteArrayInputStream(der)) as X509Certificate

            val x509Chain = chain.map(::parse)

            // Supplied anchors are added rather than replacing them, which means Trusted Roots from AndroidCAStore are still used
            // This is so Web PKI and private-CA verifiers both validate.
            // AndroidCAStore exists only on a device; without it (JVM unit tests) the supplied
            // anchors are the whole trust set.
            val systemAnchors = try {
                PKIXParameters(KeyStore.getInstance("AndroidCAStore").apply { load(null) }).trustAnchors
            } catch (e: Exception) {
                Logger.error("System trust store unavailable, using supplied anchors only: ${e.message}")
                emptySet()
            }

            val suppliedAnchors = try {
                additionalAnchors.map { TrustAnchor(parse(it), null) }
            } catch (e: Exception) {
                Logger.error("A supplied trust anchor is not a valid certificate: ${e.message}")
                return false
            }
            val anchors = systemAnchors + suppliedAnchors

            // A PKIX CertPath must stop below the trust anchor, but x5c may include the
            // self-signed root. Leaving it in fails as "does not chain with any trust anchors".
            val last = x509Chain.last()
            val path =
                if (last.subjectX500Principal == last.issuerX500Principal) x509Chain.dropLast(1)
                else x509Chain

            if (path.isEmpty()) {
                // The chain is a lone self-signed certificate: trusted only if it is an anchor.
                return anchors.any { it.trustedCert == last }
            }

            CertPathValidator.getInstance("PKIX").validate(
                certFactory.generateCertPath(path),
                PKIXParameters(anchors).apply {
                    isRevocationEnabled = false // Enable if CRL / OCSP checking is required
                },
            )
            true
        } catch (e: Exception) {
            Logger.error("Chain Trust Verification Failed: ${e.message}")
            false
        }
    }
}
