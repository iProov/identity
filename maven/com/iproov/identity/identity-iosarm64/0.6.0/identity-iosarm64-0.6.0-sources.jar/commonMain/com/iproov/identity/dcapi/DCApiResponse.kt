package com.iproov.identity.dcapi

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject

/**
 * Response returned to the OS/browser via Digital Credentials API.
 *
 * This is the structure that the wallet returns through the platform's credential manager
 * back to the requesting website/application.
 */
@Serializable
data class DCApiResponse(
    /**
     * Protocol that was used (matches the requested provider's protocol).
     */
    val protocol: String,

    /**
     * Protocol-specific response data containing the credential presentation.
     */
    val data: JsonElement,
) {
    companion object {
        private val json = Json { prettyPrint = false }

        /**
         * Create a DC API response for OpenID4VP protocol.
         *
         * @param protocol The exact protocol string the request arrived with; the W3C DC API
         *   response model echoes it back to the verifier.
         * @param vpToken The VP Token containing the credential presentation(s)
         */
        @Throws(Exception::class)
        fun forOpenID4VP(
            vpToken: String,
            state: String? = null, // Ignored: state is not defined over the DC API (OID4VP A.2).
            protocol: String = DCApiProtocol.OPENID4VP,
        ): DCApiResponse =
            DCApiResponse(
                protocol = protocol,
                data = buildJsonObject { put("vp_token", json.parseToJsonElement(vpToken)) },
            )

        /**
         * Create a DC API response for OpenID4VP with encrypted JWT response.
         *
         * @param protocol The exact protocol string the request arrived with
         * @param jwe The encrypted JWT containing the VP Token
         */
        fun forOpenID4VPJWT(
            jwe: String,
            state: String? = null, // Ignored: state is not defined over the DC API (OID4VP A.2).
            protocol: String = DCApiProtocol.OPENID4VP,
        ): DCApiResponse =
            DCApiResponse(
                protocol = protocol,
                data = buildJsonObject { put("response", JsonPrimitive(jwe)) },
            )

        /** OID4VP A.4: a protocol error is a fulfilled response whose data holds only `error`. */
        fun forError(protocol: String, code: String): DCApiResponse =
            DCApiResponse(
                protocol = protocol,
                data = buildJsonObject { put("error", JsonPrimitive(code)) },
            )

        /**
         * Create a DC API response for ISO mDoc protocol.
         *
         * @param deviceResponse Base64url-encoded DeviceResponse CBOR
         */
        fun forIsoMDoc(
            deviceResponse: String,
        ): DCApiResponse {
            val data = buildJsonObject {
                put("deviceResponse", JsonPrimitive(deviceResponse))
            }
            return DCApiResponse(
                protocol = DCApiProtocol.ISO_MDOC,
                data = data
            )
        }
    }

    /**
     * Serialize this response to JSON string for returning to the platform.
     */
    @Throws(Exception::class)
    fun toJson(): String = json.encodeToString(serializer(), this)
}

/**
 * Result of processing a DC API request.
 */
sealed class DCApiResult {
    /**
     * Successfully processed the request and generated a response.
     */
    data class Success(
        val response: DCApiResponse,
    ) : DCApiResult()

    /**
     * User declined to share credentials.
     */
    data object UserDeclined : DCApiResult()

    /**
     * No matching credentials found for the request.
     */
    data class NoMatchingCredentials(
        val message: String = "No credentials match the request",
    ) : DCApiResult()

    /**
     * Error occurred during processing.
     */
    data class Error(
        val code: String,
        val message: String,
        val cause: Throwable? = null,
    ) : DCApiResult()
}

/**
 * Error codes for DC API error responses.
 */
object DCApiErrorCode {
    const val INVALID_REQUEST = "invalid_request"
    const val UNSUPPORTED_PROTOCOL = "unsupported_protocol"
    const val NO_CREDENTIALS = "no_credentials"
    const val USER_CANCELLED = "user_cancelled"
    const val INTERNAL_ERROR = "internal_error"
    const val SIGNING_FAILED = "signing_failed"

    const val INVALID_TRANSACTION_DATA = "invalid_transaction_data"
    const val UNSUPPORTED_RESPONSE_TYPE = "unsupported_response_type"
    const val ACCESS_DENIED = "access_denied"
    const val SERVER_ERROR = "server_error"
}

/** Unused since 0.5.3; kept so 0.5.2 code compiles. Responses are built with [DCApiResponse.forOpenID4VP]. */
@Deprecated("Unused; build responses with DCApiResponse.forOpenID4VP")
@Serializable
data class OpenID4VPResponse(
    @SerialName("vp_token")
    val vpToken: JsonElement,
    val state: String? = null,
)
