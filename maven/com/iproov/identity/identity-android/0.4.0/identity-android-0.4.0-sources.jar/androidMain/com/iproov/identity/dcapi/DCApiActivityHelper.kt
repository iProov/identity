package com.iproov.identity.dcapi

import android.app.Activity
import android.content.Intent
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.credentials.CredentialOption
import androidx.credentials.DigitalCredential
import androidx.credentials.ExperimentalDigitalCredentialApi
import androidx.credentials.GetCredentialResponse
import androidx.credentials.GetDigitalCredentialOption
import androidx.credentials.exceptions.GetCredentialUnknownException
import androidx.credentials.provider.PendingIntentHandler
import androidx.credentials.provider.ProviderGetCredentialRequest
import androidx.credentials.registry.provider.selectedEntryId
import com.iproov.identity.AppContext
import com.iproov.identity.Logger
import com.iproov.identity.R

/**
 * Helper class for consumer apps to handle DC API credential selection in their Activity.
 *
 * With the registry-based DC API approach, credentials are registered with the system
 * via AndroidDCApiRegistrar. When a verifier requests credentials and the user selects
 * one from the system picker, the system launches your Activity.
 *
 * Setup in AndroidManifest.xml:
 * ```xml
 * <activity
 *     android:name=".CredentialSelectionActivity"
 *     android:exported="true">
 *     <intent-filter>
 *         <action android:name="androidx.credentials.registry.provider.action.GET_CREDENTIAL" />
 *         <category android:name="android.intent.category.DEFAULT" />
 *     </intent-filter>
 * </activity>
 * ```
 *
 * Usage in your Activity:
 * ```kotlin
 * class CredentialSelectionActivity : AppCompatActivity() {
 *     private lateinit var dcApiHelper: DCApiActivityHelper
 *
 *     override fun onCreate(savedInstanceState: Bundle?) {
 *         super.onCreate(savedInstanceState)
 *
 *         dcApiHelper = DCApiActivityHelper(this)
 *
 *         if (!dcApiHelper.isValidRequest()) {
 *             finish()
 *             return
 *         }
 *
 *         // Get request details
 *         val request = dcApiHelper.getProviderRequest()
 *         val selectedEntryId = dcApiHelper.getSelectedEntryId()
 *         val callingPackage = dcApiHelper.getCallingPackageName()
 *
 *         lifecycleScope.launch {
 *             // Process with your wallet SDK
 *             val response = processCredentialRequest(request, selectedEntryId)
 *
 *             when (response) {
 *                 is DCApiResult.Success -> dcApiHelper.returnSuccess(response)
 *                 is DCApiResult.Error -> dcApiHelper.returnError(response)
 *                 else -> dcApiHelper.returnCancelled()
 *             }
 *         }
 *     }
 * }
 * ```
 */
@RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
class DCApiActivityHelper(private val activity: Activity) {

    private val intent: Intent = activity.intent

    private var providerRequest: ProviderGetCredentialRequest? = null

    init {
        // Try to retrieve the provider request from the intent
        providerRequest = try {
            PendingIntentHandler.retrieveProviderGetCredentialRequest(intent)
        } catch (e: Exception) {
            Logger.debug("DC API: Could not retrieve provider request: ${e.message}")
            null
        }
    }

    /**
     * Check if this Activity was launched with a valid DC API credential request.
     */
    fun isValidRequest(): Boolean {
        return providerRequest != null
    }

    /**
     * Get the full provider credential request.
     */
    fun getProviderRequest(): ProviderGetCredentialRequest? {
        return providerRequest
    }

    /**
     * Get the ID of the credential entry that was selected by the user.
     */
    fun getSelectedEntryId(): String? {
        return providerRequest?.selectedEntryId
    }

    /**
     * Get the package name of the app that initiated the credential request.
     */
    fun getCallingPackageName(): String? {
        return providerRequest?.callingAppInfo?.packageName
    }

    /**
     * Get the origin (for web requests) if available.
     * Returns the origin of the calling app. This is only non-null if a privileged app like a browser calls Credential Manager APIs on behalf of another application.
     * Additionally, in order to get the origin, the credential provider must provide an allowlist of privileged browsers/apps that it trusts. This allowlist must be in the form of a valid, non-empty JSON. The origin will only be returned if the packageName and the SHA256 hash of the newest signature obtained from the signingInfo, is present in the privilegedAllowlist.
     * Packages that are signed with multiple signers will only receive the origin if all of the signatures are present in the privilegedAllowlist.
     *
     * @param privilegeAllowList
     * The format of this privilegedAllowlist JSON must adhere to the following sample.
     * ```json
     * {"apps": [
     *    {
     *       "type": "android",
     *       "info": {
     *          "package_name": "com.example.myapp",
     *          "signatures" : [
     *          {"build": "release",
     *              "cert_fingerprint_sha256": "59:0D:2D:7B:33:6A:BD:FB:54:CD:3D:8B:36:8C:5C:3A:
     *              7D:22:67:5A:9A:85:9A:6A:65:47:FD:4C:8A:7C:30:32"
     *          },
     *          {"build": "userdebug",
     *          "cert_fingerprint_sha256": "59:0D:2D:7B:33:6A:BD:FB:54:CD:3D:8B:36:8C:5C:3A:7D:
     *          22:67:5A:9A:85:9A:6A:65:47:FD:4C:8A:7C:30:32"
     *          }]
     *       }
     *     }
     * ]}
     * ````
     * All keys in the JSON must be exactly as stated in the sample above. Note that if the build for a given fingerprint is specified as 'userdebug', that fingerprint will only be considered if the device is on a 'userdebug' build, as determined by Build.TYPE.
     *
     * @throws IllegalArgumentException - If privilegedAllowlist is empty, or an invalid JSON, or does not follow the format detailed above
     * @throws  IllegalStateException - If the origin is non-null, but the packageName and signingInfo do not have a match in the privilegedAllowlist
     */
    fun getCallingOrigin(privilegeAllowList: String? = null): String? {
        val allowList = privilegeAllowList ?: run {
            AppContext.get().resources.openRawResource(R.raw.privileged_browsers)
                .bufferedReader()
                .use { it.readText() }
        }

        return providerRequest?.callingAppInfo?.getOrigin(allowList)
    }

    /**
     * Get the credential options from the request.
     * Use this to extract the actual credential request data.
     */
    fun getCredentialOptions(): List<CredentialOption>? {
        return providerRequest?.credentialOptions
    }

    /**
     * Extract the request JSON from a DigitalCredential option.
     */
    @OptIn(ExperimentalDigitalCredentialApi::class)
    fun extractRequestJson(): String? {
        val options = providerRequest?.credentialOptions ?: return null

        for (option in options) {
            if (option is GetDigitalCredentialOption) {
                return option.requestJson
            }
        }

        // Fallback: try to find requestJson in any option's data
        for (option in options) {
            val data = option.candidateQueryData
            val json = data.getString("requestJson")
                ?: data.getString("androidx.credentials.BUNDLE_KEY_REQUEST_JSON")
            if (json != null) return json
        }

        return null
    }

    /**
     * Convert the ProviderGetCredentialRequest to a JSON string for logging or processing.
     * This extracts the key information from the request into a JSON format.
     */
    @OptIn(ExperimentalDigitalCredentialApi::class)
    fun requestToJson(): String? {
        val request = providerRequest ?: return null

        return try {
            val json = org.json.JSONObject()

            // Add calling app info
            request.callingAppInfo?.let { appInfo ->
                json.put("callingAppInfo", org.json.JSONObject().apply {
                    put("packageName", appInfo.packageName)
                    // Note: origin requires privilegedAllowlist, so we skip it here
                })
            }

            // Add selected entry ID
            request.selectedEntryId?.let {
                json.put("selectedEntryId", it)
            }

            // Add credential options
            val optionsArray = org.json.JSONArray()
            for (option in request.credentialOptions) {
                val optionJson = org.json.JSONObject()
                optionJson.put("type", option.type)
                optionJson.put("isSystemProviderRequired", option.isSystemProviderRequired)

                // If it's a digital credential option, include the request JSON
                if (option is GetDigitalCredentialOption) {
                    optionJson.put("requestJson", org.json.JSONObject(option.requestJson))
                }

                // Include candidate query data keys
                val dataKeys = org.json.JSONArray()
                option.candidateQueryData.keySet().forEach { key ->
                    dataKeys.put(key)
                }
                optionJson.put("candidateQueryDataKeys", dataKeys)

                optionsArray.put(optionJson)
            }
            json.put("credentialOptions", optionsArray)

            json.toString(2) // Pretty print with 2-space indent
        } catch (e: Exception) {
            Logger.error("DC API: Error converting request to JSON: ${e.message}")
            null
        }
    }

    /**
     * Return a successful credential response to the system.
     *
     * @param response The DCApiResult.Success containing the credential response
     */
    @OptIn(ExperimentalDigitalCredentialApi::class)
    fun returnSuccess(response: DCApiResult.Success) {
        Logger.debug("DC API: Returning successful response")

        try {
            val resultData = Intent()

            // Create a DigitalCredential with the response JSON
            val digitalCredential = DigitalCredential(response.response.toJson())

            // Wrap in GetCredentialResponse
            val getCredentialResponse = GetCredentialResponse(digitalCredential)

            // Use PendingIntentHandler to set the response properly
            PendingIntentHandler.setGetCredentialResponse(resultData, getCredentialResponse)

            activity.setResult(Activity.RESULT_OK, resultData)
        } catch (e: Exception) {
            Logger.error("DC API: Error creating credential response: ${e.message}")
            returnError(DCApiResult.Error("response_error", e.message ?: "Failed to create response"))
            return
        }

        activity.finish()
    }

    /**
     * Return a successful response with raw JSON.
     *
     * @param responseJson The credential response as JSON string
     */
    @OptIn(ExperimentalDigitalCredentialApi::class)
    fun returnSuccessJson(responseJson: String) {
        Logger.debug("DC API: Returning successful response (JSON)")

        try {
            val resultData = Intent()
            val digitalCredential = DigitalCredential(responseJson)
            val getCredentialResponse = GetCredentialResponse(digitalCredential)
            PendingIntentHandler.setGetCredentialResponse(resultData, getCredentialResponse)
            activity.setResult(Activity.RESULT_OK, resultData)
        } catch (e: Exception) {
            Logger.error("DC API: Error creating credential response: ${e.message}")
            returnError(DCApiResult.Error("response_error", e.message ?: "Failed to create response"))
            return
        }

        activity.finish()
    }

    /**
     * Return a user-cancelled response to the system.
     */
    fun returnCancelled() {
        Logger.debug("DC API: User cancelled credential selection")

        try {
            val resultData = Intent()
            PendingIntentHandler.setGetCredentialException(
                resultData,
                androidx.credentials.exceptions.GetCredentialCancellationException()
            )
            activity.setResult(Activity.RESULT_OK, resultData)
        } catch (e: Exception) {
            activity.setResult(Activity.RESULT_CANCELED)
        }

        activity.finish()
    }

    /**
     * Return an error response to the system.
     *
     * @param error The DCApiResult.Error containing the error information
     */
    fun returnError(error: DCApiResult.Error) {
        Logger.error("DC API: Returning error: ${error.code} - ${error.message}")

        try {
            val resultData = Intent()
            PendingIntentHandler.setGetCredentialException(
                resultData,
                GetCredentialUnknownException(error.message)
            )
            activity.setResult(Activity.RESULT_OK, resultData)
        } catch (e: Exception) {
            Logger.error("DC API: Error setting credential exception: ${e.message}")
            activity.setResult(Activity.RESULT_CANCELED)
        }

        activity.finish()
    }

    /**
     * Return a "no matching credentials" response.
     */
    fun returnNoCredentials() {
        Logger.debug("DC API: No matching credentials")

        try {
            val resultData = Intent()
            PendingIntentHandler.setGetCredentialException(
                resultData,
                androidx.credentials.exceptions.NoCredentialException()
            )
            activity.setResult(Activity.RESULT_OK, resultData)
        } catch (e: Exception) {
            activity.setResult(Activity.RESULT_CANCELED)
        }

        activity.finish()
    }
}
