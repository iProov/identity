package com.iproov.identity.proximity

/**
 * Requires an Entitlement to host an HCE service on the IOS
 * This is purely to adhere to the expect/actual of KMP
 */
internal actual object NfcEngagementRegistry {

    actual suspend fun publish(handle: NfcEngagementHandler) {
        throw NfcEngagementUnavailableException(
            "NFC holder engagement is not available on iOS — Apple restricts " +
                    "third-party HCE for mdoc. Please use the QR overload of startProximityPresentation instead."
        )
    }

    actual suspend fun current(): NfcEngagementHandler? = null
}