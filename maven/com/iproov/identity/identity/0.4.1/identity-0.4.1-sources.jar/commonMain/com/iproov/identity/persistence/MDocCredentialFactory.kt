package com.iproov.identity.persistence

import com.iproov.identity.Base64Utils.decodeFromBase64Url
import com.iproov.identity.Base64Utils.matchesBase64Url
import com.iproov.identity.HexUtils.matchesHex
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialFormat
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.VerificationSummary
import com.iproov.identity.models.toJsonElement
import com.iproov.identity.models.toNativeTypes
import kotlinx.serialization.json.JsonObject
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.DataItem
import org.multipaz.cose.CoseSign1
import org.multipaz.mdoc.issuersigned.IssuerNamespaces
import org.multipaz.mdoc.mso.MobileSecurityObject

/**
 * Factory for creating [MDocCredential] instances from OID4VCI credential responses.
 *
 * Parses the IssuerSigned CBOR structure as defined in ISO 18013-5:
 * ```
 * IssuerSigned = {
 *   "nameSpaces": IssuerNameSpaces,
 *   "issuerAuth": COSE_Sign1  ; Contains the Mobile Security Object (MSO)
 * }
 * ```
 */
class MDocCredentialFactory : CredentialFactory {

    override val format: String = CredentialFormat.MDOC.value

    override fun createCredential(raw: String): Credential {
        val signedBytes = decodeCredentialData(raw)
        val issuerSignedMap = Cbor.decode(signedBytes).asMap

        val nameSpacesDataItem = issuerSignedMap.getByKey("nameSpaces")
            ?: error("IssuerSigned missing 'nameSpaces' field")
        val issuerAuthDataItem = issuerSignedMap.getByKey("issuerAuth")
            ?: error("IssuerSigned missing 'issuerAuth' field")

        val issuerNamespaces = IssuerNamespaces.fromDataItem(nameSpacesDataItem)
        val mso = parseMobileSecurityObject(issuerAuthDataItem)

        val nameSpaces = issuerNamespaces.data.entries.associate { (namespace, claims) ->
            namespace to claims.entries.associate { (claimName, item) ->
                claimName to item.dataElementValue.toNativeTypes()
            }
        }

        return MDocCredential(
            raw = raw,
            body = nameSpaces.toJsonElement() as JsonObject,
            docType = mso.docType,
            nameSpaces = nameSpaces,
            onCheckVerificationStatus = { VerificationSummary.start() }
        )
    }

    private fun decodeCredentialData(raw: String): ByteArray {
        val isHex = raw.matchesHex()
        val isBase64Url = raw.matchesBase64Url()
        require(isHex || isBase64Url) { "Credential data is neither hex nor base64url encoded" }
        return if (isHex) raw.hexToByteArray() else raw.decodeFromBase64Url()
    }

    private fun parseMobileSecurityObject(issuerAuthDataItem: DataItem): MobileSecurityObject {
        // issuerAuth is a COSE_Sign1 with payload containing Tag24(MSO)
        val coseSign1 = CoseSign1.fromDataItem(issuerAuthDataItem)
        val msoPayload = coseSign1.payload
            ?: error("IssuerAuth COSE_Sign1 has no payload")

        // Unwrap Tag 24 to get the MSO DataItem
        val msoDataItem = Cbor.decode(msoPayload).asTaggedEncodedCbor
        return MobileSecurityObject.fromDataItem(msoDataItem)
    }

    /** Helper to find a value in a CBOR map by its text string key */
    private fun Map<DataItem, DataItem>.getByKey(key: String): DataItem? =
        entries.find { (k, _) -> k.asTstr == key }?.value
}