package com.iproov.identity.models

/**
 * Apple-specific extensions for SdJwtVcCredential that convert
 * kotlinx.serialization types to native Swift-compatible types.
 */

/**
 * Get the credential body as a native Swift dictionary.
 */
val SdJwtVcCredential.body: Map<String, Any?>
    get() = body.toMap().mapValues { it.value.toNativeTypes() }

/**
 * Get the confirmation key (cnf) as a native Swift dictionary.
 */
val SdJwtVcCredential.confirmationKey: Map<String, Any?>?
    get() = confirmationKey?.toMap()?.mapValues { it.value.toNativeTypes() }
