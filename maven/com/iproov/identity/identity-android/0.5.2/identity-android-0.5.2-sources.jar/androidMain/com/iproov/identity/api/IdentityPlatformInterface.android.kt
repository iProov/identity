package com.iproov.identity.api

import com.iproov.identity.AppInfo
import com.iproov.identity.DeviceInfo
import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Platform
import com.iproov.identity.attestation.SimplePasswordAttestationService
import com.iproov.identity.encodeToJsonObject

import com.iproov.identity.models.Jwt
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlin.coroutines.cancellation.CancellationException

internal class AndroidIdentityPlatformInterface(
    apiClient: ApiClient,
    private val platform: Platform,
    keyPairFactory: KeyPairFactory
) : IdentityPlatformInterface(apiClient, keyPairFactory) {
    object Requests {
        @Serializable
        data class RegisterWallet(
            @SerialName("device")
            val deviceInfo: DeviceInfo,
            @SerialName("app")
            val appInfo: AppInfo,
            @SerialName("keytype")
            val keySecurityLevel: String,
            /**
             * The Play Integrity token. Omitted on the simple-password (emulator/dev) path — the
             * server dispatches on this field first and would run real Play Integrity verification
             * against whatever it holds. See [omitNullsJson] for why the key is absent rather than
             * null.
             */
            @SerialName("playintegrity")
            val playIntegrity: String? = null,
            /**
             * Set only on the simple-password (emulator/dev) path, where the token is verified by
             * value rather than by attesting the device. Omitted otherwise.
             */
            @SerialName("attestation_token")
            val attestationToken: String? = null,
        )
    }

    private val keyPair get() = keyPairFactory()
    override var platformAttestationKeyId: String? = null


    @Throws(ApiException::class, CancellationException::class)
    override suspend fun registerWallet(attestationToken: String): List<Jwt> {
        val isSimplePassword =
            attestationToken == SimplePasswordAttestationService.SIMPLE_PASSWORD

        val request = Requests.RegisterWallet(
            deviceInfo = platform.deviceInfo,
            appInfo = platform.appInfo,
            keySecurityLevel = keyPair.getKeySecurityLevel(),
            playIntegrity = attestationToken.takeUnless { isSimplePassword },
            attestationToken = attestationToken.takeIf { isSimplePassword },
        ).encodeToJsonObject(omitNullsJson)

        val response = apiClient.signAndPost(Routes.Wallet.REGISTER, request)

        return getClaims(response)
    }
}