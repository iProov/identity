package com.iproov.identity.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC


/** DCQL — minimal structure needed for matching. */
@Serializable
data class DcqlQuery(
    val credentials: List<CredentialQuery> = emptyList(),
    @SerialName("credential_sets")
    val credentialSets: List<CredentialSetQuery>? = null
) {
    init {
        credentialSets?.let {
            require(it.isNotEmpty()) {
                "credential_sets, when present, must be a non-empty array (Section 6)"
            }
        }

        // Credential ids must be unique within the request (Section 6.1)
        val ids = credentials.map { it.id }
        require(ids.size == ids.toSet().size) {
            "Credential Query id values must be unique within the request (Section 6.1)"
        }
        
        // Every id referenced in credential_sets must exist in credentials (Section 6.2)
        credentialSets?.let { sets ->
            val knownIds = ids.toSet()
            sets.flatMap { it.options.flatten() }.forEach { ref ->
                require(ref in knownIds) {
                    "credential_sets references unknown Credential Query id: $ref (Section 6.2)"
                }
            }
        }
    }
}

/**
 * Represents a Credential Set Query as defined in OpenID for Verifiable Presentations 1.0, Section 6.2.
 *
 * A Credential Set Query specifies constraints on which combination of requested Credentials
 * must be returned to satisfy a particular use case with the Verifier.
 *
 * @property options Non-empty list where each element is a non-empty list of Credential Query
 *                   identifiers (referencing `id` values in the top-level `credentials` array).
 *                   Each inner list represents one acceptable set of Credentials that satisfies
 *                   the use case.
 * @property required Whether this set of Credentials is required. Defaults to true per spec
 *                    when omitted from the serialised form.
 */
@Serializable
data class CredentialSetQuery(
    val options: List<List<String>>,
    val required: Boolean = true,
) {
    init {
        require(options.isNotEmpty()) {
            "options must be a non-empty array (Section 6.2)"
        }
        require(options.all { it.isNotEmpty() }) {
            "Each element in options must be a non-empty array of Credential Query identifiers (Section 6.2)"
        }
    }
}

@OptIn(ExperimentalObjCRefinement::class)
@Serializable
data class CredentialQuery(
    val id: String,

    /**
     * Format used to identify the credential in the wallet.
     */
    val format: String, // e.g., jwt_vc_json | ldp_vc | mso_mdoc | dc+sd-jwt
    val claims: List<ClaimQuery>? = null,

    @HiddenFromObjC
    val meta: JsonObject? = null, // format-specific tuning: type_values, vct_values, doctype_value...

    /**
     * Whether multiple credentials can be returned for this query
     */
    val multiple: Boolean = false,

    // Defined in OIDVP 6.1.1
    @SerialName("trusted_authorities")
    val trustedAuthorities: List<String>? = null,
    @SerialName("require_cryptographic_holder_binding")
    val requireCryptographicHolderBinding: Boolean? = null,

    /**
     * Combinations of the claims that can be submitted.
     */
    @SerialName("claim_sets")
    val claimSets: List<List<String>>? = null
) {
    init {
        // Per OID4VP § 6.1.1: id is REQUIRED on each ClaimQuery when claim_sets is defined.
        claimSets?.let {
            require(claims?.all { claim -> claim.id != null } != false) {
                "All claims must have an id when claim_sets is defined (OID4VP § 6.1.1)"
            }
        }
    }
}

@OptIn(ExperimentalObjCRefinement::class)
@Serializable
data class ClaimQuery(
    /**
     * REQUIRED if CredentialQuery has defined [claimSets]
     */
    val id: String? = null,

    /**
     * Where in the VC this can be found
     */
    val path: List<String>,

    /**
     * Accepted values for this requested property.
     */
    @HiddenFromObjC
    val values: List<JsonElement>? = null,

    /**
     * Whether the issuer intends to retain
     */
    @SerialName("intent_to_retain")
    val intentToRetain: Boolean = false
)