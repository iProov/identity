package com.iproov.identity.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlinx.serialization.json.Json

@Serializable
sealed class VerificationEvent(val isFinal: Boolean) {

    @Serializable
    @SerialName("started")
    data object Started : VerificationEvent(false)

    @Serializable
    @SerialName("loading")
    data object Loading : VerificationEvent(false)

    @Serializable
    @SerialName("completed")
    data class Completed(
        @Transient val offer: RespondableCredentialOffer? = null // For now this is nullable as verifyFace doesn't support this only verify/docdb
    ) : VerificationEvent(true)


    @Serializable
    @SerialName("error")
    data class Error(val message: String) : VerificationEvent(true)

    @Serializable
    @SerialName("cancelled")
    data object Canceled : VerificationEvent(true)

    fun toJsonString() = Json.encodeToString(this)
}
