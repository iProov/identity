package com.iproov.identity

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import platform.Foundation.NSError
import platform.Foundation.NSLocalizedDescriptionKey

// Helper extension function to convert Throwable to NSError
@OptIn(ExperimentalForeignApi::class)
fun Throwable.toNSError(domain: String = "com.iproov.identity.FlowError", code: Long = -1): NSError {
    val userInfo = mutableMapOf<Any?, Any>()
    userInfo[NSLocalizedDescriptionKey] = this.message ?: this.toString()
    return NSError(domain, code, userInfo)
}

class FlowWrapper<out T> internal constructor(
    private val scope: CoroutineScope,
    private val flow: Flow<T>
) {
    private var job: Job? = null
    private var isCancelled = false

    /**
     *  Cancels the flow
     */
    fun cancel() {
        isCancelled = true
        job?.cancel()
    }

    /**
     * Starts the flow
     * @param onEach callback called on each emission
     * @param onError callback called when flow completes. It will be provided with a non
     * nullable Throwable if it completes abnormally
     */
    fun collect(
        onEach: (T) -> Unit,
        onError: (NSError) -> Unit
    ) {
        if (isCancelled) return
        job = scope.launch {
            try {
                Logger.info("FlowWrapper.collect: Coroutine launched")
                flow.collect { item ->
                    onEach.invoke(item)
                }
            } catch (e: Throwable) {
                Logger.info("FlowWrapper.collect: Exception: ${e.message}")
                onError(e.toNSError())
            }
        }
    }
}

@Throws(Exception::class)
internal fun <T> Flow<T>.wrap(scope: CoroutineScope = MainScope()) = FlowWrapper<T>(scope, this)
