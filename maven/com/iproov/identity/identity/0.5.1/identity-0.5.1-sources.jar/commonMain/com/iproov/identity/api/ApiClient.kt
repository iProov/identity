package com.iproov.identity.api

import com.benasher44.uuid.uuid4
import com.iproov.identity.Logger
import com.iproov.identity.Platform
import com.iproov.identity.cryptography.KeyPair
import com.iproov.identity.cryptography.signRs
import com.iproov.identity.models.Jwt
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpRequestTimeoutException
import io.ktor.client.request.accept
import io.ktor.client.request.forms.submitForm
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.Parameters
import io.ktor.http.isSuccess
import kotlinx.io.IOException
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

sealed class ApiException(message: String? = null, cause: Throwable? = null) : Exception(message) {

    data class NetworkError(
        override val cause: Throwable? = null
    ) :
        ApiException(
            "We couldn't reach our servers, please ensure you are connected to the internet.",
            cause
        )

    data class TimeoutError(override val cause: Throwable? = null) :
        ApiException("Request timed out.", cause)

    data class HttpError(
        val statusCode: HttpStatusCode,
        override val message: String?,
        val errorCode: String?,
        val recoveryMessage: String?,
        override val cause: Throwable? = null
    ) : ApiException(message, cause)

    data class SerializationError(override val cause: Throwable? = null) :
        ApiException("An internal error has occurred.", cause)
}

interface NetworkClient {
    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): HttpResponse;
    suspend fun post(
        url: String, body: Any, headers: Map<String, String> = emptyMap()
    ): HttpResponse

    suspend fun submitForm(
        url: String,
        params: Parameters,
        headers: Map<String, String> = emptyMap()
    ): HttpResponse
}

class ApiClient(
    val baseUrl: String,
    val keyPairGenerator: () -> KeyPair,
    val platform: Platform,
    instanceId: String
) : NetworkClient {

    /** Test-only transport injection without changing the public constructor surface. */
    internal constructor(
        baseUrl: String,
        keyPairGenerator: () -> KeyPair,
        platform: Platform,
        instanceId: String,
        client: HttpClient,
        userAgent: UserAgent,
    ) : this(baseUrl, keyPairGenerator, platform, instanceId) {
        this.clientOverride = client
        this.userAgentOverride = userAgent
    }

    private var userAgentOverride: UserAgent? = null
    private val userAgent: UserAgent by lazy { userAgentOverride ?: getUserAgent() }

    private val keyPair get() = keyPairGenerator()

    private val sessionId: String = uuid4().toString()

    private var clientOverride: HttpClient? = null
    private val client: HttpClient by lazy { clientOverride ?: httpClient }

    override suspend fun submitForm(
        url: String, params: Parameters, headers: Map<String, String>
    ): HttpResponse = try {
        Logger.info("Submitting for to $url")
        Logger.debug("Params: $params")
        Logger.debug("[submitForm][$url] headers: $headers")
        client.submitForm(url, params) {
            // Handle Accept header specially to override ContentNegotiation plugin
            val acceptHeader = headers["Accept"]
            if (acceptHeader != null) {
                accept(ContentType.parse(acceptHeader))
            }
            // Set all other headers
            for ((key, value) in headers) {
                if (key != "Accept") {
                    header(key, value)
                }
            }
        }
    } catch (e: HttpRequestTimeoutException) {
        Logger.error("[post] Request timeout: ${e.message}")
        throw ApiException.TimeoutError(e)
    } catch (e: IOException) {
        Logger.error("[post] Network error: ${e.message}")
        throw ApiException.NetworkError(e)
    } catch (e: SerializationException) {
        Logger.error("[post] Serialization error: ${e.message}")
        throw ApiException.SerializationError(e)
    } catch (e: Throwable) {
        e.printStackTrace()
        Logger.error("[post] Unknown error: ${e.message}")
        throw e
    }


    suspend fun signAndPost(
        path: String,
        body: JsonObject,
        headers: Map<String, String> = emptyMap(),
        keyId: String? = null
    ): JsonObject {

        Logger.info("Making signed JWS request $path")
        Logger.debug("[signAndPost][$path] RAW body: $body")

        Logger.debug("[signAndPost][$path] Constructing JWT")

        // The getter re-invokes the validated factory each access; resolve once to avoid a redundant
        // key reconstruction + re-validation per request.
        val signingKey = keyPair
        val jws = Jwt.create(
            signingKey.getJwk(),
            payload = mapOf(
                "payload" to body
            )
        ) { signingKey.signRs(it) }

        Logger.debug("[signAndPost][$path] Signed JWS constructed")
        Logger.debug("[signAndPost][$path] Signed JWS length: ${jws.length}")

        Logger.debug("[signAndPost][$path] Posting request now")

        val response = post(
            baseUrl + path, jws, headers = headers
                .plus(
                    mapOf(
                        "Content-Type" to "application/jwt",
                        "App-Target" to platform.appInfo.client,
                    )
                )
                .plus(getPlatformHeaders(jws, keyId))
        )

        Logger.debug("[signAndPost][$path] Response: ${response.bodyAsText()}")

        val jwt = Jwt(response.bodyAsText())

        Logger.debug("[signAndPost][$path] Response JWT: $jwt")

        return jwt.payload
    }

    override suspend fun post(
        url: String,
        body: Any,
        headers: Map<String, String>,
    ): HttpResponse {
        val requestHeaders =
            defaultHeaders.plus(headers).map { (key, value) -> key to value }.toMap()
        Logger.debug("[post][$url] headers: $requestHeaders")
        Logger.debug("[post][$url] body: $body")

        val response = try {
            client.post(url) {
                for ((key, value) in requestHeaders) header(key, value)
                setBody(body)
            }
        } catch (e: HttpRequestTimeoutException) {
            Logger.error("[post] Request timeout: ${e.message}")

            throw ApiException.TimeoutError(e)
        } catch (e: IOException) {
            Logger.error("[post] Network error: ${e.message}")

            throw ApiException.NetworkError(e)
        } catch (e: SerializationException) {
            Logger.error("[post] Serialization error: ${e.message}")
            throw ApiException.SerializationError(e)
        }

        response.validate()
        return response
    }

    override suspend fun get(url: String, headers: Map<String, String>): HttpResponse {
        Logger.debug("[get] $url")

        val response = try {
            client.get(url) {
                for ((key, value) in defaultHeaders.plus(headers)) header(key, value)
            }
        } catch (e: IOException) {
            Logger.error("[get] Network exception was thrown: $e")
            throw ApiException.NetworkError(e)
        }

        response.validate()
        return response
    }


    private val defaultHeaders: Map<String, String> by lazy {
        mapOf(
            "x-instance-id" to instanceId,
            "session-id" to sessionId,
            "accept" to "application/json",
            "user-agent" to userAgent.header,
        )
    }
}

expect val httpClient: HttpClient

suspend fun HttpResponse.validate(): HttpResponse {

    if (status.isSuccess()) return this

    val bodyMap = Json.decodeFromString<JsonObject>(bodyAsText())

    throw ApiException.HttpError(
        statusCode = status,
        message = bodyMap["error"]?.jsonPrimitive?.content,
        errorCode = bodyMap["recovery_code"]?.jsonPrimitive?.content,
        recoveryMessage = bodyMap["recovery_msg"]?.jsonPrimitive?.content,
    )
}

/**
 * This will be called each signed post request to the backend, at the moment only getting the ios assertion header
 * on iOS and keyId is provided, however may contain more headers in the future.
 */
expect suspend fun getPlatformHeaders(jws: String, keyId: String? = null): Map<String, String>
