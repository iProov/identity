package com.iproov.identity

enum class LogLevel {
    DEBUG,
    INFO,
    ERROR,
    NONE,
}

internal object Logger {

    var isEnabled: Boolean = false

    /**
     * Helper method for ERROR logging
     */
    fun error(message: String) = output(LogLevel.ERROR, message)

    /**
     * Helper method for INFO logging
     */
    fun info(message: String) = output(LogLevel.INFO, message)

    /**
     * Helper method for DEBUG logging
     */
    fun debug(message: String) = output(LogLevel.DEBUG, message)


    private fun output(logLevel: LogLevel, message: String) {
        if (!isEnabled) return

        println("iProov Identity ${logLevel.name}: $message")
    }
}