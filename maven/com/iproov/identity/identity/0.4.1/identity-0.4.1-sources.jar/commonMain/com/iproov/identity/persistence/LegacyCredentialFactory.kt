package com.iproov.identity.persistence

import com.iproov.identity.Logger
import com.iproov.identity.models.Claim
import com.iproov.identity.models.LegacyCredential
import com.iproov.identity.models.LegacyCredential.IdentityCredential
import com.iproov.identity.models.LegacyCredential.UriCredential


typealias LegacyCredentialBuilder = (String, List<Claim>) -> LegacyCredential


/**
 * Defines a contract for creating a specific type of Credential.
 * Implementations of this interface can be registered with the PluggableCredentialDeserializer.
 */
interface LegacyCredentialFactory {

    /**
     * The unique prefix string that this factory handles (e.g., "iddoc").
     * This prefix is typically the part of the source string before the first colon.
     * Can be used to override the deserialization of existing credentials
     */
    val prefix: String


    /**
     * Creates a Credential instance from the given source and claims.
     *
     * @param source The full source string for the credential (e.g., "fp:user-thumb").
     * @param claims The list of claims associated with this credential.
     * @return The constructed Credential object.
     */
    fun createCredential(source: String, claims: List<Claim>): LegacyCredential
}


/**
 * A deserializer for Credentials that can be extended by registering custom CredentialFactory instances.
 * This allows plugins or other modules to introduce new credential types.
 */
class LegacyCredentialDeserializer {

    // Stores custom factories registered by plugins or other parts of the application.
    private val customFactories = mutableMapOf<String, LegacyCredentialFactory>()

    companion object Companion {
        const val TAG = "PluggableCredentialDeserializer"

        // Default, built-in deserialization logic.
        val defaultDeserializer = mapOf<String, LegacyCredentialBuilder>(
            "iddoc" to { source, claims -> IdentityCredential.fromClaims(source, claims) },
            "sms" to { source, claims -> UriCredential.PhoneNumber(source, claims) },
            "mailto" to { source, claims -> UriCredential.EmailAddress(source, claims) },
        )
    }

    /**
     * Registers a custom CredentialFactory.
     * If a factory for the same prefix already exists (either custom or default),
     * a warning is printed, and the new factory will take precedence over custom ones,
     * and custom ones take precedence over defaults.
     *
     * @param factory The CredentialFactory to register.
     */
    fun registerFactory(factory: LegacyCredentialFactory) {
        if (customFactories.containsKey(factory.prefix)) {
            Logger.info("Warning: Custom factory for prefix '${factory.prefix}' is being overridden.")
        } else if (defaultDeserializer.containsKey(factory.prefix)) {
            Logger.info("Info: Custom factory for prefix '${factory.prefix}' will shadow a default deserializer.")
        }
        customFactories[factory.prefix] = factory
    }

    /**
     * Deserializes a Credential from a source string and a list of claims.
     * It first checks registered custom factories, then default deserializers.
     * If no specific handler is found, it returns a generic Credential instance.
     *
     * @param source The source string identifying the credential type and instance.
     * @param claims The list of claims for the credential.
     * @return A specific Credential instance if a handler is found, or a generic Credential otherwise.
     */
    fun deserialize(source: String, claims: List<Claim>): LegacyCredential {
        val prefix = source.substringBefore(":")

        // 1. Try custom factories first
        customFactories[prefix]?.let { factory ->
            return factory.createCredential(source, claims)
        }

        // 2. Try default deserializers
        defaultDeserializer[prefix]?.let { deserializerFunc ->
            return deserializerFunc(source, claims)
        }

        // 3. Fallback to a generic credential
        Logger.info("Info: No specific factory found for prefix '$prefix'. Using generic Credential.")
        return LegacyCredential(source, claims)
    }
}