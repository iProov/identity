package com.iproov.identity.models

import com.iproov.identity.Logger
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.builtins.ByteArraySerializer
import kotlinx.serialization.cbor.Cbor

/**
 * CBOR encoder for COSE structures (device authentication, signatures, etc.)
 * Requires specific settings for COSE compliance.
 */
@OptIn(ExperimentalSerializationApi::class)
internal val vpCompliantCbor = Cbor {
    // COSE requires definite-length encoding
    useDefiniteLengthEncoding = true
    // ByteArray always as CBOR bstr (major type 2)
    alwaysUseByteString = true
    // Numeric labels for COSE header maps
    preferCborLabelsOverNames = true
    // Tags for #6.24 wrapped data
    encodeValueTags = true
    encodeObjectTags = true
    // Ensure default values are encoded
    encodeDefaults = true
}

/**
 * CBOR encoder matching WaltID's MdocCbor configuration for handover info hash computation.
 * Used ONLY for encoding OpenID4VPHandoverInfo to compute the hash.
 *
 * IMPORTANT: This must match the encoding the verifier expects for interoperability.
 * Definite-length encoding is required for hash consistency.
 */
@OptIn(ExperimentalSerializationApi::class)
internal val handoverInfoCbor = Cbor {
    ignoreUnknownKeys = true
    encodeDefaults = true
    alwaysUseByteString = true
    useDefiniteLengthEncoding = true
}

@OptIn(ExperimentalSerializationApi::class)
internal fun wrapAsTag24(payloadCbor: ByteArray): ByteArray {
    val bstr = vpCompliantCbor.encodeToByteArray(
        ByteArraySerializer(),
        payloadCbor
    ) // major type 2 (thanks to alwaysUseByteString)
    // Tag 24 header is d8 18.
    return byteArrayOf(0xD8.toByte(), 0x18.toByte()) + bstr
}

internal fun wrapWithTag24(cborPayload: ByteArray): ByteArray {
    val bytes = wrapAsTag24(cborPayload)
    if (bytes.size < 2 || bytes[0] != 0xD8.toByte() || bytes[1] != 0x18.toByte()) {
        Logger.debug("ERROR: wrapWithTag24 did not produce correct bytes!")
    } else {
        Logger.debug("wrapWithTag24 successful. Bytes start with d8 18.")
    }
    return bytes
}


// Extract the inner CBOR bytes from a d8 18 <bstr(... )> sequence.
// Accepts only definite-length byte strings (which is what we emit).
internal fun stripTag24(tagged: ByteArray): ByteArray {
    require(tagged.size >= 3 && tagged[0] == 0xD8.toByte() && tagged[1] == 0x18.toByte()) {
        "Input does not start with tag 24 (d8 18)"
    }
    // parse the following byte-string header (major type 2)
    val i0 = tagged[2].toInt() and 0xFF
    return when (i0) {
        in 0x40..0x57 -> { // lengths 0..23
            val len = i0 - 0x40
            require(tagged.size == 3 + len) { "Invalid bstr length for tag 24" }
            tagged.copyOfRange(3, 3 + len)
        }

        0x58 -> {
            val len = (tagged[3].toInt() and 0xFF)
            require(tagged.size == 4 + len) { "Invalid bstr length (1-byte) for tag 24" }
            tagged.copyOfRange(4, 4 + len)
        }

        0x59 -> {
            val len = ((tagged[3].toInt() and 0xFF) shl 8) or (tagged[4].toInt() and 0xFF)
            require(tagged.size == 5 + len) { "Invalid bstr length (2-byte) for tag 24" }
            tagged.copyOfRange(5, 5 + len)
        }

        0x5A -> {
            val len = ((tagged[3].toLong() and 0xFF) shl 24 or
                    (tagged[4].toLong() and 0xFF) shl 16 or
                    (tagged[5].toLong() and 0xFF) shl 8 or
                    (tagged[6].toLong() and 0xFF)).toInt()
            require(tagged.size == 7 + len) { "Invalid bstr length (4-byte) for tag 24" }
            tagged.copyOfRange(7, 7 + len)
        }

        else -> error("Unsupported tag24 bstr header: 0x${i0.toString(16)}")
    }
}