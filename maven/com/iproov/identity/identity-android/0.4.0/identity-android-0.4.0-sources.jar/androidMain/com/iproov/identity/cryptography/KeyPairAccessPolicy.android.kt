package com.iproov.identity.cryptography

import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

actual abstract class KeyPairAccessPolicy(
    val authenticationValidityDuration: Int,
    val display: AuthenticationDisplayProperties = AuthenticationDisplayProperties()
) {


    abstract val options: (KeyGenParameterSpec.Builder) -> Unit

    abstract val allowedAuthenticators: Int

    /**
     * Allow access to the private key if the device has been unlocked.
     *
     */
    class DeviceUnlocked(authenticationValidityDuration: Int = DEFAULT_AUTH_VALIDITY_DURATION_SECONDS) :
        KeyPairAccessPolicy(authenticationValidityDuration) {

        override val options: (builder: KeyGenParameterSpec.Builder) -> Unit = { builder ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Require auth on every use; allow biometrics OR device credential
                builder.setUserAuthenticationParameters(
                    authenticationValidityDuration,
                    KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL
                )
            } else {
                // Older API: cannot separate auth types; any screen lock (PIN/pattern/password/biometric)
                builder.setUserAuthenticationValidityDurationSeconds(0)
            }
        }

        override val allowedAuthenticators = BiometricManager.Authenticators.DEVICE_CREDENTIAL

        override fun toString(): String {
            return "Device Unlocked, (Validity of $authenticationValidityDuration)s"
        }
    }

    /**
     * Require any **STRONG** biometric to be presented to access the private key.
     *
     * Do not invalidate the private key if new biometrics get added.
     */
    class AnyBiometric(authenticationValidityDuration: Int = DEFAULT_AUTH_VALIDITY_DURATION_SECONDS) :
        KeyPairAccessPolicy(authenticationValidityDuration) {
        override val options: (builder: KeyGenParameterSpec.Builder) -> Unit = { builder ->
            builder.setUserAuthenticationRequired(true)

            // iOS: .biometryAny (biometrics required, but enrollment changes are allowed)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                builder.setUserAuthenticationParameters(
                    authenticationValidityDuration,
                    KeyProperties.AUTH_BIOMETRIC_STRONG
                )
            } else {
                builder.setUserAuthenticationValidityDurationSeconds(authenticationValidityDuration)
            }

            // Do NOT invalidate when enrollment changes – equivalent to BiometryAny
            builder.setInvalidatedByBiometricEnrollment(false)
        }

        override val allowedAuthenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG

        override fun toString(): String {
            return "Any Biometrics, (Validity of $authenticationValidityDuration)s"
        }
    }

    class CurrentBiometrics(authenticationValidityDuration: Int = DEFAULT_AUTH_VALIDITY_DURATION_SECONDS) :
        KeyPairAccessPolicy(authenticationValidityDuration) {

        override val options: (builder: KeyGenParameterSpec.Builder) -> Unit = { builder ->
            // iOS: .biometryCurrentSet (biometrics only, invalidate on enrollment change)
            builder.setUserAuthenticationRequired(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Biometrics only, every use
                builder.setUserAuthenticationParameters(
                    authenticationValidityDuration,
                    KeyProperties.AUTH_BIOMETRIC_STRONG
                )
            } else {
                // Older API: “some auth” required on every use
                builder.setUserAuthenticationValidityDurationSeconds(authenticationValidityDuration)
            }

            // Approximate “current set only” – key is killed when enrollment changes
            builder.setInvalidatedByBiometricEnrollment(true)
        }

        override val allowedAuthenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG

        override fun toString(): String {
            return "Current Biometrics Only, (Validity of $authenticationValidityDuration)s"
        }
    }

    actual companion object {
        actual val DeviceUnlocked: KeyPairAccessPolicy = DeviceUnlocked()
    }

    /**
     * Checks if the device is capable of authenticating with the methods required by the current [accessPolicy].
     *
     * @return [AuthenticationAvailability] indicating the status.
     */
    fun canAuthenticate(context: Context): AuthenticationAvailability {
        // 1. Handle Device Unlocked Policy (PIN/Pattern/Password or Biometrics)
        if (this is DeviceUnlocked) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // API 30+ supports checking for device credential availability via BiometricManager
                val biometricManager = context.getSystemService(BiometricManager::class.java)
                return mapBiometricStatus(biometricManager.canAuthenticate(allowedAuthenticators))
            } else {
                // On API < 30, BiometricManager doesn't support checking for DEVICE_CREDENTIAL.
                // We use KeyguardManager to check if the device is secure (has PIN/Pattern/Password).
                val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
                return if (keyguardManager.isDeviceSecure) {
                    AuthenticationAvailability.Available
                } else {
                    AuthenticationAvailability.DeviceNotSecure
                }
            }
        }

        // 2. Handle Strict Biometric Policies
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val biometricManager = context.getSystemService(BiometricManager::class.java)
            val status = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                biometricManager.canAuthenticate(allowedAuthenticators)
            } else {
                biometricManager.canAuthenticate()
            }
            return mapBiometricStatus(status)
        }

        // 3. Fallback for very old APIs or unsupported states
        return AuthenticationAvailability.BiometricsNotSupported
    }

    private fun mapBiometricStatus(status: Int): AuthenticationAvailability {
        return when (status) {
            BiometricManager.BIOMETRIC_SUCCESS -> AuthenticationAvailability.Available
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> AuthenticationAvailability.BiometricsNotEnrolled
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE,
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE,
            BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED -> AuthenticationAvailability.BiometricsNotSupported

            else -> AuthenticationAvailability.BiometricsNotSupported
        }
    }
}
