package com.iproov.identity

import platform.Foundation.NSURL

// NSURL is what Foundation's URL(string:) is built on, so this agrees with the Swift bridge's own
// guard in createConfig — verified for the malformed authorities that reach it.
internal actual fun isParsableUri(redirectUri: String): Boolean =
    NSURL.URLWithString(redirectUri) != null
