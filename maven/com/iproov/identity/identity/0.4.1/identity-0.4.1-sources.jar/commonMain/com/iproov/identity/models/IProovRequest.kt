package com.iproov.identity.models

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

sealed class VerificationException(message: String) : Exception(message)

class InvalidVerificationMethod(method: String) :
    VerificationException("Verification method: $method is not supported. Please make sure your app is up to date.")

class ExpectedVerificationConfig(method: String) :
    VerificationException("Verification method $method requires a non-null config.")

class InvalidVerificationConfig(method: String, missingKey: String) :
    VerificationException("Verification config for method $method expected $missingKey but was not present.")

sealed class VerificationMethod {
    companion object {
        fun fromJson(json: JsonObject): VerificationMethod {
            val method = json["method"]?.jsonPrimitive?.contentOrNull
            val config = json["config"]?.jsonObject
            when (method) {
                "iproov" -> {
                    if (config == null) throw ExpectedVerificationConfig("iproov")
                    return IProov.fromConfig(config)
                }

                "skip" -> {
                    if (config == null) throw ExpectedVerificationConfig("skip")
                    return Skip.fromConfig(config)
                }

                else -> throw InvalidVerificationMethod(method ?: "Not provided")
            }
        }
    }

    @Serializable
    data class Skip(val token: String) : VerificationMethod() {
        companion object {
            fun fromConfig(json: JsonObject): VerificationMethod.Skip {
                val token =
                    json["token"]?.jsonPrimitive?.contentOrNull ?: throw InvalidVerificationConfig(
                        "skip",
                        "token"
                    )

                return Skip(token)
            }
        }
    }

    @Serializable
    data class IProov(val token: String, val url: String) : VerificationMethod() {
        companion object {
            fun fromConfig(json: JsonObject): IProov {
                val token =
                    json["token"]?.jsonPrimitive?.contentOrNull ?: throw InvalidVerificationConfig(
                        "iproov",
                        "token"
                    )

                val url = json["service_location"]?.jsonPrimitive?.contentOrNull
                    ?: throw InvalidVerificationConfig(
                        "iproov",
                        "service_location"
                    )

                return IProov(token, url)
            }
        }
    }
}

