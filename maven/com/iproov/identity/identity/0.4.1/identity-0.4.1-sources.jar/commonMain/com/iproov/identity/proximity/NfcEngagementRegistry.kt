package com.iproov.identity.proximity

/**
 * Single-slot, process-wide registry bridging the wallet session (commonMain) and the
 * platform HCE service (androidMain). At most one active engagement at a time.
 */
internal expect object NfcEngagementRegistry {

    /** Publish the active engagement handle. Throws if an unsettled one is already primed. */
    suspend fun publish(handle: NfcEngagementHandler)

    /** Read the currently-registered handle, if any. */
    suspend fun current(): NfcEngagementHandler?
}