package com.iproov.identity.proximity

import com.iproov.identity.Logger
import kotlinx.io.bytestring.ByteString
import org.multipaz.cbor.DataItem
import org.multipaz.cose.Cose
import org.multipaz.cose.CoseSign1
import org.multipaz.cose.toCoseLabel
import org.multipaz.crypto.X509Cert
import org.multipaz.crypto.X509CertChain
import org.multipaz.crypto.X509KeyUsage
import org.multipaz.mdoc.request.DeviceRequest

private const val OID_COMMON_NAME = "2.5.4.3"
private const val OID_COUNTRY_NAME = "2.5.4.6"
private const val OID_STATE_OR_PROVINCE = "2.5.4.8"

// ISO/IEC 18013-5 §B.1.7 / Annex B id-mdl-kp-mdlReaderAuth.
// id-mdl(1.0.18013.5) → id-mdl-kp(.1) → mdlReaderAuth(.6)
private const val OID_ID_READER_AUTH = "1.0.18013.5.1.6"

/**
 * Verifies mdoc reader authentication per ISO/IEC 18013-5 §9.1.4 and applies
 * the configured [ReaderTrustPolicy].
 *
 * Verification pipeline per docRequest:
 *  1. ReaderAuth presence check (§9.1.4 — optional in CDDL, presence drives policy)
 *  2. COSE_Sign1 signature verification over ReaderAuthenticationBytes (§9.1.4.4)
 *  3. RFC 5280 §6.1 chain validation via [CertTrust]
 *  4. Trusted reader-CA resolution against [trustedRoots] (§B.1.1, §9.3.3)
 *  5. Leaf cert id-mdl-kp-mdlReaderAuth EKU check (§B.1.7 / Table B.6)
 *
 * Aggregation (Q1): per-docRequest results are combined "all-or-nothing" — any
 * present readerAuth that fails to verify or trust fails the whole DeviceRequest.
 * The spec is silent on multi-docRequest semantics; this is the safest reading.
 *
 * Empty trust list under [ReaderTrustPolicy.EnforceIfPresent] (Q2): a signed
 * reader with no configured roots cannot establish trust → rejected. §B.1.1
 * delegates trust-anchor curation to the consumer; the SDK refuses to silently
 * fall back to signature-only validation.
 */
internal object ReaderAuthVerifier {

    /**
     * Aggregated outcome of verification + policy evaluation.
     *
     * - [Accepted]: policy allows the request to reach the consumer's consent UI.
     *   Carries the [ReaderAuth] so the UI can surface "verified reader: <CN>".
     * - [Rejected]: policy refuses the request; the session should terminate
     *   without emitting [ProximityPresentationEvent.RequestReceived].
     */
    sealed class VerificationOutcome {
        data class Accepted(val result: ReaderAuth) : VerificationOutcome()
        data class Rejected(
            val result: ReaderAuth,
            val reason: String,
        ) : VerificationOutcome()
    }

    suspend fun verify(
        deviceRequest: DeviceRequest,
        sessionTranscript: DataItem,
        trustedRoots: List<ByteArray>,
        policy: ReaderTrustPolicy,
    ): VerificationOutcome {

        // Did the reader provide a valid signature
        // True - if there is a signature & its valid OR if there is NO signature at all / anonymous request
        // False - if there is a signature & its invalid.
        val isReaderSignatureValid = runCatching {
            deviceRequest.verifyReaderAuthentication(sessionTranscript)
        }.isSuccess

        val aggregated = if (!isReaderSignatureValid) {
            ReaderAuth.SignatureInvalid
        } else {
            val readerAuthsForDocumentsRequested =
                deviceRequest.docRequests.map { requestedDocument ->
                    val readerAuth = runCatching { requestedDocument.readerAuth }.getOrNull()

                    when {
                        // If there is no signature for this document -> Absent
                        readerAuth == null -> ReaderAuth.Absent

                        // There is a signature for this document, evaluate its trust status relative to the trust source
                        else -> evaluateReaderTrust(
                            readerAuth,
                            requestedDocument.docType,
                            trustedRoots
                        )
                    }
                }
            readerAuthsForDocumentsRequested.aggregate()
        }

        return applyPolicy(aggregated, policy)
    }

    // wraps the existing evaluateChainTrust; replaces inline lines 74-95
    private suspend fun evaluateReaderTrust(
        readerAuth: CoseSign1, docType: String, trustedRoots: List<ByteArray>
    ): ReaderAuth /* per-doc state */ {

        return runCatching {
            val chain = readerCertChain(readerAuth)
            evaluateChainTrust(chain, trustedRoots, "DocRequest[${docType}]")
        }.fold(
            onSuccess = { commonName -> ReaderAuth.Trusted(commonName) },
            onFailure = {
                Logger.info("Reader chain trust failed for ${docType}: ${it.message}"); ReaderAuth.Untrusted(
                null
            )
            },
        )
    }

    private fun readerCertChain(cose: CoseSign1): X509CertChain {
        val label = Cose.COSE_LABEL_X5CHAIN.toCoseLabel
        val dataItem =
            cose.protectedHeaders[label] ?: cose.unprotectedHeaders[label] ?: throw Exception(
                "Expected a certificate chain in document request from reader but was not present"
            )

        return dataItem.asX509CertChain
    }

    /**
     * Evaluate the aggregated [ReaderAuth] state against [policy].
     *
     * The four [ReaderAuth] states replace the old (isPresent, isVerified, isTrusted)
     * boolean triple, so illegal combinations are now unrepresentable:
     *  - [ReaderAuth.Absent]           no ReaderAuth in the request (optional per §9.1.4 CDDL)
     *  - [ReaderAuth.SignatureInvalid] ReaderAuth present but its COSE_Sign1 signature failed (§9.1.4.4)
     *  - [ReaderAuth.Untrusted]        signature valid, but the x5chain did not resolve to a trusted
     *                                  reader-CA root (§B.1.1 / §9.3.3 / EKU §B.1.7)
     *  - [ReaderAuth.Trusted]          signature valid AND chain trusted (carries the leaf commonName)
     *
     * Policy table (cross-ref §9.1.4 + Q2 strictness decision):
     *
     * | Policy           | Absent | SignatureInvalid | Untrusted | Trusted |
     * | ---------------- | ------ | ---------------- | --------- | ------- |
     * | DoNotEnforce     | accept | accept           | accept    | accept  |
     * | EnforceIfPresent | accept | reject           | reject    | accept  |
     * | AlwaysRequire    | reject | reject           | reject    | accept  |
     *
     * EnforceIfPresent accepts [Absent] (unsigned/anonymous readers are allowed) but rejects every
     * present-but-not-fully-trusted state. AlwaysRequire additionally rejects [Absent]. Only [Trusted]
     * is accepted under both enforcing policies — chain validity alone is never sufficient.
     */

    private fun applyPolicy(result: ReaderAuth, policy: ReaderTrustPolicy): VerificationOutcome =
        when (policy) {
            ReaderTrustPolicy.DoNotEnforce -> VerificationOutcome.Accepted(result)

            ReaderTrustPolicy.EnforceIfPresent ->
                if (result == ReaderAuth.Absent) VerificationOutcome.Accepted(result)
                else if (result is ReaderAuth.Trusted) VerificationOutcome.Accepted(result)
                else VerificationOutcome.Rejected(result, reasonFor(result))

            ReaderTrustPolicy.AlwaysRequire ->
                if (result is ReaderAuth.Trusted) VerificationOutcome.Accepted(result)
                else VerificationOutcome.Rejected(result, reasonFor(result))
        }

    private fun reasonFor(result: ReaderAuth): String = when (result) {
        ReaderAuth.Absent -> "Reader authentication required but no ReaderAuth in request"
        ReaderAuth.SignatureInvalid -> "Reader authentication signature verification failed"
        is ReaderAuth.Untrusted -> "Reader certificate chain is not trusted"
        else -> "Reader authentication rejected"
    }

    /**
     * Trust evaluation for a single reader cert chain — RFC 5280 §6.1 +
     * §18013-5 §B.1.1 trust anchor + §B.1.7 EKU + §9.3.3 country/state match.
     *
     * Returns the leaf's commonName on success; throws with a context-prefixed
     * message on failure. Intended to be wrapped in `runCatching` by the caller
     * so per-docRequest failures degrade gracefully into the aggregation.
     */
    internal suspend fun evaluateChainTrust(
        chain: X509CertChain, trustedRoots: List<ByteArray>, contextLabel: String,
    ): String {
        val certs = chain.certificates
        val leaf =
            certs.firstOrNull() ?: throw Exception("$contextLabel: no reader certificate present")
        val context = "$contextLabel: reader"

        // RFC 5280 §6.1 — shared with issuer-trust path
        CertTrust.verifyCertValidityPeriods(certs, context)
        CertTrust.verifyCaConstraints(certs, context)
        CertTrust.verifyChainSignatures(certs, context)

        // §B.1.1 — resolve to a trusted reader-CA root
        val rootMatch = resolveTrustedReaderRoot(certs, trustedRoots, context)

        // §9.3.3 — country / state match between trust anchor and leaf
        verifyReaderCountryStateMatch(rootMatch, leaf, context)

        // §B.1.7 Table B.6 — leaf must carry id-mdl-kp-mdlReaderAuth EKU
        CertTrust.requireExtendedKeyUsage(leaf, OID_ID_READER_AUTH, context)
        CertTrust.requireKeyUsage(leaf, X509KeyUsage.DIGITAL_SIGNATURE, context)
        
        // This is common name
        return leaf.subject.components[OID_COMMON_NAME]?.value
            ?: throw Exception("commonName must be present in all certificates")
    }

    private suspend fun resolveTrustedReaderRoot(
        chain: List<X509Cert>, trustedRoots: List<ByteArray>, context: String
    ): X509Cert {
        if (trustedRoots.isEmpty()) {
            throw Exception(
                "$context: no trusted reader-CA certificates configured " +
                        "(ProximityConfig.trustedReaderCertificates is empty)"
            )
        }
        val candidates = trustedRoots.map { X509Cert(ByteString(it)) }
        val topOfChain = chain.last()
        return candidates.find { trusted ->
            try {
                topOfChain.verify(trusted.ecPublicKey)
                true
            } catch (_: Exception) {
                false
            }
        } ?: throw Exception(
            "$context: certificate chain is not trusted — " +
                    "no matching reader-CA root found"
        )
    }

    private fun verifyReaderCountryStateMatch(root: X509Cert, leaf: X509Cert, context: String) {
        val rootCountry = root.subject.components[OID_COUNTRY_NAME]?.value
        val leafCountry = leaf.subject.components[OID_COUNTRY_NAME]?.value
        if (rootCountry != null && leafCountry != null && rootCountry != leafCountry) {
            throw Exception(
                "$context: countryName mismatch — reader CA '$rootCountry' vs reader cert '$leafCountry'"
            )
        }

        val rootState = root.subject.components[OID_STATE_OR_PROVINCE]?.value
        val leafState = leaf.subject.components[OID_STATE_OR_PROVINCE]?.value
        if (rootState != null && leafState != null && rootState != leafState) {
            throw Exception(
                "$context: stateOrProvinceName mismatch — reader CA '$rootState' vs reader cert '$leafState'"
            )
        }
    }
}
