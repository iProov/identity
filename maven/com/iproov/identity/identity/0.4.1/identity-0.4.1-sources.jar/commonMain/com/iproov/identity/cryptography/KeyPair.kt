package com.iproov.identity.cryptography

import at.asitplus.signum.indispensable.asn1.Asn1Element
import at.asitplus.signum.indispensable.asn1.encoding.parseFirst
import com.iproov.identity.Logger
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient

enum class AuthenticationAvailability {
    Available,
    DeviceNotSecure,
    BiometricsNotEnrolled,
    BiometricsNotSupported
}

const val DEFAULT_AUTH_VALIDITY_DURATION_SECONDS = 1 * 60 // 1 Minutes

data class AuthenticationDisplayProperties(
    val title: String = "Authentication Required",
    val subtitle: String? = "Please authenticate to access your storage",
    val description: String? = null,
    val negativeButtonText: String? = null,
    val confirmationRequired: Boolean = false,
)

expect abstract class KeyPairAccessPolicy {
    companion object {
        val DeviceUnlocked: KeyPairAccessPolicy
    }
}

@Serializable
data class OnDeviceKeyPairJwk(
    val crv: String,
    val kty: String,
    val x: String,
    val y: String,
    @Transient
    val keyId: String? = null
)

@Serializable
data class EllipticCurvePublicKey(
    val alg: String,
    val jwk: OnDeviceKeyPairJwk,
)

open class KeyPairException(message: String) : Exception(message)

class KeyPairAuthenticationError(message: String) : Exception(message)

class KeyPairAuthenticationCanceled : Exception("User canceled the authentication")

interface KeyPair {
    fun getJwk(): EllipticCurvePublicKey
    fun getPublicKey(): ByteArray
    fun getKeySecurityLevel(): String
    fun sign(data: ByteArray): ByteArray

    @Throws(KeyPairException::class)
    fun reset()
}

fun KeyPair.signRs(data: ByteArray): ByteArray {
    Logger.debug("[KeyPair.signRs] Signing payload")
    val signed = sign(data)
    Logger.debug("[KeyPair.signRs] Payload signed")
    val ans1 = asn1ToRs(signed)
    Logger.debug("[KeyPair.signRs] Converted signed payload to ASN1")
    return ans1
}

fun asn1ToRs(signature: ByteArray): ByteArray {

    val parsed = Asn1Element.parseFirst(signature)
    val sequence = parsed.first.asSequence()
    val r = sequence.children[0].asPrimitive().content
    val s = sequence.children[1].asPrimitive().content

    val rBytes = padTo32Bytes(r)
    val sBytes = padTo32Bytes(s)

    return rBytes + sBytes
}

private fun padTo32Bytes(input: ByteArray): ByteArray {
    return if (input.size >= 32) {
        input.takeLast(32).toByteArray()
    } else {
        ByteArray(32 - input.size) + input
    }
}

/**
 * Function for getting the default key pair that's used for signing, this is bound to the device.
 */
expect fun getDeviceBoundKeyPair(policy: KeyPairAccessPolicy, alias: String): KeyPair