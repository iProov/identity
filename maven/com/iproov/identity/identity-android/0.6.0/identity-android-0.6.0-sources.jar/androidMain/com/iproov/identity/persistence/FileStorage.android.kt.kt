package com.iproov.identity.persistence

import android.content.Context
import android.util.Log
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.ObjectInputStream
import java.io.ObjectOutputStream

class FileStorage(private val context: Context, private val fileName: String) {

    // The file is encrypted with a Keystore key that never leaves the device, so a restored or transferred copy can
    // never be decrypted: keep it where Android neither backs up nor transfers. Older releases wrote to filesDir.
    private val legacyFile get() = File(context.filesDir, fileName)

    private val temp get() = File(file.parentFile, "${file.name}.tmp")

    private val file: File by lazy {
        val file = File(context.noBackupFilesDir, fileName)
        val legacy = legacyFile
        // A failed rename keeps using the old file rather than showing an empty wallet, unless another instance
        // moved it meanwhile: the storage engine opens a new FileStorage for every access.
        if (legacy.exists() && !file.exists() && !legacy.renameTo(file) && !file.exists()) legacy else file
    }

    fun read(): ByteArray {
        return try {
            if (file.exists()) {
                file.readBytes()
            } else {
                ByteArray(0)
            }
        } catch (e: IOException) {
            Log.e("FileStorage", "Failed to read from local storage.", e)
            throw StorageException("Failed to read from local storage: ${e.message}")
        }
    }

    /**
     * Archives the provided [HashMap] into a [ByteArray] using Java serialization.
     *
     * This method is used to serialize data before encryption or persistence.
     *
     * @param data The [HashMap] instance.
     * @return [ByteArray] containing the serialized representation of the input map.
     * @throws StorageException if serialization fails.
     */
    fun archiveDictionary(data: Map<String, String?>): ByteArray {
        return try {
            ByteArrayOutputStream().use { byteStream ->
                ObjectOutputStream(byteStream).use { objectStream ->
                    objectStream.writeObject(data)
                    byteStream.toByteArray()
                }
            }
        } catch (e: IOException) {
            Log.e("FileStorage", "Failed to archive data.", e)
            throw StorageException("Failed to archive data: ${e.message}")
        }
    }


    /**
     * Unarchives a [ByteArray] into a [HashMap] using Java deserialization.
     *
     * @param data The [ByteArray] containing the output of a corresponding [archiveDictionary] process.
     * @return The successfully deserialized [HashMap].
     * @throws StorageException If deserialization fails due to decoding errors or other issues.
     */
    @Suppress("UNCHECKED_CAST")
    fun unarchiveData(data: ByteArray): HashMap<String, String?> {
        return try {
            ByteArrayInputStream(data).use { byteStream ->
                ObjectInputStream(byteStream).use { objectStream ->
                    objectStream.readObject() as? HashMap<String, String?>
                        ?: throw StorageException("Unarchived data is not a HashMap<String, Any?>")
                }
            }
        } catch (e: IOException) {
            Log.e("FileStorage", "Failed to unarchive data.", e)
            throw StorageException("Failed to unarchive data: ${e.message}")
        } catch (e: ClassNotFoundException) {
            Log.e("FileStorage", "Failed to unarchive data (ClassNotFound).", e)
            throw StorageException("Failed to unarchive data (ClassNotFound): ${e.message}")
        }
    }

    /**
     * Writes the provided [ByteArray] to the file atomically.
     *
     * @param data The [ByteArray] to write to disk.
     * @throws StorageException if the file write fails.
     */
    fun write(data: ByteArray) {
        try {
            // Write beside the file, sync, then rename over it: rename is atomic, so a crash can't leave a partial
            // wallet. The lock stops two writes sharing the temp file, as the engine opens a FileStorage per access.
            // ponytail: the lock is per process; a host writing one wallet from two processes would need a file lock.
            synchronized(FileStorage::class.java) {
                temp.outputStream().use { it.write(data); it.fd.sync() }
                if (!temp.renameTo(file)) throw IOException("Failed to replace ${file.name}")
            }
        } catch (e: IOException) {
            Log.e("FileStorage", "Failed to write data to file.", e)
            throw StorageException("Failed to write data to file: ${e.message}")
        }
    }

    fun delete() {
        try {
            // Under the write lock, so a write in progress can't rename the wallet back into place afterwards.
            synchronized(FileStorage::class.java) {
                if (file.exists()) {
                    file.delete()
                }
                legacyFile.delete()
                temp.delete() // a write cut short by a crash leaves it, holding a copy of the wallet
            }
        } catch (e: SecurityException) {
            Log.e("FileStorage", "Failed to delete file (security).", e)
            throw StorageException("Failed to delete file (security): ${e.message}")
        }
    }

    val fileHasBeenCreated: Boolean
        get() = file.exists()

}