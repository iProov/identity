package com.iproov.identity

import com.iproov.identity.persistence.createCFDictionary
import com.iproov.identity.persistence.toCFData
import com.iproov.identity.persistence.toCFString
import kotlinx.cinterop.COpaquePointerVar
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.value
import platform.CoreFoundation.CFRelease
import platform.CoreFoundation.CFStringRef
import platform.CoreFoundation.CFTypeRef
import platform.CoreFoundation.kCFBooleanTrue
import platform.Foundation.NSBundle
import platform.Security.SecItemCopyMatching
import platform.Security.SecItemUpdate
import platform.Security.errSecSuccess
import platform.Security.kSecAttrAccessGroup
import platform.Security.kSecAttrApplicationTag
import platform.Security.kSecAttrKeyType
import platform.Security.kSecAttrKeyTypeECSECPrimeRandom
import platform.Security.kSecClass
import platform.Security.kSecClassKey
import platform.Security.kSecReturnRef

/** True when running inside an app extension rather than the containing app. */
internal val isAppExtension: Boolean
    get() = NSBundle.mainBundle.bundleURL.pathExtension == "appex"

/**
 * Process-wide because it describes the app's entitlements, not any one key — and holding it once
 * stops the signing key and the storage key ending up in different groups.
 *
 * Set by [com.iproov.identity.persistence.DeviceBoundAppleStorageEngine] before any key is used.
 * See docs/ios-keychain-sharing.md for what is shared and why.
 */
@OptIn(ExperimentalForeignApi::class)
internal object AppleKeychainSharing {
    var accessGroup: String? = null

    /** The App Group the SDK storage engine was built with; null while a custom engine is in use. */
    var appGroupIdentifier: String? = null

    /** The SDK keys a document-provider extension must reach: the device signing key and the storage key. */
    private val sharedKeyTags = listOf("com.iproov.identity", "com.iproov.identity.encryption")

    /**
     * Moves existing SDK keys into [accessGroup]. This updates the keychain item's access-group
     * attribute only — nothing is exported or copied, so it is safe for Secure Enclave keys. It never
     * creates a key and never touches keys the SDK does not own. Failures are logged; callers that
     * depend on sharing confirm it with [unsharedKeys].
     */
    fun shareExistingKeys() {
        val group = accessGroup ?: return
        if (isAppExtension) return
        for (tag in sharedKeyTags) {
            if (!keyExists(tag, group = null) || keyExists(tag, group)) continue
            // SecItemUpdate rejects return-type keys in its query with errSecParam (-50).
            val query = createCFDictionary(keyQuery(tag, group = null) - kSecReturnRef)
            val update = createCFDictionary(mutableMapOf<CFStringRef?, CFTypeRef?>(kSecAttrAccessGroup to group.toCFString()))
            try {
                val status = SecItemUpdate(query, update)
                if (status != errSecSuccess) Logger.error("Key '$tag' could not be moved into access group '$group' ($status).")
            } finally {
                CFRelease(query)
                CFRelease(update)
            }
        }
    }

    /** Existing SDK keys not verified as shared. Custom keys remain the integrator's responsibility. */
    fun unsharedKeys(containsKey: (String, String?) -> Boolean = ::keyExists): List<String> {
        val group = accessGroup
        return sharedKeyTags.filter {
            containsKey(it, null) && (group.isNullOrBlank() || !containsKey(it, group))
        }
    }

    private fun keyQuery(tag: String, group: String?): Map<CFStringRef?, CFTypeRef?> =
        mutableMapOf<CFStringRef?, CFTypeRef?>(
            kSecClass to kSecClassKey,
            kSecAttrApplicationTag to tag.encodeToByteArray().toCFData(),
            kSecAttrKeyType to kSecAttrKeyTypeECSECPrimeRandom,
            kSecReturnRef to kCFBooleanTrue,
        ).apply { group?.let { this[kSecAttrAccessGroup] = it.toCFString() } }

    private fun keyExists(tag: String, group: String?): Boolean = memScoped {
        val query = createCFDictionary(keyQuery(tag, group))
        try {
            val item = alloc<COpaquePointerVar>()
            val found = SecItemCopyMatching(query, item.ptr) == errSecSuccess
            item.value?.let { CFRelease(it) }
            found
        } finally {
            CFRelease(query)
        }
    }
}
