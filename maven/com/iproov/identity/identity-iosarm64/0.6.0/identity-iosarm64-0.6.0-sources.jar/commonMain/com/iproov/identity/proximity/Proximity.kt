package com.iproov.identity.proximity

import org.multipaz.mdoc.connectionmethod.MdocConnectionMethod
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethodBle
import org.multipaz.mdoc.transport.MdocTransportOptions
import org.multipaz.util.UUID
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import kotlin.time.DurationUnit

/**
 * Shared BLE transport options. L2CAP improves throughput for large payloads (e.g. portrait)
 * and falls back to GATT when the peer doesn't support it. Both roles MUST share these.
 */
internal val MDOC_TRANSPORT_OPTIONS = MdocTransportOptions(bleUseL2CAP = true)

data class NfcRetrievalOptions(val dialogMessage: String? = null)

sealed class PresentationMethod {
    data object QrPresentation : PresentationMethod()
    data object NfcPresentation : PresentationMethod()
}


/**
 * Settings for one proximity session (ISO 18013-5 §6): [Holder] to present a credential, [Reader] to
 * request one. Which readers a holder trusts is set once per wallet, in
 * [com.iproov.identity.TrustConfiguration.readerTrust].
 */
sealed class ProximityConfig {
    /** How long engagement may take. Swift sees a [Duration] as its raw `Int64` encoding; read [engagementTimeoutSeconds]. */
    abstract val engagementTimeout: Duration

    /** How long the session may sit idle. Swift sees a [Duration] as its raw `Int64` encoding; read [sessionInactivityTimeoutSeconds]. */
    abstract val sessionInactivityTimeout: Duration

    /** [engagementTimeout] in seconds, for Swift. */
    val engagementTimeoutSeconds: Double get() = engagementTimeout.toDouble(DurationUnit.SECONDS)

    /** [sessionInactivityTimeout] in seconds, for Swift. */
    val sessionInactivityTimeoutSeconds: Double get() = sessionInactivityTimeout.toDouble(DurationUnit.SECONDS)

    /**
     * Settings for presenting a credential. [bleRoles] is the BLE mode the holder advertises
     * (ISO 18013-5 §8.3.3.1.1): exactly one until multipaz can run both transports at once.
     */
    data class Holder @Throws(Exception::class) constructor(
        val bleRoles: Set<ProximityBLERole> = setOf(ProximityBLERole.PeripheralServer),
        override val engagementTimeout: Duration = 30.seconds,
        override val sessionInactivityTimeout: Duration = 300.seconds,
    ) : ProximityConfig() {
        constructor() : this(setOf(ProximityBLERole.PeripheralServer), 30.seconds, 300.seconds)

        /** For Swift, where a [Duration] arrives as its raw `Int64` encoding rather than seconds. */
        @Throws(Exception::class)
        constructor(
            bleRoles: Set<ProximityBLERole>,
            engagementTimeoutSeconds: Double,
            sessionInactivityTimeoutSeconds: Double,
        ) : this(bleRoles, engagementTimeoutSeconds.seconds, sessionInactivityTimeoutSeconds.seconds)

        init {
            require(bleRoles.isNotEmpty()) { "bleRoles must contain at least one role" }
            require(bleRoles.size == 1) {
                "Only one BLE role per session is currently supported (multipaz transport " +
                        "constraint). Spec-allowed dual-mode advertising will land when multipaz " +
                        "exposes dual-transport support."
            }
        }
    }

    /**
     * Settings for requesting a credential. [bleRoles] are the BLE roles the reader may take, both by
     * default, with [ReaderBLERole.Central] preferred when the holder allows both.
     */
    data class Reader @Throws(Exception::class) constructor(
        val bleRoles: Set<ReaderBLERole> = setOf(ReaderBLERole.Central, ReaderBLERole.Peripheral),
        override val engagementTimeout: Duration = 30.seconds,
        override val sessionInactivityTimeout: Duration = 300.seconds,
    ) : ProximityConfig() {
        constructor() : this(
            setOf(ReaderBLERole.Central, ReaderBLERole.Peripheral),
            30.seconds,
            300.seconds
        )

        /** For Swift, where a [Duration] arrives as its raw `Int64` encoding rather than seconds. */
        @Throws(Exception::class)
        constructor(
            bleRoles: Set<ReaderBLERole>,
            engagementTimeoutSeconds: Double,
            sessionInactivityTimeoutSeconds: Double,
        ) : this(bleRoles, engagementTimeoutSeconds.seconds, sessionInactivityTimeoutSeconds.seconds)

        init {
            require(bleRoles.isNotEmpty()) { "bleRoles must contain at least one role" }
        }

        /**
         * The BLE method to take from what the holder [offered], reduced to that one mode because multipaz
         * refuses a method carrying both, or null when none fits [bleRoles].
         */
        internal fun selectBleMethod(offered: List<MdocConnectionMethod>): MdocConnectionMethodBle? {
            val ble = offered.filterIsInstance<MdocConnectionMethodBle>()
            if (ReaderBLERole.Central in bleRoles) {
                ble.firstOrNull { it.supportsPeripheralServerMode }?.let {
                    return it.copy(supportsCentralClientMode = false, centralClientModeUuid = null)
                }
            }
            if (ReaderBLERole.Peripheral in bleRoles) {
                ble.firstOrNull { it.supportsCentralClientMode }?.let {
                    return it.copy(
                        supportsPeripheralServerMode = false,
                        peripheralServerModeUuid = null,
                        peripheralServerModePsm = null,
                        peripheralServerModeMacAddress = null,
                    )
                }
            }
            return null
        }

        /** Whether this reader may take [method]: the mode it names must be one of [bleRoles]. */
        internal fun allows(method: MdocConnectionMethodBle): Boolean =
            (method.supportsPeripheralServerMode && ReaderBLERole.Central in bleRoles) ||
                    (method.supportsCentralClientMode && ReaderBLERole.Peripheral in bleRoles)

        /** The methods to offer in an NFC negotiated handover: one per allowed role, sharing [uuid]. */
        internal fun negotiatedHandoverMethods(uuid: UUID): List<MdocConnectionMethodBle> =
            buildList {
                if (ReaderBLERole.Central in bleRoles) add(
                    MdocConnectionMethodBle(
                        true,
                        false,
                        uuid,
                        uuid
                    )
                )
                if (ReaderBLERole.Peripheral in bleRoles) add(
                    MdocConnectionMethodBle(
                        false,
                        true,
                        uuid,
                        uuid
                    )
                )
            }

        internal val noUsableBleModeMessage: String
            get() = "The holder offers no Bluetooth mode this reader may take (bleRoles=$bleRoles)"
    }
}

/**
 * How strictly the holder enforces mdoc reader authentication (ISO 18013-5 §9.1.4), set once per wallet
 * in [com.iproov.identity.TrustConfiguration.readerTrust]. A reader that signs its request chains, or
 * fails to chain, to one of [certificates], the reader CA root certificates in DER, and [ReaderAuth]
 * reports which. [EnforceIfPresent], the default, accepts an unsigned request and a chained one;
 * [AlwaysRequire] accepts only a chained one; [DoNotEnforce] accepts every reader and still reports.
 */
sealed class ReaderTrustPolicy {
    /** The reader CA root certificates, in DER, a signing reader must chain to. */
    abstract val certificates: List<ByteArray>

    /**
     * Accepts every reader. With [certificates], [ReaderAuth] still says whether a signing reader chains
     * to them, so a consent screen can show "verified" or "unknown" without blocking either.
     */
    data class DoNotEnforce(override val certificates: List<ByteArray> = emptyList()) :
        ReaderTrustPolicy() {
        constructor() : this(emptyList())
    }

    data class EnforceIfPresent(override val certificates: List<ByteArray> = emptyList()) :
        ReaderTrustPolicy() {
        constructor() : this(emptyList())
    }

    /**
     * Accepts only a reader that chains to [certificates], so it needs at least one;
     * [com.iproov.identity.TrustConfiguration] refuses an empty list.
     */
    data class AlwaysRequire(override val certificates: List<ByteArray>) : ReaderTrustPolicy()
}

/**
 * BLE mode the holder offers in its device engagement (ISO 18013-5 §8.3.3.1.1).
 * [PeripheralServer] (default): holder advertises, reader connects.
 * [CentralClient]: holder scans, reader advertises.
 */
enum class ProximityBLERole { CentralClient, PeripheralServer }

/**
 * BLE role the reader takes (ISO 18013-5 §8.3.3.1.1): [Central] connects to a holder in
 * [ProximityBLERole.PeripheralServer] mode, [Peripheral] advertises for one in [ProximityBLERole.CentralClient] mode.
 */
enum class ReaderBLERole { Central, Peripheral }

/**
 * How the wallet decides whether to trust the issuer of a credential, set for the wallet in
 * [com.iproov.identity.TrustConfiguration].
 * [TrustAll] is development-only; production should use [TrustedCertificates].
 */
sealed class IssuerTrustPolicy {
    /** Don't check who issued the credential. Development only. */
    data object TrustAll : IssuerTrustPolicy()

    /**
     * Trust a credential only when its Document Signer certificate chains to one of [certificates], the
     * issuer's IACA root certificates in DER (ISO 18013-5 §9.3.3).
     *
     * The Document Signer certificate must also carry [documentSignerKeyUsage] as an extended key usage.
     * It defaults to the mDL Document Signer OID, 1.0.18013.5.1.2 (ISO 18013-5 Table B.3). Pass another OID
     * if your credential's profile defines its own, or null if its Document Signer has none.
     */
    data class TrustedCertificates(
        val certificates: List<ByteArray>,
        val documentSignerKeyUsage: String? = MDL_DOCUMENT_SIGNER_KEY_USAGE,
    ) : IssuerTrustPolicy() {
        constructor(certificates: List<ByteArray>) : this(
            certificates,
            MDL_DOCUMENT_SIGNER_KEY_USAGE
        )
    }
}

/** The mDL Document Signer extended key usage (ISO 18013-5 Table B.3). */
internal const val MDL_DOCUMENT_SIGNER_KEY_USAGE = "1.0.18013.5.1.2"
