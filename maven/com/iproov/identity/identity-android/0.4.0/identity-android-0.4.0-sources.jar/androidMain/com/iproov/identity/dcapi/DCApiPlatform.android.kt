package com.iproov.identity.dcapi

import android.os.Build
import com.iproov.identity.AppContext

/**
 * Android implementation of DC API platform functions.
 *
 * DC API is available on Android 14+ (API 34) via CredentialManager.
 */

actual fun createPlatformDCApiRegistrar(): DCApiRegistrar? {
    return if (isDCApiPlatformAvailable()) {
        AndroidDCApiRegistrar(AppContext.get())
    } else {
        null
    }
}

actual fun isDCApiPlatformAvailable(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE // API 34 = Android 14
}
