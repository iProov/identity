package com.iproov.identity.proximity

import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.nfc.NfcManager
import com.iproov.identity.AppContext
import com.iproov.identity.Logger


/**
 * Android implementation of proximity platform availability.
 *
 * Returns true when the device can in principle present mdoc credentials over BLE per
 * ISO/IEC 18013-5:2021. Runtime concerns — Bluetooth toggled off, permissions not yet
 * granted — are NOT gated here; they surface as Failure events at session start.
 *
 * Checks (all required):
 * 1. Hardware supports BLE (PackageManager.FEATURE_BLUETOOTH_LE)
 * 2. Bluetooth adapter exists
 * 3. Radio supports BLE peripheral mode (isMultipleAdvertisementSupported) —
 *    the decisive check; many real-world Android devices have BLE central but
 *    not BLE peripheral. Known quirk: this can return false when Bluetooth is
 *    currently off, which is the accepted false-negative for static availability.
 *
 * Note: the SDK's minSdk is 26, so a `Build.VERSION.SDK_INT` check is unnecessary
 * — the OS install guarantees we're on a supported API level.
 */
actual fun isProximityPlatformAvailable(): Boolean {
    val context = try {
        AppContext.get()
    } catch (e: Exception) {
        Logger.debug("AppContext not initialized; proximity unavailable: ${e.message}")
        return false
    }

    if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
        return false
    }

    val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    val adapter = bluetoothManager?.adapter ?: return false

    return adapter.isMultipleAdvertisementSupported
}

/**
 * Android implementation of NFC engagement availability.
 *
 * Returns true when the device can in principle perform NFC static handover for
 * mdoc engagement per ISO/IEC 18013-5:2021 §8.2.2.1. As with BLE, runtime concerns
 * (NFC currently disabled in system settings, app not foregrounded) are NOT gated
 * here; they surface as Failure events when NfcEngagement.enable() is called.
 *
 * Checks (all required):
 * 1. Hardware has an NFC radio (PackageManager.FEATURE_NFC)
 * 2. Hardware supports Host Card Emulation (PackageManager.FEATURE_NFC_HOST_CARD_EMULATION) —
 *    the decisive check; many devices have NFC reader-only mode without HCE.
 * 3. NFC adapter is exposed by the OS (defaultAdapter != null)
 */
actual fun isNfcEngagementAvailable(): Boolean {
    val context = try {
        AppContext.get()
    } catch (e: Exception) {
        Logger.debug("AppContext not initialized; NFC engagement unavailable: ${e.message}")
        return false
    }

    val pm = context.packageManager
    if (!pm.hasSystemFeature(PackageManager.FEATURE_NFC)) return false
    if (!pm.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)) return false

    val nfcManager = context.getSystemService(Context.NFC_SERVICE) as? NfcManager
    return nfcManager?.defaultAdapter != null
}

/**
 * Android implementation of the platform NFC engagement factory.
 *
 * Throws for PR 1 — the real implementation lands in PR 7, which will return an
 * `AndroidNfcEngagement` backed by an HCE service declared in the SDK manifest.
 * Until then, `wallet.proximity.nfcEngagement()` on Android throws this
 * exception with a message pointing at PR 7. Consumers gate the call with
 * `isNfcAvailable()` (which currently returns true on capable Android devices
 * but will never proceed to actual NFC behaviour until the PR 7 work lands).
 */
internal actual fun createPlatformNfcEngagement(): NfcEngagement {
    throw NfcEngagementUnavailableException(
        "NFC engagement is not yet wired up on Android — pending PR 7 " +
            "(AndroidNfcEngagement + HCE service implementation)."
    )
}
