package com.iproov.identity.attestation

import com.iproov.identity.api.ApiException
import kotlin.coroutines.cancellation.CancellationException


class AttestationNotSupportedException() : Exception("This device doesn't support attestation")
class AttestationKeyGenerationException(message: String) : Exception(message)
class AttestationException(message: String) : Exception(message)

internal interface AttestationService {
    @Throws(
        ApiException::class,
        CancellationException::class,
        AttestationNotSupportedException::class,
        AttestationKeyGenerationException::class,
        AttestationException::class,
        Exception::class
    )
    suspend fun getAttestationToken(): String
}

/**
 * This implementation of the attestation service allows a non-attestable device
 * to use the DEV environment such as a simulator, emulator or CLI.
 */
class SimplePasswordAttestationService : AttestationService {

    companion object {
        const val SIMPLE_PASSWORD = "sspba:HYbv00kS4StgVZxm"
    }

    override suspend fun getAttestationToken(): String = SIMPLE_PASSWORD
}