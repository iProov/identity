package com.iproov.identity.proximity

import org.multipaz.mdoc.transport.MdocTransportOptions
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * BLE transport options shared by both proximity roles (presenter and reader). Enabling
 * L2CAP lets large responses (e.g. with a portrait) stream over an L2CAP channel instead
 * of stalling on chunked GATT notifications, and falls back to GATT automatically when the
 * peer doesn't support L2CAP. Both roles MUST use the same options or they can negotiate
 * inconsistent transports — keep this as the single source of truth.
 */
internal val MDOC_TRANSPORT_OPTIONS = MdocTransportOptions(bleUseL2CAP = true)

/*
 * Configuration types for the proximity package.
 *
 * Following the DC API convention, there is no top-level factory function —
 * `Wallet` directly constructs `DefaultProximityOrchestrator` and passes a
 * `ProximityConfig`. The types live here in their own file so consumers can
 * locate construction-time inputs without scrolling through the orchestrator.
 */

/**
 * Plain English: How the wallet is configured?
 *
 * Configuration for proximity sessions.
 *
 * Defaults match the floors set by ISO/IEC 18013-5:2021:
 * - 30s engagement timeout (§8.2.3)
 * - 300s session inactivity timeout (§9.1.1.4)
 * - Reader auth verification when a reader provides it (EnforceIfPresent)
 *
 * Note on equality: [trustedReaderCertificates] holds `ByteArray` instances, which
 * Kotlin compares by reference inside data class `equals` / `hashCode`. Two
 * [ProximityConfig] instances with structurally identical certificate bytes will
 * therefore NOT compare equal unless the byte arrays are the same instances. This
 * is rarely load-bearing — config objects are typically created once and read
 * many times rather than compared for equality.
 */
data class ProximityConfig(
    val transports: Set<ProximityTransport> = setOf(ProximityTransport.Ble),
    val readerTrust: ReaderTrustPolicy = ReaderTrustPolicy.EnforceIfPresent,
    val trustedReaderCertificates: List<ByteArray> = emptyList(),
    val issuerTrust: IssuerTrustPolicy = IssuerTrustPolicy.TrustAll,
    val engagementTimeout: Duration = 30.seconds,
    val sessionInactivityTimeout: Duration = 300.seconds,
    val bleRoles: Set<ProximityBLERole> = setOf(ProximityBLERole.PeripheralServer),
) {
    // Kotlin/Native doesn't export a no-arg init to ObjC/Swift for data classes with all-default params
    constructor() : this(
        transports = setOf(ProximityTransport.Ble),
        readerTrust = ReaderTrustPolicy.EnforceIfPresent,
        trustedReaderCertificates = emptyList(),
        issuerTrust = IssuerTrustPolicy.TrustAll,
        engagementTimeout = 30.seconds,
        sessionInactivityTimeout = 300.seconds,
    )

    init {
        require(bleRoles.isNotEmpty()) { "bleRoles must contain at least one role" }
        require(bleRoles.size == 1) {
            "Only one BLE role per session is currently supported (multipaz transport " +
                    "constraint). Spec-allowed dual-mode advertising will land when multipaz " +
                    "exposes dual-transport support."
        }
    }
}

/** Which transports the orchestrator should make available for sessions. */
enum class ProximityTransport { Ble, Nfc, Wifi } //TODO Note - added in Wifi Aware just in case - convo to have with Josh

/**
 * How strictly to enforce mdoc reader authentication (ISO/IEC 18013-5 §9.1.4).
 *
 * - [DoNotEnforce]: ignore reader auth even if present
 * - [EnforceIfPresent]: verify chain + signature when reader auth is included; allow unsigned readers
 * - [AlwaysRequire]: reject any request without a verified, trusted reader auth
 */
enum class ReaderTrustPolicy { DoNotEnforce, EnforceIfPresent, AlwaysRequire }


/**
 * BLE role the mdoc takes for a single proximity session.
 *
 * - [PeripheralServer]: wallet (mdoc) advertises; reader scans + dials in.
 *   Natural pattern after QR engagement; default.
 * - [CentralClient]: wallet scans + dials; reader advertises.
 *
 * ISO/IEC 18013-5 §8.3.3.1.1.1 allows the engagement to advertise *both* roles
 * (with the reader picking central client per the spec tiebreaker). Today the
 * SDK supports exactly one role per session — multipaz's transport factory
 * does not yet expose dual-transport advertising.
 *
 * When it does, this enum stays the same; [ProximityConfig.bleRoles] is already a `Set` so
 * multi-element values can be honoured then without an API change.
 *
 * ref (ISO 18013-5 §8.3.3.1.1)
 */
enum class ProximityBLERole { CentralClient, PeripheralServer }

/**
 * How to validate the issuer's certificate chain in a received DeviceResponse.
 *
 * - [TrustAll]: accept any issuer without IACA validation (development only)
 * - [TrustedCertificates]: validate the DS certificate chain against the provided IACA root certificates
 */
sealed class IssuerTrustPolicy {
    data object TrustAll : IssuerTrustPolicy()
    data class TrustedCertificates(val certificates: List<ByteArray>) : IssuerTrustPolicy()
}
