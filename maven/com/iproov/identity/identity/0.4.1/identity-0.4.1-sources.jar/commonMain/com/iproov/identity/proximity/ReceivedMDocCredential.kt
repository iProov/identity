package com.iproov.identity.proximity

import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

enum class DeviceAuthType { Signature, Mac }

@OptIn(ExperimentalObjCRefinement::class)
class ReceivedMDocCredential(
    val docType: String,
    val nameSpaces: Map<String, Map<String, Any?>>,
    @HiddenFromObjC val issuerCertificateChain: List<ByteArray>,
    val issuerCountry: String?,
    val validFrom: String?,
    val validUntil: String?,
    val deviceAuthType: DeviceAuthType,
    val errors: Map<String, Map<String, Int>>,
)
