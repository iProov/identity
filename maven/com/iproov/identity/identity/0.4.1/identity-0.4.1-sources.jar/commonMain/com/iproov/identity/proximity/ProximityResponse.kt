package com.iproov.identity.proximity

import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.MDocCredential


/**
 * A credential the user has chosen to disclose, optionally narrowed to a subset of
 * elements via [disclosedItems] (null = disclose everything the reader requested).
 */
data class DisclosedDocument(
    val credential: MDocCredential,
    val metadata: CredentialMetadata,
    val disclosedItems: Map<String, Set<String>>? = null,
)

/** Terminal outcome of [RespondableProximityRequest.respond]. */
sealed class ProximityResponseOutcome {

    /** DeviceResponse sent successfully; reader typically closes shortly after.
     * @property redirectUri optional URI to open after presentation (reader-driven web flows). */
    data class Sent(val redirectUri: String? = null) : ProximityResponseOutcome()

    /** Unrecoverable error while building, encrypting, or sending the response. */
    data class Failure(val cause: Throwable) : ProximityResponseOutcome()
}
