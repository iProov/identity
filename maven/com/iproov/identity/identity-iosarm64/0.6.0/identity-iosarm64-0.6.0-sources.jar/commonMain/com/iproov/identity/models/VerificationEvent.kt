package com.iproov.identity.models

import com.iproov.kmp.api.IproovState
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlinx.serialization.json.Json

@Serializable
sealed class VerificationEvent(val isFinal: Boolean) {

    @Serializable
    @SerialName("started")
    data object Started : VerificationEvent(false)

    @Serializable
    @SerialName("loading")
    data object Loading : VerificationEvent(false)

    @Serializable
    @SerialName("completed")
    data class Completed(
        @Transient val offer: RespondableCredentialOffer? = null // For now this is nullable as verifyFace doesn't support this only verify/docdb
    ) : VerificationEvent(true)


    @Serializable
    @SerialName("error")
    data class Error(val message: String) : VerificationEvent(true) {
        /**
         * The iProov face-capture feedback codes behind a failed capture, e.g. `ambiguous_outcome`; empty otherwise.
         * Not part of `equals`, `hashCode` or `copy`, which keeps the constructor and `copy` signatures unchanged.
         */
        var feedbackCodes: List<String> = emptyList()
            internal set

        override fun toString() = "Error(message=$message, feedbackCodes=$feedbackCodes)"
    }

    @Serializable
    @SerialName("cancelled")
    data object Canceled : VerificationEvent(true)

    @Throws(Exception::class)
    fun toJsonString() = Json.encodeToString(this)
}

internal fun IproovState.Failure.toVerificationEvent() =
    VerificationEvent.Error(failureResult.reasons.joinToString(separator = " ") { it.description })
        .apply { feedbackCodes = failureResult.reasons.map { it.feedbackCode } }

internal fun IproovState.Error.toVerificationEvent() = VerificationEvent.Error(exception.message ?: exception.title)
