package com.iproov.identity.models

import com.iproov.identity.models.VerificationEvent
import com.iproov.identity.WalletFactory
import com.iproov.identity.api.DocumentChallenge
import com.iproov.kmp.api.IproovOptions
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

enum class AssuranceType(private val displayName: String, val shortName: String) {
    EXPRESS(
        "Express",
        "LA"
    ), // TOOD: Update shortcode to reflect the backend when changed from old codes to new
    DYNAMIC("Dynamic", "GPA");

    companion object {
        fun fromString(value: String): AssuranceType {
            return when (value.uppercase()) {
                "LA" -> EXPRESS
                "GPA" -> DYNAMIC
                else -> throw IllegalArgumentException("Invalid assurance type: $value")
            }
        }
    }
}

sealed class ReverificationRequest {
    abstract val displayName: String

    companion object {
        @OptIn(DelicateCoroutinesApi::class)
        @Throws(IllegalArgumentException::class)
        fun forAcr(string: String, loginRequest: LoginRequest): ReverificationRequest {
            return when {
                string == "document_present" -> DocumentReverificationRequest @Throws(Exception::class) { document ->
                    GlobalScope.async {
                        return@async WalletFactory.instance!!.addDocumentWithMrz(
                            document.mrz.value as String,
                            loginRequest = loginRequest
                        )
                    }

                }

                string.startsWith("face_present") -> {
                    val components = string.split(":") // Example face_present:iproov:la
                    if (components.size != 3) {
                        throw IllegalArgumentException("Invalid face_present format: $string")
                    }
                    val assuranceType = AssuranceType.fromString(components.last())
                    FaceReverificationRequest(
                        verify = @Throws(Exception::class) { document, options ->
                            document.verifyFace(loginRequest = loginRequest, options = options)
                        },
                        assuranceType = assuranceType
                    )
                }

                else -> throw IllegalArgumentException("Invalid reverification request: $string")
            }
        }
    }
}

class DocumentReverificationRequest(
    private val onGetChallenge: (LegacyCredential.IdentityCredential.Mrtd) -> Deferred<DocumentChallenge>
) : ReverificationRequest() {
    override val displayName: String = "Document present"

    @Throws(Exception::class)
    suspend fun getChallenge(mrtd: LegacyCredential.IdentityCredential.Mrtd): DocumentChallenge =
        onGetChallenge(mrtd).await()
}

@OptIn(ExperimentalObjCRefinement::class)
class FaceReverificationRequest(
    @HiddenFromObjC val verify: (LegacyCredential.IdentityCredential.Mrtd, IproovOptions?) -> Flow<VerificationEvent>,
    val assuranceType: AssuranceType
) : ReverificationRequest() {
    override val displayName: String = "Face present (${assuranceType.shortName})"
}