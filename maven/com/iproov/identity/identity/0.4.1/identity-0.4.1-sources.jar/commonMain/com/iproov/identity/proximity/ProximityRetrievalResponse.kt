package com.iproov.identity.proximity

class ProximityRetrievalResponse(
    val documents: List<ReceivedMDocCredential>,
    val documentErrors: List<DocumentError>,
    val rawResponse: ByteArray,
)

class DocumentError(
    val docType: String,
    val errorCode: Int,
)
