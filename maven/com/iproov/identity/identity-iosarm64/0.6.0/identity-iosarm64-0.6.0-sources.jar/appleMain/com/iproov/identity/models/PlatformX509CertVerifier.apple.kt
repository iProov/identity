package com.iproov.identity.models

import com.iproov.identity.Logger
import com.iproov.identity.X509TrustBridge
import com.iproov.identity.attestation.toNSData
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

internal actual object PlatformX509CertVerifier {
    @OptIn(ExperimentalForeignApi::class)
    actual suspend fun verifyCertTrustChain(
        chain: List<ByteArray>,
        additionalAnchors: List<ByteArray>,
    ): Boolean = suspendCancellableCoroutine { continuation ->
        X509TrustBridge.verifyTrustChainWithDerChain(
            derChain = chain.map { it.toNSData() },
            additionalAnchors = additionalAnchors.map { it.toNSData() },
        ) { trusted, error ->
            if (error != null) {
                Logger.error("Chain trust evaluation: ${error.localizedDescription}")
            }
            continuation.resume(trusted)
        }
    }
}
