package com.iproov.identity.persistence

import com.iproov.identity.Logger
import com.iproov.identity.attestation.toNSData
import com.iproov.identity.cryptography.AppleKeyPair
import com.iproov.identity.cryptography.KeyPairAccessPolicy
import com.iproov.identity.cryptography.KeyPairException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.io.IOException
import kotlinx.io.files.FileNotFoundException
import platform.Foundation.NSDate
import platform.Foundation.NSDictionary
import platform.Foundation.NSNotificationCenter
import platform.Foundation.timeIntervalSinceReferenceDate
import platform.UIKit.UIApplicationDidEnterBackgroundNotification
import kotlin.concurrent.Volatile

class DeviceBoundAppleStorageEngine(
    val accessControlPolicy: KeyPairAccessPolicy = KeyPairAccessPolicy.DeviceUnlocked,
) : StorageEngine {

    // Mutex ensures thread safety for cache access and file I/O
    private val mutex = Mutex()

    // In-memory cache of the decrypted data
    private var cachedData: MutableMap<String, String?>? = null

    // Timestamp of the last successful authentication (decrypt) or write
    private var lastAuthenticatedTime: Double = 0.0

    // Flag indicating if an authentication operation is in progress
    // If authenticating, we should not clear the cache on backgrounding
    @Volatile
    private var isAuthenticating: Boolean = false

    private val fileStorage
        get() = FileStorage("com.iproov.identity")

    // Avoid holding a reference to the keypair, it can be deleted at any time
    private val keyPair: AppleKeyPair
        get() = AppleKeyPair("com.iproov.identity.encryption", accessControlPolicy)

    init {
        // SECURITY: Automatically wipe memory when App enters background
        // This ensures if the user switches apps, the data is locked immediately.
        NSNotificationCenter.defaultCenter.addObserverForName(
            name = UIApplicationDidEnterBackgroundNotification,
            `object` = null,
            queue = null
        ) { _ ->
            if (!isAuthenticating) {
                Logger.debug("App entering background: Wiping secure storage cache.")
                cachedData = null
                lastAuthenticatedTime = 0.0
            } else {
                Logger.debug("App backgrounded during auth - preserving cache.")
            }
        }
    }

    /**
     * Internal helper: Loads, Decrypts, and parses data from disk.
     * WARNING: This triggers FaceID/Biometrics if the key requires it.
     */
    @Throws(IOException::class, FileNotFoundException::class, KeyPairException::class)
    private fun loadFromDisk(): MutableMap<String, String?> {
        if (!fileStorage.fileHasBeenCreated) {
            Logger.debug("Storage file has not been created, returning empty.")
            return mutableMapOf()
        }

        Logger.debug("Loading from disk (may trigger FaceID)...")
        isAuthenticating = true
        try {
            val encryptedArchivedData = fileStorage.read()
            val archivedData = keyPair.decrypt(encryptedArchivedData.toByteArray())
            val data = fileStorage.unarchiveData(archivedData.toNSData())
            return (data as? Map<String, String?>)?.toMutableMap() ?: mutableMapOf()
        } finally {
            isAuthenticating = false
        }
    }

    /**
     * Internal helper: Encrypts and writes data to disk.
     * Usually uses Public Key, so FaceID is NOT required.
     */
    private fun saveToDisk(dictionary: Map<String, String?>) {
        val archivedData = fileStorage.archiveDictionary(dictionary as NSDictionary)
        val encryptedData = keyPair.encrypt(archivedData.toByteArray())

        fileStorage.write(encryptedData.toNSData())
        fileStorage.preventBackup()
    }

    /**
     * Checks if the current in-memory cache is valid and not expired.
     */
    private fun isSessionValid(): Boolean {
        if (cachedData == null) return false

        val currentTime = NSDate.timeIntervalSinceReferenceDate()
        val elapsed = currentTime - lastAuthenticatedTime

        return elapsed < accessControlPolicy.authenticationValidityDuration
    }

    private fun startSession(data: MutableMap<String, String?>) {
        cachedData = data
        lastAuthenticatedTime = NSDate.timeIntervalSinceReferenceDate()
    }

    override suspend fun read(key: String): String? = mutex.withLock {
        Logger.debug("Reading $key ...")

        // 1. Check Cache (Fast Path - No FaceID)
        if (isSessionValid()) {
            Logger.debug("Session valid. Returning from cache.")
            return cachedData!![key]
        }

        // 2. Load from Disk (Slow Path - Triggers FaceID)
        val data = try {
            loadFromDisk()
        } catch (e: Exception) {
            Logger.error("Failed to load secure storage: ${e.message}")
            throw e
        }

        // 3. Update Session
        startSession(data)

        return data[key].also {
            Logger.debug("Found value $it")
        }
    }

    override suspend fun write(key: String, value: String?): Unit = mutex.withLock {
        val map = if (isSessionValid()) {
            cachedData!!
        } else {
            // If session expired, we MUST load from disk to get the other keys
            // before we append the new one. Triggers FaceID.
            val loaded = loadFromDisk()
            startSession(loaded)
            loaded
        }

        if (value == null) {
            map.remove(key)
        } else {
            map[key] = value
        }

        saveToDisk(map)

        lastAuthenticatedTime = NSDate.timeIntervalSinceReferenceDate()

        Logger.debug("Wrote $key to secure storage.")
    }

    override suspend fun deleteAll(): Unit = mutex.withLock {
        cachedData = null
        if (fileStorage.fileHasBeenCreated) {
            fileStorage.delete()
        }
        Logger.debug("Deleted all secure storage data.")
    }
}

actual fun getDeviceBoundStorageEngine(accessPolicy: KeyPairAccessPolicy): StorageEngine =
    DeviceBoundAppleStorageEngine(accessPolicy)