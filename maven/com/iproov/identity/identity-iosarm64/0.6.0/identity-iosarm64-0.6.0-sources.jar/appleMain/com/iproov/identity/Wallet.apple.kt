package com.iproov.identity

import com.benasher44.uuid.uuid5Of
import com.benasher44.uuid.uuidFrom
import com.iproov.identity.OID4VCIClient as SwiftOID4VCIClient
import com.iproov.identity.api.ApiClient
import com.iproov.identity.api.ApiException
import com.iproov.identity.api.AppleIdentityPlatformInterface
import com.iproov.identity.attestation.AppleAttestationService
import com.iproov.identity.attestation.PrimedSimplePasswordAttestationService
import com.iproov.identity.dcapi.AppleDCApiRegistrar
import com.iproov.identity.dcapi.DCApiStatus
import com.iproov.identity.dcapi.mdoc.MdocDcApiException
import com.iproov.identity.dcapi.mdoc.RespondableDigitalCredentialsRequest
import com.iproov.identity.dcapi.mdoc.serializeOrigin
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.LegacyCredential
import com.iproov.identity.models.LoginRequest
import com.iproov.identity.persistence.CredentialDeserializer
import com.iproov.identity.persistence.Keychain
import com.iproov.identity.persistence.LegacyCredentialDeserializer
import com.iproov.identity.persistence.LocalStorage
import com.iproov.identity.persistence.Repository
import com.iproov.identity.persistence.StorageEngine
import com.iproov.identity.persistence.toByteArray
import com.iproov.identity.proximity.DocumentRequest
import com.iproov.identity.proximity.EngagementAcquisition
import com.iproov.identity.proximity.NfcRetrievalOptions
import com.iproov.identity.proximity.ProximityConfig
import com.iproov.identity.proximity.ProximityRetrievalEvent
import com.iproov.identity.proximity.ProximityRetrievalSession
import com.iproov.identity.proximity.ReaderSigningData
import com.iproov.kmp.api.IproovOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.runBlocking
import platform.Foundation.NSBundle
import platform.Foundation.NSData
import platform.Foundation.NSDate
import platform.Foundation.NSURL
import platform.Foundation.NSUUID.Companion.UUID
import platform.Foundation.now
import platform.Foundation.timeIntervalSince1970
import kotlin.coroutines.cancellation.CancellationException
import kotlin.experimental.ExperimentalObjCName
import kotlin.time.Duration.Companion.seconds
import kotlin.time.DurationUnit

@OptIn(kotlinx.cinterop.ExperimentalForeignApi::class)
internal actual fun getWalletInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration?,
    isLoggingEnabled: Boolean,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
    legacyCredentialDeserializer: LegacyCredentialDeserializer, // Remove when when legacy credentials have been removed
    credentialDeserializer: CredentialDeserializer,
    trustConfiguration: TrustConfiguration,
): Wallet {
    // Set before anything else so the attestation choice below is actually logged. The Swift flag also
    // gates the JWE helper used by presentation, which may run before any issuance client exists.
    Logger.isEnabled = isLoggingEnabled
    SwiftOID4VCIClient.setIsLoggingEnabled(isLoggingEnabled)
    quietMultipazUnlessLogging(isLoggingEnabled)

    val instanceId = getInstanceId()
    val platform = ApplePlatform(instanceId)

    val apiClient = ApiClient(baseUrl, signingKeyPairFactory, platform, instanceId)
    val identityPlatformInterface =
        AppleIdentityPlatformInterface(signingKeyPairFactory, platform, apiClient)

    // App Attest is unavailable on the simulator — DCDevice.isSupported() returns false there, so
    // AppleAttestationService would throw AttestationNotSupportedException and register() could
    // never complete. A simulator build therefore falls back to the simple-password service. That
    // token is only honoured by the DEV environment, so the choice is logged explicitly: against
    // PROD registration will still fail, and the reason should not be a mystery.
    val attestationService = if (platform.isVirtual) {
        Logger.info(
            "Simulator build: using SimplePasswordAttestationService instead of App Attest. " +
                    "This is only accepted by the DEV environment."
        )
        PrimedSimplePasswordAttestationService(identityPlatformInterface)
    } else {
        AppleAttestationService(identityPlatformInterface, signingKeyPairFactory)
    }

    val localStorage = LocalStorage(storageEngine)
    val repository = Repository(localStorage, legacyCredentialDeserializer, credentialDeserializer)

    // Keys created before sharing was configured stay invisible to the extension until moved.
    AppleKeychainSharing.shareExistingKeys()

    return Wallet(
        attestationService = attestationService,
        identityPlatformInterface = identityPlatformInterface,
        localStorage = localStorage,
        repository = repository,
        getKeyPair = signingKeyPairFactory,
        clientConfiguration = clientConfiguration,
        trustConfiguration = trustConfiguration,
    )
}

private fun getInstanceId(): String {
    val sdkNamespace =
        uuid5Of(uuidFrom("00000000-0000-0000-0000-000000000000"), "com.iproov.identity")
    val appId = NSBundle.mainBundle.bundleIdentifier!!
    val deviceId = getDeviceId()

    val appNamespace = uuid5Of(sdkNamespace, appId)
    return uuid5Of(appNamespace, deviceId).toString()
}

private fun getDeviceId(): String {
    val keychain = Keychain("com.iproov.identity")
    keychain.get("deviceID")?.let { deviceID ->
        // Moves an id saved by an earlier release to ThisDeviceOnly; the id itself is unchanged.
        if (!isAppExtension) runCatching { keychain.set("deviceID", deviceID) }
            .onFailure { Logger.error("Device ID not moved to ThisDeviceOnly: ${it.message}") }
        return deviceID
    }

    val deviceID = UUID().UUIDString
    // An extension deliberately does not persist one. It never calls the API, so the value is
    // unused there, and writing it would leave a second deviceID in the shared group that the app
    // could then read in place of its own — silently changing the instance it reports.
    if (!isAppExtension) keychain.set("deviceID", deviceID)
    return deviceID
}

@OptIn(ExperimentalObjCName::class)
@Throws(
    WalletNotRegisteredException::class,
    RequiredClaimNotPresent::class,
    ApiException::class,
    CancellationException::class,
    Exception::class,
)
@ObjCName("addFaceVerification")
fun Wallet.addFaceVerificationToCredential(
    credential: LegacyCredential,
    loginRequest: LoginRequest? = null,
    options: IproovOptions? = null,
) = addFaceVerification(
    credential,
    loginRequest,
    options
).wrap(scope = CoroutineScope(SupervisorJob() + Dispatchers.Default))

@Throws(
    WalletNotRegisteredException::class,
    ApiException::class,
    CancellationException::class,
    Exception::class,
)
fun Wallet.addDocumentWithReference(
    reference: String,
    demoReferencePhoto: NSData? = null,
    loginRequest: LoginRequest? = null,
    options: IproovOptions? = null,
    addLegacyCredential: Boolean = true,
) = addDocumentWithReference(
    reference,
    demoReferencePhoto?.toByteArray(),
    loginRequest,
    options,
    addLegacyCredential
).wrap(scope = CoroutineScope(SupervisorJob() + Dispatchers.Default))

@OptIn(ExperimentalObjCName::class)
@Throws(Exception::class)
@ObjCName("isRegistered")
fun Wallet.isRegisteredBlocking(): Boolean = runBlocking(Dispatchers.Default) { isRegistered() }

@Throws(Exception::class)
suspend fun Wallet.refreshExpiredCredentials() =
    refreshExpiredCredentials(
        isExpiredFromEpochSecondsOverride = NSDate.now().timeIntervalSince1970.seconds.toLong(
            DurationUnit.SECONDS
        )
    )

@Throws(Exception::class)
fun Wallet.startProximityRetrieval(
    options: NfcRetrievalOptions = NfcRetrievalOptions(),
    requestedDocuments: List<DocumentRequest>,
    createSigningData: (suspend () -> ReaderSigningData)? = null,
    config: ProximityConfig.Reader = ProximityConfig.Reader(),
): ProximityRetrievalSession = buildRetrievalSession(
    engagementSource = {
        send(ProximityRetrievalEvent.Engagement.Nfc.RequestingTag)
        val outcome =
            EngagementAcquisition.acquireFromNfc(options.dialogMessage, config, proximityOrchestrator)
        send(ProximityRetrievalEvent.Engagement.Nfc.Completed)
        outcome
    },
    requestedDocuments, createSigningData, config,
)

@OptIn(ExperimentalObjCName::class)
@Throws(Exception::class)
@ObjCName("digitalCredentialsStatus")
suspend fun Wallet.digitalCredentialsStatus(): DCApiStatus = appleRegistrar.status()


/**
 * Registers one credential for DC API discovery, leaving existing registrations alone.
 *
 * iOS only. Android's registry is matched over an uploaded snapshot that must carry claim
 * values, and writing it replaces the registry wholesale, so a single-credential add cannot be
 * expressed there — use [Wallet.registerAllCredentialsForDCApi] on both platforms instead when
 * you need shared behaviour.
 */
@OptIn(ExperimentalObjCName::class)
@Throws(Exception::class)
@ObjCName("registerDigitalCredential")
suspend fun Wallet.registerDigitalCredential(metadata: CredentialMetadata) =
    registerSingleCredentialForDCApi(metadata)

/** The wallet's own registrar, so registrations made here show in isCredentialRegisteredForDCApi. */
private val Wallet.appleRegistrar: AppleDCApiRegistrar
    get() = platformDCApiRegistrar as? AppleDCApiRegistrar ?: AppleDCApiRegistrar()


@OptIn(ExperimentalObjCName::class)
@Throws(Exception::class)
@ObjCName("digitalCredentialsRequest")
suspend fun Wallet.digitalCredentialsRequest(
    requestJson: String,
    origin: NSURL,
): RespondableDigitalCredentialsRequest =
    RespondableDigitalCredentialsRequest(
        buildDigitalCredentialsSession(
            requestJson,
            origin.serializedOrigin(),
        )
    )

private fun NSURL.serializedOrigin(): String {
    val urlScheme = scheme
        ?: throw MdocDcApiException("Requesting origin has no scheme; aborting per §C.5")
    val urlHost = host
        ?: throw MdocDcApiException("Requesting origin has no host; aborting per §C.5")
    return serializeOrigin(urlScheme, urlHost, port?.intValue)
}