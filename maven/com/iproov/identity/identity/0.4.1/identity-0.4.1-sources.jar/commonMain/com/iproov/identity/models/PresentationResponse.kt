package com.iproov.identity.models


sealed interface PresentationOutcome {
    data class Success(val redirectUri: String? = null) : PresentationOutcome
    data class Declined(val reason: String? = null) : PresentationOutcome
    data class Rejected(val code: String, val description: String?) : PresentationOutcome

    /**
     * Response for DC API (Digital Credentials API) presentation mode.
     *
     * Unlike direct_post modes, DC API returns the credential response directly to the
     * browser/OS rather than POSTing to a response_uri.
     *
     * @param vpToken The VP Token or encrypted JWE to return to the requester
     * @param state Optional state parameter to echo back
     * @param encrypted True if vpToken is an encrypted JWE (dc_api.jwt mode)
     */
    data class DCApiResponse(
        val vpToken: String,
        val state: String? = null,
        val encrypted: Boolean = false
    ) : PresentationOutcome
}