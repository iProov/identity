// Copyright (c) 2024 iProov Ltd. All rights reserved.
package com.iproov.identity

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.startup.Initializer

internal class AppContextInitializer : Initializer<Context> {
    override fun create(context: Context): Context {
        AppContext.setUp(context.applicationContext)
        // Required for Multipaz Proximity Engagements
        org.multipaz.context.initializeApplication(context.applicationContext)
        return AppContext.get()
    }

    override fun dependencies(): List<Class<out Initializer<*>>> = emptyList()
}

/**
 * Provides access to the Application context.
 */
internal object AppContext {
    private lateinit var application: Application

    // Several Activities can be resumed at once (multi-window, API 29+); each is paused before it is destroyed.
    private val resumed = LinkedHashSet<Activity>()

    /** The foreground Activity, for prompts the SDK has to show itself, such as storage-key authentication. */
    val resumedActivity: Activity? get() = resumed.lastOrNull()

    fun setUp(context: Context) {
        application = context as Application
        application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) { resumed.remove(activity); resumed.add(activity) }
            override fun onActivityPaused(activity: Activity) { resumed.remove(activity) }
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityStarted(activity: Activity) = Unit
            override fun onActivityStopped(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
    }

    fun get(): Context {
        if (::application.isInitialized.not())
            throw Exception("Application context isn't initialized")
        return application
    }
}