package com.iproov.identity.proximity

import com.iproov.identity.Base64Utils.decodeFromBase64Url
import kotlinx.serialization.ExperimentalSerializationApi
import org.multipaz.cbor.Cbor
import org.multipaz.crypto.EcPublicKey
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethod
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethodBle
import org.multipaz.mdoc.engagement.DeviceEngagement
import org.multipaz.mdoc.engagement.buildDeviceEngagement
import org.multipaz.util.UUID

/**
 * Returned by [com.iproov.identity.Wallet.proximity]. Consumers use this to check
 * availability, start sessions, expose an NFC engagement handle, and update reader
 * trust at runtime. Always non-null; check [isAvailable] / [isBleAvailable] /
 * [isNfcAvailable] before calling transport-specific methods on devices that may
 * not support the requested transport.
 */
interface ProximityOrchestrator {

    /** True if either BLE peripheral mode or NFC HCE is supported on this device. */
    fun isAvailable(): Boolean

    /** True if the device can advertise as a BLE peripheral (ISO 18013-5 §8.3.3.1.1). */
    fun isBleAvailable(): Boolean

    /** True if the device supports NFC Host Card Emulation (ISO 18013-5 §8.2.2.1). */
    fun isNfcAvailable(): Boolean

    /**
     * Start a forward-engagement BLE session: the wallet generates an `mdoc:` URI
     * and waits for a reader to scan it and connect.
     *
     * @return a [ProximityRetrievalSession] — collect its `events` flow to drive the lifecycle
     * @throws BleEngagementUnavailableException if BLE peripheral mode isn't supported
     *   on this device. Check [isBleAvailable] before calling to avoid the throw.
     */
    //suspend fun startBleSession(): ProximityRetrievalSession

    /**
     * Start a reverse-engagement BLE session: the wallet parses a reader-generated
     * `mdoc:` URI (typically from an NFC tap or deep link) and dials in.
     *
     * @param engagementUri an `mdoc:`-scheme URI from the reader
     * @return a [ProximityRetrievalSession] — collect its `events` flow to drive the lifecycle
     * @throws BleEngagementUnavailableException if BLE peripheral mode isn't supported
     * @throws IllegalArgumentException if [engagementUri] is not a well-formed mdoc URI
     */
    //suspend fun startBleSession(engagementUri: String): ProximityRetrievalSession

    /**
     * The platform's NFC engagement handle.
     *
     * Consumers should call [NfcEngagement.enable] on `onResume` / `viewWillAppear`
     * and [NfcEngagement.disable] on the matching pause callback.
     *
     * @throws NfcEngagementUnavailableException if NFC HCE isn't supported on this
     *   device or platform. Check [isNfcAvailable] before calling to avoid the throw.
     */
    fun nfcEngagement(): NfcEngagement

    /**
     * Replace the trusted reader certificate list at runtime without recreating
     * the orchestrator. Used to push trust-store updates from a server.
     */
    suspend fun updateReaderTrust(trustedCertificates: List<ByteArray>)

    suspend fun retrieveProximityEngagement(uri: String): DeviceEngagement

    suspend fun presentProximityEngagement(
        publicKey: EcPublicKey,
        config: ProximityConfig
    ): DeviceEngagement
}

/**
 * Plain English: The handle for NFC engagement (Android-only today).
 *
 * Acquired via [ProximityOrchestrator.nfcEngagement]. The host activity must call
 * [enable] on `onResume` and [disable] on `onPause` to manage the HCE service
 * lifecycle correctly.
 */
interface NfcEngagement {

    /** True while [enable] has been called and not [disable]d. */
    val isEnabled: Boolean

    /** Activate NFC card emulation. Call from the host activity's `onResume`. */
    fun enable()

    /** Deactivate NFC card emulation. Call from the host activity's `onPause`. */
    fun disable()
}

/**
 * Plain English: The default proximity orchestrator the Wallet uses.
 *
 * Wired into [com.iproov.identity.Wallet] at construction. Availability methods
 * return real answers backed by the platform checks; session-start methods throw
 * [NotImplementedError] until their bodies land in PR 4–6.
 */
class DefaultProximityOrchestrator() : ProximityOrchestrator {

    private val MDOC_STRING_PREFIX = "mdoc"
    private val SUPPORTED_VERSION = "1.0"

    /**
     * Lazily evaluates [createPlatformNfcEngagement] so the orchestrator can be
     * constructed on platforms where NFC isn't supported without throwing. The
     * factory's exception is captured by [Lazy] and re-thrown on every access,
     * which is exactly the contract `nfcEngagement()` documents.
     */
    private val nfcLazy: Lazy<NfcEngagement> = lazy { createPlatformNfcEngagement() }

    override fun isAvailable(): Boolean = isBleAvailable() || isNfcAvailable()

    override fun isBleAvailable(): Boolean = isProximityPlatformAvailable()

    override fun isNfcAvailable(): Boolean = isNfcEngagementAvailable()

    @OptIn(ExperimentalSerializationApi::class)
    override suspend fun presentProximityEngagement(
        publicKey: EcPublicKey,
        config: ProximityConfig,
    ): DeviceEngagement {
        val connectionMethod = createMdocConnection(config)
        return buildDeviceEngagement(publicKey) {
            addConnectionMethod(connectionMethod)
        }
    }

    /**
     * The content of the QR code must be formatted as a URI with the following specifications:
     * Scheme: mdoc:
     *
     * Path: The DeviceEngagement structure, encoded using base64url-without-padding (according to RFC 4648)
     * .
     * This results in the final QR code string taking the form of mdoc:<base64url-without-padding encoded device engagement structure>
     */
    @OptIn(ExperimentalSerializationApi::class)
    override suspend fun retrieveProximityEngagement(uri: String): DeviceEngagement {
        val colonIndex = uri.indexOf(':')
        if (colonIndex < 0 || uri.substring(0, colonIndex).lowercase() != MDOC_STRING_PREFIX) {
            throw Exception("Invalid URI: expected mdoc: scheme")
        }

        val payload = uri.substring(colonIndex + 1)

        val bytes = payload.decodeFromBase64Url()
        val dataItem = Cbor.decode(bytes)

        val engagement = DeviceEngagement.fromDataItem(dataItem)

        // Right now we only support -5 (offline sharing)
        if (engagement.version != SUPPORTED_VERSION) {
            throw Exception("Only offline proximity sharing is supported.")
        }

        return engagement
    }

    override fun nfcEngagement(): NfcEngagement = nfcLazy.value

    override suspend fun updateReaderTrust(trustedCertificates: List<ByteArray>) {
        TODO("PR 8: hot-swap config.trustedReaderCertificates")
    }

    private fun createMdocConnection(config: ProximityConfig): MdocConnectionMethod {
        // Size of bleRoles is enforced to be exactly 1 by ProximityConfig.init;
        return when (config.bleRoles.single()) {
            ProximityBLERole.PeripheralServer -> {
                if (!isBleAvailable()) {
                    throw BleEngagementUnavailableException(
                        "BLE peripheral mode requested but not supported on this device"
                    )
                }
                MdocConnectionMethodBle(
                    supportsPeripheralServerMode = true,
                    supportsCentralClientMode = false,
                    peripheralServerModeUuid = UUID.randomUUID(),
                    centralClientModeUuid = null,
                )
            }

            ProximityBLERole.CentralClient -> MdocConnectionMethodBle(
                supportsPeripheralServerMode = false,
                supportsCentralClientMode = true,
                peripheralServerModeUuid = null,
                centralClientModeUuid = UUID.randomUUID(),
            )
        }
    }
}

/**
 * Plain English: BLE peripheral mode isn't supported here.
 *
 * Thrown by [ProximityOrchestrator.startBleSession] when the device cannot
 * advertise as a BLE peripheral (ISO 18013-5 §8.3.3.1.1). Consumers should
 * gate the call with [ProximityOrchestrator.isBleAvailable] to avoid this.
 */
class BleEngagementUnavailableException(message: String) : Exception(message)

/**
 * Plain English: NFC card emulation isn't supported here.
 *
 * Thrown by [ProximityOrchestrator.nfcEngagement] (via the platform factory)
 * when NFC Host Card Emulation is unavailable — currently every iOS device,
 * and any Android device without the FEATURE_NFC_HOST_CARD_EMULATION feature.
 * Consumers should gate the call with [ProximityOrchestrator.isNfcAvailable].
 */
class NfcEngagementUnavailableException(message: String) : Exception(message)

class ProximityNotSupportedException(
    message: String = "Proximity is not supported on this device (no BLE peripheral mode or NFC HCE)."
) : Exception(message)

/**
 * QR engagement URI per ISO/IEC 18013-5 §8.2.2.3.
 *
 * Format: `mdoc:` followed by the base64url-without-padding encoding of the CBOR
 * `DeviceEngagement` structure. Single colon, no `//`.
 *
 * Consumers render this as a QR code via platform extensions (`asBitmap()` on
 * Android, `asUIImage()` on iOS) or by passing [mdocUri] to any QR library.
 */
data class QrEngagementPayload(val mdocUri: String)
