package com.iproov.identity.api

import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

/**
 * Each request this will get called and the contents of this map will be added to the headers of the request
 */
actual suspend fun getPlatformHeaders(jws: String, keyId: String?): Map<String, String> = mapOf(

)

actual val httpClient: HttpClient
    get() = HttpClient(Android) {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
        installSdkLogging()
    }