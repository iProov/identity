package com.iproov.identity.models

import kotlinx.serialization.json.JsonObject


/**
 * When implementation was correct but there was a problem with the context e.g credential expired.
 */
data class OID4VCICredentialError(
    val error: String,
    val description: String,
)

/**
 * When something was meant to happen according to the standard but was not implemented that way
 */
sealed class OID4VCIException(
    val step: Step,
    val error: String,
    val description: String,
    override val cause: Throwable? = null,
    val details: Map<String, String> = mapOf()
) : Exception("$error (${description})", cause) {

    enum class Step(val displayName: String) {
        // In the parsing of the credential offer stage
        RetrievingCredentialOffer("Retrieving credential offer"),
        RetrievingIssuerMetadata("Retrieving issuer metadata"),
        ResolvingOfferedCredentials("Resolving offered credential format"),

        CreatingAccessToken("Creating access token"),
        CreatingProofOfPossession("Creating proof of possession"),
        RetrievingCredentials("Retrieving credentials using offer"),
        RetrievingBatchCredentials("Retrieving batch credentials"),
        RetrievingDeferredCredentials("Retrieving batch credentials"),
        StoringCredentials("Storing credentials"),
    }

    class NotImplemented(step: Step, what: String) : OID4VCIException(
        step,
        error = "Not implemented",
        description = "$what has not been implemented"
    )

    class DecodingCredentialOffer(
        error: String,
        description: String,
        cause: Throwable,
    ) : OID4VCIException(
        step = Step.RetrievingCredentialOffer,
        error = error,
        description = description,
        cause = cause,
    )

    class RetrievingOfferedCredentialFormats(
        error: String,
        description: String,
        cause: Throwable,
    ) : OID4VCIException(
        step = Step.ResolvingOfferedCredentials,
        error = error,
        description = description,
        cause = cause,
    )

    class RetrievingCredentialOffer(
        error: String,
        description: String,
        cause: Throwable,
    ) : OID4VCIException(
        step = Step.RetrievingCredentialOffer,
        error = error,
        description = description,
        cause = cause,
    )

    class RetrievingIssuerMetadata(
        error: String,
        description: String,
        cause: Throwable,
    ) : OID4VCIException(
        step = Step.RetrievingIssuerMetadata,
        error = error,
        description = description,
        cause = cause,
    )

    class CreatingAccessToken(
        error: String,
        description: String,
        cause: Throwable? = null,
    ) : OID4VCIException(
        step = Step.CreatingAccessToken,
        error = error,
        description = description,
        cause = cause,
    )

    class UnsupportedCredentialOffer(
        val expected: String,
        val why: String,
    ) : OID4VCIException(
        Step.RetrievingCredentialOffer,
        error = "Credential offer is not supported: $expected",
        description = why
    )

    class IncorrectIssuerMetadata(
        step: Step,
        val expected: String,
        val why: String,
        val metadata: JsonObject,
    ) : OID4VCIException(
        step,
        error = "Issuers metadata was expected to include: $expected",
        description = why
    )

    class RetrievingCredential(
        val url: String,
        error: String? = null,
        description: String,
    ) : OID4VCIException(
        step = Step.RetrievingCredentials,
        error = error ?: "Failed to fetch credentials",
        description = description,
        details = mapOf(
            "url" to url
        )
    )

    class StoringCredential(
        error: String? = null,
        description: String,
        cause: Throwable? = null,
    ) : OID4VCIException(
        step = Step.RetrievingCredentials,
        error = error ?: "Failed to fetch credentials",
        description = description,
    )
}

/**
 * The issuer requires a key-attested proof, but the configured signing key cannot provide the
 * evidence needed to construct one.
 */
class RequiredKeyAttestationUnavailableException(
    val credentialConfigurationId: String,
    message: String,
) : OID4VCIException(
    step = Step.CreatingProofOfPossession,
    error = "required_key_attestation_unavailable",
    description = message,
    details = mapOf("credential_configuration_id" to credentialConfigurationId),
)

data class IssuanceSummary(
    val credentialsAdded: List<CredentialMetadata>,
    val errors: Map<CredentialMetadata, OID4VCICredentialError>
)
