package com.iproov.identity.dcapi

import com.iproov.identity.Base64Utils.base64Decode
import com.iproov.identity.Base64Utils.base64UrlDecode
import com.iproov.identity.CLOCK_SKEW_SECONDS
import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.api.VPTokenFactory
import com.iproov.identity.cryptography.JWEFactory
import com.iproov.identity.cryptography.KeyPairAuthenticationCanceled
import com.iproov.identity.encodeToJsonObject
import com.iproov.identity.models.AuthorizationRequest
import com.iproov.identity.models.AuthorizationRequestClientMetadata
import com.iproov.identity.models.ClaimQuery
import com.iproov.identity.models.ClientIdType
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialQuery
import com.iproov.identity.models.DcqlQuery
import com.iproov.identity.models.Jwk
import com.iproov.identity.models.Jwks
import com.iproov.identity.models.Jwt
import com.iproov.identity.models.KeyUse
import com.iproov.identity.models.PresentationRequest
import com.iproov.identity.models.Query
import com.iproov.identity.models.ResponseMode
import com.iproov.identity.models.Verifier
import com.iproov.identity.models.VerifierDisplayProperties
import com.iproov.identity.models.X509CertVerifier
import com.iproov.identity.persistence.CredentialSubmission
import com.iproov.identity.persistence.DCQLMatchResult
import com.iproov.identity.persistence.DCQLMatcher
import com.iproov.identity.persistence.Repository
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlin.time.Clock
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/**
 * Orchestrator for processing Digital Credentials API requests.
 *
 * This interface handles DC API requests from OS-level credential managers (Android CredentialManager,
 * iOS IdentityDocumentServices) and coordinates credential presentation without HTTP responses.
 */
interface DCApiOrchestrator {

    /**
     * Process a DC API request and find matching credentials.
     *
     * @param requestJson The JSON request from navigator.credentials.get()
     * @param callingOrigin The origin verified by the OS credential API, obtained independently
     * of the request JSON.
     * @return Information about matching credentials and the query
     */
    @Throws(Exception::class)
    suspend fun processRequest(requestJson: String, callingOrigin: String): DCApiMatchResult

    @Throws(Exception::class)
    suspend fun processRequest(
        requestJson: String,
        callingOrigin: String,
        trustedVerifierCertificates: List<ByteArray>,
    ): DCApiMatchResult {
        if (trustedVerifierCertificates.isNotEmpty()) {
            throw UnsupportedOperationException("This DCApiOrchestrator does not accept caller-supplied trust anchors")
        }
        return processRequest(requestJson, callingOrigin)
    }

    /**
     * Build a credential response for the selected credentials.
     *
     * @param matchResult The result from processRequest containing the query context
     * @param submission The user's credential selection
     * @return The DC API response to return to the browser
     */
    @Throws(Exception::class)
    suspend fun buildResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission,
    ): DCApiResult

    /**
     * Register multiple credentials with the OS credential manager.
     * This replaces any existing registrations with the provided list.
     * On unsupported platforms, this is a no-op.
     *
     * @param credentials The list of credentials to register
     */
    @Throws(Exception::class)
    suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>)

    /** 0.5.2 behaviour: registers this one credential where the platform can (iOS); Android logs and returns. */
    @Deprecated(
        "Single registration is iOS-only; Android logs and returns",
        ReplaceWith("registerCredentials(credentials)")
    )
    @Throws(Exception::class)
    suspend fun registerCredential(metadata: CredentialMetadata)

    /**
     * Unregister a credential from the OS credential manager.
     * On unsupported platforms, this is a no-op.
     *
     * @param credentialId The ID of the credential to unregister
     */
    @Throws(Exception::class)
    suspend fun unregisterCredential(credentialId: String)

    /**
     * Check if DC API is available on this platform/OS version.
     */
    fun isAvailable(): Boolean

    /**
     * Check if a specific credential is registered with the OS credential manager.
     *
     * @param credentialId The ID of the credential to check
     * @return true if the credential is registered, false otherwise
     */
    fun isCredentialRegistered(credentialId: String): Boolean
}

/**
 * Result of processing a DC API request to find matching credentials.
 */
sealed class DCApiMatchResult {
    /**
     * Found matching credentials that can satisfy the request.
     */
    data class Success(
        val presentationRequest: PresentationRequest,
        val matchResult: DCQLMatchResult,
        val dcApiRequest: DCApiRequest,
        val browserHandoverInfo: BrowserHandoverInfo?,
    ) : DCApiMatchResult()

    /**
     * No credentials match the request.
     */
    data class NoMatch(
        val message: String,
    ) : DCApiMatchResult()

    /**
     * Request processing failed. [code] distinguishes invalid requests, cancellation,
     * and internal failures; the class name is retained for source compatibility.
     * [message] is safe to return to the requesting application.
     */
    data class InvalidRequest(
        val code: String,
        val message: String,
    ) : DCApiMatchResult()
}

internal suspend fun withDCApiMatchErrorHandling(
    process: suspend () -> DCApiMatchResult,
): DCApiMatchResult = try {
    process()
} catch (e: CancellationException) {
    throw e
} catch (e: KeyPairAuthenticationCanceled) {
    currentCoroutineContext().ensureActive()
    DCApiMatchResult.InvalidRequest(DCApiErrorCode.USER_CANCELLED, "User cancelled authentication")
} catch (e: Exception) {
    currentCoroutineContext().ensureActive()
    // Storage decoding errors may contain decrypted credential data. Keep them off both
    // the cross-process response and logs.
    Logger.error("Unable to process credential request")
    DCApiMatchResult.InvalidRequest(DCApiErrorCode.INTERNAL_ERROR, "Unable to process credential request")
}

// OID4VP A.2: the request parameters defined over the DC API. Others must be ignored, so they are
// dropped before typed decoding rather than allowed to fail it.
private val DC_API_REQUEST_PARAMETERS = setOf(
    "response_type", "response_mode", "nonce", "client_metadata", "transaction_data", "dcql_query", "verifier_info",
)

// client_id and expected_origins apply only to signed requests (A.2, A.3.2).
private val SIGNED_DC_API_REQUEST_PARAMETERS = DC_API_REQUEST_PARAMETERS + setOf("client_id", "expected_origins")

/**
 * Default implementation of DCApiOrchestrator.
 *
 * This implementation reuses existing VP Token generation logic while adapting
 * the transport layer for DC API (no HTTP POST, direct response return).
 */
class DefaultDCApiOrchestrator(
    private val repository: Repository,
    private val keyPairFactory: KeyPairFactory,
    private val jweFactory: JWEFactory,
    private val dcApiRegistrar: DCApiRegistrar? = null,
) : DCApiOrchestrator {

    /** The platform registrar, so platform-specific entry points act on the same registration state. */
    internal val registrar: DCApiRegistrar? get() = dcApiRegistrar

    private val dcqlMatcher = DCQLMatcher(repository)
    private val vpTokenFactory by lazy { VPTokenFactory(keyPairFactory) }
    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun processRequest(requestJson: String, callingOrigin: String): DCApiMatchResult =
        processRequest(requestJson, callingOrigin, emptyList())

    override suspend fun processRequest(
        requestJson: String,
        callingOrigin: String,
        trustedVerifierCertificates: List<ByteArray>,
    ): DCApiMatchResult = withDCApiMatchErrorHandling {
        processRequestInternal(requestJson, callingOrigin, trustedVerifierCertificates)
    }

    private suspend fun processRequestInternal(
        requestJson: String,
        callingOrigin: String,
        trustedVerifierCertificates: List<ByteArray>,
    ): DCApiMatchResult {
        if (callingOrigin.isBlank()) {
            return DCApiMatchResult.InvalidRequest(DCApiErrorCode.INVALID_REQUEST, "Calling origin is required")
        }
        Logger.debug("Processing DC API request: $requestJson")

        // Parse the DC API request
        val dcApiRequest = try {
            DCApiRequest.fromJson(requestJson)
        } catch (e: Exception) {
            Logger.error("Failed to parse DC API request: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid DC API request format: ${e.message}"
            )
        }

        // Find supported provider
        val provider = dcApiRequest.findSupportedProvider()
            ?: return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.UNSUPPORTED_PROTOCOL,
                message = "No supported protocol found. Supported: ${DCApiProtocol.OPENID4VP}, ${DCApiProtocol.ISO_MDOC}"
            )

        return when (provider.protocol) {
            DCApiProtocol.OPENID4VP -> processOpenID4VPRequest(
                provider,
                dcApiRequest,
                callingOrigin,
                trustedVerifierCertificates
            )

            DCApiProtocol.ISO_MDOC -> processIsoMDocRequest(provider, dcApiRequest, callingOrigin)
            else -> DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.UNSUPPORTED_PROTOCOL,
                message = "Unsupported protocol: ${provider.protocol}"
            )
        }
    }

    private suspend fun processOpenID4VPRequest(
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String,
        trustedVerifierCertificates: List<ByteArray>
    ): DCApiMatchResult {
        Logger.debug("Processing OpenID4VP DC API request (signed=${provider.isSignedRequest})")

        // Handle signed vs unsigned requests differently
        return if (provider.isSignedRequest) {
            processSignedOpenID4VPRequest(
                provider,
                dcApiRequest,
                origin,
                trustedVerifierCertificates
            )
        } else {
            processUnsignedOpenID4VPRequest(provider, dcApiRequest, origin)
        }
    }

    /**
     * Process a signed OpenID4VP DC API request (JAR format).
     * The request data contains {"request": "<JWT>"} where the JWT contains the authorization parameters.
     */
    private suspend fun processSignedOpenID4VPRequest(
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String,
        trustedVerifierCertificates: List<ByteArray>
    ): DCApiMatchResult {
        Logger.debug("Processing signed OpenID4VP DC API request")

        // Extract JWT from data.request
        val requestJwt = try {
            provider.request.jsonObject["request"]?.jsonPrimitive?.content
                ?: return DCApiMatchResult.InvalidRequest(
                    code = DCApiErrorCode.INVALID_REQUEST,
                    message = "Signed request missing 'request' field containing JWT"
                )
        } catch (e: Exception) {
            Logger.error("Failed to extract JWT from signed request: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid signed request format: ${e.message}"
            )
        }

        Logger.debug("Extracted JWT from signed request")

        val authorizationRequest = try {
            val claims = Jwt(requestJwt).body
            validateOpenID4VPParameters(claims)?.let { return it }
            requestObjectTimeError(claims)?.let {
                return DCApiMatchResult.InvalidRequest(DCApiErrorCode.INVALID_REQUEST, it)
            }
            AuthorizationRequest.fromClaims(
                JsonObject(claims.filterKeys { it in SIGNED_DC_API_REQUEST_PARAMETERS }), requestJwt
            )
        } catch (e: Exception) {
            Logger.error("Failed to parse signed authorization request JWT: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid signed authorization request: ${e.message}"
            )
        }

        Logger.debug("Decoded authorization request from JWT: clientId=${authorizationRequest.clientId}")

        // OID4VP A.2: a signed request MUST carry expected_origins and the Wallet MUST compare the
        // calling origin against it. Checked before any cryptography so a replayed request fails cheaply.
        val expectedOrigins = authorizationRequest.expectedOrigins
        if (expectedOrigins.isNullOrEmpty() || expectedOrigins.none { it.equals(origin, ignoreCase = true) }) {
            Logger.error("Origin '$origin' not present in expected_origins")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Origin is not listed in expected_origins"
            )
        }

        val jwsParts = requestJwt.split(".")
        if (jwsParts.size != 3) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid JWS format"
            )
        }

        val headerJson = try {
            Json.parseToJsonElement(jwsParts[0].base64UrlDecode().decodeToString()).jsonObject
        } catch (e: Exception) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Failed to parse JOSE Header: ${e.message}"
            )
        }

        // RFC 7515 §4.1.11: no critical extensions are implemented by this wallet.
        if ("crit" in headerJson) {
            return DCApiMatchResult.InvalidRequest(
                DCApiErrorCode.INVALID_REQUEST, "Critical JOSE extensions are not supported"
            )
        }

        val typ = (headerJson["typ"] as? JsonPrimitive)?.contentOrNull

        if (typ == null || typ != "oauth-authz-req+jwt") {
            Logger.error("Signed request missing or invalid 'typ' header: expected 'oauth-authz-req+jwt', got '$typ'")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Signed request object 'typ' header parameter MUST be 'oauth-authz-req+jwt'"
            )
        }

        val alg = (headerJson["alg"] as? JsonPrimitive)?.contentOrNull
            ?: return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Signed request 'alg' header parameter is missing or not a string"
            )

        if (alg == "none") {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Algorithm 'none' is forbidden for this process"
            )
        }

        // EC only: the signature check below uses the leaf's EC public key.
        val oidSupportedAlgs = listOf("ES256", "ES384")
        if (alg !in oidSupportedAlgs) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Unsupported algorithm '$alg'"
            )
        }

        val arrayOfX5c = headerJson["x5c"] as? JsonArray
        if (arrayOfX5c.isNullOrEmpty()) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "'x5c' header parameter is missing or not an array"
            )
        }

        val x5cDerList = try {
            arrayOfX5c.map { it.jsonPrimitive.content.base64Decode() }
        } catch (e: Exception) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid Base64 encoding in 'x5c' certificate chain: ${e.message}"
            )
        }

        //Pulls the first due to RFC 7515 guarantees this is the leafCert
        val leafCert = x5cDerList.first()

        if (!X509CertVerifier.verifyCertTrustChain(x5cDerList, trustedVerifierCertificates)) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "x5c certificate chain is not trusted"
            )
        }

        // The Client Identifier Prefix decides how client_id binds to the leaf.
        val clientId = authorizationRequest.clientId
            ?: return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Signed request is missing client_id"
            )

        val bindingError = when (ClientIdType.infer(clientId)) {
            ClientIdType.X509_SAN_DNS ->
                if (X509CertVerifier.verifySanDns(
                        leafCert,
                        clientId.removePrefix("x509_san_dns:")
                    )
                ) null
                else "client_id does not match a dNSName in the signing certificate"

            ClientIdType.X509_HASH ->
                if (X509CertVerifier.verifyCertHash(
                        leafCert,
                        clientId.removePrefix("x509_hash:")
                    )
                ) null
                else "client_id hash does not match the signing certificate"

            else ->
                "Client Identifier Prefix '${authorizationRequest.clientIdType}' cannot be " +
                        "authenticated by a request signature"
        }
        if (bindingError != null) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = bindingError
            )
        }

        if (!X509CertVerifier.verifySignature(requestJwt, leafCert)) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Request signature is invalid"
            )
        }

        //Standards Ref: The value of the response_mode parameter MUST be dc_api when the response is not encrypted
        //and dc_api.jwt when the response is encrypted.
        if (authorizationRequest.responseMode != ResponseMode.DC_API &&
            authorizationRequest.responseMode != ResponseMode.DC_API_JWT
        ) {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "response_mode must be 'dc_api' or 'dc_api.jwt' for DC API requests"
            )
        }

        return buildMatchResult(authorizationRequest, provider, dcApiRequest, origin)
    }

    /**
     * Process an unsigned OpenID4VP DC API request.
     * The request data contains the authorization parameters directly as JSON.
     */
    private suspend fun processUnsignedOpenID4VPRequest(
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String
    ): DCApiMatchResult {
        Logger.debug("Processing unsigned OpenID4VP DC API request")

        val oid4vpRequest = try {
            validateOpenID4VPParameters(provider.request.jsonObject)?.let { return it }
            OpenID4VPDCApiRequest.fromJsonElement(
                JsonObject(provider.request.jsonObject.filterKeys { it in DC_API_REQUEST_PARAMETERS })
            )
        } catch (e: Exception) {
            Logger.error("Failed to parse OpenID4VP DC API request: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid OpenID4VP request: ${e.message}"
            )
        }
        // Determine response mode
        val responseMode = when (oid4vpRequest.responseMode) {
            "dc_api" -> ResponseMode.DC_API
            "dc_api.jwt" -> ResponseMode.DC_API_JWT
            //Standards Ref: The value of the response_mode parameter MUST be dc_api when the response is not encrypted
            //and dc_api.jwt when the response is encrypted.
            else -> return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "response_mode must be 'dc_api' or 'dc_api.jwt', got '${oid4vpRequest.responseMode}'"
            )
        }

        Logger.debug("Response mode: $responseMode")
        // Build DCQL query
        val dcqlQuery = if (oid4vpRequest.dcqlQuery != null) {
            try {
                json.decodeFromJsonElement(DcqlQuery.serializer(), oid4vpRequest.dcqlQuery)
            } catch (e: Exception) {
                Logger.error("Failed to parse DCQL query: ${e.message}")
                return DCApiMatchResult.InvalidRequest(
                    code = DCApiErrorCode.INVALID_REQUEST,
                    message = "Invalid DCQL query: ${e.message}"
                )
            }
        } else {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "DCQL query is required for OpenID4VP DC API requests"
            )
        }

        Logger.debug("DCQL: $dcqlQuery")
        // Parse client metadata if present
        val clientMetadata = oid4vpRequest.clientMetadata?.let {
            try {
                json.decodeFromJsonElement(AuthorizationRequestClientMetadata.serializer(), it)
            } catch (e: Exception) {
                Logger.debug("Could not parse client metadata: ${e.message}")
                null
            }
        }

        val nonce = oid4vpRequest.nonce?.takeIf { it.isNotBlank() }
            ?: return DCApiMatchResult.InvalidRequest(DCApiErrorCode.INVALID_REQUEST, "Nonce is required")

        // Build AuthorizationRequest for reuse with existing VP Token factory
        val authorizationRequest = AuthorizationRequest(
            // OID4VP Appendix Ref(A.2): MUST ignore client_id on unsigned requests.
            // The origin is the only identity the platform vouches for.
            clientId = null,
            nonce = nonce,
            responseType = requireNotNull(oid4vpRequest.responseType),
            responseMode = responseMode,
            responseUri = null, // DC API doesn't use response_uri
            redirectUri = null,
            dcqlQuery = dcqlQuery,
            scope = null,
            state = null,
            clientMetadata = clientMetadata,
            raw = json.encodeToString(provider.request.jsonObject),
            transactionData = oid4vpRequest.transactionData,
        )

        Logger.debug("AuthorizationRequest: $authorizationRequest")

        return buildMatchResult(authorizationRequest, provider, dcApiRequest, origin)
    }

    private fun validateOpenID4VPParameters(parameters: JsonObject): DCApiMatchResult.InvalidRequest? {
        // OID4VP §8.4 rejects the parameter's presence, including empty or null values.
        if ("transaction_data" in parameters) {
            return DCApiMatchResult.InvalidRequest(
                DCApiErrorCode.INVALID_TRANSACTION_DATA, "transaction_data is not supported"
            )
        }
        for (name in listOf("response_type", "response_mode")) {
            val value = parameters[name] as? JsonPrimitive
            if (value?.isString != true) {
                return DCApiMatchResult.InvalidRequest(
                    DCApiErrorCode.INVALID_REQUEST, "$name is required and must be a string"
                )
            }
        }
        return null
    }

    /** RFC 7519 §4.1.4–4.1.5: a signed Request Object's exp and nbf bound its use when present. */
    private fun requestObjectTimeError(claims: JsonObject): String? {
        val now = Clock.System.now().epochSeconds
        for (name in listOf("exp", "nbf")) {
            val claim = claims[name] ?: continue
            val time = (claim as? JsonPrimitive)?.takeUnless { it.isString }?.doubleOrNull
                ?: return "Request Object '$name' must be a NumericDate"
            if (name == "exp" && now >= time + CLOCK_SKEW_SECONDS) return "Request Object has expired"
            if (name == "nbf" && now + CLOCK_SKEW_SECONDS < time) return "Request Object is not yet valid"
        }
        return null
    }

    /**
     * Build the match result from an authorization request.
     * Shared by both signed and unsigned request processing.
     */
    private suspend fun buildMatchResult(
        authorizationRequest: AuthorizationRequest,
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String,
    ): DCApiMatchResult {
        val dcqlQuery = authorizationRequest.dcqlQuery
            ?: return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "DCQL query is required for OpenID4VP DC API requests"
            )

        if (authorizationRequest.nonce.isBlank()) {
            return DCApiMatchResult.InvalidRequest(DCApiErrorCode.INVALID_REQUEST, "Nonce is required")
        }

        // RFC 6749 4.1.2.1 (via OID4VP 8.5): vp_token is the only response type this wallet can produce.
        if (authorizationRequest.responseType != "vp_token") {
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.UNSUPPORTED_RESPONSE_TYPE,
                message = "response_type must be 'vp_token'"
            )
        }

        val browserHandoverInfo = BrowserHandoverInfo(
            origin = origin,
            nonce = authorizationRequest.nonce,
            requesterKeyHash = null,
        )

        Logger.debug("BrowserHandoverInfo: $browserHandoverInfo")

        // Get client metadata from authorization request
        val clientMetadata = authorizationRequest.clientMetadata

        // Build presentation request
        val presentationRequest = PresentationRequest(
            raw = if (provider.request is JsonNull) JsonObject(emptyMap()) else provider.request.jsonObject,
            verifier = Verifier(
                clientId = authorizationRequest.clientId,
                display = VerifierDisplayProperties(
                    logoUri = null,
                    displayName = clientMetadata?.clientName,
                    userHint = null
                ),
                jwks = if (clientMetadata == null || clientMetadata.jwks == null) null else clientMetadata.jwks.encodeToJsonObject(),
            ),
            request = authorizationRequest,
            query = Query(
                raw = dcqlQuery.encodeToJsonObject(),
                definition = dcqlQuery
            ) { dcqlMatcher.match(dcqlQuery) }
        )

        Logger.debug("PresentationRequest: $presentationRequest")

        // Find matching credentials
        val matchResult = dcqlMatcher.match(dcqlQuery)
        if (matchResult.isEmpty || !matchResult.allRequiredSetsSatisfied) {
            return DCApiMatchResult.NoMatch(
                message = "No credentials match the requested criteria"
            )
        }

        return DCApiMatchResult.Success(
            presentationRequest = presentationRequest,
            matchResult = matchResult,
            dcApiRequest = dcApiRequest,
            browserHandoverInfo = browserHandoverInfo
        )
    }

    private suspend fun processIsoMDocRequest(
        provider: DCApiProvider,
        dcApiRequest: DCApiRequest,
        origin: String,
    ): DCApiMatchResult {

        Logger.debug("Processing ISO MDoc DC API request")

        val mdocRequest = try {
            IsoMDocDCApiRequest.fromJsonElement(provider.request)
        } catch (e: Exception) {
            Logger.error("Failed to parse ISO mDoc DC API request: ${e.message}")
            return DCApiMatchResult.InvalidRequest(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Invalid ISO mDoc request: ${e.message}"
            )
        }

        if (mdocRequest.origin != null && mdocRequest.origin != origin) {
            return DCApiMatchResult.InvalidRequest(
                DCApiErrorCode.INVALID_REQUEST, "Request origin does not match the calling origin"
            )
        }
        val nonce = mdocRequest.nonce?.takeIf { it.isNotBlank() }
            ?: return DCApiMatchResult.InvalidRequest(DCApiErrorCode.INVALID_REQUEST, "Nonce is required")

        // Build DCQL query from mDoc request.
        //
        // Every element listed in nameSpaces is requested; the Boolean against it is
        // IntentToRetain (ISO 18013-5 8.3.2.1.2.1), which says what the reader will do with
        // the value afterwards - it does NOT say whether the element was asked for. Filtering
        // on it dropped every element a reader did not intend to retain, which is the common
        // case, and produced a presentation containing nothing.
        val claims = mdocRequest.nameSpaces
            ?.flatMap { (namespace, elements) ->
                elements.map { (element, intentToRetain) ->
                    ClaimQuery(
                        id = element,
                        path = listOf(namespace, element),
                        intentToRetain = intentToRetain,
                    )
                }
            }
            // An empty request asks for no selectively disclosable claims (OID4VP 6.4.1),
            // which is expressed as absent claims rather than an empty array (OID4VP 6.1).
            ?.takeIf { it.isNotEmpty() }

        val dcqlQuery = DcqlQuery(
            credentials = listOf(
                CredentialQuery(
                    id = "mdoc_request",
                    format = "mso_mdoc",
                    meta = buildJsonObject { put("doctype_value", mdocRequest.docType) },
                    claims = claims,
                )
            )
        )

        // Build a pseudo AuthorizationRequest for compatibility
        val authorizationRequest = AuthorizationRequest(
            clientId = origin,
            nonce = nonce,
            responseType = "vp_token",
            responseMode = ResponseMode.DC_API,
            responseUri = null,
            redirectUri = null,
            dcqlQuery = dcqlQuery,
            scope = null,
            state = null,
            clientMetadata = null,
            raw = json.encodeToString(provider.request.jsonObject),
        )

        val browserHandoverInfo = BrowserHandoverInfo(origin = origin, nonce = nonce)

        val presentationRequest = PresentationRequest(
            raw = provider.request.jsonObject,
            verifier = Verifier(
                clientId = origin,
                display = VerifierDisplayProperties(null, null, null),
                jwks = null
            ),
            request = authorizationRequest,
            query = Query(
                raw = provider.request.jsonObject,
                definition = dcqlQuery
            ) { dcqlMatcher.match(dcqlQuery) }
        )

        val matchResult = dcqlMatcher.match(dcqlQuery)
        if (matchResult.isEmpty || !matchResult.allRequiredSetsSatisfied) {
            return DCApiMatchResult.NoMatch(
                message = "No mDoc credentials match docType: ${mdocRequest.docType}"
            )
        }

        return DCApiMatchResult.Success(
            presentationRequest = presentationRequest,
            matchResult = matchResult,
            dcApiRequest = dcApiRequest,
            browserHandoverInfo = browserHandoverInfo
        )
    }

    override suspend fun buildResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission,
    ): DCApiResult {
        try {
            dcqlMatcher.validateSubmission(
                submission.copy(matchResult = matchResult.matchResult),
                matchResult.presentationRequest.query.definition.credentialSets,
            )
        } catch (e: IllegalStateException) {
            return DCApiResult.Error(DCApiErrorCode.INVALID_REQUEST, "Selected credentials do not satisfy the request")
        }

        return try {
            when (val responseMode = matchResult.presentationRequest.request.responseMode) {
                ResponseMode.DC_API -> buildPlainResponse(matchResult, submission)
                ResponseMode.DC_API_JWT -> buildEncryptedResponse(matchResult, submission)
                else -> DCApiResult.Error(
                    code = DCApiErrorCode.INTERNAL_ERROR,
                    message = "Unexpected response mode for DC API: $responseMode"
                )
            }
        } catch (e: CancellationException) {
            // CancellationException is an Exception in Kotlin, so the broad catch below would
            // otherwise swallow it and report a signing failure for what is really the caller
            // going away — the Activity being destroyed on rotation, for instance.
            throw e
        } catch (e: KeyPairAuthenticationCanceled) {
            currentCoroutineContext().ensureActive()
            DCApiResult.UserDeclined
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            Logger.error("Failed to build DC API response")
            DCApiResult.Error(
                code = DCApiErrorCode.SIGNING_FAILED,
                message = "Failed to build credential response",
                cause = e
            )
        }
    }

    private suspend fun buildPlainResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission,
    ): DCApiResult {
        // Build VP Token using existing factory with DC API session transcript
        val vpToken = vpTokenFactory.buildForDCApi(
            matchResult.presentationRequest,
            submission,
            matchResult.browserHandoverInfo
        )

        val provider = matchResult.dcApiRequest.findSupportedProvider()!!
        val response = when (provider.protocol) {
            DCApiProtocol.OPENID4VP -> DCApiResponse.forOpenID4VP(
                protocol = provider.originalProtocol,
                vpToken = vpToken
            )

            DCApiProtocol.ISO_MDOC -> DCApiResponse.forIsoMDoc(
                deviceResponse = vpToken
            )

            else -> return DCApiResult.Error(
                code = DCApiErrorCode.UNSUPPORTED_PROTOCOL,
                message = "Unsupported protocol: ${provider.protocol}"
            )
        }

        return DCApiResult.Success(response)
    }

    private suspend fun buildEncryptedResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission,
    ): DCApiResult {
        // For dc_api.jwt, we need to encrypt the response
        val clientMetadata = matchResult.presentationRequest.request.clientMetadata
        val jwks = clientMetadata?.jwks
            ?: return DCApiResult.Error(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "Client JWKS required for dc_api.jwt response mode"
            )

        // Find suitable encryption key
        val encryptionKey = selectEncryptionKey(clientMetadata, jwks)
            ?: return DCApiResult.Error(
                code = DCApiErrorCode.INVALID_REQUEST,
                message = "No suitable encryption key found in client JWKS"
            )

        val (alg, enc, jwk) = encryptionKey
        val jwkThumbprint = jwk.computeThumbprint()

        // Build VP Token with JWK thumbprint for device binding
        val vpToken = vpTokenFactory.buildForDCApi(
            matchResult.presentationRequest,
            submission,
            matchResult.browserHandoverInfo,
            jwkThumbprint
        )

        // Build payload to encrypt
        val payload = buildJsonObject {
            put("vp_token", json.parseToJsonElement(vpToken))
        }

        // Encrypt the payload
        val jwe = jweFactory.create(
            payload = json.encodeToString(JsonObject.serializer(), payload).encodeToByteArray(),
            recipientPublicKey = jwk,
            alg = alg,
            encToUse = enc
        )

        val response = DCApiResponse.forOpenID4VPJWT(
            protocol = matchResult.dcApiRequest.findSupportedProvider()!!.originalProtocol,
            jwe = jwe
        )

        return DCApiResult.Success(response)
    }

    /**
     * Select an encryption key from the client's JWKS for encrypting the Authorization Response.
     *
     * Key selection follows RFC 7517 (JWK) and RFC 7516 (JWE) requirements:
     * - 'use' parameter is OPTIONAL per RFC 7517 Section 4.2; accept if absent or "enc"
     * - 'alg' is REQUIRED on encryption keys by OpenID4VP §5.1
     * - Content encryption algorithm defaults to A128GCM per OpenID4VP spec
     *
     * @return Triple of (keyManagementAlg, contentEncryptionAlg, jwk) or null if no suitable key found
     */
    private fun selectEncryptionKey(
        metadata: AuthorizationRequestClientMetadata,
        jwks: Jwks,
    ): Triple<String, String, Jwk>? {
        // Determine supported content encryption algorithms
        // Per OpenID4VP: default is A128GCM if not specified
        val supportedEncs = metadata.encryptedResponseSupportedAlgorithms
            ?.filter { jweFactory.supportedEncryptionAlgorithms.contains(it) }
            ?: listOf("A128GCM").filter { jweFactory.supportedEncryptionAlgorithms.contains(it) }

        if (supportedEncs.isEmpty()) {
            Logger.error("No supported content encryption algorithms available")
            return null
        }

        return jwks.keys.firstNotNullOfOrNull { jwk ->
            // Per RFC 7517 Section 4.2: 'use' is OPTIONAL
            // Accept if absent (key can be used for any purpose) or if explicitly 'enc'
            val useAcceptable = jwk.use == null || jwk.use == KeyUse.ENC
            if (!useAcceptable) {
                Logger.debug("JWK kid=${jwk.kid} has use=${jwk.use}, skipping (not suitable for encryption)")
                return@firstNotNullOfOrNull null
            }

            // OpenID4VP §5.1 requires alg even though the generic JWK format makes it optional.
            val keyAlg = jwk.alg
            if (keyAlg == null) {
                Logger.debug("Cannot determine key management algorithm for JWK kid=${jwk.kid}, kty=${jwk.kty}, crv=${jwk.crv}")
                return@firstNotNullOfOrNull null
            }

            if (!jweFactory.supportedKeyManagementAlgorithms.contains(keyAlg)) {
                Logger.debug("JWK kid=${jwk.kid} uses unsupported key management algorithm: $keyAlg")
                return@firstNotNullOfOrNull null
            }

            Triple(keyAlg, supportedEncs.first(), jwk)
        }
    }

    @Deprecated(
        "Single registration is iOS-only; Android logs and returns",
        ReplaceWith("registerCredentials(credentials)")
    )
    override suspend fun registerCredential(metadata: CredentialMetadata) {
        val credential = repository.getCredential(metadata).credentials[metadata]
            ?: throw IllegalArgumentException("Credential ${metadata.uuid} could not be loaded")
        dcApiRegistrar?.registerCredential(CredentialRegistrationInfo(metadata, credential))
    }

    override suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>) {
        dcApiRegistrar?.registerCredentials(credentials)
    }

    override suspend fun unregisterCredential(credentialId: String) {
        dcApiRegistrar?.unregisterCredential(credentialId)
    }

    override fun isAvailable(): Boolean {
        return dcApiRegistrar?.isAvailable() ?: false
    }

    override fun isCredentialRegistered(credentialId: String): Boolean {
        return dcApiRegistrar?.isCredentialRegistered(credentialId) ?: false
    }
}


/**
 * Data class combining credential metadata with the actual credential for DC API registration.
 */
data class CredentialRegistrationInfo(
    val metadata: CredentialMetadata,
    val credential: Credential,
)


/**
 * Platform-specific interface for registering credentials with OS credential managers.
 * Implemented separately for Android and iOS.
 */
interface DCApiRegistrar {
    /** 0.5.2 member. Registrations are synced as a set, so single adds are no longer supported. */
    @Deprecated(
        "Registrations are synced as a set",
        ReplaceWith("registerCredentials(credentials)")
    )
    suspend fun registerCredential(metadata: CredentialMetadata) {
        throw UnsupportedOperationException("Registrations are synced as a set; use registerCredentials")
    }

    /**
     * Registers one credential and leaves the others in place. Only iOS can do this; Android's
     * registry is written as a set, so its registrar logs and returns.
     */
    suspend fun registerCredential(info: CredentialRegistrationInfo) {
        @Suppress("DEPRECATION")
        registerCredential(info.metadata)
    }

    @Throws(Exception::class)
    suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>)

    /**
     * Unregister a credential from the OS credential manager.
     */
    @Throws(Exception::class)
    suspend fun unregisterCredential(credentialId: String)

    /**
     * Check if DC API registration is available on this platform.
     */
    fun isAvailable(): Boolean

    /**
     * Check if a specific credential is registered with the OS credential manager.
     */
    fun isCredentialRegistered(credentialId: String): Boolean
}
