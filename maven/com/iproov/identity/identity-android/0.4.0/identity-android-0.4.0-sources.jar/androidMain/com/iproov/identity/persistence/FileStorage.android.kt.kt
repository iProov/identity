package com.iproov.identity.persistence

import android.content.Context
import android.util.Log
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.ObjectInputStream
import java.io.ObjectOutputStream

class FileStorage(private val context: Context, private val fileName: String) {

    private val file: File
        get() = File(context.filesDir, fileName)

    fun read(): ByteArray {
        return try {
            if (file.exists()) {
                file.readBytes()
            } else {
                ByteArray(0)
            }
        } catch (e: IOException) {
            Log.e("FileStorage", "Failed to read from local storage.", e)
            throw StorageException("Failed to read from local storage: ${e.message}")
        }
    }

    /**
     * Archives the provided [HashMap] into a [ByteArray] using Java serialization.
     *
     * This method is used to serialize data before encryption or persistence.
     *
     * @param data The [HashMap] instance.
     * @return [ByteArray] containing the serialized representation of the input map.
     * @throws StorageException if serialization fails.
     */
    fun archiveDictionary(data: Map<String, String?>): ByteArray {
        return try {
            ByteArrayOutputStream().use { byteStream ->
                ObjectOutputStream(byteStream).use { objectStream ->
                    objectStream.writeObject(data)
                    byteStream.toByteArray()
                }
            }
        } catch (e: IOException) {
            Log.e("FileStorage", "Failed to archive data.", e)
            throw StorageException("Failed to archive data: ${e.message}")
        }
    }


    /**
     * Unarchives a [ByteArray] into a [HashMap] using Java deserialization.
     *
     * @param data The [ByteArray] containing the output of a corresponding [archiveDictionary] process.
     * @return The successfully deserialized [HashMap].
     * @throws StorageException If deserialization fails due to decoding errors or other issues.
     */
    @Suppress("UNCHECKED_CAST")
    fun unarchiveData(data: ByteArray): HashMap<String, String?> {
        return try {
            ByteArrayInputStream(data).use { byteStream ->
                ObjectInputStream(byteStream).use { objectStream ->
                    objectStream.readObject() as? HashMap<String, String?>
                        ?: throw StorageException("Unarchived data is not a HashMap<String, Any?>")
                }
            }
        } catch (e: IOException) {
            Log.e("FileStorage", "Failed to unarchive data.", e)
            throw StorageException("Failed to unarchive data: ${e.message}")
        } catch (e: ClassNotFoundException) {
            Log.e("FileStorage", "Failed to unarchive data (ClassNotFound).", e)
            throw StorageException("Failed to unarchive data (ClassNotFound): ${e.message}")
        }
    }

    /**
     * Writes the provided [ByteArray] to the file atomically.
     *
     * @param data The [ByteArray] to write to disk.
     * @throws StorageException if the file write fails.
     */
    fun write(data: ByteArray) {
        try {
            file.writeBytes(data)
        } catch (e: IOException) {
            Log.e("FileStorage", "Failed to write data to file.", e)
            throw StorageException("Failed to write data to file: ${e.message}")
        }
    }

    fun delete() {
        try {
            if (file.exists()) {
                file.delete()
            }
        } catch (e: SecurityException) {
            Log.e("FileStorage", "Failed to delete file (security).", e)
            throw StorageException("Failed to delete file (security): ${e.message}")
        }
    }

    val fileHasBeenCreated: Boolean
        get() = file.exists()

}