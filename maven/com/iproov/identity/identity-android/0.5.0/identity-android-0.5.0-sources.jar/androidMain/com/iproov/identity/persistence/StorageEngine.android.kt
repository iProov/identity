package com.iproov.identity.persistence

import android.app.Activity
import android.content.Context
import com.iproov.identity.AppContext
import com.iproov.identity.Logger
import com.iproov.identity.cryptography.AndroidDefaultKeyPair
import com.iproov.identity.cryptography.EncryptionKey
import com.iproov.identity.cryptography.EncryptionKeyFactory
import com.iproov.identity.cryptography.KeyPairAccessPolicy
import com.iproov.identity.cryptography.KeyPairAuthenticationCanceled
import com.iproov.identity.cryptography.KeyPairAuthenticationError
import com.iproov.identity.cryptography.SymmetricKey
import com.iproov.identity.cryptography.assertEncryptionKeyProducesCiphertext
import com.iproov.identity.cryptography.resetBestEffort
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class DeviceBoundAndroidStorageEngine(
    private val context: Context,
    private val accessPolicy: KeyPairAccessPolicy = KeyPairAccessPolicy.DeviceUnlocked,
) : StorageEngine {

    // Custom storage-encryption key; when null the SDK uses its own device-bound key.
    private var encryptionKeyFactory: EncryptionKeyFactory? = null

    /**
     * Creates storage backed by a caller-supplied encryption key.
     *
     * This is a secondary constructor so the original two-argument JVM constructor and its
     * Kotlin default-argument bridge remain available to already-compiled consumers.
     */
    constructor(
        context: Context,
        accessPolicy: KeyPairAccessPolicy,
        encryptionKeyFactory: EncryptionKeyFactory,
    ) : this(context, accessPolicy) {
        this.encryptionKeyFactory = encryptionKeyFactory
    }

    init {
        Logger.info("Access policy: ${accessPolicy}")
    }

    private val json = Json {
        ignoreUnknownKeys = true; prettyPrint = true
    }

    private val fileStorage
        get() = FileStorage(context, "com.iproov.identity")

    // Avoid holding a reference to the key, it can be deleted at any time.
    private val encryptionKey: EncryptionKey
        get() = encryptionKeyFactory?.invoke()
            ?: AndroidDefaultKeyPair(context, "com.iproov.identity.encryption", accessPolicy)

    @Volatile
    private var encryptionKeyValidated = false

    /** Guards a caller key once before first use so a no-op key can't silently persist plaintext; the
     *  SDK's own key is trusted and skipped. */
    private fun validateCallerKeyOnce(key: EncryptionKey) {
        if (encryptionKeyFactory == null || encryptionKeyValidated) return
        assertEncryptionKeyProducesCiphertext(key)
        encryptionKeyValidated = true
    }

    private suspend fun read(): Map<String, String?> {
        if (!fileStorage.fileHasBeenCreated) return emptyMap()

        return authenticateIfRequired {
            val key = encryptionKey
            validateCallerKeyOnce(key)
            val encrypted = fileStorage.read()
            val raw = key.decrypt(encrypted).decodeToString()
            json.decodeFromString<Map<String, String?>>(raw)
        }
    }

    override suspend fun read(key: String): String? {
        if (!fileStorage.fileHasBeenCreated) return null

        return read()[key]
    }

    override suspend fun write(key: String, value: String?) {
        val map = read().toMutableMap().apply {
            set(key, value)
        }

        val encoded = json.encodeToString(map).encodeToByteArray()
        val encKey = encryptionKey
        validateCallerKeyOnce(encKey)
        val encrypted = encKey.encrypt(encoded)
        fileStorage.write(encrypted)
    }

    override suspend fun deleteAll() {
        fileStorage.delete()
        encryptionKey.resetBestEffort()
    }

    private suspend fun <T> authenticateIfRequired(block: () -> T): T {
        // Try running the block first. If the key is already unlocked (validity period active),
        // this will succeed without prompting the user.
        return try {
            block()
        } catch (e: Exception) {
            // Check if this is an authentication-related exception.
            // We look for the exceptions re-thrown by AndroidDefaultKeyPair.decrypt.
            // A custom EncryptionKey is expected to manage its own authentication, so the
            // interactive prompt below only applies to the SDK's own AndroidDefaultKeyPair.
            val authKey = encryptionKey as? AndroidDefaultKeyPair
            if (isAuthenticationRequired(e) && authKey != null) {
                Logger.info("Authentication is required for $accessPolicy, launching now... ")

                // We must be on the Main Thread to show UI, but we shouldn't block it.
                // We use withContext(Dispatchers.Main) to ensure the prompt is launched correctly.
                withContext(Dispatchers.Main) {
                    val activity = context as? Activity
                        ?: throw IllegalStateException("Context must be FragmentActivity to use BiometricPrompt")

                    try {
                        authKey.authenticate(activity)
                    } catch (e: CancellationException) {
                        throw KeyPairAuthenticationCanceled()
                    } catch (e: KeyPairAuthenticationCanceled) {
                        // If the error was because the user
                        throw e
                    } catch (e: KeyPairAuthenticationError) {
                        // If the error was because the user
                        throw e
                    } catch (error: Throwable) {
                        Logger.error("Authentication failed: ${error.message}" + error.stackTraceToString())
                        throw KeyPairAuthenticationError(
                            error.message ?: "Authentication was not successful but required to use the keypair"
                        )
                    }
                }

                Logger.info("Authentication completed, retrying operation")
                // Retry the block now that auth succeeded
                block()
            } else {
                throw e
            }
        }
    }

    private fun isAuthenticationRequired(e: Exception): Boolean {
        // Check for Android Keystore exceptions
        // AndroidDefaultKeyPair now throws the raw exceptions (UserNotAuthenticatedException) on API 23+
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (e is android.security.keystore.UserNotAuthenticatedException) return true
            if (e is android.security.keystore.KeyPermanentlyInvalidatedException) return true
        }
        return false
    }
}

class EncryptedPreferencesAndroidStorageEngine(context: Context) : StorageEngine {

    private val preferences: EncryptedPreferences = EncryptedPreferences(context)

    override suspend fun read(key: String): String? = preferences.getString(key)

    override suspend fun write(key: String, value: String?) = preferences.setString(key, value)

    override suspend fun deleteAll() = preferences.deleteAll()
}

/**
 * The credentials are encrypted with a key in
 */
class BackedUpStorageEngine(context: Context) : StorageEngine {

    companion object {
        const val ENCRYPTION_KEY = "encryptionKey"
        const val FILE_NAME = "com.iproov.identity"
    }

    private val backedUpStorage = BackedUpKeyValueStorage(context)

    private val fileStorage = FileStorage(context, FILE_NAME)

    override suspend fun read(key: String): String? = read()[key]

    override suspend fun write(key: String, value: String?) {
        val dict = read().toMutableMap()
        dict[key] = value
        write(dict)
    }

    override suspend fun deleteAll() = fileStorage.delete()

    private fun getEncryptionKey(): SymmetricKey {
        val encryptionKey = backedUpStorage.read(ENCRYPTION_KEY)

        if (encryptionKey == null) {
            val newEncryptionKey = SymmetricKey.new()
            backedUpStorage.write(ENCRYPTION_KEY, newEncryptionKey.getKeyString())
        }

        return SymmetricKey(encryptionKey!!)
    }

    @Throws(StorageException::class)
    private fun read(): Map<String, String?> {
        val rawData = fileStorage.read()
        val encryptionKey = getEncryptionKey()
        val decryptedData =
            encryptionKey.decrypt(rawData) ?: throw StorageException("Failed to decrypt data")
        return fileStorage.unarchiveData(decryptedData)
    }

    @Throws(StorageException::class)
    private fun write(map: Map<String, String?>) {
        val encryptionKey = getEncryptionKey()
        val archivedData = fileStorage.archiveDictionary(map)
        val encryptedData =
            encryptionKey.encrypt(archivedData) ?: throw StorageException("Failed to encrypt data")
        fileStorage.write(encryptedData)
    }

}

actual fun getDeviceBoundStorageEngine(accessPolicy: KeyPairAccessPolicy): StorageEngine =
    DeviceBoundAndroidStorageEngine(AppContext.get(), accessPolicy)

actual fun getDeviceBoundStorageEngine(
    accessPolicy: KeyPairAccessPolicy,
    encryptionKeyFactory: EncryptionKeyFactory,
): StorageEngine = DeviceBoundAndroidStorageEngine(
    AppContext.get(),
    accessPolicy,
    encryptionKeyFactory,
)
