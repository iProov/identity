package com.iproov.identity.models

import com.iproov.identity.attestation.hash
import com.iproov.identity.attestation.toNSData
import io.ktor.utils.io.core.toByteArray
import platform.Security.*
import kotlinx.cinterop.*

@OptIn(ExperimentalForeignApi::class)
actual fun generateRandomBytes(length: Int): ByteArray {
    val bytes = ByteArray(length)
    bytes.usePinned { pinnedBytes ->
        val status = SecRandomCopyBytes(kSecRandomDefault, length.toULong(), pinnedBytes.addressOf(0))
        if (status != 0) {
            throw RuntimeException("Failed to generate random bytes: $status")
        }
    }
    return bytes
}


actual fun hash(data: ByteArray): ByteArray =
    hash(data) // references an internal hash function used in the AttestationService

val ActiveAuthentication.challenge
    get() = challenge.toNSData()

val ActiveAuthentication.secret
    get() = secret.toNSData()