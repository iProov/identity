package com.iproov.identity.models

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@OptIn(ExperimentalObjCRefinement::class)
@Serializable
class CredentialDescriptor(

    val id: String,

    /**
     * Raw credential descriptor from the issuers metadata for this credential
     */
    @HiddenFromObjC
    val raw: JsonObject,

    /**
     * Format of the credential being offered
     */
    val format: String,

    /**
     * OAuth scope value associated with this credential configuration.
     * Required for HAIP-compliant authorization_code flows (HAIP 1.0 Section 5.1.2).
     */
    val scope: String? = null,

    /**
     * Mapping of locale to display properties for this credential
     */
    val display: Map<String?, DisplayProperties> = mapOf()
)