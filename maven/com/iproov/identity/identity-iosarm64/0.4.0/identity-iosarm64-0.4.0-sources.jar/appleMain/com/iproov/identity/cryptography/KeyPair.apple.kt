package com.iproov.identity.cryptography

import com.iproov.identity.Logger
import com.iproov.identity.persistence.StorageException
import com.iproov.identity.persistence.createCFDictionary
import com.iproov.identity.persistence.toByteArray
import com.iproov.identity.persistence.toCFData
import com.iproov.identity.persistence.toCFNumber
import kotlinx.cinterop.COpaquePointerVar
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.readBytes
import kotlinx.cinterop.toKString
import kotlinx.cinterop.usePinned
import kotlinx.cinterop.value
import platform.CoreFoundation.CFDataGetBytePtr
import platform.CoreFoundation.CFDataGetLength
import platform.CoreFoundation.CFDictionaryGetValue
import platform.CoreFoundation.CFDictionaryRef
import platform.CoreFoundation.CFErrorCopyDescription
import platform.CoreFoundation.CFErrorGetCode
import platform.CoreFoundation.CFErrorRef
import platform.CoreFoundation.CFErrorRefVar
import platform.CoreFoundation.CFRelease
import platform.CoreFoundation.CFRetain
import platform.CoreFoundation.CFStringGetCString
import platform.CoreFoundation.CFStringGetLength
import platform.CoreFoundation.CFStringGetMaximumSizeForEncoding
import platform.CoreFoundation.CFStringRef
import platform.CoreFoundation.kCFAllocatorDefault
import platform.CoreFoundation.kCFBooleanTrue
import platform.CoreFoundation.kCFStringEncodingUTF8
import platform.Foundation.CFBridgingRelease
import platform.Foundation.NSString
import platform.Security.SecAccessControlCreateWithFlags
import platform.Security.SecItemCopyMatching
import platform.Security.SecItemDelete
import platform.Security.SecKeyCopyAttributes
import platform.Security.SecKeyCopyExternalRepresentation
import platform.Security.SecKeyCopyPublicKey
import platform.Security.SecKeyCreateDecryptedData
import platform.Security.SecKeyCreateEncryptedData
import platform.Security.SecKeyCreateRandomKey
import platform.Security.SecKeyCreateSignature
import platform.Security.SecKeyRef
import platform.Security.errSecSuccess
import platform.Security.kSecAttrAccessControl
import platform.Security.kSecAttrAccessibleWhenUnlockedThisDeviceOnly
import platform.Security.kSecAttrApplicationTag
import platform.Security.kSecAttrIsPermanent
import platform.Security.kSecAttrKeySizeInBits
import platform.Security.kSecAttrKeyType
import platform.Security.kSecAttrKeyTypeECSECPrimeRandom
import platform.Security.kSecAttrTokenID
import platform.Security.kSecAttrTokenIDSecureEnclave
import platform.Security.kSecClass
import platform.Security.kSecClassKey
import platform.Security.kSecKeyAlgorithmECDSASignatureMessageX962SHA256
import platform.Security.kSecKeyAlgorithmECIESEncryptionCofactorX963SHA256AESGCM
import platform.Security.kSecPrivateKeyAttrs
import platform.Security.kSecReturnRef
import kotlin.experimental.and
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import com.iproov.identity.cryptography.KeyPair as SdkKeyPair

// The secure enclave gives us the signature as ASN.1, however JWT requires
// that the signature is the raw R and S values.
// So we need to unpack the ASN.1 signature, extract the R & S values, then
// concatenate them and re-encode them back to base64.
//actual fun getRSFromSignature(signature: String): String {
//    return signature
//}

private object Constants {
    @OptIn(ExperimentalForeignApi::class)
    val keyType = kSecAttrKeyTypeECSECPrimeRandom

    const val keySize = 256

    @OptIn(ExperimentalForeignApi::class)
    val encryptionAlgorithm = kSecKeyAlgorithmECIESEncryptionCofactorX963SHA256AESGCM

    @OptIn(ExperimentalForeignApi::class)
    val signatureAlgorithm = kSecKeyAlgorithmECDSASignatureMessageX962SHA256

    val asn1Header = byteArrayOf(
        0x30,
        0x59,
        0x30,
        0x13,
        0x06,
        0x07,
        0x2A,
        0x86.toByte(),
        0x48,
        0xCE.toByte(),
        0x3D,
        0x02,
        0x01,
        0x06,
        0x08,
        0x2A,
        0x86.toByte(),
        0x48,
        0xCE.toByte(),
        0x3D,
        0x03,
        0x01,
        0x07,
        0x03,
        0x42,
        0x00
    )

}

@OptIn(ExperimentalForeignApi::class)
class AppleKeyPair(
    private val tag: String, private val accessControlPolicy: KeyPairAccessPolicy
) : SdkKeyPair {

    enum class Location {
        SECURE_ENCLAVE,
        KEYCHAIN;

        val stringValue: String
            get() {
                return when (this) {
                    SECURE_ENCLAVE -> "secureEnclave"
                    KEYCHAIN -> "keychain"
                }
            }
    }

    private var privateKey: SecKeyRef

    init {
        memScoped {
            val query = createCFDictionary(
                mapOf(
                    kSecClass to kSecClassKey,
                    kSecAttrApplicationTag to tag.encodeToByteArray().toCFData(),
                    kSecAttrKeyType to Constants.keyType,
                    kSecReturnRef to kCFBooleanTrue,
                )
            )
            try {
                val itemPtr = alloc<COpaquePointerVar>()
                val status = SecItemCopyMatching(query, itemPtr.ptr)

                privateKey = if (status == errSecSuccess) {
                    itemPtr.value as SecKeyRef
                } else {
                    createPrivateKey(tag)
                }
            } finally {
                CFRelease(query)
            }

        }
    }

    // This is lazy to avoid unnecessary calls to SecKeyCopyPublicKey
    // the use of the key pair is always through a getter and never stored in memory as a
    // property so this can be kept in memory for the lifetime of the getter.
    private val _publicKey: SecKeyRef by lazy {
        SecKeyCopyPublicKey(privateKey)
            ?: throw KeyPairException("Failed to get public key")
    }

    override fun getJwk(): EllipticCurvePublicKey {
        return EllipticCurvePublicKey(
            alg = "ES256",
            jwk = derToJwk(publicKey)
        )
    }

    override fun getPublicKey(): ByteArray = publicKey

    private val publicKey: ByteArray
        get() = memScoped {
            val error = alloc<CFErrorRefVar>()
            val pkDataRef = SecKeyCopyExternalRepresentation(
                _publicKey,
                error.ptr
            ) ?: throw KeyPairException("Failed to get public key: ${error.value}")

            val length = CFDataGetLength(pkDataRef)
            val bytes = CFDataGetBytePtr(pkDataRef)

            val publicKeyBytes = bytes?.readBytes(length.toInt())?.also {
                CFRelease(pkDataRef)
            } ?: throw KeyPairException("Failed to read public key bytes from reference")

            Logger.info("Raw DER bytes: ${publicKeyBytes.contentToString()}") // Log the raw bytes

            return Constants.asn1Header.plus(publicKeyBytes)
        }

    private val location: Location by lazy {
        val tokenID = memScoped {
            val ref =
                SecKeyCopyAttributes(privateKey)
                    ?: throw KeyPairException("Failed to key location of private key")

            val tokenID = getCFDictionaryValue(ref, kSecAttrTokenID) as NSString?
            CFRelease(ref)

            return@memScoped tokenID;
        }
        val isLocationSecureEnclave = tokenID != null && tokenID.equals("com.apple.setoken")

        if (isLocationSecureEnclave) Location.SECURE_ENCLAVE else Location.KEYCHAIN
    }

    override fun sign(data: ByteArray): ByteArray {
        var signedData: ByteArray
        memScoped {
            val errorRefVar = alloc<CFErrorRefVar>()
            Logger.debug("Signing data")
            val result = SecKeyCreateSignature(
                privateKey,
                Constants.signatureAlgorithm,
                data.toCFData(),
                errorRefVar.ptr
            )

            if (result == null) {
                // Check if user canceled
                val errorRef = errorRefVar.value
                throw mapCFErrorToException(errorRef)
            }

            signedData = result.toByteArray()
            CFRelease(result)
        }
        return signedData
    }

    @Throws(KeyPairException::class)
    fun encrypt(data: ByteArray): ByteArray {
        Logger.debug("Using KeyPair to encrypt data")
        var encrypted: ByteArray
        memScoped {
            val errorRefVar = alloc<CFErrorRefVar>()
            val result = SecKeyCreateEncryptedData(
                _publicKey,
                Constants.encryptionAlgorithm,
                data.toCFData(),
                errorRefVar.ptr
            )

            if (result == null) {
                val errorRef = errorRefVar.value

                try {
                    throw mapCFErrorToException(errorRef)
                } finally {
                    // Release the CFError we were given
                    CFRelease(errorRef)
                }
            }

            Logger.debug("Encryption complete")
            encrypted = result.toByteArray()
            CFRelease(result)
        }
        return encrypted
    }

    @Throws(KeyPairException::class)
    fun decrypt(data: ByteArray): ByteArray {
        Logger.debug("Attempting decryption")
        var decrypted: ByteArray
        memScoped {
            val errorRefVar = alloc<CFErrorRefVar>()

            val result = SecKeyCreateDecryptedData(
                privateKey,
                Constants.encryptionAlgorithm,
                data.toCFData(),
                errorRefVar.ptr
            )

            if (result == null) {
                val errorRef = errorRefVar.value

                if (errorRef != null) {
                    try {
                        throw mapCFErrorToException(errorRef)
                    } finally {
                        // Release the CFError we were given
                        CFRelease(errorRef)
                    }
                }

                // If we get here we have no usable CFError or it wasn't from kSecErrorDomain
                Logger.error("Failed to decrypt data, no usable CFError or it wasn't from kSecErrorDomain")
                throw StorageException("Failed to decrypt the data.")
            }

            decrypted = result.toByteArray()
            CFRelease(result)
        }
        return decrypted
    }

    override fun getKeySecurityLevel() = location.stringValue

    @Throws(KeyPairException::class)
    override fun reset() {
        val query = createCFDictionary(
            mapOf(
                kSecClass to kSecClassKey,
                kSecAttrApplicationTag to tag.encodeToByteArray().toCFData(),
                kSecAttrKeyType to Constants.keyType,
                kSecReturnRef to kCFBooleanTrue,
            )
        )

        val status = SecItemDelete(query)
        CFRelease(query)
        if (status != errSecSuccess) throw KeyPairException("Unable to delete key pair. Status: $status")
    }

    private fun createPrivateKey(
        tag: String,
        location: Location = Location.SECURE_ENCLAVE
    ): SecKeyRef = memScoped {
        val error = alloc<CFErrorRefVar>()
        // Standard Keychain supports these flags (UserPresence, Biometry, etc.) on modern iOS.
        Logger.debug("Attempting to create private key in $location with flags: ${accessControlPolicy.accessControlFlags}")
        val access = SecAccessControlCreateWithFlags(
            kCFAllocatorDefault,
            kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            flags = accessControlPolicy.accessControlFlags,
            error.ptr,
        ) ?: throw KeyPairException("Failed to create SecAccessControl: ${error.value}")

        val privateKeyAttrs = createCFDictionary(
            mapOf(
                kSecAttrApplicationTag to tag.encodeToByteArray().toCFData(),
                kSecAttrIsPermanent to kCFBooleanTrue,
                kSecAttrAccessControl to access
            )
        )

        val attrs = mutableMapOf(
            kSecAttrKeyType to Constants.keyType,
            kSecAttrKeySizeInBits to Constants.keySize.toCFNumber(),
            kSecPrivateKeyAttrs to privateKeyAttrs,
        )

        // Only add the TokenID if we are specifically targeting the Secure Enclave
        if (location == Location.SECURE_ENCLAVE) {
            attrs[kSecAttrTokenID] = kSecAttrTokenIDSecureEnclave
        }

        val params = createCFDictionary(attrs)

        val privkey = SecKeyCreateRandomKey(
            params,
            error.ptr
        )

        CFRelease(access)
        CFRelease(params)
        CFRelease(privateKeyAttrs)

        if (privkey == null) {
            // Cleanup before recursive call/return
            if (location == Location.SECURE_ENCLAVE) {
                Logger.info("Failed to create key in secure enclave ${error.value}, falling back to Keychain.")
                return createPrivateKey(tag, Location.KEYCHAIN)
            } else {
                Logger.info("Failed to create key in Keychain ${error.value}")
                throw KeyPairException("Failed to create private key ${error.value}")
            }
        }

        return privkey
    }
}

@OptIn(ExperimentalForeignApi::class)
fun getCFDictionaryValue(dictionary: CFDictionaryRef?, key: CFStringRef?): Any? {
    val valuePtr = CFDictionaryGetValue(dictionary, key) ?: return null

    // CFDictionaryGetValue follows "Get Rule" - we don't own it
    // If we need to bridge to Kotlin/ARC, retain first then bridge
    CFRetain(valuePtr)
    return CFBridgingRelease(valuePtr)
}

@OptIn(ExperimentalEncodingApi::class)
fun derToJwk(derBytes: ByteArray): OnDeviceKeyPairJwk {
    val (curveName, x, y) = parseEcPublicKeyFromDer(derBytes)

    // Base64Url encode x and y
    val xBase64Url = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT).encode(x)
    val yBase64Url = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT).encode(y)

    // Create the JWK JSON
    return OnDeviceKeyPairJwk(
        curveName,
        "EC",
        xBase64Url,
        yBase64Url,
    )

}

// Look at making this more platform agnnostic
fun parseEcPublicKeyFromDer(derBytes: ByteArray): Triple<String, ByteArray, ByteArray> {
    // Basic DER parsing logic (simplified for common structures)
    var index = 0

    // Ensure we start with a SEQUENCE
    if (derBytes[index] != 0x30.toByte()) throw KeyPairException("Invalid DER: Not a SEQUENCE")
    index++

    // Get total SEQUENCE length
    val lengthInfo = derBytes[index].toLength(derBytes, index + 1)
    index += lengthInfo.lengthBytes

    // Skip AlgorithmIdentifier SEQUENCE
    if (derBytes[index] != 0x30.toByte()) throw KeyPairException("Invalid DER: Missing AlgorithmIdentifier")
    index++

    val algoLengthInfo = derBytes[index].toLength(derBytes, index + 1)
    index += algoLengthInfo.lengthBytes + algoLengthInfo.value

    // Parse the public key BIT STRING
    if (derBytes[index] != 0x03.toByte()) throw KeyPairException("Invalid DER: Missing BIT STRING")
    index++

    val bitStringLengthInfo = derBytes[index].toLength(derBytes, index + 1)
    index += bitStringLengthInfo.lengthBytes

    // Skip unused bits byte
    index++

    // Extract x and y from the uncompressed EC public key
    if (derBytes[index] != 0x04.toByte()) throw KeyPairException("Invalid EC Public Key: Expected uncompressed format")
    index++

    val keyLength = (bitStringLengthInfo.value - 1) / 2
    val x = derBytes.copyOfRange(index, index + keyLength)
    val y = derBytes.copyOfRange(index + keyLength, index + 2 * keyLength)

    // Determine curve name based on key size
    val curveName = when (keyLength * 8) {
        256 -> "P-256"
        384 -> "P-384"
        521 -> "P-521"
        else -> throw KeyPairException("Unsupported curve size: ${keyLength * 8}")
    }

    return Triple(curveName, x, y)
}

fun Byte.toLength(input: ByteArray, startIndex: Int): Length {
    if (this and 0x80.toByte() == 0.toByte()) {
        // Single-byte length
        return Length(value = this.toInt(), lengthBytes = 1)
    }

    // Multi-byte length
    val numBytes = this and 0x7F.toByte()
    if (numBytes <= 0 || startIndex + numBytes >= input.size) {
        throw KeyPairException("Invalid DER length encoding")
    }

    var value = 0
    for (i in 0 until numBytes.toInt()) {
        value = (value shl 8) or (input[startIndex + i].toInt() and 0xFF)
    }

    return Length(value = value, lengthBytes = numBytes.toInt() + 1)
}

data class Length(val value: Int, val lengthBytes: Int)

actual fun getDeviceBoundKeyPair(policy: KeyPairAccessPolicy, alias: String): SdkKeyPair =
    AppleKeyPair(alias, policy)

// Helper to extract the localized description from a CFErrorRef
@OptIn(ExperimentalForeignApi::class)
private fun getErrorDescription(errorRef: CFErrorRef?): String {
    if (errorRef == null) return "Unknown error"

    // CFErrorCopyLocalizedDescription returns a retained CFStringRef
    val cfString = CFErrorCopyDescription(errorRef)

    return if (cfString != null) {
        // Convert CFString to Kotlin String using built-in interop
        // Note: In some KMP versions, you might need to interpret the pointer.
        // The standard 'toString()' on a CFStringRef often works or use bridges.
        // A safe, manual conversion approach:
        val length = CFStringGetLength(cfString)
        val maxSize = CFStringGetMaximumSizeForEncoding(length, kCFStringEncodingUTF8)
        val buffer = ByteArray(maxSize.toInt() + 1)

        val success = buffer.usePinned { pinned ->
            CFStringGetCString(cfString, pinned.addressOf(0), buffer.size.toLong(), kCFStringEncodingUTF8)
        }

        CFRelease(cfString) // Important: Release the string we copied

        if (success) buffer.toKString() else "Error decoding description"
    } else {
        "Unknown error"
    }
}

@OptIn(ExperimentalForeignApi::class)
private fun mapCFErrorToException(errorRef: CFErrorRef?): Exception {

    val errorCode = CFErrorGetCode(errorRef).toInt()
    val systemMessage = getErrorDescription(errorRef) // Extract the text

    Logger.error("Crypto failure: $errorCode - $systemMessage")
    when (errorCode) {
        // --- Cancellation ---
        // errSecUserCanceled (-128) OR kLAErrorUserCancel (-2)
        -128, -2 -> {
            Logger.error("The user canceled authentication (Code: $errorCode): $systemMessage")
            return KeyPairAuthenticationCanceled()
        }

        // --- Biometric/Auth Failures ---
        // errSecAuthFailed (-25293)
        // errSecInteractionNotAllowed (-25308)
        // kLAErrorAuthenticationFailed (-1)
        // kLAErrorBiometryLockout (-8)
        -25293, -25308, -1, -8 -> {
            Logger.error("Authentication failed or locked out: (Code=$errorCode)")
            return KeyPairAuthenticationError(
                "Biometric authentication failed: $systemMessage"
            )
        }

        // --- System/App Interruptions ---
        // kLAErrorAppCancel (-9), kLAErrorSystemCancel (-4)
        -9, -4 -> {
            Logger.error("Authentication interrupted by system/app: (Code=$errorCode)")
            return KeyPairAuthenticationError(
                "Authentication interrupted: $systemMessage"
            )
        }

        else -> {
            Logger.error("Failed to decrypt data with unknown error: $errorCode")
            // Pass the specific code up for debugging
            return KeyPairAuthenticationError(
                "Keychain/Auth error while decrypting: $systemMessage"
            )
        }
    }
}