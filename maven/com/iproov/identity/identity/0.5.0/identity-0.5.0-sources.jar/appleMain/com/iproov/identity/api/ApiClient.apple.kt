package com.iproov.identity.api

import com.iproov.identity.attestation.AttestationException
import com.iproov.identity.attestation.hash
import com.iproov.identity.attestation.toNSData
import com.iproov.identity.persistence.toByteArray
import io.ktor.client.HttpClient
import io.ktor.client.engine.darwin.Darwin
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.Logger
import io.ktor.client.plugins.logging.Logging
import io.ktor.client.plugins.logging.SIMPLE
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.json.Json
import platform.DeviceCheck.DCAppAttestService
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi


/**
 * This will be called each signed post request to the backend, at the moment only getting the iOS assertion header
 * on iOS and keyId is provided, however may contain more headers in the future.
 */
@OptIn(ExperimentalEncodingApi::class)
actual suspend fun getPlatformHeaders(jws: String, keyId: String?): Map<String, String> {
    if (keyId == null) return emptyMap()

    val jwsHash = hash(jws.encodeToByteArray())
    val attestationObject = generateAssertion(keyId, jwsHash)

    return mapOf(
        "x-ios-assertion" to Base64.Default.encode(attestationObject)
    )
}

private suspend fun generateAssertion(keyId: String, jwsHash: ByteArray) = suspendCancellableCoroutine { continuation ->
    DCAppAttestService.sharedService.generateAssertion(keyId, jwsHash.toNSData()) { attestationKey, error ->
        if (error != null) {
            // Resume with an exception if an error occurs
            continuation.resumeWithException(AttestationException(error.localizedDescription))
        } else if (attestationKey != null) {
            // Resume with the result if successful
            continuation.resume(attestationKey.toByteArray())
        } else {
            // Handle unexpected null
            continuation.resumeWithException(AttestationException("Unexpected null attestation key"))
        }
    }
}

actual val httpClient: HttpClient
    get() = HttpClient(Darwin) {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
        install(Logging) { logger = Logger.SIMPLE }
    }