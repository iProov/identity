package com.iproov.identity.cryptography

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyInfo
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.security.keystore.UserNotAuthenticatedException
import com.iproov.identity.Logger
import java.math.BigInteger
import java.nio.ByteBuffer
import java.security.AlgorithmParameters
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.Signature
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPublicKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import com.iproov.identity.cryptography.KeyPair as SdkKeyPair

internal class AndroidKeystoreKeyPair(
    context: Context,
    private val keyAlias: String,
    private val accessPolicy: KeyPairAccessPolicy,
) : SdkKeyPair {

    companion object Companion {
        const val SHOULD_USE_STRONGBOX = false
        const val EC_POINT_LEN = 65
        const val GCM_TAG_LENGTH_BITS = 128
        const val AES_KEY_SIZE_BYTES = 16
        const val GCM_IV_LENGTH_BYTES = 16
    }

    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply {
        load(null)
    }

    private val keyPair: java.security.KeyPair

    val publicKey: ECPublicKey get() = keyPair.public as ECPublicKey

    private val hasStrongBox: Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_STRONGBOX_KEYSTORE)
    } else {
        false;
    }

    init {
        val privateKey = keyStore.getKey(keyAlias, null) as PrivateKey?
        keyPair = if (privateKey == null) {
            generateKeyPair()
        } else {
            val publicKey = keyStore.getCertificate(keyAlias).publicKey
            KeyPair(publicKey, privateKey)
        }
    }

    override fun getJwk(): EllipticCurvePublicKey = EllipticCurvePublicKey(
        alg = "ES256",
        jwk = ecPublicKeyToJwk(publicKey)
    )

    override fun getPublicKey(): ByteArray = publicKey.encoded

    @SuppressLint("NewApi")
    private fun generateKeyPair(): java.security.KeyPair =
        KeyPairGenerator.getInstance("EC", "AndroidKeyStore").run {
            val spec = buildKeyGenParameterSpec()
            initialize(spec)
            return generateKeyPair()
        }

    private fun buildKeyGenParameterSpec(): KeyGenParameterSpec {

        val keyProperties = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_AGREE_KEY
        } else {
            // Ephemeral keys are used for device engagement so not needed any current flows &
            // PURPOSE_AGREE_KEY is not available until API 31 so we can just fall back to just PURPOSE_SIGN
            KeyProperties.PURPOSE_SIGN
        }
        val builder = KeyGenParameterSpec.Builder(keyAlias, keyProperties).apply {
            setDigests(KeyProperties.DIGEST_SHA256)
            setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))

            // Match "device must be unlocked" semantics where supported
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                setUnlockedDeviceRequired(true)
            }

            // Enable key attestation - generates certificate chain proving key is in secure hardware
            // The challenge can be any value; actual nonce binding happens in KeyAttestationJWT
            val attestationChallenge = ByteArray(32).also {
                java.security.SecureRandom().nextBytes(it)
            }
            setAttestationChallenge(attestationChallenge)
            Logger.debug("Key attestation challenge set for hardware-backed key generation")
        }

        Logger.info("Creating key ($keyAlias) with access policy: ${accessPolicy}")
        builder.apply(accessPolicy.options)
        val spec = builder.build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Logger.info(
                """Key built with following params:
            {
                Authentication is required: ${spec.isUserAuthenticationRequired}
                Authentication type: ${spec.userAuthenticationType}
                Authentication duration: ${spec.userAuthenticationValidityDurationSeconds}
                Key is invalidated by biometrics: ${spec.isInvalidatedByBiometricEnrollment}
                Key purposes: ${spec.purposes}
            }
            """.trimIndent()
            )
        }
        return spec
    }

    override fun sign(data: ByteArray): ByteArray = Signature.getInstance("SHA256withECDSA").run {
        initSign(keyPair.private)
        update(data)
        return sign()
    }

    @Throws(KeyPairException::class)
    fun encrypt(data: ByteArray): ByteArray {
        Logger.info("Encrypting with ($keyAlias)")
        try {
            val keyGen = KeyPairGenerator.getInstance("EC")
            keyGen.initialize(ECGenParameterSpec("secp256r1"))
            val ephemeralKeyPair = keyGen.generateKeyPair()

            val keyAgreement = KeyAgreement.getInstance("ECDH")
            keyAgreement.init(ephemeralKeyPair.private)
            keyAgreement.doPhase(keyPair.public, true)
            val z = keyAgreement.generateSecret()

            val derivedMaterial = x963Kdf(z, AES_KEY_SIZE_BYTES + GCM_IV_LENGTH_BYTES)
            val aesKeyBytes = derivedMaterial.copyOfRange(0, AES_KEY_SIZE_BYTES)
            val ivBytes = derivedMaterial.copyOfRange(
                AES_KEY_SIZE_BYTES,
                AES_KEY_SIZE_BYTES + GCM_IV_LENGTH_BYTES
            )

            val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, ivBytes)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(aesKeyBytes, "AES"), spec)
            val encryptedData = cipher.doFinal(data)

            val ephemeralPubBytes =
                encodeEcPublicKeyToUncompressed(ephemeralKeyPair.public as ECPublicKey)

            return ByteBuffer.allocate(ephemeralPubBytes.size + encryptedData.size)
                .put(ephemeralPubBytes)
                .put(encryptedData)
                .array()

        } catch (e: Exception) {
            throw KeyPairException("Encryption failed: ${e.message}")
        }
    }

    @Throws(KeyPairException::class)
    fun decrypt(data: ByteArray): ByteArray {
        Logger.info("Decrypting with ($keyAlias)")
        try {
            if (data.size < EC_POINT_LEN) throw KeyPairException("Invalid data length")

            val ephemeralPubBytes = data.copyOfRange(0, EC_POINT_LEN)
            val ciphertext = data.copyOfRange(EC_POINT_LEN, data.size)
            val ephemeralPublicKey = decodeEcPublicKeyFromUncompressed(ephemeralPubBytes)

            val keyAgreement = KeyAgreement.getInstance("ECDH", "AndroidKeyStore")
            keyAgreement.init(keyPair.private)
            keyAgreement.doPhase(ephemeralPublicKey, true)
            val z = keyAgreement.generateSecret()

            val derivedMaterial = x963Kdf(z, AES_KEY_SIZE_BYTES + GCM_IV_LENGTH_BYTES)
            val aesKeyBytes = derivedMaterial.copyOfRange(0, AES_KEY_SIZE_BYTES)
            val ivBytes = derivedMaterial.copyOfRange(
                AES_KEY_SIZE_BYTES,
                AES_KEY_SIZE_BYTES + GCM_IV_LENGTH_BYTES
            )

            val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, ivBytes)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(aesKeyBytes, "AES"), spec)

            return cipher.doFinal(ciphertext)

        } catch (e: Exception) {
            e.printStackTrace()
            // Allow authentication-related exceptions to bubble up so the UI can handle them
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (e is UserNotAuthenticatedException) throw e
                if (e is KeyPermanentlyInvalidatedException) throw e
            }
            throw KeyPairException("Decryption failed: ${e.message}")
        }
    }

    private fun decodeEcPublicKeyFromUncompressed(bytes: ByteArray): PublicKey {
        if (bytes[0] != 0x04.toByte()) throw KeyPairException("Invalid key format, expected uncompressed header 0x04")
        val xBytes = bytes.copyOfRange(1, 33)
        val yBytes = bytes.copyOfRange(33, 65)
        val x = BigInteger(1, xBytes)
        val y = BigInteger(1, yBytes)
        val point = ECPoint(x, y)

        // Correctly derive ECParameterSpec using AlgorithmParameters
        val parameters = AlgorithmParameters.getInstance("EC")
        parameters.init(ECGenParameterSpec("secp256r1"))
        val ecParameters = parameters.getParameterSpec(ECParameterSpec::class.java)

        val spec = ECPublicKeySpec(point, ecParameters)
        val keyFactory = KeyFactory.getInstance("EC")
        return keyFactory.generatePublic(spec)
    }

    private fun x963Kdf(z: ByteArray, length: Int): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        val out = ByteArray(length)
        var counter = 1
        var offset = 0
        while (offset < length) {
            digest.update(z)
            digest.update(counter.shr(24).toByte())
            digest.update(counter.shr(16).toByte())
            digest.update(counter.shr(8).toByte())
            digest.update(counter.toByte())
            val hash = digest.digest()
            val chunk = minOf(hash.size, length - offset)
            System.arraycopy(hash, 0, out, offset, chunk)
            offset += chunk
            counter++
        }
        return out
    }

    private fun encodeEcPublicKeyToUncompressed(key: ECPublicKey): ByteArray {
        val x = toUnsignedBytes(key.w.affineX, 32)
        val y = toUnsignedBytes(key.w.affineY, 32)
        val out = ByteArray(1 + x.size + y.size)
        out[0] = 0x04
        System.arraycopy(x, 0, out, 1, x.size)
        System.arraycopy(y, 0, out, 1 + x.size, y.size)
        return out
    }

    override fun reset() = keyStore.deleteEntry(keyAlias)

    override fun getKeySecurityLevel(): String {
        val keyFactory = KeyFactory.getInstance(keyPair.private.algorithm, "AndroidKeyStore")
        val keyInfo = keyFactory.getKeySpec(keyPair.private, KeyInfo::class.java)

        // Cannot get detailed security level in API <31:
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return if (keyInfo.isInsideSecureHardware) "android21:secureElement" else "android21:UNKNOWN"
        }

        return when (keyInfo.securityLevel) {
            KeyProperties.SECURITY_LEVEL_UNKNOWN -> "android31:SECURITY_LEVEL_UNKNOWN"
            KeyProperties.SECURITY_LEVEL_SOFTWARE -> "android31:SECURITY_LEVEL_SOFTWARE"
            KeyProperties.SECURITY_LEVEL_STRONGBOX -> "android31:SECURITY_LEVEL_STRONGBOX"
            KeyProperties.SECURITY_LEVEL_TRUSTED_ENVIRONMENT -> "android31:SECURITY_LEVEL_TRUSTED_ENVIRONMENT"
            KeyProperties.SECURITY_LEVEL_UNKNOWN_SECURE -> "android31:SECURITY_LEVEL_UNKNOWN_SECURE"
            else -> "android31:UNKNOWN"
        }
    }

    /**
     * Get the attestation certificate chain for this key, if available.
     * Returns null if the key was not generated with attestation or attestation is not supported.
     */
    fun getAttestationCertificateChain(): Array<java.security.cert.Certificate>? {
        return try {
            keyStore.getCertificateChain(keyAlias)
        } catch (e: Exception) {
            Logger.debug("Failed to get attestation certificate chain: ${e.message}")
            null
        }
    }
}