package com.iproov.identity.proximity

import org.multipaz.mdoc.transport.MdocTransportOptions
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * Shared BLE transport options. L2CAP improves throughput for large payloads (e.g. portrait)
 * and falls back to GATT when the peer doesn't support it. Both roles MUST share these.
 */
internal val MDOC_TRANSPORT_OPTIONS = MdocTransportOptions(bleUseL2CAP = true)

data class NfcRetrievalOptions(val dialogMessage: String? = null)

sealed class PresentationMethod {
    data object QrPresentation : PresentationMethod()
    data object NfcPresentation : PresentationMethod()
}

data class ProximityConfig(
    val readerTrust: ReaderTrustPolicy = ReaderTrustPolicy.EnforceIfPresent,
    val trustedReaderCertificates: List<ByteArray> = emptyList(),
    val issuerTrust: IssuerTrustPolicy = IssuerTrustPolicy.TrustAll,
    val engagementTimeout: Duration = 30.seconds,
    val sessionInactivityTimeout: Duration = 300.seconds,
    val bleRoles: Set<ProximityBLERole> = setOf(ProximityBLERole.PeripheralServer),
) {
    constructor() : this(
        readerTrust = ReaderTrustPolicy.EnforceIfPresent,
        trustedReaderCertificates = emptyList(),
        issuerTrust = IssuerTrustPolicy.TrustAll,
        engagementTimeout = 30.seconds,
        sessionInactivityTimeout = 300.seconds,
    )

    init {
        require(bleRoles.isNotEmpty()) { "bleRoles must contain at least one role" }
        require(bleRoles.size == 1) {
            "Only one BLE role per session is currently supported (multipaz transport " +
                    "constraint). Spec-allowed dual-mode advertising will land when multipaz " +
                    "exposes dual-transport support."
        }
    }
}

/**
 * How strictly to enforce mdoc reader authentication (ISO 18013-5 §9.1.4).
 * [EnforceIfPresent] (default) verifies when present, allows when absent.
 */
enum class ReaderTrustPolicy { DoNotEnforce, EnforceIfPresent, AlwaysRequire }


/**
 * BLE role the holder takes during retrieval (ISO 18013-5 §8.3.3.1.1).
 * [PeripheralServer] (default): holder advertises, reader connects.
 * [CentralClient]: holder scans, reader advertises.
 */
enum class ProximityBLERole { CentralClient, PeripheralServer }

/**
 * IACA trust policy for the issuer's DS certificate chain (ISO 18013-5 §9.3.2).
 * [TrustAll] is development-only; production should pin [TrustedCertificates].
 */
sealed class IssuerTrustPolicy {
    data object TrustAll : IssuerTrustPolicy()
    data class TrustedCertificates(val certificates: List<ByteArray>) : IssuerTrustPolicy()
}
