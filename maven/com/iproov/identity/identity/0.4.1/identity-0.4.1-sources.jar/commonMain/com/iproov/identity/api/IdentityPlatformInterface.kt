package com.iproov.identity.api

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.cryptography.signRs
import com.iproov.identity.decodeFromJson
import com.iproov.identity.encodeToJsonObject
import com.iproov.identity.models.AccessControl
import com.iproov.identity.models.Claim
import com.iproov.identity.models.Format
import com.iproov.identity.models.Gender
import com.iproov.identity.models.Jwt
import com.iproov.identity.models.LegacyCredential
import com.iproov.identity.models.LoginRequest
import com.iproov.identity.models.LoginResponse
import com.iproov.identity.models.MrtdData
import com.iproov.identity.models.VerificationMethod
import io.ktor.client.call.body
import io.ktor.client.statement.bodyAsText
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.encodeToJsonElement
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.coroutines.cancellation.CancellationException
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.time.Instant

abstract class IdentityPlatformInterface(
    val apiClient: ApiClient,
    val keyPairFactory: KeyPairFactory
) {
    internal object Routes {

        object Wallet {
            const val REGISTER = "/v2/register/wallet"
            const val REVOKE = "/v2/delete/wallet"
        }

        object Credentials {
            const val GET_DEMO = "/v2/get/demo"

            const val INIT_DOC = "/v2/init/doc"
            const val INIT_FACE = "/v2/init/face"
            const val INIT_CREDENTIAL = "/v2/init/credential"
            const val INIT_DOC_REFERENCE = "/v2/init/docdb"

            const val VERIFY_MRTD = "/v2/verify/doc"
            const val VERIFY_READID = "/v2/verify/readid"
            const val VERIFY_FACE = "/v2/verify/face"
            const val VERIFY_REFERENCE_DOCUMENT = "/v2/verify/docdb"
            const val VERIFY_CREDENTIAL = "/v2/verify/credential"

            const val REFRESH = "/v2/get/claims"
        }

        object Presentation {
            const val GET_REQUEST = "/v2/auth/a/"
            const val RESPOND = "v2/auth/s"
        }

        const val GET_CHALLENGE = "/v2/get/challenge"
        const val DELETE_CREDENTIAL = "/v2/delete/credential"
        const val TRANSLATIONS_CACHE = "https://cache.svipe.net/translations-en.json"
        const val OIDC_SERVERS = "/oidc/v1/.well-known/openid-servers"
    }

    private val keyPair get() = keyPairFactory()
    open var platformAttestationKeyId: String? = null

    val json = Json { ignoreUnknownKeys = true }

    @Throws(CancellationException::class)
    abstract suspend fun registerWallet(attestationToken: String): List<Jwt>

    @Throws(CancellationException::class)
    suspend fun getChallenge(keyIdentifier: String?): Challenge {
        val request = Requests.GetChallenge(keyIdentifier).encodeToJsonObject()
        val response =
            apiClient.signAndPost(IdentityPlatformInterface.Routes.GET_CHALLENGE, request)
        val challengeResponse = response.decodeFromJson<Responses.GetChallenge>()

        return Challenge(
            challenge = challengeResponse.challengeAsBytes,
            expires = Instant.fromEpochSeconds(challengeResponse.expiry.toLong())
        )
    }

    /**
     * @param reference The reference used by the identity platform to fetch the data representing the identity being added.
     * @param reverificationToken A token for re-verifying the identity reference
     * @param demoReferencePhoto An image used to verify the identity reference.
     */
    @OptIn(ExperimentalEncodingApi::class, ExperimentalObjCRefinement::class)
    suspend fun initDocReference(
        reference: String,
        reverificationToken: String? = null,
        demoReferencePhoto: ByteArray? = null
    ): VerificationMethod {
        val request = Requests.InitDocumentReference(
            reference = reference,
            verificationToken = reverificationToken,
            demoReferencePhoto = demoReferencePhoto?.let { Base64.encode(it) }
        ).encodeToJsonObject()

        val response = apiClient.signAndPost(Routes.Credentials.INIT_DOC_REFERENCE, request)

        return VerificationMethod.fromJson(response)
    }

    @Throws(CancellationException::class, ApiException::class, Exception::class)
    suspend fun initUriCredential(uri: String): Challenge {
        val request = Requests.InitUriCredential(uri).encodeToJsonObject()
        val response =
            apiClient.signAndPost(
                Routes.Credentials.INIT_CREDENTIAL,
                request,
                keyId = platformAttestationKeyId
            )
        val expirationResponse = response.decodeFromJson<Responses.Expires>()
        return Challenge(
            challenge = null,
            expires = Instant.fromEpochMilliseconds(expirationResponse.expiry.toLong())
        )
    }

    @Throws(CancellationException::class, ApiException::class)
    suspend fun verifyUriCredential(uri: String, token: String): List<Jwt> {
        val request = Requests.VerifyUriCredential(uri, token).encodeToJsonObject()
        val response = apiClient.signAndPost(
            Routes.Credentials.VERIFY_CREDENTIAL, request, keyId = platformAttestationKeyId
        )
        return getClaims(response)
    }

    @OptIn(ExperimentalEncodingApi::class)
    @Throws(CancellationException::class)
    suspend fun initDoc(challenge: ByteArray, reverificationToken: String? = null): Challenge {
        val request = Requests.InitDoc(
            challenge = Base64.Default.encode(challenge),
            reverificationToken = reverificationToken
        ).encodeToJsonObject()

        val response =
            apiClient.signAndPost("/v2/init/doc", request, keyId = platformAttestationKeyId)
        val challengeResponse = response.decodeFromJson<Responses.GetChallenge>()

        return Challenge(
            challenge = challengeResponse.challengeAsBytes,
            expires = Instant.fromEpochSeconds(challengeResponse.expiry.toLong())
        )
    }

    @OptIn(ExperimentalEncodingApi::class)
    @Throws(Exception::class)
    suspend fun verifyMrtd(
        mrtd: MrtdData,
        challenge: ByteArray,
        secret: ByteArray,
        aaSignature: ByteArray?,
        accessControl: AccessControl
    ): Responses.OfferedCredentialResponse {
        val request = Requests.VerifyMrtd(
            device = apiClient.platform.deviceInfo,
            doc = mrtd,
            verification = Requests.DocumentVerification(
                challenge = Base64.encode(challenge),
                signature = if (aaSignature != null) Base64.encode(aaSignature) else null,
                secret = Base64.encode(secret),
                accessControl = accessControl.name
            )
        ).encodeToJsonObject()

        val payload = apiClient.signAndPost(
            Routes.Credentials.VERIFY_MRTD,
            request,
            keyId = platformAttestationKeyId
        )

        return json.decodeFromJsonElement(
            Responses.OfferedCredentialResponse.serializer(), payload
        )
    }

    @Throws(CancellationException::class)
    suspend fun getDemo(gender: Gender, format: Format): MrtdData {
        val request = Requests.DemoMrtd(
            gender = gender.value,
            format = format.value,
        ).encodeToJsonObject()

        val payload = apiClient.signAndPost(
            Routes.Credentials.GET_DEMO,
            request,
            keyId = platformAttestationKeyId
        )["doc"]!!.jsonObject

        return payload.decodeFromJson<MrtdData>()
    }

    @Throws(CancellationException::class, ApiException::class)
    suspend fun signAndPost(
        path: String,
        payload: JsonObject,
        headers: Map<String, String>,
    ): JsonObject = apiClient.signAndPost(path, payload, headers, keyId = platformAttestationKeyId)

    @Throws(ApiException::class, CancellationException::class)
    suspend fun getAuthRequest(baseUrl: String, code: String, nfcCapable: Boolean): Jwt {
        val url = baseUrl + Routes.Presentation.GET_REQUEST + code
        val response = apiClient.get(
            url, headers = mapOf(
                "client-capabilities" to "fv:iproov:la;fv:iproov:gpa${if (nfcCapable) ";nfc:cd" else ""}"
            )
        )

        return Jwt(response.bodyAsText())
    }

    @Throws(ApiException::class, CancellationException::class)
    suspend fun respondToAuthRequest(
        baseUrl: String,
        loginRequest: LoginRequest,
        jwts: List<Jwt>
    ): LoginResponse {
        val request = try {
            Requests.SharedClaimsPayload.fromLoginRequest(
                jwts,
                loginRequest,
                keyPair.getJwk(),
                apiClient.platform.appInfo.client
            )
        } catch (e: Throwable) {
            Logger.error("JWK doesn't contain expected properties: ${e.message}")
            Logger.error(e.stackTraceToString())
            throw Exception("JWK doesn't contain expected properties: ${e.message}")
        }

        Logger.debug("[respondToAuthRequest] Creating JWT")
        val jwt = Jwt.create(
            payload = Json.encodeToJsonElement(request).jsonObject.toMap(),
            publicKey = keyPair.getJwk(),
            signingFunction = { keyPair.signRs(it) },
        )

        return apiClient.post(
            baseUrl + Routes.Presentation.RESPOND,

            mapOf(
                "uuid" to request.state,
                "jwt" to jwt,
            ),
            headers = mapOf("Content-Type" to "application/json").plus(getPlatformHeaders(jwt))
        ).body<LoginResponse?>() ?: LoginResponse()
    }

    @Throws(CancellationException::class, ApiException::class)
    suspend fun getTranslations(): Map<String, String?> {
        val response = apiClient.get(Routes.TRANSLATIONS_CACHE)
        return response.bodyAsText().decodeFromJson<Map<String, String?>>()
    }

    @Throws(CancellationException::class)
    suspend fun deleteWallet() {
        apiClient.signAndPost(
            Routes.Wallet.REVOKE,
            JsonObject(emptyMap()),
            keyId = platformAttestationKeyId
        )
    }

    suspend fun getOidcServers(): List<Map<String, JsonElement>> {
        val response = apiClient.get(apiClient.baseUrl + Routes.OIDC_SERVERS)
        return response.bodyAsText().decodeFromJson<List<Map<String, JsonElement>>>()
    }

    @Throws(ApiException::class, CancellationException::class)
    suspend fun initFace(dtc: Claim, reverificationToken: String?): VerificationMethod {
        val request = Requests.InitFace(
            doc = Requests.Dtc(dtc.jwt.compactString),
            reverificationToken = reverificationToken
        ).encodeToJsonObject()

        val response = apiClient.signAndPost(
            Routes.Credentials.INIT_FACE,
            request,
            keyId = platformAttestationKeyId
        )

        return VerificationMethod.fromJson(response)
    }

    @Throws(ApiException::class, CancellationException::class)
    suspend fun verifyReferenceDocument(token: String): Responses.OfferedCredentialResponse {
        val request = Requests.VerifyFace(token).encodeToJsonObject()
        val payload = apiClient.signAndPost(
            Routes.Credentials.VERIFY_REFERENCE_DOCUMENT,
            request,
            keyId = platformAttestationKeyId
        )
        return json.decodeFromJsonElement(
            Responses.OfferedCredentialResponse.serializer(),
            payload
        )
    }

    @Throws(ApiException::class, CancellationException::class)
    suspend fun verifyFace(token: String): Responses.OfferedCredentialResponse {
        val request = Requests.VerifyFace(token).encodeToJsonObject()
        val payload = apiClient.signAndPost(
            Routes.Credentials.VERIFY_FACE,
            request,
            keyId = platformAttestationKeyId
        )
        return json.decodeFromJsonElement(
            Responses.OfferedCredentialResponse.serializer(),
            payload
        )
    }

    suspend fun refreshClaims(
        document: LegacyCredential.IdentityCredential.Mrtd? = null,
        reference: LegacyCredential.IdentityCredential.Reference? = null,
        uris: List<LegacyCredential.UriCredential> = listOf()
    ): Responses.OfferedCredentialResponse {
        if (document == null && reference == null && uris.isEmpty()) return Responses.OfferedCredentialResponse()

        val request = Requests.RefreshClaims(
            document = document?.let { Requests.RefreshClaims.DocumentDtc.fromMrtdCredential(it) },
            reference = reference?.source,
            uris = uris.map { it.url }
        ).encodeToJsonObject()

        val payload = apiClient.signAndPost(Routes.Credentials.REFRESH, request)
        return json.decodeFromJsonElement(
            Responses.OfferedCredentialResponse.serializer(),
            payload
        )
    }

    fun getClaims(payload: JsonObject): List<Jwt> = (payload["claims"] as JsonArray).map {
        Jwt((it as JsonArray)[1].jsonPrimitive.content)
    }
}
