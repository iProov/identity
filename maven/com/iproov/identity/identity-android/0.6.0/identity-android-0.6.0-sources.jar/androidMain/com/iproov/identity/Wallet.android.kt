package com.iproov.identity

import android.annotation.SuppressLint
import android.content.Context
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.provider.Settings
import com.benasher44.uuid.Uuid
import com.benasher44.uuid.uuid5Of
import com.iproov.identity.api.AndroidIdentityPlatformInterface
import com.iproov.identity.api.ApiClient
import com.iproov.identity.attestation.AndroidAttestationService
import com.iproov.identity.attestation.PrimedSimplePasswordAttestationService
import com.iproov.identity.persistence.CredentialDeserializer
import com.iproov.identity.persistence.LegacyCredentialDeserializer
import com.iproov.identity.persistence.LocalStorage
import com.iproov.identity.persistence.Repository
import com.iproov.identity.persistence.StorageEngine
import com.iproov.identity.proximity.DocumentRequest
import com.iproov.identity.proximity.MDOC_TRANSPORT_OPTIONS
import com.iproov.identity.proximity.ProximityConfig
import com.iproov.identity.proximity.ProximityNotSupportedException
import com.iproov.identity.proximity.ProximityRetrievalEvent
import com.iproov.identity.proximity.ProximityRetrievalException
import com.iproov.identity.proximity.ProximityRetrievalSession
import com.iproov.identity.proximity.ReaderSigningData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.multipaz.cbor.Cbor
import org.multipaz.mdoc.engagement.DeviceEngagement
import org.multipaz.mdoc.nfc.mdocReaderNfcHandover
import org.multipaz.mdoc.role.MdocRole
import org.multipaz.mdoc.transport.MdocTransportFactory
import org.multipaz.nfc.NfcIsoTagAndroid
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

internal actual fun getWalletInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration?,
    isLoggingEnabled: Boolean,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
    legacyCredentialDeserializer: LegacyCredentialDeserializer, // Remove when when legacy credentials have been removed
    credentialDeserializer: CredentialDeserializer,
    trustConfiguration: TrustConfiguration,
): Wallet {
    // Set before anything else so the attestation choice below is actually logged.
    Logger.isEnabled = isLoggingEnabled
    quietMultipazUnlessLogging(isLoggingEnabled)

    val context = AppContext.get()
    val instanceId = getInstanceId(context)
    val platform = AndroidPlatform(context, instanceId)
    val apiClient = ApiClient(baseUrl, signingKeyPairFactory, platform, instanceId)
    val identityPlatformInterface =
        AndroidIdentityPlatformInterface(apiClient, platform, signingKeyPairFactory)

    // Play Integrity cannot succeed on an emulator, so a debuggable app running on one falls back
    // to the simple-password service. That token is only honoured by the DEV backend, so the choice
    // is logged explicitly: against PROD registration will still fail, and the reason should not be
    // a mystery. A release-signed app never reports itself debuggable, so this cannot trigger in a
    // production build — see AndroidPlatform.isVirtual.
    val attestationService = if (platform.isVirtual) {
        Logger.info(
            "Emulator + debuggable app: using SimplePasswordAttestationService instead of Play " +
                "Integrity. Registration is unattested and only accepted by the DEV environment."
        )
        PrimedSimplePasswordAttestationService(identityPlatformInterface)
    } else {
        AndroidAttestationService(identityPlatformInterface, signingKeyPairFactory, context)
    }

    val localStorage = LocalStorage(storageEngine)
    val repository = Repository(localStorage, legacyCredentialDeserializer, credentialDeserializer)

    return Wallet(
        attestationService = attestationService,
        identityPlatformInterface = identityPlatformInterface,
        localStorage = localStorage,
        repository = repository,
        getKeyPair = signingKeyPairFactory,
        clientConfiguration = clientConfiguration,
        trustConfiguration = trustConfiguration,
    )
}

@OptIn(ExperimentalTime::class)
@Throws(Exception::class)
suspend fun Wallet.refreshExpiredCredentials(clock: Clock = Clock.System) =
    refreshExpiredCredentials(clock.now().epochSeconds)

@SuppressLint("HardwareIds")
private fun getInstanceId(context: Context): String {
    val packageManager = context.packageManager
    val info = packageManager.getPackageInfo(context.packageName, 0)

    val sdkNamespace =
        uuid5Of(Uuid.fromString("00000000-0000-0000-0000-000000000000"), "com.iproov.identity")
    val appId = info.packageName
    val deviceId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)

    val appNamespace = uuid5Of(sdkNamespace, appId)
    return uuid5Of(appNamespace, deviceId).toString()
}

fun Wallet.startProximityRetrieval(
    nfcTag: Tag,
    requestedDocuments: List<DocumentRequest>,
    createSigningData: (suspend () -> ReaderSigningData)? = null,
    config: ProximityConfig.Reader = ProximityConfig.Reader(),
): ProximityRetrievalSession {
    if (!isBleAvailable()) {
        throw ProximityNotSupportedException(
            "NFC retrieval requires BLE for data transfer, which isn't available on this device ."
        )
    }

    // Run the multipaz handover synchronously against the supplied tag.
    // Tag was detected by the consumer's NfcAdapter callback and is fresh.
    val outcome = runBlocking {
        val isoDep =
            IsoDep.get(nfcTag)
                ?: throw ProximityRetrievalException("NFC tag does not support IsoDep")
        isoDep.connect()
        isoDep.timeout = 20_000

        val negotiated = config.negotiatedHandoverMethods(org.multipaz.util.UUID.randomUUID())

        val nfcIsoTag = NfcIsoTagAndroid(
            tag = isoDep,
            context = Dispatchers.Default,
            updateMessage = { /* unused — consumer controls their own dialog */ },
        )

        val handoverResult = mdocReaderNfcHandover(nfcIsoTag, negotiated)
            ?: throw ProximityRetrievalException("NFC handover failed — tag is not an NDEF mdoc")

        val deviceEngagement = DeviceEngagement.fromDataItem(
            Cbor.decode(handoverResult.encodedDeviceEngagement.toByteArray())
        )

        val transport = MdocTransportFactory.Default.createTransport(
            connectionMethod = config.selectBleMethod(handoverResult.connectionMethods)
                ?: throw ProximityRetrievalException(config.noUsableBleModeMessage),
            role = MdocRole.MDOC_READER,
            options = MDOC_TRANSPORT_OPTIONS,
        )

        ProximityRetrievalSession.EngagementOutcome(
            deviceEngagement, transport, handoverResult.handover,
        )
    }

    return buildRetrievalSession(
        engagementSource = {
            send(ProximityRetrievalEvent.Engagement.Nfc.Completed)
            outcome
        },
        requestedDocuments = requestedDocuments,
        createSigningData = createSigningData,
        config = config,
    )
}
