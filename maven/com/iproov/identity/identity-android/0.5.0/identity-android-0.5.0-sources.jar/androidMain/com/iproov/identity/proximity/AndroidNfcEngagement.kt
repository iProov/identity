package com.iproov.identity.proximity

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.iproov.identity.AppContext
import com.iproov.identity.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Android NFC HCE engagement (ISO 18013-5 §8.2.2.1). Wraps the host activity's
 * NFC enable/disable lifecycle and aborts any in-flight engagement on disable.
 */
internal class AndroidNfcEngagement : NfcEngagement {

    @Volatile
    private var enabled = false

    override val isServiceRegistered: Boolean get() = hasMdocAidRegistered()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override val isEnabled: Boolean get() = enabled

    override fun enable(): Boolean {
        if (!isServiceRegistered) {
            Logger.error(
                "NfcEngagement.enable() was called but no HCE service in this app " +
                        "registers AID $MDOC_NDEF_AID under category 'other'. NFC engagement " +
                        "will not receive taps. Check that your AndroidManifest.xml declares " +
                        "a HostApduService subclass of IsoMdocHceService with the correct " +
                        "AID xml resource. See README §NFC setup."
            )
            return false
        }
        enabled = true
        return true
    }

    override fun disable() {
        enabled = false
        // Abort any in-flight session so it fails fast instead of timing out.
        scope.launch {
            NfcEngagementRegistry.current()?.takeIf { !it.isComplete }?.abort(
                IllegalStateException("NFC engagement disabled while session active")
            )
        }
    }

    private fun hasMdocAidRegistered(): Boolean {
        val context: Context = try {
            AppContext.get()
        } catch (_: Exception) {
            return false
        }
        val pm = context.packageManager

        val services = pm.queryIntentServices(
            Intent(NFC_APDU_INTENT),
            PackageManager.GET_META_DATA,
        ).filter { it.serviceInfo.packageName == context.packageName }

        return services.any { resolveInfo ->
            val info = resolveInfo.serviceInfo
            val xmlResId = info.metaData?.getInt(NFC_HOST_APDU_META_DATA, 0) ?: 0
            if (xmlResId == 0) return@any false

            try {
                val res = pm.getResourcesForApplication(info.applicationInfo)
                res.getXml(xmlResId).use { parser ->
                    parseStaticAidsForCategory(parser, REQUIRED_CATEGORY)
                        .any { it.equals(MDOC_NDEF_AID, ignoreCase = true) }
                }
            } catch (e: Exception) {
                Logger.debug("HCE manifest XML parse failed: ${e.message}")
                false
            }
        }
    }

    private fun parseStaticAidsForCategory(
        parser: android.content.res.XmlResourceParser,
        requiredCategory: String,
    ): List<String> {
        val aids = mutableListOf<String>()
        var inMatchingGroup = false
        var event = parser.eventType
        while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name) {
                    "aid-group" -> inMatchingGroup =
                        parser.getAttributeValue(ANDROID_NS, "category") == requiredCategory

                    "aid-filter" -> if (inMatchingGroup) {
                        parser.getAttributeValue(ANDROID_NS, "name")?.let { aids.add(it) }
                    }
                }

                org.xmlpull.v1.XmlPullParser.END_TAG ->
                    if (parser.name == "aid-group") inMatchingGroup = false
            }
            event = parser.next()
        }
        return aids
    }


    companion object {
        private const val MDOC_NDEF_AID = "D2760000850101"
        private const val NFC_APDU_INTENT = "android.nfc.cardemulation.action.HOST_APDU_SERVICE"
        private const val NFC_HOST_APDU_META_DATA = "android.nfc.cardemulation.host_apdu_service"
        private const val REQUIRED_CATEGORY = "other"
        private const val ANDROID_NS = "http://schemas.android.com/apk/res/android"
    }
}