package com.iproov.identity.models

import com.iproov.identity.persistence.CredentialSubmission
import com.iproov.identity.persistence.DCQLMatchResult
import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC


@Serializable
enum class ResponseMode {
    @SerialName("fragment")
    FRAGMENT,

    @SerialName("query")
    QUERY,

    @SerialName("direct_post")
    DIRECT_POST,

    @SerialName("direct_post.jwt")
    DIRECT_POST_JWT,

    @SerialName("dc_api")
    DC_API,

    @SerialName("dc_api.jwt")
    DC_API_JWT
}


@Serializable(with = SupportedJWEEncryptionAlgorithmsSerializer::class)
enum class SupportedJWEEncryptionAlgorithms(val algorithmValue: String) {
    AES_GCM_128("A128GCM");

    companion object {
        fun fromValue(algorithmValue: String) =
            SupportedJWEEncryptionAlgorithms.entries.firstOrNull {
                it.algorithmValue == algorithmValue
            }
                ?: throw IllegalArgumentException("Unknown SupportedJWEEncryptionAlgorithms value: $algorithmValue")

    }
}

object SupportedJWEEncryptionAlgorithmsSerializer : KSerializer<SupportedJWEEncryptionAlgorithms> {
    override val descriptor: SerialDescriptor =
        PrimitiveSerialDescriptor("SupportedJWEEncryptionAlgorithms", PrimitiveKind.STRING)

    override fun serialize(encoder: Encoder, value: SupportedJWEEncryptionAlgorithms) =
        encoder.encodeString(value.algorithmValue)

    override fun deserialize(decoder: Decoder): SupportedJWEEncryptionAlgorithms {
        val algorithmValue = decoder.decodeString()
        return SupportedJWEEncryptionAlgorithms.fromValue(algorithmValue)
    }
}

@Serializable(with = MDocSupportedAlgorithmSerializer::class)
enum class MDocSupportedAlgorithm(val algorithmValue: Int) {
    HMAC_256_ECDH_P_256(-65537), // HMAC 256/256 using ECDH with Curve P-256
    HMAC_256_ECDH_P_384(-65538),  // HMAC 256/256 using ECDH with Curve P-384
    HMAC_256_ECDH_P_521(-65539), // HMAC 256/256 using ECDH with Curve P-521
    HMAC_256_ECDH_X25519(-65540);// HMAC 256/256 using ECDH with X25519

    companion object {
        fun fromValue(algorithmValue: Int) = MDocSupportedAlgorithm.entries.firstOrNull {
            it.algorithmValue == algorithmValue
        } ?: throw IllegalArgumentException("Unknown MDocSupportedAlgorithm value: $algorithmValue")

    }
}

object MDocSupportedAlgorithmSerializer : KSerializer<MDocSupportedAlgorithm> {
    override val descriptor: SerialDescriptor =
        PrimitiveSerialDescriptor("MDocSupportedAlgorithm", PrimitiveKind.INT)

    override fun serialize(encoder: Encoder, value: MDocSupportedAlgorithm) =
        encoder.encodeInt(value.algorithmValue)

    override fun deserialize(decoder: Decoder): MDocSupportedAlgorithm {
        val algorithmValue = decoder.decodeInt()
        return MDocSupportedAlgorithm.fromValue(algorithmValue)
    }
}

@Serializable
data class SupportedVPFormat(
    @SerialName("mso_mdoc")
    val mdoc: MDoc? = null
) {

    @Serializable
    data class MDoc(

        /**
         * A list of  algorithms the wallet will accept from an issuer when issuing a credential
         * (found in the IssuerAuth)
         */
        @SerialName("issuerauth_alg_values")
        val issuerAuthAlgorithm: List<MDocSupportedAlgorithm>? = null,

        @SerialName("deviceauth_alg_values")
        val deviceAuthAlgorithms: List<MDocSupportedAlgorithm>? = null
    )
}

@Serializable
data class OID4VPCapabilities(
    @EncodeDefault
    @SerialName("response_types_supported")
    val responseTypesSupported: List<String> = listOf("vp_token"),

    @SerialName("response_modes_supported")
    val responseModesSupported: List<String>,

    @SerialName("vp_formats_supported")
    val supportedVPFormat: SupportedVPFormat,

    @SerialName("client_id_prefixes_supported")
    val clientIdPrefixesSupported: List<String>? = null,

    @EncodeDefault
    @SerialName("request_object_signing_alg_values_supported")
    val requestObjectSigningAlgValuesSupported: List<String> = listOf("ES256"),

    @SerialName("encrypted_response_enc_values_supported")
    val supportedResponseEncryptionAlgorithms: List<String>? = null
)

data class CredentialQueryMatchResult(
    val metadata: CredentialMetadata,
    val credential: Credential,

    /**
     * Claim being requested to the value found in the credential
     */
    val matchingClaims: Map<ClaimQuery, Any>
)

class Query(
    val raw: JsonObject,

    /**
     * A derived definition of what the verifier is asking for
     */
    val definition: DcqlQuery,

    /**
     * Execute the query on the wallet to return the credentials that match
     */
    private val onExecute: suspend () -> DCQLMatchResult
) {

    suspend fun execute() = onExecute()
}

@OptIn(ExperimentalObjCRefinement::class)
open class PresentationRequest(
    @HiddenFromObjC
    val raw: JsonObject,

    /**
     * Information about the relying party.
     */
    val verifier: Verifier,


    val request: AuthorizationRequest,

    val query: Query
)

class RespondablePresentationRequest(
    private val presentationRequest: PresentationRequest,
    private val onRespond: suspend (CredentialSubmission) -> PresentationOutcome,
) : PresentationRequest(
    presentationRequest.raw,
    presentationRequest.verifier,
    request = presentationRequest.request,
    query = presentationRequest.query
) {

    suspend fun respond(submission: CredentialSubmission) = onRespond(submission)
}