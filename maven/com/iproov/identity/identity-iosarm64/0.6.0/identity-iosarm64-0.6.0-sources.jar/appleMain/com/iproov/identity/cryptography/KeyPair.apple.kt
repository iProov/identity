package com.iproov.identity.cryptography

import com.iproov.identity.AppleKeychainSharing
import com.iproov.identity.Logger
import com.iproov.identity.isAppExtension
import com.iproov.identity.persistence.createCFDictionary
import com.iproov.identity.persistence.toByteArray
import com.iproov.identity.persistence.toCFData
import com.iproov.identity.persistence.toCFNumber
import com.iproov.identity.persistence.toCFString
import kotlinx.cinterop.COpaquePointerVar
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.readBytes
import kotlinx.cinterop.toKString
import kotlinx.cinterop.usePinned
import kotlinx.cinterop.value
import platform.CoreFoundation.CFDataGetBytePtr
import platform.CoreFoundation.CFDataGetLength
import platform.CoreFoundation.CFDictionaryGetValue
import platform.CoreFoundation.CFDictionaryRef
import platform.CoreFoundation.CFErrorCopyDescription
import platform.CoreFoundation.CFErrorGetCode
import platform.CoreFoundation.CFErrorRef
import platform.CoreFoundation.CFErrorRefVar
import platform.CoreFoundation.CFRelease
import platform.CoreFoundation.CFRetain
import platform.CoreFoundation.CFStringGetCString
import platform.CoreFoundation.CFStringGetLength
import platform.CoreFoundation.CFStringGetMaximumSizeForEncoding
import platform.CoreFoundation.CFStringRef
import platform.CoreFoundation.kCFAllocatorDefault
import platform.CoreFoundation.kCFBooleanTrue
import platform.CoreFoundation.kCFStringEncodingUTF8
import platform.Foundation.CFBridgingRelease
import platform.Foundation.NSString
import platform.Security.SecAccessControlCreateWithFlags
import platform.Security.SecItemCopyMatching
import platform.Security.SecItemDelete
import platform.Security.SecItemUpdate
import platform.Security.SecKeyCopyAttributes
import platform.Security.SecKeyCopyExternalRepresentation
import platform.Security.SecKeyCopyPublicKey
import platform.Security.SecKeyCreateDecryptedData
import platform.Security.SecKeyCreateEncryptedData
import platform.Security.SecKeyCreateRandomKey
import platform.Security.SecKeyCreateSignature
import platform.Security.SecKeyRef
import platform.Security.errSecSuccess
import platform.Security.kSecAttrAccessControl
import platform.Security.kSecAttrAccessGroup
import platform.Security.kSecAttrAccessibleWhenUnlockedThisDeviceOnly
import platform.Security.kSecAttrApplicationTag
import platform.Security.kSecAttrIsPermanent
import platform.Security.kSecAttrKeySizeInBits
import platform.Security.kSecAttrKeyType
import platform.Security.kSecAttrKeyTypeECSECPrimeRandom
import platform.Security.kSecAttrTokenID
import platform.Security.kSecAttrTokenIDSecureEnclave
import platform.Security.kSecClass
import platform.Security.kSecClassKey
import platform.Security.kSecKeyAlgorithmECDSASignatureMessageX962SHA256
import platform.Security.kSecKeyAlgorithmECIESEncryptionCofactorX963SHA256AESGCM
import platform.Security.kSecPrivateKeyAttrs
import platform.Security.kSecReturnRef
import kotlin.experimental.and
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import com.iproov.identity.cryptography.KeyPair as SdkKeyPair

// The secure enclave gives us the signature as ASN.1, however JWT requires
// that the signature is the raw R and S values.
// So we need to unpack the ASN.1 signature, extract the R & S values, then
// concatenate them and re-encode them back to base64.
//actual fun getRSFromSignature(signature: String): String {
//    return signature
//}

private object Constants {
    @OptIn(ExperimentalForeignApi::class)
    val keyType = kSecAttrKeyTypeECSECPrimeRandom

    const val keySize = 256

    @OptIn(ExperimentalForeignApi::class)
    val encryptionAlgorithm = kSecKeyAlgorithmECIESEncryptionCofactorX963SHA256AESGCM

    @OptIn(ExperimentalForeignApi::class)
    val signatureAlgorithm = kSecKeyAlgorithmECDSASignatureMessageX962SHA256

    val asn1Header = byteArrayOf(
        0x30,
        0x59,
        0x30,
        0x13,
        0x06,
        0x07,
        0x2A,
        0x86.toByte(),
        0x48,
        0xCE.toByte(),
        0x3D,
        0x02,
        0x01,
        0x06,
        0x08,
        0x2A,
        0x86.toByte(),
        0x48,
        0xCE.toByte(),
        0x3D,
        0x03,
        0x01,
        0x07,
        0x03,
        0x42,
        0x00
    )

}

@OptIn(ExperimentalForeignApi::class)
class AppleKeyPair @Throws(Throwable::class) constructor(
    private val tag: String,
    private val accessControlPolicy: KeyPairAccessPolicy,
) : SdkKeyPair, EncryptionKey {

    /**
     * Read per use rather than captured, so a key created before storage was configured still picks
     * up the group. Null means this key is private to the app.
     */
    private val accessGroup: String?
        get() = AppleKeychainSharing.accessGroup

    enum class Location {
        SECURE_ENCLAVE,
        KEYCHAIN;

        val stringValue: String
            get() {
                return when (this) {
                    SECURE_ENCLAVE -> "secureEnclave"
                    KEYCHAIN -> "keychain"
                }
            }
    }

    private var privateKey: SecKeyRef

    /**
     * The lookup/delete query, shared by [init] and [reset].
     *
     * Deliberately unscoped: it searches every access group this process can reach, which is what
     * finds a key created before the app adopted a shared group. Adding [accessGroup] here could
     * only ever narrow the result, never find something this does not.
     */
    private fun keychainQuery() = mutableMapOf(
        kSecClass to kSecClassKey,
        kSecAttrApplicationTag to tag.encodeToByteArray().toCFData(),
        kSecAttrKeyType to Constants.keyType,
        kSecReturnRef to kCFBooleanTrue,
    )

    private fun findPrivateKey(): SecKeyRef? = memScoped {
        val query = createCFDictionary(keychainQuery())
        try {
            val itemPtr = alloc<COpaquePointerVar>()
            if (SecItemCopyMatching(query, itemPtr.ptr) == errSecSuccess) itemPtr.value as SecKeyRef
            else null
        } finally {
            CFRelease(query)
        }
    }

    init {
        // Creating a key is only ever correct in the containing app, on first run. An extension that
        // cannot see the app's key must fail: minting one there signs with a key the credential's MSO
        // does not commit to, so the verifier rejects the response, and it leaves a second key under
        // the same tag in the shared group — after which the app's own lookup is a coin toss.
        privateKey = findPrivateKey()?.also { migrateToAccessGroup() }
            ?: if (isAppExtension) {
                throw KeyPairException(
                    "No key '$tag' is reachable from this app extension. The containing app must " +
                            "create it and share it through a keychain access group."
                )
            } else {
                createPrivateKey(tag)
            }
    }

    /**
     * Moves an existing key into [accessGroup] so an extension can reach it.
     *
     * Best-effort: on failure the key stays where it is and the app keeps working, losing only
     * extension access. Safe to call on every lookup — updating a key to the group it is already in
     * is a no-op.
     */
    private fun migrateToAccessGroup() {
        val group = accessGroup ?: return
        Logger.info("Moving key '$tag' into keychain access group $group.")
        val query = createCFDictionary(
            keychainQuery().also { it.remove(kSecReturnRef) }
        )
        val attributes = createCFDictionary(mutableMapOf(kSecAttrAccessGroup to group.toCFString()))
        try {
            val status = SecItemUpdate(query, attributes)
            if (status != errSecSuccess) {
                Logger.error("Keychain access-group migration failed ($status); key left in place.")
            }
        } finally {
            CFRelease(query)
            CFRelease(attributes)
        }
    }

    // This is lazy to avoid unnecessary calls to SecKeyCopyPublicKey
    // the use of the key pair is always through a getter and never stored in memory as a
    // property so this can be kept in memory for the lifetime of the getter.
    private val _publicKey: SecKeyRef by lazy {
        SecKeyCopyPublicKey(privateKey)
            ?: throw KeyPairException("Failed to get public key")
    }

    @Throws(Throwable::class)
    override fun getJwk(): EllipticCurvePublicKey {
        return EllipticCurvePublicKey(
            alg = "ES256",
            jwk = derToJwk(publicKey)
        )
    }

    @Throws(Throwable::class)
    override fun getPublicKey(): ByteArray = publicKey

    private val publicKey: ByteArray
        get() = memScoped {
            val error = alloc<CFErrorRefVar>()
            val pkDataRef = SecKeyCopyExternalRepresentation(
                _publicKey,
                error.ptr
            ) ?: throw KeyPairException("Failed to get public key: ${error.value}")

            val length = CFDataGetLength(pkDataRef)
            val bytes = CFDataGetBytePtr(pkDataRef)

            val publicKeyBytes = bytes?.readBytes(length.toInt())?.also {
                CFRelease(pkDataRef)
            } ?: throw KeyPairException("Failed to read public key bytes from reference")

            Logger.info("Raw DER bytes: ${publicKeyBytes.contentToString()}") // Log the raw bytes

            return Constants.asn1Header.plus(publicKeyBytes)
        }

    private val location: Location by lazy {
        val tokenID = memScoped {
            val ref =
                SecKeyCopyAttributes(privateKey)
                    ?: throw KeyPairException("Failed to key location of private key")

            val tokenID = getCFDictionaryValue(ref, kSecAttrTokenID) as NSString?
            CFRelease(ref)

            return@memScoped tokenID;
        }
        val isLocationSecureEnclave = tokenID != null && tokenID.equals("com.apple.setoken")

        if (isLocationSecureEnclave) Location.SECURE_ENCLAVE else Location.KEYCHAIN
    }

    @Throws(Throwable::class)
    override fun sign(data: ByteArray): ByteArray {
        var signedData: ByteArray
        memScoped {
            val errorRefVar = alloc<CFErrorRefVar>()
            Logger.debug("Signing data")
            val result = SecKeyCreateSignature(
                privateKey,
                Constants.signatureAlgorithm,
                data.toCFData(),
                errorRefVar.ptr
            )

            if (result == null) {
                // Check if user canceled
                val errorRef = errorRefVar.value
                throw mapCFErrorToException(errorRef)
            }

            signedData = result.toByteArray()
            CFRelease(result)
        }
        return signedData
    }

    @Throws(Throwable::class)
    override fun encrypt(data: ByteArray): ByteArray {
        Logger.debug("Using KeyPair to encrypt data")
        var encrypted: ByteArray
        memScoped {
            val errorRefVar = alloc<CFErrorRefVar>()
            val result = SecKeyCreateEncryptedData(
                _publicKey,
                Constants.encryptionAlgorithm,
                data.toCFData(),
                errorRefVar.ptr
            )

            if (result == null) {
                val errorRef = errorRefVar.value

                try {
                    throw mapCFErrorToException(errorRef)
                } finally {
                    // Release the CFError we were given
                    CFRelease(errorRef)
                }
            }

            Logger.debug("Encryption complete")
            encrypted = result.toByteArray()
            CFRelease(result)
        }
        return encrypted
    }

    @Throws(Throwable::class)
    override fun decrypt(data: ByteArray): ByteArray {
        Logger.debug("Attempting decryption")
        var decrypted: ByteArray
        memScoped {
            val errorRefVar = alloc<CFErrorRefVar>()

            val result = SecKeyCreateDecryptedData(
                privateKey,
                Constants.encryptionAlgorithm,
                data.toCFData(),
                errorRefVar.ptr
            )

            if (result == null) {
                val errorRef = errorRefVar.value

                if (errorRef != null) {
                    try {
                        throw mapCFErrorToException(errorRef)
                    } finally {
                        // Release the CFError we were given
                        CFRelease(errorRef)
                    }
                }

                // If we get here we have no usable CFError or it wasn't from kSecErrorDomain
                Logger.error("Failed to decrypt data, no usable CFError or it wasn't from kSecErrorDomain")
                throw EncryptionKeyException("Failed to decrypt the data.")
            }

            decrypted = result.toByteArray()
            CFRelease(result)
        }
        return decrypted
    }

    @Throws(Throwable::class)
    override fun getKeySecurityLevel() = location.stringValue

    @Throws(Throwable::class)
    override fun reset() {
        // Unscoped: destroy must find the key whether or not it was migrated into the access group.
        val query = createCFDictionary(keychainQuery())
        val status = SecItemDelete(query)
        CFRelease(query)
        if (status != errSecSuccess) throw KeyPairException("Unable to delete key pair. Status: $status")
    }

    private fun createPrivateKey(
        tag: String,
        location: Location = Location.SECURE_ENCLAVE
    ): SecKeyRef = memScoped {
        val error = alloc<CFErrorRefVar>()
        // Standard Keychain supports these flags (UserPresence, Biometry, etc.) on modern iOS.
        Logger.debug("Attempting to create private key in $location with flags: ${accessControlPolicy.accessControlFlags}")
        val access = SecAccessControlCreateWithFlags(
            kCFAllocatorDefault,
            kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            flags = accessControlPolicy.accessControlFlags,
            error.ptr,
        ) ?: throw KeyPairException("Failed to create SecAccessControl: ${error.value}")

        // Setting the access group at creation makes placement independent of the order of the
        // app's keychain-access-groups entitlement, whose first entry would otherwise decide it.
        // A key created elsewhere can still be moved later — SecItemUpdate on kSecAttrAccessGroup
        // is a metadata change, not an export, so it works for Secure Enclave keys too.
        val privateKeyAttrs = createCFDictionary(
            mutableMapOf(
                kSecAttrApplicationTag to tag.encodeToByteArray().toCFData(),
                kSecAttrIsPermanent to kCFBooleanTrue,
                kSecAttrAccessControl to access,
            ).apply {
                accessGroup?.let { this[kSecAttrAccessGroup] = it.toCFString() }
            }
        )

        val attrs = mutableMapOf(
            kSecAttrKeyType to Constants.keyType,
            kSecAttrKeySizeInBits to Constants.keySize.toCFNumber(),
            kSecPrivateKeyAttrs to privateKeyAttrs,
        )

        // Only add the TokenID if we are specifically targeting the Secure Enclave
        if (location == Location.SECURE_ENCLAVE) {
            attrs[kSecAttrTokenID] = kSecAttrTokenIDSecureEnclave
        }

        val params = createCFDictionary(attrs)

        val privkey = SecKeyCreateRandomKey(
            params,
            error.ptr
        )

        CFRelease(access)
        CFRelease(params)
        CFRelease(privateKeyAttrs)

        if (privkey == null) {
            // Cleanup before recursive call/return
            if (location == Location.SECURE_ENCLAVE) {
                Logger.info("Failed to create key in secure enclave ${error.value}, falling back to Keychain.")
                return createPrivateKey(tag, Location.KEYCHAIN)
            } else {
                Logger.info("Failed to create key in Keychain ${error.value}")
                throw KeyPairException("Failed to create private key ${error.value}")
            }
        }

        return privkey
    }
}

@OptIn(ExperimentalForeignApi::class)
fun getCFDictionaryValue(dictionary: CFDictionaryRef?, key: CFStringRef?): Any? {
    val valuePtr = CFDictionaryGetValue(dictionary, key) ?: return null

    // CFDictionaryGetValue follows "Get Rule" - we don't own it
    // If we need to bridge to Kotlin/ARC, retain first then bridge
    CFRetain(valuePtr)
    return CFBridgingRelease(valuePtr)
}

@OptIn(ExperimentalEncodingApi::class)
@Throws(Throwable::class)
fun derToJwk(derBytes: ByteArray): OnDeviceKeyPairJwk {
    val (curveName, x, y) = parseEcPublicKeyFromDer(derBytes)

    // Base64Url encode x and y
    val xBase64Url = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT).encode(x)
    val yBase64Url = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT).encode(y)

    // Create the JWK JSON
    return OnDeviceKeyPairJwk(
        curveName,
        "EC",
        xBase64Url,
        yBase64Url,
    )

}

// Look at making this more platform agnnostic
@Throws(Throwable::class)
fun parseEcPublicKeyFromDer(derBytes: ByteArray): Triple<String, ByteArray, ByteArray> {
    // Basic DER parsing logic (simplified for common structures)
    var index = 0

    // Ensure we start with a SEQUENCE
    if (derBytes[index] != 0x30.toByte()) throw KeyPairException("Invalid DER: Not a SEQUENCE")
    index++

    // Get total SEQUENCE length
    val lengthInfo = derBytes[index].toLength(derBytes, index + 1)
    index += lengthInfo.lengthBytes

    // Skip AlgorithmIdentifier SEQUENCE
    if (derBytes[index] != 0x30.toByte()) throw KeyPairException("Invalid DER: Missing AlgorithmIdentifier")
    index++

    val algoLengthInfo = derBytes[index].toLength(derBytes, index + 1)
    index += algoLengthInfo.lengthBytes + algoLengthInfo.value

    // Parse the public key BIT STRING
    if (derBytes[index] != 0x03.toByte()) throw KeyPairException("Invalid DER: Missing BIT STRING")
    index++

    val bitStringLengthInfo = derBytes[index].toLength(derBytes, index + 1)
    index += bitStringLengthInfo.lengthBytes

    // Skip unused bits byte
    index++

    // Extract x and y from the uncompressed EC public key
    if (derBytes[index] != 0x04.toByte()) throw KeyPairException("Invalid EC Public Key: Expected uncompressed format")
    index++

    val keyLength = (bitStringLengthInfo.value - 1) / 2
    val x = derBytes.copyOfRange(index, index + keyLength)
    val y = derBytes.copyOfRange(index + keyLength, index + 2 * keyLength)

    // Determine curve name based on key size
    val curveName = when (keyLength * 8) {
        256 -> "P-256"
        384 -> "P-384"
        521 -> "P-521"
        else -> throw KeyPairException("Unsupported curve size: ${keyLength * 8}")
    }

    return Triple(curveName, x, y)
}

@Throws(Throwable::class)
fun Byte.toLength(input: ByteArray, startIndex: Int): Length {
    if (this and 0x80.toByte() == 0.toByte()) {
        // Single-byte length
        return Length(value = this.toInt(), lengthBytes = 1)
    }

    // Multi-byte length
    val numBytes = this and 0x7F.toByte()
    if (numBytes <= 0 || startIndex + numBytes >= input.size) {
        throw KeyPairException("Invalid DER length encoding")
    }

    var value = 0
    for (i in 0 until numBytes.toInt()) {
        value = (value shl 8) or (input[startIndex + i].toInt() and 0xFF)
    }

    return Length(value = value, lengthBytes = numBytes.toInt() + 1)
}

data class Length(val value: Int, val lengthBytes: Int)

@Throws(Throwable::class)
actual fun getDeviceBoundKeyPair(policy: KeyPairAccessPolicy, alias: String): SdkKeyPair =
    AppleKeyPair(alias, policy)

// Helper to extract the localized description from a CFErrorRef
@OptIn(ExperimentalForeignApi::class)
private fun getErrorDescription(errorRef: CFErrorRef?): String {
    if (errorRef == null) return "Unknown error"

    // CFErrorCopyLocalizedDescription returns a retained CFStringRef
    val cfString = CFErrorCopyDescription(errorRef)

    return if (cfString != null) {
        // Convert CFString to Kotlin String using built-in interop
        // Note: In some KMP versions, you might need to interpret the pointer.
        // The standard 'toString()' on a CFStringRef often works or use bridges.
        // A safe, manual conversion approach:
        val length = CFStringGetLength(cfString)
        val maxSize = CFStringGetMaximumSizeForEncoding(length, kCFStringEncodingUTF8)
        val buffer = ByteArray(maxSize.toInt() + 1)

        val success = buffer.usePinned { pinned ->
            CFStringGetCString(
                cfString,
                pinned.addressOf(0),
                buffer.size.toLong(),
                kCFStringEncodingUTF8
            )
        }

        CFRelease(cfString) // Important: Release the string we copied

        if (success) buffer.toKString() else "Error decoding description"
    } else {
        "Unknown error"
    }
}

@OptIn(ExperimentalForeignApi::class)
private fun mapCFErrorToException(errorRef: CFErrorRef?): CryptographyException {

    val errorCode = CFErrorGetCode(errorRef).toInt()
    val systemMessage = getErrorDescription(errorRef) // Extract the text

    Logger.error("Crypto failure: $errorCode - $systemMessage")
    when (errorCode) {
        // --- Cancellation ---
        // errSecUserCanceled (-128) OR kLAErrorUserCancel (-2)
        -128, -2 -> {
            Logger.error("The user canceled authentication (Code: $errorCode): $systemMessage")
            return KeyPairAuthenticationCanceled()
        }

        // --- Biometric/Auth Failures ---
        // errSecAuthFailed (-25293)
        // errSecInteractionNotAllowed (-25308)
        // kLAErrorAuthenticationFailed (-1)
        // kLAErrorBiometryLockout (-8)
        -25293, -25308, -1, -8 -> {
            Logger.error("Authentication failed or locked out: (Code=$errorCode)")
            return KeyPairAuthenticationError(
                "Biometric authentication failed: $systemMessage"
            )
        }

        // --- System/App Interruptions ---
        // kLAErrorAppCancel (-9), kLAErrorSystemCancel (-4)
        -9, -4 -> {
            Logger.error("Authentication interrupted by system/app: (Code=$errorCode)")
            return KeyPairAuthenticationError(
                "Authentication interrupted: $systemMessage"
            )
        }

        else -> {
            Logger.error("Failed to decrypt data with unknown error: $errorCode")
            // Pass the specific code up for debugging
            return KeyPairAuthenticationError(
                "Keychain/Auth error while decrypting: $systemMessage"
            )
        }
    }
}
