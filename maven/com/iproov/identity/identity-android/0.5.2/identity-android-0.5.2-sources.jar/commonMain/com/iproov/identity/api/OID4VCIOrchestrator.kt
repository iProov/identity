package com.iproov.identity.api

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.OID4VCIClientConfiguration
import com.iproov.identity.models.CredentialDescriptor
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialOffer
import com.iproov.identity.models.CredentialRecord
import com.iproov.identity.models.IssuanceResult
import com.iproov.identity.models.IssuanceSummary
import com.iproov.identity.models.OID4VCICredentialError
import com.iproov.identity.models.OID4VCIException
import com.iproov.identity.models.RespondableCredentialOffer
import com.iproov.identity.models.TransactionCodeChallenge
import com.iproov.identity.persistence.Repository
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

interface OID4VCIOrchestrator {
    @Throws(Exception::class)
    suspend fun addCredential(uri: String): RespondableCredentialOffer

    @Throws(Exception::class)
    suspend fun addCredential(offer: JsonObject): RespondableCredentialOffer
}

internal class DefaultOID4VCIOrchestrator(
    /**
     * A way to sign data to create the PoP when retrieving credentials
     * (should not be a reference to a single keypair itself, in case the keypair is destroyed when
     * the wallet instance is deleted)
     */
    val keyPairFactory: KeyPairFactory,

    /**
     * The repository is used to store the credentials & metadata
     */
    val repository: Repository,

    /**
     * The networking client is used to communicate with the issuer during the protocol
     */
    val networkClient: NetworkClient,

    /**
     * The app's OAuth client. Required by authorization-code issuance; pre-authorized issuance
     * falls back to the platform's client ID without it.
     */
    val clientConfiguration: OID4VCIClientConfiguration? = null,
) : OID4VCIOrchestrator {

    private val client: OID4VCIClient by lazy {
        createOID4VCIClient(keyPairFactory, networkClient, clientConfiguration)
    }

    private val json = Json { }

    override suspend fun addCredential(uri: String): RespondableCredentialOffer {
        Logger.debug("Resolving credential offer from URI: $uri")
        val offer = client.resolveOffer(uri)
        return processCredentialOffer(offer)
    }

    override suspend fun addCredential(offer: JsonObject): RespondableCredentialOffer {
        val resolvedOffer = client.resolveOffer(offer)
        return processCredentialOffer(resolvedOffer)
    }

    /**
     * Process a credential offer through the full issuance flow.
     * Handles transaction code requirements, authorization code flow, and credential storage.
     */
    private fun processCredentialOffer(offer: CredentialOffer) =
        RespondableCredentialOffer.fromCredentialOffer(
            offer = offer,
            onAccept = @Throws(Exception::class) { credentials ->
                when {
                    credentials.isEmpty() -> IssuanceResult.Empty

                    offer.transactionCodeDetails == null -> {
                        Logger.info("No transaction code required, proceeding with credential issuance")
                        val summary = issueAndStoreCredentials(offer, credentials, transactionCode = null)
                        IssuanceResult.Immediate(summary)
                    }

                    else -> {
                        Logger.info("Transaction code required: ${json.encodeToString(offer.transactionCodeDetails)}")
                        val challenge = TransactionCodeChallenge(
                            details = offer.transactionCodeDetails!!,
                            onRespond = @Throws(Exception::class) { txCode ->
                                issueAndStoreCredentials(offer, credentials, transactionCode = txCode)
                            }
                        )
                        IssuanceResult.TransactionCodeRequired(challenge)
                    }
                }
            },
            onAuthorize = @Throws(Exception::class) { credentials ->
                when {
                    credentials.isEmpty() -> IssuanceResult.Empty

                    else -> {
                        // prepareAuthorizationRequest validates the app's configuration before it
                        // touches the network, on both platforms.
                        Logger.info("Preparing authorization code flow")
                        val preparation = client.prepareAuthorizationRequest(offer, credentials)
                        Logger.debug("Authorization URL: ${preparation.authorizationUrl}")

                        IssuanceResult.AuthorizationRequired(
                            authorizationUrl = preparation.authorizationUrl,
                            onAuthorizationResponse = @Throws(Exception::class) { authorizationCode, authorizationState, iss ->
                                Logger.info("Received authorization code, issuing credentials")
                                validateAuthorizationResponseIssuer(
                                    iss = iss,
                                    expectedIssuer = preparation.authorizationServerIssuer,
                                    issParameterSupported = preparation.issParameterSupported,
                                    acceptUnadvertisedIss = clientConfiguration
                                        ?.acceptUnadvertisedIssParameter == true,
                                )
                                val result = client.issueCredentialsWithAuthCode(
                                    offer = offer,
                                    authorizationCode = authorizationCode,
                                    authorizationState = authorizationState,
                                    preparation = preparation,
                                    credentials = credentials,
                                )
                                processIssuanceResult(offer, credentials, result)
                            }
                        )
                    }
                }
            },
        )

    /**
     * Issue credentials using the pre-authorized code flow and store them in the repository.
     */
    private suspend fun issueAndStoreCredentials(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
        transactionCode: String?
    ): IssuanceSummary {
        Logger.info("Issuing ${credentials.size} credential(s)")
        val result = client.issueCredentials(offer, credentials, transactionCode)
        return processIssuanceResult(offer, credentials, result)
    }

    /**
     * Process an issuance result: store credentials in the repository and build an IssuanceSummary.
     * Shared by both pre-authorized code and authorization code flows.
     */
    private suspend fun processIssuanceResult(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
        result: OID4VCIIssuanceResult,
    ): IssuanceSummary {
        val descriptorsByConfigId = credentials.associateBy { it.id }
        val credentialsAdded = mutableListOf<CredentialMetadata>()
        val errors = mutableMapOf<CredentialMetadata, OID4VCICredentialError>()

        // Process successfully issued credentials
        for (issuedData in result.credentials) {
            val descriptor = descriptorsByConfigId[issuedData.configurationId]

            Logger.debug("Processing credential '${issuedData.configurationId}': format=${issuedData.format}, deferred=${issuedData.isDeferred}")

            val metadata = buildMetadata(offer, descriptor, issuedData.format)

            if (issuedData.isDeferred) {
                errors[metadata] = OID4VCICredentialError(
                    error = "deferred_not_supported",
                    description = "Deferred credential issuance is not yet supported"
                )
            } else {
                val record = CredentialRecord(format = issuedData.format, data = issuedData.rawCredential)
                repository.addCredentialRecord(metadata, record)
                credentialsAdded.add(metadata)
                Logger.info("Stored credential: ${metadata.format}" + (issuedData.credentialIdentifier?.let { " (identifier: $it)" } ?: ""))
            }
        }

        // Process errors returned by the issuer
        for (issuanceError in result.errors) {
            Logger.error("Credential '${issuanceError.configurationId}' failed: ${issuanceError.error.error} - ${issuanceError.error.description}")

            val descriptor = descriptorsByConfigId[issuanceError.configurationId]
            val metadata = buildMetadata(offer, descriptor, descriptor?.format ?: "unknown")
            errors[metadata] = issuanceError.error
        }

        return IssuanceSummary(credentialsAdded, errors)
    }

    private fun buildMetadata(
        offer: CredentialOffer,
        descriptor: CredentialDescriptor?,
        format: String,
    ) = CredentialMetadata(
        issuer = offer.issuer,
        offer = descriptor?.raw ?: JsonObject(emptyMap()),
        format = format,
        display = descriptor?.display?.values?.toList() ?: emptyList()
    )
}

/**
 * Checks the `iss` of an authorization response against the authorization server the request was
 * sent to, as RFC 9207 Section 2.4 requires.
 *
 * This is a mix-up defence (RFC 9700 Section 4.4), not a profile feature: without it a wallet that
 * talks to more than one issuer can be walked into redeeming a code at the wrong authorization
 * server. HAIP 1.0 Section 4 inherits the requirement from FAPI 2.0, but nothing here is gated on
 * HAIP — an authorization server that does not implement RFC 9207 simply sends no [iss], and the
 * comparison is skipped.
 *
 * @param iss the `iss` query parameter of the redirect, or null if it carried none.
 * @param expectedIssuer [AuthorizationPreparation.authorizationServerIssuer].
 * @param issParameterSupported [AuthorizationPreparation.issParameterSupported].
 * @param acceptUnadvertisedIss
 * [com.iproov.identity.OID4VCIClientConfiguration.acceptUnadvertisedIssParameter].
 * @throws com.iproov.identity.models.OID4VCIException.CreatingAccessToken with error
 * `invalid_iss` or `missing_iss`.
 */
internal fun validateAuthorizationResponseIssuer(
    iss: String?,
    expectedIssuer: String?,
    issParameterSupported: Boolean,
    acceptUnadvertisedIss: Boolean = false,
) {
    // RFC 8414 Section 2 compares issuer identifiers as strings, so a mismatch is either an
    // authorization server that normalizes its own identifier inconsistently — a trailing slash is
    // the usual one — or a response from a server the request never went to.
    val isMismatch = iss != null && expectedIssuer != null && iss != expectedIssuer

    // The opt-out covers only a server that never advertised the parameter, which is the extent of
    // the local policy RFC 9207 Section 2.4 permits. A server that sets
    // authorization_response_iss_parameter_supported is compared whatever the app configured, so
    // the mix-up defence cannot be disabled for a server that says it applies.
    val mismatchIsFatal = issParameterSupported || !acceptUnadvertisedIss

    when {
        isMismatch && mismatchIsFatal -> {
            Logger.error(
                "Rejected the authorization response: its iss \"$iss\" is not the authorization " +
                    "server the request was sent to (\"$expectedIssuer\"). This is the RFC 9207 " +
                    "check that stops an authorization code being redeemed at the wrong server. " +
                    "To fix: confirm the issuer's iss matches the issuer value in its " +
                    "/.well-known metadata exactly, including any trailing slash, and that the " +
                    "redirect was not replayed from a different issuance attempt." +
                    // The app asked for leniency and did not get it, which is worth saying outright.
                    if (acceptUnadvertisedIss) {
                        " This server advertises " +
                            "authorization_response_iss_parameter_supported, so " +
                            "acceptUnadvertisedIssParameter does not apply to it."
                    } else {
                        ""
                    }
            )
            throw OID4VCIException.CreatingAccessToken(
                error = "invalid_iss",
                description = "Authorization response iss \"$iss\" is not the authorization " +
                    "server the request was sent to (\"$expectedIssuer\").",
            )
        }

        // Reached only with acceptUnadvertisedIssParameter set and a server that published no
        // support for the parameter. Logged at every use: this is the one path where a code is
        // redeemed at a server the response did not prove it came from.
        isMismatch -> Logger.info(
            "Accepted an authorization response whose iss \"$iss\" is not the authorization " +
                "server the request was sent to (\"$expectedIssuer\"), because the wallet is " +
                "configured with acceptUnadvertisedIssParameter and this server does not " +
                "advertise authorization_response_iss_parameter_supported. The RFC 9207 mix-up " +
                "check did not run for this issuance. Clear that flag once the issuer publishes " +
                "an issuer identifier matching the iss it sends."
        )

        // RFC 9207 Section 2.4: the server advertised the parameter, so a response without it is
        // rejected rather than treated as a pre-RFC 9207 server.
        iss == null && issParameterSupported -> {
            Logger.error(
                "Rejected the authorization response: it carried no iss, but the authorization " +
                    "server advertises authorization_response_iss_parameter_supported. To fix: " +
                    "pass the redirect's iss query parameter to respond(), and check that " +
                    "nothing between the browser and your app strips query parameters."
            )
            throw OID4VCIException.CreatingAccessToken(
                error = "missing_iss",
                description = "Authorization server advertises " +
                    "authorization_response_iss_parameter_supported but the authorization " +
                    "response carried no iss.",
            )
        }

        iss == null -> Logger.info(
            "Authorization response carried no iss and the authorization server does not " +
                "advertise support for it, so the RFC 9207 check was skipped. Issuance " +
                "continues; this server cannot be checked against a mix-up attack."
        )

        expectedIssuer == null -> Logger.info(
            "Authorization response carried iss \"$iss\" but the authorization server metadata " +
                "published no issuer to compare it against, so the RFC 9207 check was skipped."
        )

        else -> Logger.debug("Authorization response iss matches the authorization server.")
    }
}
