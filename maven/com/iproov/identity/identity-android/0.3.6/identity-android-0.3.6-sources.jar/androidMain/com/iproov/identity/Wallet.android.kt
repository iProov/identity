package com.iproov.identity

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import com.benasher44.uuid.Uuid
import com.benasher44.uuid.uuid5Of
import com.iproov.identity.api.AndroidIdentityPlatformInterface
import com.iproov.identity.api.ApiClient
import com.iproov.identity.attestation.AndroidAttestationService
import com.iproov.identity.persistence.CredentialDeserializer
import com.iproov.identity.persistence.LegacyCredentialDeserializer
import com.iproov.identity.persistence.LocalStorage
import com.iproov.identity.persistence.Repository
import com.iproov.identity.persistence.StorageEngine
import com.iproov.identity.trust.TrustEvaluator
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

actual fun getWalletInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
    trustEvaluator: TrustEvaluator,
    legacyCredentialDeserializer: LegacyCredentialDeserializer, // Remove when when legacy credentials have been removed
    credentialDeserializer: CredentialDeserializer,
): Wallet {
    val context = AppContext.get()
    val instanceId = getInstanceId(context)
    val platform = AndroidPlatform(context, instanceId)
    val apiClient = ApiClient(baseUrl, signingKeyPairFactory, platform, instanceId)
    val identityPlatformInterface =
        AndroidIdentityPlatformInterface(apiClient, platform, signingKeyPairFactory)
    val attestationService =
        AndroidAttestationService(identityPlatformInterface, signingKeyPairFactory, context)

    val localStorage = LocalStorage(storageEngine)
    val repository = Repository(localStorage, legacyCredentialDeserializer, credentialDeserializer)
    Logger.isEnabled = isLoggingEnabled

    return Wallet(
        attestationService,
        identityPlatformInterface,
        localStorage,
        repository,
        signingKeyPairFactory,
        trustEvaluator,
    )
}

@OptIn(ExperimentalTime::class)
@Throws(Exception::class)
suspend fun Wallet.refreshExpiredCredentials(clock: Clock = Clock.System) =
    refreshExpiredCredentials(clock.now().epochSeconds)

@SuppressLint("HardwareIds")
private fun getInstanceId(context: Context): String {
    val packageManager = context.packageManager
    val info = packageManager.getPackageInfo(context.packageName, 0)

    val sdkNamespace =
        uuid5Of(Uuid.fromString("00000000-0000-0000-0000-000000000000"), "com.iproov.identity")
    val appId = info.packageName
    val deviceId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)

    val appNamespace = uuid5Of(sdkNamespace, appId)
    return uuid5Of(appNamespace, deviceId).toString()
}
