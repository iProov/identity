package com.iproov.identity.proximity

/**
 * Plain English: What does this device support?
 *
 * Static platform-capability checks for proximity transports.
 *
 * These answer "can this device, in principle, ever perform <transport>?" — pure
 * hardware/capability introspection with no side effects. They do NOT prompt the
 * user, request runtime permissions, or check whether the relevant radio is
 * currently powered on. Those concerns surface as Failure events at session start.
 *
 * Cheap enough to call repeatedly; safe to call from any thread.
 */

/** True if the device can advertise as a BLE peripheral (ISO 18013-5 §8.3.3.1.1). */
expect fun isProximityPlatformAvailable(): Boolean

/** True if the device supports NFC Host Card Emulation (ISO 18013-5 §8.2.2.1). */
expect fun isNfcHceAvailable(): Boolean

/**
 * True if NFC is currently enabled by the user in system settings.
 *
 * Distinct from [isNfcHceAvailable]: that one is a static hardware-capability
 * check, while this one reflects the runtime on/off state of the adapter.
 */
expect fun isNfcAdapterEnabled(): Boolean


/**
 * True if the device can perform reader-side NFC scanning right now (ISO 18013-5
 * §8.2.2 from the mdoc-reader perspective).
 *
 * Combined check: hardware present + adapter enabled (Android) / entitlement
 * granted (iOS). Distinct from [isNfcHceAvailable], which is HCE-specific
 * (mdoc-holder side). iOS can never emulate as a holder but CAN read tags, so
 * these two answer different questions and must not be confused.
 */
expect fun isNfcReaderAvailable(): Boolean

/**
 * Returns the platform's [NfcEngagement] implementation.
 *
 * Lazily invoked inside [DefaultProximityOrchestrator] when consumers call
 * `nfcEngagement()`. Consumers don't call this directly.
 *
 * Mirrors the role that `createPlatformDCApiRegistrar()` plays for DC API.
 *
 * @throws NfcEngagementUnavailableException on platforms without HCE (currently all iOS).
 * Android returns an AndroidNfcEngagement.
 */
internal expect fun createPlatformNfcEngagement(): NfcEngagement
