package com.iproov.identity.models

val ClaimQuery.values get() = this.values?.map { it.toNativeTypes() }

val CredentialQuery.meta get() = this.meta?.toNativeTypes()
