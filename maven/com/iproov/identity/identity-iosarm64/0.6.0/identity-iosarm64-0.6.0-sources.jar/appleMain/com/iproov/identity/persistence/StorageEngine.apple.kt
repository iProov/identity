package com.iproov.identity.persistence

import com.iproov.identity.AppleKeychainSharing
import com.iproov.identity.Logger
import com.iproov.identity.attestation.toNSData
import com.iproov.identity.cryptography.AppleKeyPair
import com.iproov.identity.cryptography.CryptographyException
import com.iproov.identity.cryptography.EncryptionKey
import com.iproov.identity.cryptography.EncryptionKeyFactory
import com.iproov.identity.cryptography.KeyPairAccessPolicy
import com.iproov.identity.cryptography.assertEncryptionKeyProducesCiphertext
import com.iproov.identity.cryptography.resetBestEffort
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.io.IOException
import kotlinx.io.files.FileNotFoundException
import platform.Foundation.NSDate
import platform.Foundation.NSDictionary
import platform.Foundation.NSNotificationCenter
import platform.Foundation.timeIntervalSinceReferenceDate
import platform.UIKit.UIApplicationDidEnterBackgroundNotification
import kotlin.concurrent.Volatile
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/** One lock for every engine in the process: the wallet file is shared state, each instance's cache is not. */
private val storeMutex = Mutex()

class DeviceBoundAppleStorageEngine private constructor(
    val appGroupIdentifier: String,
    private val keychainAccessGroup: String?,
    val accessControlPolicy: KeyPairAccessPolicy,
    // Custom storage-encryption key; when null the SDK uses its own Secure Enclave / Keychain key.
    private val encryptionKeyFactory: EncryptionKeyFactory?,
) : StorageEngine {

    @Throws(Exception::class)
    constructor(
        appGroupIdentifier: String,
        accessControlPolicy: KeyPairAccessPolicy = KeyPairAccessPolicy.DeviceUnlocked,
    ) : this(appGroupIdentifier, null, accessControlPolicy, null)

    /**
     * Creates storage backed by a caller-supplied encryption key.
     *
     */
    @Throws(Exception::class)
    constructor(
        appGroupIdentifier: String,
        accessControlPolicy: KeyPairAccessPolicy,
        encryptionKeyFactory: EncryptionKeyFactory,
    ) : this(appGroupIdentifier, null, accessControlPolicy, encryptionKeyFactory)

    /**
     * Enables the Digital Credentials API: the SDK keys are shared with the document-provider extension
     * through the keychain group, so both entitlements are required from here on.
     *
     * @param keychainAccessGroup Team-ID-prefixed, e.g. "ABCDE12345.com.example.wallet.signing".
     */
    @Throws(Exception::class)
    constructor(
        appGroupIdentifier: String,
        accessControlPolicy: KeyPairAccessPolicy,
        keychainAccessGroup: String,
    ) : this(appGroupIdentifier, keychainAccessGroup, accessControlPolicy, null)

    /**
     * Bring-your-own-key with the Digital Credentials API enabled.
     *
     * The caller-supplied key is responsible for its own keychain sharing; only the file
     * container and the SDK's own encryption key are handled here.
     */
    @Throws(Exception::class)
    constructor(
        appGroupIdentifier: String,
        accessControlPolicy: KeyPairAccessPolicy,
        encryptionKeyFactory: EncryptionKeyFactory,
        keychainAccessGroup: String,
    ) : this(appGroupIdentifier, keychainAccessGroup, accessControlPolicy, encryptionKeyFactory)

    // Serialises cache access and file I/O across every engine instance in this process.
    private val mutex = storeMutex

    // In-memory cache of the decrypted data
    private var cachedData: MutableMap<String, String?>? = null

    // Stamp of the file the cache was filled from. Another engine, in this process or another, may have
    // written since; a moved stamp forces a reload so a stale cache is never served or written back.
    private var loadedStamp: String? = null

    private fun isCacheCurrent(): Boolean = fileStorage.stamp() == loadedStamp

    // Timestamp of the last successful authentication (decrypt) or write
    private var lastAuthenticatedTime: Double = 0.0

    // Flag indicating if an authentication operation is in progress
    // If authenticating, we should not clear the cache on backgrounding
    @Volatile
    private var isAuthenticating: Boolean = false

    private val fileStorage: FileStorage
        get() = FileStorage(WALLET_FILE_NAME, appGroupIdentifier)

    // Avoid holding a reference to the key, it can be deleted at any time.
    private val encryptionKey: EncryptionKey
        get() = encryptionKeyFactory?.invoke()
            ?: AppleKeyPair("com.iproov.identity.encryption", accessControlPolicy)

    private var encryptionKeyValidated = false

    /** Guards a caller key once before first use so a no-op key can't silently persist plaintext; the
     *  SDK's own key is trusted and skipped. Called only under [mutex]. */
    private fun validateCallerKeyOnce(key: EncryptionKey) {
        if (encryptionKeyFactory == null || encryptionKeyValidated) return
        assertEncryptionKeyProducesCiphertext(key)
        encryptionKeyValidated = true
    }

    init {
        require(appGroupIdentifier.isNotBlank()) { "appGroupIdentifier must not be blank." }
        if (keychainAccessGroup != null && !fileStorage.hasSharedContainer) {
            throw StorageException(
                "App Group container unavailable for '$appGroupIdentifier'. Add the App Groups entitlement " +
                        "to the app and the extension before enabling sharing."
            )
        }
        // Keys and the DC API registrar read this configuration process-wide, so a second engine with
        // different groups would silently reconfigure the first. Identical configuration is fine.
        val publishedGroup = AppleKeychainSharing.appGroupIdentifier
        if (publishedGroup != null &&
            (publishedGroup != appGroupIdentifier || AppleKeychainSharing.accessGroup != keychainAccessGroup)
        ) {
            throw StorageException(
                "A DeviceBoundAppleStorageEngine is already configured in this process with App Group " +
                        "'$publishedGroup' and keychain group '${AppleKeychainSharing.accessGroup}'. " +
                        "Construct one engine per process."
            )
        }
        // Published only after validation, so a failed construction leaves earlier configuration untouched.
        // The signing key is created far from here, with no other route to these values.
        AppleKeychainSharing.appGroupIdentifier = appGroupIdentifier
        AppleKeychainSharing.accessGroup = keychainAccessGroup

        // SECURITY: Automatically wipe memory when App enters background
        // This ensures if the user switches apps, the data is locked immediately.
        NSNotificationCenter.defaultCenter.addObserverForName(
            name = UIApplicationDidEnterBackgroundNotification,
            `object` = null,
            queue = null
        ) { _ ->
            if (!isAuthenticating) {
                Logger.debug("App entering background: Wiping secure storage cache.")
                cachedData = null
                lastAuthenticatedTime = 0.0
            } else {
                Logger.debug("App backgrounded during auth - preserving cache.")
            }
        }
    }

    /**
     * Internal helper: Loads, Decrypts, and parses data from disk.
     * WARNING: This triggers FaceID/Biometrics if the key requires it.
     */
    @Throws(IOException::class, FileNotFoundException::class, CryptographyException::class)
    private fun loadFromDisk(): MutableMap<String, String?> {
        fileStorage.checkLocation()
        if (!fileStorage.fileHasBeenCreated) {
            Logger.debug("Storage file has not been created, returning empty.")
            loadedStamp = null
            return mutableMapOf()
        }

        Logger.debug("Loading from disk (may trigger FaceID)...")
        isAuthenticating = true
        // Stamped before the read: a write landing in between then looks newer than what we hold.
        val stamp = fileStorage.stamp()
        try {
            val key = encryptionKey
            validateCallerKeyOnce(key)
            val encryptedArchivedData = fileStorage.read()
            val archivedData = key.decrypt(encryptedArchivedData.toByteArray())
            val data = fileStorage.unarchiveData(archivedData.toNSData())
            loadedStamp = stamp
            return (data as? Map<String, String?>)?.toMutableMap() ?: mutableMapOf()
        } catch (e: Exception) {
            // The cache may describe a file that has since changed; never serve or write it back.
            cachedData = null
            lastAuthenticatedTime = 0.0
            throw e
        } finally {
            isAuthenticating = false
        }
    }

    /**
     * Internal helper: Encrypts and writes data to disk.
     * Usually uses Public Key, so FaceID is NOT required.
     */
    private fun saveToDisk(dictionary: Map<String, String?>) {
        fileStorage.checkLocation()
        val key = encryptionKey
        validateCallerKeyOnce(key)
        val archivedData = fileStorage.archiveDictionary(dictionary as NSDictionary)
        val encryptedData = key.encrypt(archivedData.toByteArray())

        fileStorage.write(encryptedData.toNSData())
        fileStorage.preventBackup()
        loadedStamp = fileStorage.stamp()
    }

    /**
     * Checks if the current in-memory cache is valid and not expired.
     */
    private fun isSessionValid(): Boolean {
        if (cachedData == null) return false

        val currentTime = NSDate.timeIntervalSinceReferenceDate()
        val elapsed = currentTime - lastAuthenticatedTime

        return elapsed < accessControlPolicy.authenticationValidityDuration
    }

    private fun startSession(data: MutableMap<String, String?>) {
        cachedData = data
        lastAuthenticatedTime = NSDate.timeIntervalSinceReferenceDate()
    }

    override suspend fun read(key: String): String? = mutex.withLock {
        Logger.debug("Reading $key ...")

        // 1. Check Cache (Fast Path - No FaceID)
        if (isSessionValid() && isCacheCurrent()) {
            Logger.debug("Session valid. Returning from cache.")
            return cachedData!![key]
        }

        // 2. Load from Disk (Slow Path - Triggers FaceID)
        val data = try {
            loadFromDisk()
        } catch (e: Exception) {
            Logger.error("Failed to load secure storage: ${e.message}")
            throw e
        }

        // 3. Update Session
        startSession(data)

        return data[key]
    }

    override suspend fun write(key: String, value: String?): Unit = mutex.withLock {
        // Start from the committed state: the cache if it is valid and still matches the file on disk,
        // else disk (may prompt FaceID).
        val current = if (isSessionValid() && isCacheCurrent()) {
            cachedData!!
        } else {
            loadFromDisk()
        }

        // Persist before touching the cache: a failed encrypt/write must never leave the cache
        // holding a value that was never written to disk.
        val updated = current.toMutableMap()
        if (value == null) {
            updated.remove(key)
        } else {
            updated[key] = value
        }

        saveToDisk(updated)

        // Commit succeeded — adopt the new state as the session cache.
        startSession(updated)

        Logger.debug("Wrote $key to secure storage.")
    }

    override suspend fun deleteAll(): Unit = mutex.withLock {
        cachedData = null
        loadedStamp = null
        fileStorage.delete()
        encryptionKey.resetBestEffort()
        Logger.debug("Deleted all secure storage data.")
    }
}

private const val IOS_STORAGE_HINT =
    "On iOS, construct DeviceBoundAppleStorageEngine(appGroupIdentifier, accessControlPolicy) and pass it as storageEngine."

/** iOS storage needs an App Group, which the common contract cannot supply. */
@OptIn(ExperimentalObjCRefinement::class)
@HiddenFromObjC
actual fun getDeviceBoundStorageEngine(accessPolicy: KeyPairAccessPolicy): StorageEngine =
    throw StorageException(IOS_STORAGE_HINT)

@OptIn(ExperimentalObjCRefinement::class)
@HiddenFromObjC
actual fun getDeviceBoundStorageEngine(
    accessPolicy: KeyPairAccessPolicy,
    encryptionKeyFactory: EncryptionKeyFactory,
): StorageEngine = throw StorageException(IOS_STORAGE_HINT)
