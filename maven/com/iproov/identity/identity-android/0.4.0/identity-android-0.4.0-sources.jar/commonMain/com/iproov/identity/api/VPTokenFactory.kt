package com.iproov.identity.api


import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.dcapi.BrowserHandoverInfo
import com.iproov.identity.models.AuthorizationRequest
import com.iproov.identity.models.DeviceResponse
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.OpenID4VPDCAPIHandover
import com.iproov.identity.models.OpenID4VPHandover
import com.iproov.identity.models.PresentationRequest
import com.iproov.identity.models.ResponseMode
import com.iproov.identity.models.SdJwtVcCredential
import com.iproov.identity.models.hash
import com.iproov.identity.persistence.CredentialSubmission
import com.iproov.identity.persistence.DisclosedCredential
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.cbor.ByteString
import kotlinx.serialization.cbor.CborArray
import kotlinx.serialization.cbor.CborTag
import kotlinx.serialization.cbor.ValueTags
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.time.Clock

@OptIn(ExperimentalSerializationApi::class)
class VPTokenFactory(
    val keyPairFactory: KeyPairFactory,
) {

    val json = Json { prettyPrint = false }

    /**
     * Create a VP Token based on the provided Authorization Request & Credentials selected by the user.
     */
    suspend fun build(
        presentationRequest: PresentationRequest,
        submission: CredentialSubmission,
        jwkThumbprint: ByteArray? = null // JWK thumbprint of the key used to encrypt the VP Token (for direct_post.jwt)
    ): String {
        Logger.debug("Building VP Token for OpenID4VP")
        Logger.debug("Submission: $submission")
        val vp = buildJsonObject {
            submission.disclosedCredentials.forEach { (query, credential) ->
                val encodedMatch = buildSelectedMatch(
                    presentationRequest, credential, jwkThumbprint
                )
                put(query.id, buildJsonArray { add(JsonPrimitive(encodedMatch)) })
            }

        }
        return json.encodeToString(JsonObject.serializer(), vp)
    }

    /**
     * Create a VP Token for DC API (Digital Credentials API) requests.
     *
     * DC API uses a different SessionTranscript structure based on ISO 18013-7 Annex C
     * for browser-initiated credential requests.
     *
     * @param presentationRequest The presentation request from the verifier
     * @param submission The user's credential selection
     * @param browserHandoverInfo Browser handover information for session transcript (null for non-browser contexts)
     * @param jwkThumbprint JWK thumbprint for encrypted responses (dc_api.jwt)
     */
    fun buildForDCApi(
        presentationRequest: PresentationRequest,
        submission: CredentialSubmission,
        browserHandoverInfo: BrowserHandoverInfo?,
        jwkThumbprint: ByteArray? = null
    ): String {
        Logger.debug("Building VP Token for DC API")
        Logger.debug("Submission: $submission")
        Logger.debug("BrowserHandoverInfo: $browserHandoverInfo")

        val vp = buildJsonObject {
            submission.disclosedCredentials.forEach { (query, credential) ->
                val encodedMatch = buildSelectedMatchForDCApi(
                    presentationRequest, credential, browserHandoverInfo, jwkThumbprint
                )
                put(query.id, buildJsonArray { add(JsonPrimitive(encodedMatch)) })
            }
        }
        return json.encodeToString(JsonObject.serializer(), vp)
    }

    private fun buildSelectedMatchForDCApi(
        presentationRequest: PresentationRequest,
        selectedCredential: DisclosedCredential,
        browserHandoverInfo: BrowserHandoverInfo?,
        jwkThumbprint: ByteArray?
    ): String = when (selectedCredential.credential) {
        is MDocCredential -> buildMDocMatchForDCApi(
            presentationRequest, selectedCredential, browserHandoverInfo, jwkThumbprint
        )

        is SdJwtVcCredential -> buildSdJwtVcMatch(presentationRequest, selectedCredential)
    }

    /**
     * Build mDoc match for DC API with browser handover session transcript.
     * Calls DeviceResponse.buildForDCApi() directly with the appropriate parameters.
     */
    private fun buildMDocMatchForDCApi(
        presentationRequest: PresentationRequest,
        selectedCredential: DisclosedCredential,
        browserHandoverInfo: BrowserHandoverInfo?,
        jwkThumbprint: ByteArray?
    ): String {
        val credential = selectedCredential.credential as MDocCredential

        val handoverInfo = browserHandoverInfo ?: BrowserHandoverInfo(
            origin = presentationRequest.request.redirectUri.orEmpty(),
            nonce = requireNotNull(presentationRequest.request.nonce) {
                "nonce is required for session transcript"
            },
            requesterKeyHash = jwkThumbprint
        )

        val authorizationRequest = AuthorizationRequest(
            clientId = handoverInfo.origin,
            nonce = handoverInfo.nonce,
            responseUri = null,
            responseType = "vp_token",
            responseMode = ResponseMode.DC_API,
            redirectUri = null,
            dcqlQuery = null,
            scope = null,
            state = null,
            clientMetadata = null,
            raw = ""
        )

        val deviceResponseBytes = DeviceResponse.buildForDCApi(
            authorizationRequest = authorizationRequest,
            credential = credential,
            claims = selectedCredential.claims.toList(),
            deviceKeyPair = keyPairFactory(),
            browserHandoverInfo = handoverInfo,
        )

        Logger.debug("DeviceResponse (DC API): ${deviceResponseBytes.toHexString()}")
        return base64Url(deviceResponseBytes)
    }

    private fun buildSelectedMatch(
        presentationRequest: PresentationRequest, selectedCredential: DisclosedCredential,
        jwkThumbprint: ByteArray?, // Only needed for direct_post.jwt
    ): String = when (selectedCredential.credential) {
        is MDocCredential -> buildMDocMatch(presentationRequest, selectedCredential, jwkThumbprint)
        is SdJwtVcCredential -> buildSdJwtVcMatch(presentationRequest, selectedCredential)
    }

    /**
     * For mDoc: each value is base64url(DeviceResponse CBOR).
     * Calls DeviceResponse.build() directly with the appropriate parameters.
     */
    private fun buildMDocMatch(
        presentationRequest: PresentationRequest,
        selectedCredential: DisclosedCredential,
        jwkThumbprint: ByteArray?, // Only needed for direct_post.jwt
    ): String {
        require(presentationRequest.request.responseUri != null) {
            "response_uri is required for OpenID4VP direct_post"
        }

        val credential = selectedCredential.credential as MDocCredential

        // Use resolved client_id for session transcript (extracts DNS SAN for X509 schemes)
        val resolvedClientId = presentationRequest.request.clientId ?: ""
        Logger.debug("Resolved client_id for session transcript: $resolvedClientId (original: ${presentationRequest.request.clientId})")

        val clientId = resolvedClientId.ifEmpty {
            requireNotNull(presentationRequest.request.clientId) {
                "client_id is required for OpenID4VP session transcript"
            }
        }
        val nonce = requireNotNull(presentationRequest.request.nonce) {
            "nonce is required for OpenID4VP session transcript"
        }
        val responseUri = requireNotNull(presentationRequest.request.responseUri) {
            "response_uri is required for OpenID4VP direct_post"
        }

        val authorizationRequest = AuthorizationRequest(
            clientId = clientId,
            nonce = nonce,
            responseUri = responseUri,
            responseType = "vp_token",
            responseMode = ResponseMode.DIRECT_POST,
            redirectUri = null,
            dcqlQuery = null,
            scope = null,
            state = null,
            clientMetadata = null,
            raw = ""
        )

        val deviceResponseBytes = DeviceResponse.build(
            authorizationRequest = authorizationRequest,
            credential = credential,
            claims = selectedCredential.claims.toList(),
            deviceKeyPair = keyPairFactory(),
            jwkThumbprint = jwkThumbprint
        )

        Logger.debug("DeviceResponse: ${deviceResponseBytes.toHexString()}")
        return base64Url(deviceResponseBytes)
    }

    /**
     * For SD-JWT-VC: return the SD-JWT presentation with selected disclosures and optional KB-JWT.
     */
    @OptIn(ExperimentalEncodingApi::class)
    private fun buildSdJwtVcMatch(
        presentationRequest: PresentationRequest,
        selectedCredential: DisclosedCredential,
    ): String {
        val credential = selectedCredential.credential as SdJwtVcCredential
        Logger.debug("Building SD-JWT-VC presentation for vct: ${credential.vct}")

        // Extract claim names from the selected claims
        // ClaimQuery.path for SD-JWT is typically [claim_name] (single element)
        val claimNames = selectedCredential.claims
            .mapNotNull { it.path.lastOrNull() }
            .toSet()

        Logger.debug("Selected claims for disclosure: $claimNames")

        // Create the presentation
        val presentation = if (credential.requiresKeyBinding) {
            Logger.debug("Creating SD-JWT-VC presentation with key binding")

            val nonce = presentationRequest.request.nonce
            val audience = presentationRequest.request.clientId

            credential.createPresentation(
                claimNames = claimNames,
                nonce = nonce,
                audience = audience,
                keyBindingJwtFactory = { n, aud, sdHash ->
                    createKeyBindingJwt(n, aud, sdHash)
                }
            )
        } else {
            Logger.debug("Creating SD-JWT-VC presentation without key binding")
            credential.createPresentation(claimNames = claimNames)
        }

        Logger.debug("SD-JWT-VC presentation created: ${presentation.take(100)}...")
        return presentation
    }

    /**
     * Create a Key Binding JWT for SD-JWT-VC presentation.
     *
     * KB-JWT structure:
     * Header: { "typ": "kb+jwt", "alg": "ES256" }
     * Payload: { "iat": <timestamp>, "aud": <verifier>, "nonce": <nonce>, "sd_hash": <hash> }
     */
    @OptIn(ExperimentalEncodingApi::class)
    private fun createKeyBindingJwt(
        nonce: String,
        audience: String,
        sdJwtHash: String
    ): String {
        val keyPair = keyPairFactory()
        val ecPublicKey = keyPair.getJwk()

        // Build JWK object for header
        val jwkJson = buildJsonObject {
            put("kty", JsonPrimitive(ecPublicKey.jwk.kty))
            put("crv", JsonPrimitive(ecPublicKey.jwk.crv))
            put("x", JsonPrimitive(ecPublicKey.jwk.x))
            put("y", JsonPrimitive(ecPublicKey.jwk.y))
        }

        // Build header
        val header = buildJsonObject {
            put("typ", JsonPrimitive("kb+jwt"))
            put("alg", JsonPrimitive("ES256"))
            put("jwk", jwkJson)
        }

        // Build payload
        val now = Clock.System.now().epochSeconds
        val payload = buildJsonObject {
            put("iat", JsonPrimitive(now))
            put("aud", JsonPrimitive(audience))
            put("nonce", JsonPrimitive(nonce))
            put("sd_hash", JsonPrimitive(sdJwtHash))
        }

        // Encode header and payload
        val headerB64 =
            base64Url(json.encodeToString(JsonObject.serializer(), header).encodeToByteArray())
        val payloadB64 =
            base64Url(json.encodeToString(JsonObject.serializer(), payload).encodeToByteArray())

        // Sign (need to convert DER signature to R||S format for JWT)
        val signingInput = "$headerB64.$payloadB64"
        val derSignature = keyPair.sign(signingInput.encodeToByteArray())
        val rsSignature = com.iproov.identity.cryptography.asn1ToRs(derSignature)
        val signatureB64 = base64Url(rsSignature)

        Logger.debug("Created KB-JWT for SD-JWT-VC presentation")
        return "$headerB64.$payloadB64.$signatureB64"
    }
}

/**
 * SessionTranscript for OpenID4VP (redirect/direct_post profile).
 * DeviceEngagementBytes = null, EReaderKeyBytes = null, Handover = ["OpenID4VPHandover", SHA-256(CBOR(info))]
 */
@CborArray
@Serializable
data class SessionTranscript(
    val deviceEngagementBytes: ByteArray?, // null for this profile
    val eReaderKeyBytes: ByteArray?,       // null for this profile
    val handover: OpenID4VPHandover,  // ("OpenID4VPHandover", sha256(CBOR(info)))
)

/**
 * SessionTranscript for OpenID4VP (redirect/direct_post profile).
 * DeviceEngagementBytes = null, EReaderKeyBytes = null, Handover = ["OpenID4VPHandover", SHA-256(CBOR(info))]
 */
@CborArray
@Serializable
data class SessionTranscriptDCAPI(
    val deviceEngagementBytes: ByteArray?, // null for this profile
    val eReaderKeyBytes: ByteArray?,       // null for this profile
    val handover: OpenID4VPDCAPIHandover,  // ("OpenID4VPHandover", sha256(CBOR(info)))
)

@CborArray
@Serializable
data class SessionTranscriptProximity(
    // Tag 24 wrapping per ISO/IEC 18013-5 §9.1.5.1: both byte strings are
    // CBOR-encoded data items, not raw bstrs. Must match the Multipaz form
    // used by SessionEncryption — otherwise the reader's verification fails.
    @ValueTags(CborTag.CBOR_ENCODED_DATA)
    @ByteString val deviceEngagementBytes: ByteArray,
    @ValueTags(CborTag.CBOR_ENCODED_DATA)
    @ByteString val eReaderKeyBytes: ByteArray,
    val handover: Nothing? = null,
)

/* ======================= Utilities ======================= */

private fun base64Url(bytes: ByteArray): String =
    Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT).encode(bytes)

internal fun sha256(bytes: ByteArray): ByteArray = hash(bytes)
