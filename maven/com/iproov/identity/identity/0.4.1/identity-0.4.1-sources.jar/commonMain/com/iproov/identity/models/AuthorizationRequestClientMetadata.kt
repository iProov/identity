package com.iproov.identity.models

import com.iproov.identity.api.sha256
import io.ktor.utils.io.core.toByteArray
import io.matthewnelson.encoding.core.Encoder.Companion.encodeToString
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable


/**
 * Verifier-provided metadata (a.k.a. client_metadata) sent in the Authorization Request.
 * Used by the Wallet to understand the Verifier’s crypto & format preferences.
 *
 * Spec usage examples:
 * - Include a JWKS for encrypting the Authorization Response (e.g., direct_post.jwt)
 * - Declare supported VP formats/parameters (e.g., proof types for LDP-VC)
 * - Indicate the JWE encryption content cipher for the response
 */
@Serializable
data class AuthorizationRequestClientMetadata(
    /** Human-friendly name for UX (optional). */
    @SerialName("client_name")
    val clientName: String? = null,

    /** Which VP formats & knobs the Verifier can process. */
    @SerialName("vp_formats_supported")
    val vpFormatsSupported: VpFormatsSupported? = null,

    /** Verifier's public keys (for encrypting responses, etc.). */
    val jwks: Jwks? = null,

    /**
     * JWE content-encryption algorithm for Authorization Response
     * when using a JWT-based direct_post.jwt (e.g., "A256GCM").
     */
    @SerialName("encrypted_response_enc_values_supported")
    val encryptedResponseSupportedAlgorithms: List<String>? = null
)

/**
 * Structured “vp_formats_supported”.
 * Keep fields optional so it remains forward-compatible.
 *
 * Examples from the spec:
 * - LDP VC: proof_type_values = ["DataIntegrityProof"]
 * - SD-JWT VC: vct_values = ["MembershipCardCredential"]
 */
@Serializable
data class VpFormatsSupported(
    @SerialName("jwt_vc_json")
    val jwtVcJson: JwtVcJsonPrefs? = null,

    @SerialName("ldp_vc")
    val ldpVc: LdpVcPrefs? = null,

    @SerialName("mso_mdoc")
    val msoMdoc: MsoMdocPrefs? = null,

    @SerialName("dc+sd-jwt")
    val dcSdJwt: DcSdJwtPrefs? = null
)

/** JWT-VC (W3C VC in JWS) preferences. */
@Serializable
data class JwtVcJsonPrefs(
    /** Preferred JWS algs, e.g., ["ES256"]. */
    @SerialName("alg_values")
    val algValues: List<String>? = null
)

/** Linked-Data VC preferences. */
@Serializable
data class LdpVcPrefs(
    /** Proof suites the Verifier accepts, e.g., ["DataIntegrityProof"]. */
    @SerialName("proof_type_values")
    val proofTypeValues: List<String>? = null
)

/** SD-JWT VC preferences. */
@Serializable
data class DcSdJwtPrefs(
    /** Accepted VC Types (vct), e.g., ["MembershipCardCredential"]. */
    @SerialName("vct_values")
    val vctValues: List<String>? = null
)

/** mDL / mdoc preferences. */
@Serializable
data class MsoMdocPrefs(
    /** Accepted doc types, e.g., ["org.iso.18013.5.1.mDL"]. */
    @SerialName("doctype_values")
    val doctypeValues: List<String>? = null
)

/** Minimal JWK(S) types for encryption keys. */
@Serializable
data class Jwks(
    val keys: List<Jwk> = emptyList()
)


@Serializable
enum class KeyUse {
    @SerialName("sig")
    SIG,

    @SerialName("enc")
    ENC
}

@Serializable
data class Jwk(
    val kty: String,
    val kid: String? = null,
    val use: KeyUse? = null,      // ENC in the OpenID4VP examples
    val alg: String? = null,
    val crv: String? = null,
    val x: String? = null,
    val y: String? = null,
    val n: String? = null,
    val e: String? = null,
    @SerialName("x5c") val x5c: List<String>? = null
) {
    /**
     * Compute JWK Thumbprint per RFC 7638.
     *
     * For EC keys: SHA-256({"crv":"...","kty":"EC","x":"...","y":"..."})
     * Members are in lexicographic order with no whitespace.
     */
    fun computeThumbprint(): ByteArray {
        val data = when (kty) {
            "EC" -> """{"crv":"$crv","kty":"$kty","x":"$x","y":"$y"}"""
            "RSA" -> """{"e":"$e","kty":"$kty","n":"$n"}"""
            else -> throw IllegalArgumentException("Unsupported kty: $kty")
        }
        println("[JWK Thumbprint] RFC 7638 JSON: $data")
        val thumbprint = sha256(data.encodeToByteArray())
        println("[JWK Thumbprint] SHA-256 result: ${thumbprint.toHexString()}")
        return thumbprint
    }

    private fun ByteArray.toHexString(): String =
        joinToString("") { (it.toInt() and 0xFF).toString(16).padStart(2, '0') }
}
