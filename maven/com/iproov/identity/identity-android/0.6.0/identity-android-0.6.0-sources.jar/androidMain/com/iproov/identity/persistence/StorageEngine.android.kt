package com.iproov.identity.persistence

import android.app.Activity
import android.content.Context
import java.security.KeyFactory
import java.security.KeyStore
import java.security.PrivateKey
import javax.crypto.BadPaddingException
import android.os.Build
import android.security.keystore.KeyInfo
import android.security.keystore.KeyProperties
import com.iproov.identity.AppContext
import com.iproov.identity.Logger
import com.iproov.identity.cryptography.AndroidDefaultKeyPair
import com.iproov.identity.cryptography.AndroidKeystoreAesKey
import com.iproov.identity.cryptography.EncryptionKey
import com.iproov.identity.cryptography.EncryptionKeyFactory
import com.iproov.identity.cryptography.KeyPairAccessPolicy
import com.iproov.identity.cryptography.KeyPairAuthenticationCanceled
import com.iproov.identity.cryptography.KeyPairAuthenticationError
import com.iproov.identity.cryptography.assertEncryptionKeyProducesCiphertext
import com.iproov.identity.cryptography.resetBestEffort
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

private const val EC_KEY_ALIAS = "com.iproov.identity.encryption"
private const val AES_KEY_ALIAS = "com.iproov.identity.encryption.aes"

/**
 * Below API 31 the default ECIES key can't decrypt, so storage uses AES. On 31+ AES stays in use once its key exists,
 * so data written before an OS upgrade remains readable. It is also used when the EC key is a sign-only one an earlier
 * release made below 31, whose data can never be decrypted, so the AES read discards it. Other 31+ installs keep ECIES.
 */
internal fun useAesStorageKey(sdkInt: Int, aesNeededOn31: () -> Boolean) =
    sdkInt < Build.VERSION_CODES.S || aesNeededOn31()

private fun ecStorageKeyIsSignOnly(): Boolean = runCatching {
    val key = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.getKey(EC_KEY_ALIAS, null) as? PrivateKey
        ?: return false
    val info = KeyFactory.getInstance(key.algorithm, "AndroidKeyStore").getKeySpec(key, KeyInfo::class.java)
    (info.purposes and KeyProperties.PURPOSE_AGREE_KEY) == 0
}.getOrDefault(false)

/** ECIES data (0x04-led) that an earlier release wrote below API 31, where it can never be decrypted. */
internal fun isUndecryptableLegacyData(readWithAesKey: Boolean, data: ByteArray, error: Throwable) =
    readWithAesKey && error is BadPaddingException && data.firstOrNull() == 0x04.toByte()

class DeviceBoundAndroidStorageEngine(
    private val context: Context,
    private val accessPolicy: KeyPairAccessPolicy = KeyPairAccessPolicy.DeviceUnlocked,
) : StorageEngine {

    // Custom storage-encryption key; when null the SDK uses its own device-bound key.
    private var encryptionKeyFactory: EncryptionKeyFactory? = null

    /**
     * Creates storage backed by a caller-supplied encryption key.
     *
     * This is a secondary constructor so the original two-argument JVM constructor and its
     * Kotlin default-argument bridge remain available to already-compiled consumers.
     */
    constructor(
        context: Context,
        accessPolicy: KeyPairAccessPolicy,
        encryptionKeyFactory: EncryptionKeyFactory,
    ) : this(context, accessPolicy) {
        this.encryptionKeyFactory = encryptionKeyFactory
    }

    init {
        Logger.info("Access policy: ${accessPolicy}")
    }

    private val json = Json {
        ignoreUnknownKeys = true; prettyPrint = true
    }

    private val fileStorage
        get() = FileStorage(context, "com.iproov.identity")

    // Avoid holding a reference to the key, it can be deleted at any time.
    private val encryptionKey: EncryptionKey
        get() = encryptionKeyFactory?.invoke() ?: when {
            // The prompt has no CryptoObject, so it can't authorise a key that needs authentication on every use.
            (accessPolicy is KeyPairAccessPolicy.UserPresent || accessPolicy is KeyPairAccessPolicy.AnyBiometrics ||
                accessPolicy is KeyPairAccessPolicy.CurrentBiometrics) &&
                accessPolicy.authenticationValidityDuration <= 0 ->
                throw IllegalArgumentException("$accessPolicy: storage needs an authenticationValidityDuration above 0")
            useAesStorageKey(Build.VERSION.SDK_INT) {
                AndroidKeystoreAesKey.exists(AES_KEY_ALIAS) || ecStorageKeyIsSignOnly()
            } ->
                AndroidKeystoreAesKey(AES_KEY_ALIAS, accessPolicy)
            else -> AndroidDefaultKeyPair(context, EC_KEY_ALIAS, accessPolicy)
        }

    @Volatile
    private var encryptionKeyValidated = false

    /** Guards a caller key once before first use so a no-op key can't silently persist plaintext; the
     *  SDK's own key is trusted and skipped. */
    private fun validateCallerKeyOnce(key: EncryptionKey) {
        if (encryptionKeyFactory == null || encryptionKeyValidated) return
        assertEncryptionKeyProducesCiphertext(key)
        encryptionKeyValidated = true
    }

    private suspend fun read(): Map<String, String?> {
        if (!fileStorage.fileHasBeenCreated) return emptyMap()

        return authenticateIfRequired {
            val key = encryptionKey
            validateCallerKeyOnce(key)
            val encrypted = fileStorage.read()
            val raw = try {
                key.decrypt(encrypted)
            } catch (e: Exception) {
                if (!isUndecryptableLegacyData(key is AndroidKeystoreAesKey, encrypted, e)) throw e
                Logger.error("Discarding wallet data this device can never decrypt; the wallet starts empty")
                fileStorage.delete()
                return@authenticateIfRequired emptyMap()
            }
            json.decodeFromString<Map<String, String?>>(raw.decodeToString())
        }
    }

    override suspend fun read(key: String): String? {
        if (!fileStorage.fileHasBeenCreated) return null

        return read()[key]
    }

    override suspend fun write(key: String, value: String?) {
        val map = read().toMutableMap().apply {
            set(key, value)
        }

        val encoded = json.encodeToString(map).encodeToByteArray()
        val encKey = encryptionKey
        validateCallerKeyOnce(encKey)
        // Unlike the ECIES key, which encrypts with its public half, an AES key needs authentication to encrypt too.
        val encrypted = authenticateIfRequired { encKey.encrypt(encoded) }
        fileStorage.write(encrypted)
    }

    override suspend fun deleteAll() {
        fileStorage.delete()
        encryptionKey.resetBestEffort()
        // An EC key an earlier release made below API 31 is sign-only; a later ECIES write must not reuse it.
        if (encryptionKeyFactory == null) {
            runCatching { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(EC_KEY_ALIAS) }
        }
    }

    private suspend fun <T> authenticateIfRequired(block: () -> T): T {
        // Try running the block first. If the key is already unlocked (validity period active),
        // this will succeed without prompting the user.
        return try {
            block()
        } catch (e: Exception) {
            // Check if this is an authentication-related exception.
            // We look for the exceptions re-thrown by AndroidDefaultKeyPair.decrypt.
            // A custom EncryptionKey is expected to manage its own authentication, so the
            // interactive prompt below only applies to the SDK's own AndroidDefaultKeyPair.
            // The prompt depends only on the access policy, so it serves the AES key as well.
            val authKey = when (val key = encryptionKey) {
                is AndroidDefaultKeyPair -> key
                is AndroidKeystoreAesKey -> AndroidDefaultKeyPair(context, EC_KEY_ALIAS, accessPolicy)
                else -> null
            }
            if (isAuthenticationRequired(e) && authKey != null) retryAfterPrompt(block) {
                Logger.info("Authentication is required for $accessPolicy, launching now... ")

                // We must be on the Main Thread to show UI, but we shouldn't block it.
                // We use withContext(Dispatchers.Main) to ensure the prompt is launched correctly.
                withContext(Dispatchers.Main) {
                    // The engine usually holds the Application context, and a captured Activity may since have been
                    // recreated, so prompt on whichever Activity is in the foreground now.
                    val activity = AppContext.resumedActivity ?: context as? Activity
                        ?: throw KeyPairAuthenticationError("No Activity is in the foreground to show the authentication prompt")

                    try {
                        authKey.authenticate(activity)
                    } catch (e: CancellationException) {
                        throw KeyPairAuthenticationCanceled()
                    } catch (e: KeyPairAuthenticationCanceled) {
                        // If the error was because the user
                        throw e
                    } catch (e: KeyPairAuthenticationError) {
                        // If the error was because the user
                        throw e
                    } catch (error: Throwable) {
                        Logger.error("Authentication failed: ${error.message}" + error.stackTraceToString())
                        throw KeyPairAuthenticationError(
                            error.message ?: "Authentication was not successful but required to use the keypair"
                        )
                    }
                }

                Logger.info("Authentication completed, retrying operation")
            } else {
                throw e
            }
        }
    }

}

// KeyPermanentlyInvalidatedException is not here: no prompt can revive the key, only deleteAll() can.
internal fun isAuthenticationRequired(e: Exception) = e is android.security.keystore.UserNotAuthenticatedException

// Process-wide: a second prompt cancels the one on screen and fails its caller, whichever engine started it.
private val promptLock = Mutex()

/** Runs [prompt] then [block], one caller at a time; a caller that waited first retries, as the window may be open. */
internal suspend fun <T> retryAfterPrompt(block: () -> T, prompt: suspend () -> Unit): T = promptLock.withLock {
    try {
        return@withLock block()
    } catch (e: Exception) {
        if (!isAuthenticationRequired(e)) throw e
    }
    prompt()
    block()
}

class EncryptedPreferencesAndroidStorageEngine(context: Context) : StorageEngine {

    private val preferences: EncryptedPreferences = EncryptedPreferences(context)

    override suspend fun read(key: String): String? = preferences.getString(key)

    override suspend fun write(key: String, value: String?) = preferences.setString(key, value)

    override suspend fun deleteAll() = preferences.deleteAll()
}

actual fun getDeviceBoundStorageEngine(accessPolicy: KeyPairAccessPolicy): StorageEngine =
    DeviceBoundAndroidStorageEngine(AppContext.get(), accessPolicy)

actual fun getDeviceBoundStorageEngine(
    accessPolicy: KeyPairAccessPolicy,
    encryptionKeyFactory: EncryptionKeyFactory,
): StorageEngine = DeviceBoundAndroidStorageEngine(
    AppContext.get(),
    accessPolicy,
    encryptionKeyFactory,
)
