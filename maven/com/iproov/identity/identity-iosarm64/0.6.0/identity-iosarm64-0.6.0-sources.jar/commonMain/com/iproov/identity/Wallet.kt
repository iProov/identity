@file:Suppress("DEPRECATION")

package com.iproov.identity

import com.iproov.identity.api.ApiException
import com.iproov.identity.api.DefaultOID4VCIOrchestrator
import com.iproov.identity.api.DefaultOID4VPOrchestrator
import com.iproov.identity.api.DocumentChallenge
import com.iproov.identity.api.DocumentChallengeResponder
import com.iproov.identity.api.IdentityPlatformInterface
import com.iproov.identity.api.OID4VCIOrchestrator
import com.iproov.identity.api.OID4VPOrchestrator
import com.iproov.identity.api.Responses
import com.iproov.identity.api.StatusListVerifier
import com.iproov.identity.api.UriCredentialChallenge
import com.iproov.identity.api.UriCredentialChallengeResponder
import com.iproov.identity.attestation.AttestationException
import com.iproov.identity.attestation.AttestationService
import com.iproov.identity.cryptography.JWEFactory
import com.iproov.identity.cryptography.KeyPair
import com.iproov.identity.cryptography.SdkManagedKey
import com.iproov.identity.cryptography.getPlatformJWEFactory
import com.iproov.identity.dcapi.CredentialRegistrationInfo
import com.iproov.identity.dcapi.DCApiMatchResult
import com.iproov.identity.dcapi.DCApiOrchestrator
import com.iproov.identity.dcapi.DCApiRegistrar
import com.iproov.identity.dcapi.DCApiResult
import com.iproov.identity.dcapi.DefaultDCApiOrchestrator
import com.iproov.identity.dcapi.createPlatformDCApiRegistrar
import com.iproov.identity.dcapi.mdoc.MdocDcApiSession
import com.iproov.identity.dcapi.withDCApiMatchErrorHandling
import com.iproov.identity.models.ActiveAuthentication
import com.iproov.identity.models.BacKey
import com.iproov.identity.models.Claim
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialStatus
import com.iproov.identity.models.CredentialStatusException
import com.iproov.identity.models.CredentialSummary
import com.iproov.identity.models.Format
import com.iproov.identity.models.Gender
import com.iproov.identity.models.Jwt
import com.iproov.identity.models.LegacyCredential
import com.iproov.identity.models.LoginRequest
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.MrtdData
import com.iproov.identity.models.RespondableCredentialOffer
import com.iproov.identity.models.RespondableLoginRequest
import com.iproov.identity.models.RespondablePresentationRequest
import com.iproov.identity.models.ReverificationRequest
import com.iproov.identity.models.VerificationEvent
import com.iproov.identity.models.toVerificationEvent
import com.iproov.identity.models.VerificationMethod
import com.iproov.identity.persistence.CredentialSubmission
import com.iproov.identity.persistence.IssuerSignedMdoc
import com.iproov.identity.persistence.LocalStorage
import com.iproov.identity.persistence.Repository
import com.iproov.identity.proximity.DefaultProximityOrchestrator
import com.iproov.identity.proximity.DocumentRequest
import com.iproov.identity.proximity.EngagementAcquisition.acquireFromUri
import com.iproov.identity.proximity.NfcEngagementUnavailableException
import com.iproov.identity.proximity.PresentationMethod
import com.iproov.identity.proximity.ProximityConfig
import com.iproov.identity.proximity.ProximityNotSupportedException
import com.iproov.identity.proximity.ProximityOrchestrator
import com.iproov.identity.proximity.ProximityPresentationSession
import com.iproov.identity.proximity.ProximityRetrievalEvent
import com.iproov.identity.proximity.ProximityRetrievalSession
import com.iproov.identity.proximity.ReaderSigningData
import com.iproov.kmp.api.Iproov
import com.iproov.kmp.api.IproovOptions
import com.iproov.kmp.api.IproovState
import com.iproov.kmp.api.IproovUIState
import io.ktor.http.HttpStatusCode
import io.ktor.http.URLParserException
import io.ktor.http.Url
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.channels.ProducerScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.transformWhile
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC
import kotlin.random.Random
import kotlin.time.Clock
import kotlin.time.Duration.Companion.seconds

class AppIdNotSupportedException() :
    Exception("This app has not been authorized to use the iProov Identity Platform. Please provide your App ID to our support team to enable access.")

class CredentialNotFoundException(id: String) : Exception("Credential with id: $id not found.")
class InvalidOpenIdServerConfiguration(message: String) : Exception(message)
class UnsupportedVerificationMethodException(message: String) : Exception(message)
class WalletNotRegisteredException : Exception("Your wallet has not been registered.")
class WalletAlreadyRegisteredException : Exception("You have already registered your wallet.")
class CredentialAlreadyExistsException(source: String) :
    Exception("Claims with source: $source already exist")

class RequiredClaimNotPresent(val claimName: String, message: String) : Exception(message)
class NoSupportedCredentialOffers() :
    Exception("Identity Platform didn't return any supported credential offers.")

/** Supplies the wallet signing key. Integrators may return their own [KeyPair] implementation. */
typealias KeyPairFactory = () -> KeyPair

/**
 * Resets SDK-owned signing material and deletes local wallet data as two independent teardown
 * operations. Kept outside [Wallet] so the failure-ordering contract can be tested without
 * constructing platform services.
 */
internal suspend fun destroyWalletState(
    getSigningKey: KeyPairFactory,
    deleteLocalData: suspend () -> Unit,
) {
    var resetFailure: Throwable? = null

    try {
        // Only SDK-owned signing keys are reset; a caller-managed key stays the caller's responsibility.
        val signingKey = getSigningKey()
        if (signingKey is SdkManagedKey) signingKey.reset()
    } catch (error: Throwable) {
        resetFailure = error
    }

    try {
        deleteLocalData()
    } catch (error: Throwable) {
        if (resetFailure != null) error.addSuppressed(resetFailure)
        throw error
    }

    resetFailure?.let { throw it }
}

@OptIn(ExperimentalObjCRefinement::class)
class Wallet internal constructor(
    private val attestationService: AttestationService,
    val identityPlatformInterface: IdentityPlatformInterface,
    private val localStorage: LocalStorage,
    val repository: Repository,
    private val getKeyPair: KeyPairFactory,
    private val clientConfiguration: OID4VCIClientConfiguration? = null,
    internal val trustConfiguration: TrustConfiguration = TrustConfiguration(),
    private val jweFactory: JWEFactory = getPlatformJWEFactory(),
    private val oid4vpOrchestrator: OID4VPOrchestrator = DefaultOID4VPOrchestrator(
        identityPlatformInterface.apiClient,
        repository = repository,
        keyPairFactory = getKeyPair,
        jweFactory = jweFactory,
    ),
    private val oid4vciOrchestrator: OID4VCIOrchestrator = DefaultOID4VCIOrchestrator(
        keyPairFactory = getKeyPair,
        repository = repository,
        networkClient = identityPlatformInterface.apiClient,
        clientConfiguration = clientConfiguration,
        trustConfiguration = trustConfiguration,
    ),
    private val dcApiOrchestrator: DCApiOrchestrator = DefaultDCApiOrchestrator(
        repository = repository,
        keyPairFactory = getKeyPair,
        jweFactory = jweFactory,
        dcApiRegistrar = createPlatformDCApiRegistrar {
            repository.getCredentials(repository.getCredentialMetadata()).credentials
                .map { (metadata, credential) -> CredentialRegistrationInfo(metadata, credential) }
        },
    ),
    internal val proximityOrchestrator: ProximityOrchestrator = DefaultProximityOrchestrator()
) {
    companion object {
        const val DTC_CLAIM_NAME = "com.svipe:dtc"
    }

    private val keyPair: KeyPair get() = getKeyPair()

    @Throws(Exception::class)
    suspend fun register() {
        if (isRegistered()) throw WalletAlreadyRegisteredException()

        val attestationToken = attestationService.getAttestationToken()
        val jwts = try {
            identityPlatformInterface.registerWallet(attestationToken)
        } catch (e: ApiException.HttpError) {
            throw if (e.statusCode == HttpStatusCode.NotFound) AppIdNotSupportedException() else e
        }

        updateJwts(jwts)
        localStorage.setAttestationToken(attestationToken)
        getTranslations()
    }

    @Throws(Exception::class)
    suspend fun delete() {
        throwIfNotRegistered()

        try {
            identityPlatformInterface.deleteWallet()
        } catch (e: ApiException) {
            Logger.error("Unable to delete wallet: ${e.message}")
        } catch (e: AttestationException) {
            // A key that no longer works on this device can't sign the revoke; the local wipe is what recovers.
            Logger.error("Unable to delete wallet: ${e.message}")
        } finally {
            destroy()
        }
    }

    @Throws(Exception::class)
    suspend fun destroy() {
        // Clear platform registrations before deleting the data needed to reconcile them.
        val clearFailure =
            runCatching { dcApiOrchestrator.registerCredentials(emptyList()) }.exceptionOrNull()

        destroyWalletState(getKeyPair, localStorage::deleteAll)

        clearFailure?.let { throw it }
    }

    /**
     * Fetch all credentials stored issued to the wallet.
     */
    @Throws(Exception::class)
    suspend fun getCredentialMetadata(): List<CredentialMetadata> {
        throwIfNotRegistered()
        return repository.getCredentialMetadata()
    }

    /**
     * Fetch all credentials stored issued to the wallet.
     */
    @Throws(Exception::class)
    suspend fun getCredentials(): CredentialSummary = getCredentials(
        repository.getCredentialMetadata()
    )

    @Throws(Exception::class)
    suspend fun getCredential(metadata: CredentialMetadata): Credential {
        throwIfNotRegistered()
        val summary = repository.getCredential(metadata)
        return summary.credentials.values.firstOrNull() ?: throw Exception(
            summary.failures.values.first().error
        )
    }

    @Throws(Exception::class)
    suspend fun getCredentials(metadata: List<CredentialMetadata>): CredentialSummary {
        throwIfNotRegistered()
        return repository.getCredentials(metadata)
    }

    @Throws(Exception::class)
    suspend fun getPresentationRequest(uri: String): RespondablePresentationRequest {
        throwIfNotRegistered()
        return oid4vpOrchestrator.createPresentationRequest(uri)

    }

    /**
     * Retrieves a respondable credential offer over OID4VCI
     */
    @Throws(Exception::class)
    suspend fun addCredentialWithOffer(uri: String): RespondableCredentialOffer {
        throwIfNotRegistered()
        return oid4vciOrchestrator.addCredential(uri)
    }

    // ==================== DC API (Digital Credentials API) Methods ====================

    /**
     * Check if DC API (Digital Credentials API) is available on this platform.
     *
     * DC API is available on:
     * - Android 14+ (API 34) with CredentialManager
     * - On iOS (Requires iOS 26+)
     *
     * Reports OS support only. On iOS, whether the user has authorized the provider is reported
     * separately by `digitalCredentialsStatus()`.
     *
     * On unsupported platforms, this returns false and DC API operations are no-ops.
     */
    fun isDCApiAvailable(): Boolean = dcApiOrchestrator.isAvailable()

    /**
     * Android Only: Process a Digital Credentials API request from the OS credential manager.
     *
     * This is called when the wallet is invoked by the OS to handle a credential request
     * from a browser or native app using navigator.credentials.get() or equivalent API.
     *
     * @param requestJson The JSON request string from the DC API invocation
     * @param callingOrigin The origin verified by the OS credential API, obtained independently
     * of the request JSON.
     * @return Result containing matching credentials or an error
     */
    @Throws(Exception::class)
    suspend fun processDCApiRequest(requestJson: String, callingOrigin: String): DCApiMatchResult =
        processDCApiRequest(requestJson, callingOrigin, emptyList())

    /** [trustedVerifierCertificates]: DER roots accepted for signed requests, in addition to the platform trust store. */
    @Throws(Exception::class)
    suspend fun processDCApiRequest(
        requestJson: String,
        callingOrigin: String,
        trustedVerifierCertificates: List<ByteArray>
    ): DCApiMatchResult = withDCApiMatchErrorHandling {
        throwIfNotRegistered()
        dcApiOrchestrator.processRequest(requestJson, callingOrigin, trustedVerifierCertificates)
    }

    /**
     * Android Only - Build a DC API response for the selected credentials.
     *
     * After the user selects which credentials to present, call this method to
     * build the response to return to the browser/requester.
     *
     * @param matchResult The successful match result from processDCApiRequest
     * @param submission The user's credential selection
     * @return The response to return to the OS credential manager
     */
    @Throws(Exception::class)
    suspend fun buildDCApiResponse(
        matchResult: DCApiMatchResult.Success,
        submission: CredentialSubmission
    ): DCApiResult {
        throwIfNotRegistered()
        return dcApiOrchestrator.buildResponse(matchResult, submission)
    }

    @Deprecated(
        "Single registration is iOS-only; Android logs and returns",
        ReplaceWith("registerAllCredentialsForDCApi()")
    )
    @Throws(Exception::class)
    suspend fun registerCredentialForDCApi(metadata: CredentialMetadata) =
        registerSingleCredentialForDCApi(metadata)

    /** Shared by the deprecated 0.5.2 method and the iOS-only `registerDigitalCredential`. */
    internal suspend fun registerSingleCredentialForDCApi(metadata: CredentialMetadata) {
        throwIfNotRegistered()
        if (!isDCApiAvailable()) return
        @Suppress("DEPRECATION")
        dcApiOrchestrator.registerCredential(metadata)
    }

    /** The platform registrar behind this wallet, for platform-specific entry points. */
    internal val platformDCApiRegistrar: DCApiRegistrar?
        get() = (dcApiOrchestrator as? DefaultDCApiOrchestrator)?.registrar

    /**
     * Replaces all existing registrations with the current credential set. No-op where DC API is
     * unsupported.
     */
    @Throws(Exception::class)
    suspend fun registerAllCredentialsForDCApi() {
        throwIfNotRegistered()
        if (!isDCApiAvailable()) return

        val summary = getCredentials()
        val registrationInfos = summary.credentials.map { (metadata, credential) ->
            CredentialRegistrationInfo(metadata, credential)
        }
        dcApiOrchestrator.registerCredentials(registrationInfos)
    }

    internal suspend fun buildDigitalCredentialsSession(
        requestJson: String,
        serializedOrigin: String,
    ): MdocDcApiSession {
        throwIfNotRegistered()
        return MdocDcApiSession.create(
            requestJson, serializedOrigin, repository, keyPair, trustConfiguration.readerTrust
        )
    }


    /**
     * Unregister a credential from the OS credential manager.
     *
     * This removes the credential from DC API discovery. The credential itself
     * remains stored locally.
     *
     * On platforms that don't support DC API, this is a no-op.
     */
    @Throws(Exception::class)
    suspend fun unregisterCredentialFromDCApi(credentialId: String) {
        throwIfNotRegistered()
        dcApiOrchestrator.unregisterCredential(credentialId)
    }

    /**
     * Whether this wallet instance has registered the credential for DC API requests. Reflects
     * registrations made since launch, so call [registerAllCredentialsForDCApi] first.
     */
    fun isCredentialRegisteredForDCApi(metadata: CredentialMetadata): Boolean =
        dcApiOrchestrator.isCredentialRegistered(metadata.uuid)

    /** See [isCredentialRegisteredForDCApi]. */
    fun isCredentialRegisteredForDCApi(credentialId: String): Boolean =
        dcApiOrchestrator.isCredentialRegistered(credentialId)

    // ==================== End DC API Methods ====================

    // ==================== Credential Status Methods ====================

    /**
     * The credential's status in its IETF Token Status List (draft-ietf-oauth-status-list-21), as the
     * EUDI wallet libraries report it. The credential's signature, issuer and validity period are
     * checked first, under this wallet's [TrustConfiguration], and its status list is not fetched if
     * any fails (Token Status List §8.3). Supports mdoc credentials.
     *
     * Throws [CredentialStatusException] when no status can be established, which never means valid.
     */
    @Throws(Exception::class)
    suspend fun resolveStatus(credential: Credential): CredentialStatus {
        throwIfNotRegistered()
        if (credential !is MDocCredential) {
            Logger.error("[StatusList] ${credential.format.value} credentials have no status check")
            throw CredentialStatusException.Unsupported(
                "Status checks support mdoc credentials only",
                mapOf("cause" to "unsupported", "format" to credential.format.value),
            )
        }
        return IssuerSignedMdoc.parseForStatus(credential.raw)
            .resolveStatus(trustConfiguration, StatusListVerifier.shared, Clock.System.now())
    }

    /** See [resolveStatus]. [credentialId] is the credential's [CredentialMetadata.uuid]. */
    @Throws(Exception::class)
    suspend fun resolveStatusById(credentialId: String): CredentialStatus {
        val metadata = getCredentialMetadata().find { it.uuid == credentialId } ?: run {
            Logger.error("[StatusList] No stored credential with id $credentialId")
            throw CredentialNotFoundException(credentialId)
        }
        return resolveStatus(getCredential(metadata))
    }

    // ==================== End Credential Status Methods ====================

    // ==================== Proximity Methods ====================

    /** True if the device supports BLE for proximity (ISO 18013-5 §8.3.3.1.1). */
    fun isBleAvailable(): Boolean = proximityOrchestrator.isBleAvailable()

    /** True if the device supports NFC HCE (ISO 18013-5 §8.2.2.1). */
    fun isNfcHceAvailable(): Boolean = proximityOrchestrator.isNfcHceAvailable()

    /** True if NFC is currently enabled in user settings (vs hardware availability above). */
    fun isNfcHceEnabled(): Boolean = proximityOrchestrator.isNfcHceEnabled()

    /**
     * True if the device can perform reader-side NFC scanning right now. Use this to
     * gate UI that triggers NFC mdoc retrieval (e.g. a "Tap to receive" button).
     *
     * Distinct from [isNfcHceAvailable], which checks HCE (mdoc-holder side). iOS
     * cannot act as an HCE holder but can read tags
     */
    fun isNfcReaderAvailable(): Boolean = proximityOrchestrator.isNfcReaderAvailable()

    /** Activate NFC card emulation — call from the host activity's `onResume`. No-op on iOS. */
    fun enableNfcEngagement(): Boolean {
        if (!isNfcHceAvailable()) return false
        return proximityOrchestrator.nfcEngagement().enable()
    }

    /** Deactivate NFC card emulation — call from the host activity's `onPause`. No-op on iOS. */
    fun disableNfcEngagement(): Boolean {
        if (!isNfcHceAvailable()) return false
        proximityOrchestrator.nfcEngagement().disable()
        return true
    }

    /**
     * Start a wallet-side proximity session (ISO 18013-5 §6). Collect the returned
     * session's `events` flow to drive the UI and to receive the reader's request.
     * @throws ProximityNotSupportedException neither BLE nor NFC HCE is available.
     * @throws NfcEngagementUnavailableException requests NFC but it's off/unsupported.
     */
    @Throws(Exception::class)
    suspend fun startProximityPresentation(
        qr: PresentationMethod.QrPresentation,
        config: ProximityConfig.Holder = ProximityConfig.Holder(),
    ): ProximityPresentationSession {
        throwIfNotRegistered()
        if (!isBleAvailable()) {
            throw ProximityNotSupportedException(
                "QR presentation requires BLE, which isn't available on this device."
            )
        }
        return ProximityPresentationSession(
            presentationMethod = qr,
            config = config,
            trust = trustConfiguration,
            orchestrator = proximityOrchestrator,
            repository = repository,
            keyPair = keyPair,
        )
    }

    /**
     * Start a wallet-side proximity session (ISO 18013-5 §6). Collect the returned
     * session's `events` flow to drive the UI and to receive the reader's request.
     * @throws ProximityNotSupportedException neither BLE nor NFC HCE is available.
     * @throws NfcEngagementUnavailableException requests NFC but it's off/unsupported.
     */
    @OptIn(ExperimentalObjCRefinement::class)
    @Throws(Exception::class)
    @HiddenFromObjC
    suspend fun startProximityPresentation(
        nfc: PresentationMethod.NfcPresentation,
        config: ProximityConfig.Holder = ProximityConfig.Holder(),
    ): ProximityPresentationSession {
        throwIfNotRegistered()
        if (!isBleAvailable()) {
            throw ProximityNotSupportedException(
                "NFC presentation requires BLE for data transfer, which isn't available on this device."
            )
        }

        when {
            !isNfcHceAvailable() -> throw NfcEngagementUnavailableException(
                "NFC engagement is not supported on this device. Use the QR overload of startProximityPresentation instead."
            )

            !isNfcHceEnabled() -> throw NfcEngagementUnavailableException(
                "NFC is turned off. Please enable NFC in system settings."
            )

            !proximityOrchestrator.nfcEngagement().isServiceRegistered -> throw NfcEngagementUnavailableException(
                "No HostApduService is registered for the mdoc NDEF AID (D2760000850101) under " +
                        "category 'other'. Declare an IsoMdocHceService subclass in your AndroidManifest " +
                        "so reader taps route to the SDK. See README §NFC setup."
            )
        }

        return ProximityPresentationSession(
            presentationMethod = nfc,
            config = config,
            trust = trustConfiguration,
            orchestrator = proximityOrchestrator,
            repository = repository,
            keyPair = keyPair,
        )
    }


    internal fun buildRetrievalSession(
        engagementSource: suspend ProducerScope<ProximityRetrievalEvent>.() -> ProximityRetrievalSession.EngagementOutcome,
        requestedDocuments: List<DocumentRequest>,
        createSigningData: (suspend () -> ReaderSigningData)? = null,
        config: ProximityConfig.Reader,
    ): ProximityRetrievalSession {
        return ProximityRetrievalSession(
            engagementSource = engagementSource,
            requestedDocuments = requestedDocuments,
            createSigningData = createSigningData,
            orchestrator = proximityOrchestrator,
            config = config,
            trust = trustConfiguration,
        )
    }

    /**
     * Start a reader-side proximity session from a scanned engagement [uri] (ISO 18013-5 §6).
     * Provide [createSigningData] for reader authentication (§9.1.4) and [requestedDocuments]
     * for the doctype/element set to ask for.
     */
    @Throws(Exception::class)
    fun startProximityRetrieval(
        uri: String,
        requestedDocuments: List<DocumentRequest>,
        createSigningData: (suspend () -> ReaderSigningData)? = null,
        config: ProximityConfig.Reader = ProximityConfig.Reader(),
    ): ProximityRetrievalSession {
        if (!isBleAvailable()) {
            throw ProximityNotSupportedException(
                "QR retrieval requires BLE, which isn't available on this device."
            )
        }
        return buildRetrievalSession(
            engagementSource = {
                send(ProximityRetrievalEvent.Engagement.Qr.Decoding)
                acquireFromUri(uri, config, proximityOrchestrator)
            },
            requestedDocuments = requestedDocuments,
            createSigningData = createSigningData,
            config = config,
        )
    }

    // ==================== End Proximity Methods ====================

    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("getCredentials()")
    )
    @Throws(Exception::class)
    suspend fun getLegacyCredentials(): List<LegacyCredential> {
        throwIfNotRegistered()

        return repository.getAllCredentials()
    }

    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("getCredentials()")
    )
    @Throws(Exception::class)
    suspend fun getLegacyCredentials(source: String): LegacyCredential? {
        throwIfNotRegistered()

        val credentials = repository.getAllCredentials()
        return credentials.firstOrNull { credential -> credential.source == source }
    }


    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("getCredentials()")
    )
    @Throws(Exception::class)
    suspend fun getAllClaims(): List<Claim> {
        throwIfNotRegistered()
        return repository.getAllClaims()
    }

    @Throws(Exception::class)
    suspend fun createDemoMrtd(): MrtdData {
        throwIfNotRegistered()

        val gender = Gender.entries[Random.nextInt(Gender.entries.size)]

        return identityPlatformInterface.getDemo(gender, Format.BASE64)
    }

    @Throws(Exception::class)
    suspend fun addDocumentWithMrz(
        mrz: String, loginRequest: LoginRequest? = null,
        addLegacyCredential: Boolean = true,
    ): DocumentChallenge {
        val bacKey = BacKey.fromMrz(mrz)
        return addDocument(bacKey, loginRequest, addLegacyCredential)
    }

    /**
     * Add a document with fields
     * @param documentNumber
     * @param dateOfExpiry Expiration date of the document in DDMMYY format
     * @param dateOfBirth Date of birth on the document in DDMMYY format
     */
    @Throws(Exception::class)
    suspend fun addDocumentWithFields(
        documentNumber: String,
        dateOfBirth: String,
        dateOfExpiry: String,
        loginRequest: LoginRequest? = null,
        addLegacyCredential: Boolean = true,
    ): DocumentChallenge {
        val bacKey = BacKey.fromFields(documentNumber, dateOfBirth, dateOfExpiry)
        return addDocument(bacKey, loginRequest, addLegacyCredential)
    }

    /**
     * Like [addDocumentWithMrz], but with [nfcServiceRead] asks for the chip to be read through the iProov
     * NFC service: see [DocumentChallenge.nfcServiceReadToken]. Falls back to an on-device read when the
     * mode isn't set up for this app.
     */
    @Throws(Throwable::class)
    suspend fun addDocumentWithMrz(
        mrz: String,
        loginRequest: LoginRequest? = null,
        addLegacyCredential: Boolean = true,
        nfcServiceRead: Boolean,
    ): DocumentChallenge = addDocument(BacKey.fromMrz(mrz), loginRequest, addLegacyCredential, nfcServiceRead)

    /**
     * Like [addDocumentWithFields], but with [nfcServiceRead] asks for the chip to be read through the
     * iProov NFC service: see [DocumentChallenge.nfcServiceReadToken]. Falls back to an on-device read when
     * the mode isn't set up for this app.
     */
    @Throws(Throwable::class)
    suspend fun addDocumentWithFields(
        documentNumber: String,
        dateOfBirth: String,
        dateOfExpiry: String,
        loginRequest: LoginRequest? = null,
        addLegacyCredential: Boolean = true,
        nfcServiceRead: Boolean,
    ): DocumentChallenge = addDocument(
        BacKey.fromFields(documentNumber, dateOfBirth, dateOfExpiry), loginRequest, addLegacyCredential, nfcServiceRead
    )

    /**
     * Add a document with reference
     * @param reference Reference to the identity
     */
    @OptIn(ExperimentalObjCRefinement::class)
    @Throws(Exception::class)
    @HiddenFromObjC
    fun addDocumentWithReference(
        reference: String,
        demoReferencePhoto: ByteArray? = null,
        loginRequest: LoginRequest? = null,
        options: IproovOptions? = null,
        addLegacyCredential: Boolean = true,
    ): Flow<VerificationEvent> {
        return verifyFace(
            target = reference,
            getVerificationMethod = { _, reverificationToken ->
                identityPlatformInterface.initDocReference(
                    reference,
                    reverificationToken,
                    demoReferencePhoto = demoReferencePhoto
                )
            },
            verifyFace = { token -> identityPlatformInterface.verifyReferenceDocument(token) },
            loginRequest = loginRequest,
            options = options,
            addLegacyCredential = addLegacyCredential
        )
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Throws(Exception::class)
    suspend fun getLoginRequest(uri: String, isNfcCapable: Boolean): RespondableLoginRequest {
        val url = try {
            Url(uri)
        } catch (e: URLParserException) {
            throw Exception("The URL provided is not a valid URL")
        }
        val responseUri = getLoginResponseUri(url);
        val code = url.segments[1]

        val presentationRequestJwt =
            identityPlatformInterface.getAuthRequest(responseUri, code, isNfcCapable)
        val translations = getTranslations()

        val request = LoginRequest(presentationRequestJwt, translations)
        val reverifications = request.acrs.map { ReverificationRequest.forAcr(it, request) }

        return RespondableLoginRequest.fromLoginRequest(
            loginRequest = request,
            reverifications,
            accept = @Throws(Exception::class) { jwts ->
                GlobalScope.async {
                    identityPlatformInterface.respondToAuthRequest(
                        responseUri,
                        request,
                        jwts,
                    )
                }
            },
            deny = @Throws(Exception::class) {
                GlobalScope.async {
                    identityPlatformInterface.respondToAuthRequest(
                        responseUri,
                        request,
                        emptyList()
                    )
                    return@async null
                }
            },
        )
    }

    @Throws(Exception::class)
    suspend fun deleteCredential(metadata: CredentialMetadata) {
        throwIfNotRegistered()
        repository.deleteCredential(metadata)

        runCatching { dcApiOrchestrator.unregisterCredential(metadata.uuid) }
            .onFailure { Logger.error("DC-API unregistration failed for ${metadata.uuid}: ${it.message}") }
    }

    /**
     * Helper method for deleting a credential with and ID
     */
    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("deleteCredential(metadata)")
    )
    @Throws(Exception::class)
    suspend fun deleteCredential(source: String) {
        val credential = repository.getAllCredentials().find { it.source == source }
            ?: throw CredentialNotFoundException(source)
        deleteCredential(credential)
    }

    /**
     * Delete a credential from the wallet.
     */
    @Deprecated(
        "Legacy credentials are deprecated & support will be removed. Please use new credential format",
        replaceWith = ReplaceWith("deleteCredential(metadata)")
    )
    @Throws(Exception::class)
    suspend fun deleteCredential(credential: LegacyCredential) {
        throwIfNotRegistered()
        repository.deleteJwts(credential.claims.map { it.jwt })
        // TOOD: Call API client to revoke credential from issuer.
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Throws(Exception::class)
    suspend fun addUriCredential(uri: String): UriCredentialChallenge {
        throwIfNotRegistered()

        val challenge = identityPlatformInterface.initUriCredential(uri)

        val responder = UriCredentialChallengeResponder @Throws(Exception::class) { token: String ->
            GlobalScope.async { verifyUriCredential(uri, token); null }
        }

        return UriCredentialChallenge(challenge, responder)
    }

    @Throws(Exception::class)
    suspend fun verifyUriCredential(uri: String, token: String) {
        throwIfNotRegistered()

        var verificationToken = token
        if (token.contains("/email/verify")) {
            verificationToken = token.split("/").last()
        }

        val jwts = identityPlatformInterface.verifyUriCredential(
            uri = uri,
            token = verificationToken,
        )

        updateJwts(jwts)
    }

    @Throws(Exception::class)
    private suspend fun getLoginResponseUri(uri: Url): String {
        val serverId = uri.segments[0]

        val openIdServers = identityPlatformInterface.getOidcServers()
        val openIdServer =
            openIdServers.firstOrNull { it["suffix"]?.jsonPrimitive?.content == "/$serverId/" }
                ?: throw InvalidOpenIdServerConfiguration("The OIDC server has not yet been configured for this base url.")

        val baseUrl = openIdServer["baseurl"]?.jsonPrimitive?.content
        val urlPath = openIdServer["urlpath"]?.jsonPrimitive?.content
        if (baseUrl !is String || urlPath !is String) {
            throw InvalidOpenIdServerConfiguration("both 'baseUrl' and 'urlpath' are expected to be present and of type String in OIDC server config")
        }

        return baseUrl + urlPath
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Throws(Exception::class)
    private suspend fun addDocument(
        bacKey: BacKey,
        loginRequest: LoginRequest? = null,
        addLegacyCredential: Boolean,
        nfcServiceRead: Boolean = false,
    ): DocumentChallenge {
        throwIfNotRegistered()

        val activeAuthentication = ActiveAuthentication.generateFromBacKey(bacKey)

        val (challenge, nfcRead) = try {
            identityPlatformInterface.initDoc(
                activeAuthentication.challenge,
                reverificationToken = loginRequest?.jwt?.compactString,
                nfcRead = nfcServiceRead,
            )
        } catch (e: ApiException.HttpError) {
            // 456: NFC-service reads aren't set up for this app here; 422: the server predates them and refuses
            // the unknown field. Either way read on the device, with a fresh secret.
            if (nfcServiceRead && e.statusCode.value in setOf(456, 422)) {
                Logger.info("NFC-service reads unavailable here, so the HTTP ${e.statusCode.value} above is expected; falling back to an on-device read")
                return addDocument(bacKey, loginRequest, addLegacyCredential)
            }
            throw e
        }

        val responder = DocumentChallengeResponder(
            usingMrtd = @Throws(Exception::class) { mrtd, accessControl, signature ->
                GlobalScope.async {
                    val response = identityPlatformInterface.verifyMrtd(
                        mrtd = mrtd,
                        challenge = challenge.challenge!!,
                        aaSignature = signature,
                        secret = activeAuthentication.secret,
                        accessControl = accessControl
                    )
                    completeDocument(response, loginRequest, addLegacyCredential)
                }
            },
        )
        if (nfcRead != null) {
            responder.usingNfcServiceRead = { completionCode ->
                val response = identityPlatformInterface.verifyNfcRead(
                    jti = nfcRead.jti,
                    completionCode = completionCode,
                    challenge = challenge.challenge!!,
                    secret = activeAuthentication.secret,
                )
                completeDocument(response, loginRequest, addLegacyCredential)
            }
        }

        return DocumentChallenge(bacKey.key, responder, challenge).apply { nfcServiceReadToken = nfcRead?.token }
    }

    private suspend fun completeDocument(
        response: Responses.OfferedCredentialResponse,
        loginRequest: LoginRequest?,
        addLegacyCredential: Boolean,
    ): RespondableCredentialOffer {
        // Legacy credential storage
        if (addLegacyCredential) {
            val jwts = response.jwts
            val existingClaims = repository.getAllClaims()
            val alreadyExists =
                existingClaims.any { claim -> jwts.any { it.source == claim.source } }
            if (alreadyExists && loginRequest == null) throw CredentialAlreadyExistsException(
                jwts.first().source
            )
            updateJwts(jwts)
        }

        Logger.info("Received VCI offer versions: ${response.oidcVCIOffers.keys}")

        val latestSupportedOffer =
            getLatestCredentialOffer(response) ?: throw NoSupportedCredentialOffers()
        return oid4vciOrchestrator.addCredential(latestSupportedOffer)
    }

    /**
     * @param credential The credential that contains a portrait being verified
     */
    @Throws(Exception::class)
    @OptIn(ExperimentalObjCRefinement::class)
    @HiddenFromObjC
    fun addFaceVerification(
        credential: LegacyCredential,
        loginRequest: LoginRequest? = null,
        options: IproovOptions? = null,
    ): Flow<VerificationEvent> {

        val dtc = credential.claims.find { claim -> claim.name == DTC_CLAIM_NAME }
            ?: throw RequiredClaimNotPresent(
                DTC_CLAIM_NAME,
                "A DTC claim is required to perform a face verification"
            )

        return verifyFace(
            target = credential,
            getVerificationMethod = { _, reverificationToken ->
                identityPlatformInterface.initFace(
                    dtc,
                    reverificationToken
                )
            },
            verifyFace = { token -> identityPlatformInterface.verifyFace(token) },
            loginRequest = loginRequest,
            options = options,
            addLegacyCredential = true,
        )
    }

    /**
     * @param getVerificationMethod Function to get a request to pass to the iProov Biometrics SDK to launch the face capture, this token in the request can then be used as a reference to that capture.
     * @param verifyFace Callback function for when the iProov Biometrics SDK has captured the face successfully, providing the request token.
     * @param completion Callback function for when the verification has bene completed.
     * @param loginRequest A login request that this verification relates to
     */
    @Throws(Exception::class)
    private fun <T> verifyFace(
        target: T,
        getVerificationMethod: suspend (target: T, verificationToken: String?) -> VerificationMethod,
        verifyFace: suspend (token: String) -> Responses.OfferedCredentialResponse,
        completion: (() -> Unit)? = null,
        loginRequest: LoginRequest? = null,
        options: IproovOptions? = null,
        addLegacyCredential: Boolean,
    ) = flow {
        throwIfNotRegistered()
        emit(VerificationEvent.Started)

        when (val verificationMethod =
            getVerificationMethod(target, loginRequest?.jwt?.compactString)) {
            is VerificationMethod.Skip -> {
                emit(VerificationEvent.Loading)

                val response = verifyFace(verificationMethod.token)

                val latestSupportedOffer = getLatestCredentialOffer(response)

                if (addLegacyCredential) {
                    updateJwts(response.jwts, loginRequest)
                }

                val responder = latestSupportedOffer?.let {
                    oid4vciOrchestrator.addCredential(it)
                }

                completion?.invoke()
                emit(VerificationEvent.Completed(responder))
                return@flow
            }

            is VerificationMethod.IProov -> {
                runCatching { Iproov.cancelSession() } // Since Iproov is a single object, cancel any existing sessions before launching.
                // iOS ends a cancelled capture asynchronously, and reports it before its screen has closed: relaunching
                // earlier fails with captureAlreadyActive or presents onto the closing screen, so the capture never shows.
                withTimeoutOrNull(5.seconds) {
                    Iproov.sessionState.first { it == null || it.isFinal }
                    Iproov.uiState.first { it == null || it == IproovUIState.Ended }
                }
                Iproov.sessionState.value = null // iOS's cancelSession keeps the last result, which the collect below would replay.

                Iproov.launchSession(
                    verificationMethod.url,
                    verificationMethod.token,
                    options ?: IproovOptions()
                )

                // End at this session's result: the state is shared, so a lingering flow would also act on the next session.
                Iproov.sessionState.transformWhile { emit(it); it?.isFinal != true }.collect { event ->
                    when (event) {
                        is IproovState.Canceled -> emit(VerificationEvent.Canceled)
                        is IproovState.Failure -> emit(event.toVerificationEvent())
                        is IproovState.Error -> emit(event.toVerificationEvent())

                        is IproovState.Success -> {
                            emit(VerificationEvent.Loading)

                            val response = verifyFace(verificationMethod.token)

                            val latestSupportedOffer = getLatestCredentialOffer(response)

                            if (addLegacyCredential) {
                                updateJwts(response.jwts, loginRequest)
                            }

                            val responder = latestSupportedOffer?.let {
                                oid4vciOrchestrator.addCredential(it)
                            }

                            completion?.invoke()
                            emit(VerificationEvent.Completed(responder))
                        }

                        else -> emit(VerificationEvent.Loading)
                    }
                }
            }
        }
    }

    @Throws(Exception::class)
    suspend fun updateJwts(jwts: List<Jwt>, loginRequest: LoginRequest? = null): List<Jwt> {
        var jwtsToUpdate = jwts
        if (loginRequest != null) {
            val presentJwts = jwtsToUpdate.filter { it.name.endsWith("_present") }
            loginRequest.reverificationJwts.addAll(presentJwts);

            // remove the _present JWTs
            jwtsToUpdate = jwtsToUpdate.filterNot { presentJwts.contains(it) }
        }

        return repository.addOrUpdateJwts(jwtsToUpdate)
    }

    @Throws(Exception::class)
    suspend fun throwIfNotRegistered() {
        // The platform interface is rebuilt on every launch; on iOS the stored token is the App Attest
        // key id that signs each request's assertion, and only registration ever set it before.
        identityPlatformInterface.platformAttestationKeyId =
            localStorage.getAttestationToken() ?: throw WalletNotRegisteredException()
    }

    @Throws(Exception::class)
    suspend fun refresh(credentials: List<LegacyCredential>) {
        throwIfNotRegistered()
        val jwts: MutableList<Jwt> = mutableListOf()

        // refresh uris
        val uriCredentials = credentials.filterIsInstance<LegacyCredential.UriCredential>()
        jwts += identityPlatformInterface.refreshClaims(
            uris = uriCredentials
        ).jwts

        // refresh the documents
        val documents = credentials.filterIsInstance<LegacyCredential.IdentityCredential.Mrtd>()
        jwts += documents.map {
            identityPlatformInterface.refreshClaims(
                document = it
            ).jwts
        }.flatten()

        repository.addOrUpdateJwts(jwts)
    }

    @Throws(Exception::class)
    suspend fun refreshExpiredCredentials(isExpiredFromEpochSecondsOverride: Long) {
        val credentials = getLegacyCredentials().filter {
            it.claims.any { claim -> isExpiredFromEpochSecondsOverride > claim.expires }
        }

        return refresh(credentials)
    }

    private suspend fun getTranslations(): Map<String, String?> {
        val storedTranslations = localStorage.getTranslations()
        if (storedTranslations != null) return storedTranslations

        val translations = identityPlatformInterface.getTranslations()
        localStorage.setTranslations(translations)
        return translations
    }

    @Throws(Exception::class)
    @HiddenFromObjC
    suspend fun isRegistered(): Boolean = localStorage.getAttestationToken() != null

    val json = Json { prettyPrint = true }
    private fun getLatestCredentialOffer(response: Responses.OfferedCredentialResponse): JsonObject? {
        // VCI Offer
        val supportedOffers =
            response.oidcVCIOffers.filter { it.key <= 1.0 }

        if (supportedOffers.isEmpty()) {
            return null
        }

        return supportedOffers.maxBy { it.key }.value
    }
}
