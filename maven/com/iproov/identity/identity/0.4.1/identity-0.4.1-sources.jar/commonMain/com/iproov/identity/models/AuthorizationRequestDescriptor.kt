package com.iproov.identity.models

import com.iproov.identity.api.NetworkClient
import com.iproov.identity.api.OID4VPError
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.Parameters
import io.ktor.http.URLBuilder
import io.ktor.http.isSuccess
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

private val json = Json { ignoreUnknownKeys = true; prettyPrint = true; explicitNulls = false }


/**
 * How the wallet should interpret and (externally) verify a client_id.
 * Verification is implemented elsewhere; this enum only documents behavior.
 *
 * - PRE_REGISTERED: Local registry lookup (static developer portal / allowlist).
 * - REDIRECT_URI_PREFIX: "redirect_uri:{uri}" — no signed request support.
 * - X509_SAN_DNS: "x509_san_dns:{dns}" — Request Object must be JWS signed by a cert whose SAN DNS matches.
 * - DID: "decentralized_identifier:{did}" — verify DID and signing key resolution.
 * - VERIFIER_ATTESTATION: "verifier_attestation:{subject}" — verify attestation JWT.
 * - OPENID_FEDERATION: "openid_federation:{entity_id}" — resolve entity + metadata via federation.
 */
enum class ClientIdType {
    PreRegistered,
    RedirectUri,

    /**
     * MUST be a DNS name and match a dNSName Subject Alternative Name (SAN) [RFC5280] entry
     * in the leaf certificate passed with the request.
     *
     * The request MUST be signed with the private key corresponding to the public key in the
     * leaf X.509 certificate of the certificate chain added to the request in the x5c JOSE header
     * [RFC7515] of the signed request object.
     */
    X509_SAN_DNS,

    /**
     *
     * The request MUST be signed with the private key corresponding to the public key in the
     * leaf X.509 certificate of the certificate chain added to the request in the
     * x5c JOSE header parameter [RFC7515] of the signed request object.
     *
     * The value of x509_hash is the base64url-encoded value of the SHA-256 hash of the DER-encoded X.509 certificate.
     * The Wallet MUST validate the signature and the trust chain of the X.509 leaf certificate.
     * All Verifier metadata other than the public key MUST be obtained from the client_metadata parameter.
     */
    X509_HASH,
    DID,
    VerifierAttestation,
    OpenIDFederation;

    companion object {
        fun infer(value: String): ClientIdType = when {
            value.startsWith("redirect_uri:") -> RedirectUri
            value.startsWith("x509_san_dns:") -> X509_SAN_DNS
            value.startsWith("x509_hash:") -> X509_HASH
            value.startsWith("decentralized_identifier:") -> DID
            value.startsWith("verifier_attestation:") -> VerifierAttestation
            value.startsWith("openid_federation:") -> OpenIDFederation
            else -> PreRegistered
        }
    }
}

/** GET or POST to the Verifier's request_uri endpoint (per spec's "request_uri_method"). */
enum class RequestUriMethod { GET, POST }

/**
 * AuthorizationRequestDescriptor is parsed from the inbound "authorization" URI.
 * It tells the wallet how to obtain/resolve the full Authorization Request object.
 *
 * Either `request` OR `request_uri` must be present.
 */
@Serializable
data class AuthorizationRequestDescriptor(
    /** Verifier identifier (how the wallet identifies the Verifier for trust decisions). */
    @SerialName("client_id")
    val clientId: String,

    /** Optional "by reference" pointer to fetch the full Request Object (JWT or plain JSON). */
    @SerialName("request_uri")
    val requestUri: String? = null,


    /** Derived type for downstream validation switch (handled elsewhere). */
    val clientIdType: ClientIdType = ClientIdType.infer(clientId),

    /**
     * If using request_uri, the wallet MAY POST its metadata instead of GET.
     * Default is GET.
     */
    @SerialName("request_uri_method")
    val requestUriMethod: RequestUriMethod = RequestUriMethod.GET,

    /**
     * Optional "by value" Request Object (usually a signed JWT).
     * If present, use this directly (no network fetch).
     */
    val request: String? = null,

    /**
     * Original URI
     */
    val raw: String
) {

    companion object {
        fun fromHttpParameters(uri: String): AuthorizationRequestDescriptor {
            val urlBuilder = URLBuilder(uri)
            val params = urlBuilder.parameters
            val clientId = requireNotNull(params["client_id"]) { "Missing client_id" }
            val requestUri = params["request_uri"]
            val request = params["request"]
            val method = when (params["request_uri_method"]?.lowercase()) {
                "post" -> RequestUriMethod.POST
                else -> RequestUriMethod.GET
            }
            return AuthorizationRequestDescriptor(
                clientId = clientId,
                requestUri = requestUri,
                requestUriMethod = method,
                request = request,
                raw = uri
            )
        }
    }


    /**
     * Resolve the effective AuthorizationRequest:
     * 1) If `request` is present: decode it (JWT payload or plain JSON).
     * 2) Else, fetch from `request_uri` using GET (default) or POST (include wallet metadata).
     * 3) Parse JSON payload into AuthorizationRequest.
     *
     * Signature and client binding validation are intentionally out-of-scope here;
     * do that in your validator using `clientIdType`.
     */
    suspend fun retrieveAuthorizationRequest(
        networkClient: NetworkClient,
        walletMetadata: OID4VPCapabilities,
    ): AuthorizationRequest {
        request?.let { byValue ->
            return AuthorizationRequest.fromRequestJwtOrJson(byValue)
        }

        val uri = requireNotNull(requestUri) { "request_uri is required when `request` is absent" }

        val res = when (requestUriMethod) {
            RequestUriMethod.GET -> {
                networkClient.get(
                    url = uri,
                    headers = mapOf("Accept" to "application/oauth-authz-req+jwt")
                )
            }

            RequestUriMethod.POST -> {
                // application/x-www-form-urlencoded + Accept header
                val params = Parameters.build {
                    set("wallet_metadata", json.encodeToString(walletMetadata))
                }
                networkClient.submitForm(
                    uri, params, mapOf(
                        HttpHeaders.Accept to "application/oauth-authz-req+jwt"
                    )
                )
            }
        }

        if (!res.status.isSuccess()) {
            if (res.status == HttpStatusCode.BadRequest) {
                throw OID4VPError.IncompatibleVerifier(
                    "The verifier's presentation request is not supported by this wallet.",
                    cause = Exception("HTTP ${res.status.value}, retrieving authorization request: $requestUri")
                )
            }

            val responseBody = res.bodyAsText()
            throw OID4VPError.FailedToFetchPresentationRequest(
                requestUri,
                "Failed to fetch request verifier. HTTP ${res.status.value} ${if (responseBody.isEmpty()) "- No further information provided" else "- $responseBody"}",
                cause = Exception("HTTP ${res.status.value}")
            )
        }

        return AuthorizationRequest.fromRequestJwtOrJson(res.bodyAsText())
    }
}


/* ---------------------------- helpers ---------------------------- */

private fun looksLikeJwt(s: String) = s.count { it == '.' } == 2