package com.iproov.identity

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build


@SuppressLint("HardwareIds")
class AndroidPlatform(private val context: Context, private val instanceId: String) : Platform {

    /**
     * True only for an emulator running a debuggable build of the *consuming app*.
     *
     * Gates the simple-password attestation fallback, which exists because Play Integrity cannot
     * succeed on an emulator. Unlike iOS — where simulator and device are separate xcframework
     * slices, so the device binary cannot contain the fallback at all — Android ships one artifact
     * for both, so the guard has to hold at runtime.
     *
     * Hence two independent conditions:
     *  - [ApplicationInfo.FLAG_DEBUGGABLE] on the host app, which is the load-bearing half. A
     *    production build — release-signed, shipped through Play — never sets it, so the fallback
     *    is unreachable there regardless of what the device reports. This deliberately asks about
     *    the *app*, not this SDK: an earlier version gated on the SDK's own `BuildConfig.DEBUG`,
     *    which only ever describes how the SDK itself was compiled, and since just the `release`
     *    variant is published (see `publishLibraryVariants`) it was permanently false for every
     *    consumer — the fallback could not activate from the released AAR at all.
     *  - The build fingerprint, which is a heuristic and forgeable on a rooted device. On its own
     *    it would be weak; combined with the above it only widens what a debuggable app accepts.
     *
     * Outside both sits the real boundary, which is server-side: the simple-password token is only
     * honoured by the DEV environment, so even a debuggable app on an emulator cannot register
     * against PROD without genuine Play Integrity.
     */
    override val isVirtual: Boolean by lazy {
        isVirtualDevice(
            isDebuggableApp = context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0,
            hardware = Build.HARDWARE,
            fingerprint = Build.FINGERPRINT,
            product = Build.PRODUCT,
        )
    }

    override val target: Platform.Target by lazy {
        Platform.Target.Android
    }

    override val appInfo: AppInfo by lazy {
        val packageManager = context.packageManager
        val info = packageManager.getPackageInfo(context.packageName, 0)

        AppInfo(
            client = context.packageName,
            version = info.versionName
        )
    }

    override val deviceInfo: DeviceInfo
        get() = DeviceInfo(
            manufacturer = Build.MANUFACTURER,
            os = "Android",
            instanceId = instanceId,
            model = Build.MODEL,
            osversion = Build.VERSION.RELEASE,
        )
}

/**
 * The [AndroidPlatform.isVirtual] decision, taking its inputs as parameters so it is testable
 * without the Android framework — `Build`'s fields are static stubs under unit test and return
 * null, which is also why the three of them are nullable here.
 *
 * [isDebuggableApp] is the gate; the rest is a deliberately narrow emulator heuristic, since a
 * false negative only costs a developer the fallback (they get the normal Play Integrity failure)
 * and so breadth buys little.
 *
 * `Build.HARDWARE` is the dependable signal: `ranchu` for the current Android Studio emulator,
 * `goldfish` for older images, and `gce_x86`/`cutf_cvm` for the Cuttlefish VMs that CI and Firebase
 * Test Lab run. The other two cover images that report a `generic` fingerprint or an SDK product
 * name — note the current AVD fingerprint (`google/sdk_gphone64_arm64/...`) matches neither, which
 * is why the hardware check has to come first.
 */
internal fun isVirtualDevice(
    isDebuggableApp: Boolean,
    hardware: String?,
    fingerprint: String?,
    product: String?,
): Boolean = isDebuggableApp && (
    hardware in setOf("goldfish", "ranchu", "gce_x86", "cutf_cvm") ||
        fingerprint?.contains("generic") == true ||
        product?.contains("sdk") == true
    )
