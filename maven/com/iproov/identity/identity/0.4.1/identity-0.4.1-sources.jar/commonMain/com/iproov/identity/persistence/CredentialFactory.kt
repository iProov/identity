package com.iproov.identity.persistence

import com.iproov.identity.models.Claim
import com.iproov.identity.models.Credential

/**
 * Defines a contract for creating a specific type of Credential.
 * Implementations of this interface can be registered with the PluggableCredentialDeserializer.
 */
interface CredentialFactory {

    /**
     * The format of the credential this factory will produce.
     *
     * String instead of enum as implementers might want to support custom / new formats that are
     * that do not have 1st class support yet.
     */
    val format: String

    /**
     * Creates a Credential with the raw data provided by a credential record
     *
     * @param raw The raw data received by the wallet from the issuer without any mutation.
     * @return The constructed Credential object.
     */
    fun createCredential(raw: String): Credential
}
