package com.iproov.identity.proximity

import com.iproov.identity.Logger
import com.iproov.identity.TrustConfiguration
import com.iproov.identity.api.StatusListVerifier
import com.iproov.identity.models.toNativeTypes
import com.iproov.identity.persistence.IssuerSignedMdoc
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.ProducerScope
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import org.multipaz.asn1.OID
import org.multipaz.cbor.Bstr
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.DataItem
import org.multipaz.cbor.Tagged
import org.multipaz.cbor.buildCborArray
import org.multipaz.crypto.Algorithm
import org.multipaz.crypto.AsymmetricKey
import org.multipaz.crypto.Crypto
import org.multipaz.crypto.EcPrivateKey
import org.multipaz.crypto.X509Cert
import org.multipaz.mdoc.devicesigned.DeviceAuth
import org.multipaz.mdoc.engagement.DeviceEngagement
import org.multipaz.mdoc.mso.MobileSecurityObject
import org.multipaz.mdoc.request.DeviceRequestGenerator
import org.multipaz.mdoc.response.DeviceResponse
import org.multipaz.mdoc.response.MdocDocument
import org.multipaz.mdoc.role.MdocRole
import org.multipaz.mdoc.sessionencryption.SessionEncryption
import org.multipaz.mdoc.transport.MdocTransport
import org.multipaz.util.Constants
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

class ProximityRetrievalSession internal constructor(

    private val engagementSource: suspend ProducerScope<ProximityRetrievalEvent>.() -> EngagementOutcome,
    private val requestedDocuments: List<DocumentRequest>,
    private val createSigningData: (suspend () -> ReaderSigningData)?,
    private val orchestrator: ProximityOrchestrator,
    private val config: ProximityConfig.Reader,
    private val trust: TrustConfiguration,
) {


    companion object {
        // Documented in Annex B.1.4
        val MAX_CERTIFICATE_EXPIRATION_DURATION = CertTrust.MAX_DOCUMENT_SIGNER_VALIDITY
    }

    internal data class EngagementOutcome(
        val deviceEngagement: DeviceEngagement,
        val mdocTransport: MdocTransport,
        val handover: DataItem,
    )

    private var transport: MdocTransport? = null
    private val transportMutex = Mutex()

    @OptIn(ExperimentalObjCRefinement::class)
    @HiddenFromObjC
    val events: Flow<ProximityRetrievalEvent> = channelFlow {
        var eReaderKey: EcPrivateKey? = null
        lateinit var sessionEncryption: SessionEncryption
        lateinit var sessionTranscript: DataItem

        try {

            trust.uncheckedIssuers?.let {
                Logger.info(
                    "TrustAll: any DS certificate will be accepted for $it. " +
                            "This is development-only — production must use TrustedCertificates."
                )
            }

            val engagementOutcome = engagementSource.invoke(this)

            transportMutex.withLock { transport = engagementOutcome.mdocTransport }

            val signingData = createSigningData?.invoke()
            val readerKey = signingData?.toEcPrivateKey()
            val readerCertChain = signingData?.toX509CertChain()

            withTimeout(config.engagementTimeout) {
                send(ProximityRetrievalEvent.Connecting)

                engagementOutcome.mdocTransport.open(engagementOutcome.deviceEngagement.eDeviceKey)
                Logger.debug("Transport session opened")

                send(ProximityRetrievalEvent.SendingRequest)

                eReaderKey =
                    Crypto.createEcPrivateKey(engagementOutcome.deviceEngagement.eDeviceKey.curve)

                val encodedDeviceEngagement =
                    Cbor.encode(engagementOutcome.deviceEngagement.toDataItem())
                val encodedEReaderKey = Cbor.encode(eReaderKey.publicKey.toCoseKey().toDataItem())

                sessionTranscript = buildCborArray {
                    add(Tagged(Tagged.ENCODED_CBOR, Bstr(encodedDeviceEngagement)))
                    add(Tagged(Tagged.ENCODED_CBOR, Bstr(encodedEReaderKey)))
                    add(engagementOutcome.handover)
                }
                val encodedSessionTranscript = Cbor.encode(sessionTranscript)

                sessionEncryption = SessionEncryption(
                    role = MdocRole.MDOC_READER,
                    eSelfKey = eReaderKey,
                    remotePublicKey = engagementOutcome.deviceEngagement.eDeviceKey,
                    encodedSessionTranscript = encodedSessionTranscript,
                )

                val deviceRequestGenerator = DeviceRequestGenerator(encodedSessionTranscript)

                for (doc in requestedDocuments) {
                    deviceRequestGenerator.addDocumentRequest(
                        docType = doc.docType,
                        itemsToRequest = doc.toItemsMap(),
                        requestInfo = null,
                        readerKey = readerKey,
                        signatureAlgorithm = readerKey?.curve?.defaultSigningAlgorithm
                            ?: Algorithm.UNSET,
                        readerKeyCertificateChain = readerCertChain,
                    )
                }

                val encodedDeviceRequest = deviceRequestGenerator.generate()
                val message = sessionEncryption.encryptMessage(
                    messagePlaintext = encodedDeviceRequest,
                    statusCode = null,
                )

                engagementOutcome.mdocTransport.sendMessage(message)
                Logger.debug("DeviceRequest sent")
            }

            send(ProximityRetrievalEvent.WaitingForResponse)

            val responseBytes = withTimeout(config.sessionInactivityTimeout) {
                engagementOutcome.mdocTransport.waitForMessage()
            }

            if (responseBytes.isEmpty()) {
                throw ProximityRetrievalException("Presenter terminated the session before responding")
            }

            val (decryptedResponse, status) = sessionEncryption.decryptMessage(responseBytes)

            if (status != null && status != Constants.SESSION_DATA_STATUS_SESSION_TERMINATION) {
                throw ProximityRetrievalException("Presenter reported error (status=$status)")
            }

            if (status == Constants.SESSION_DATA_STATUS_SESSION_TERMINATION && decryptedResponse == null) {
                throw ProximityRetrievalException("Presenter terminated the session without responding")
            }

            if (decryptedResponse == null) {
                throw ProximityRetrievalException("Received empty response from presenter")
            }

            send(ProximityRetrievalEvent.ProcessingResponse)

            val deviceResponse = DeviceResponse.fromDataItem(Cbor.decode(decryptedResponse))

            if (deviceResponse.version != "1.0") {
                throw ProximityRetrievalException("Unsupported DeviceResponse version: ${deviceResponse.version}")
            }

            if (deviceResponse.status != DeviceResponse.STATUS_OK) {
                throw ProximityRetrievalException("Presenter returned error status: ${deviceResponse.status}")
            }

            deviceResponse.verify(
                sessionTranscript = sessionTranscript,
                eReaderKey = eReaderKey?.let { AsymmetricKey.anonymous(it) },
            )

            if (deviceResponse.documents.isEmpty()) {
                throw ProximityRetrievalException("Presenter did not disclose any documents")
            }

            for (doc in deviceResponse.documents) {
                verifyReceivedIssuer(doc.issuerCertChain.certificates, doc.mso, trust)
                verifyKeyAuthorizations(doc)
                verifyNoDuplicateDigestIds(doc)
            }

            Logger.debug("DeviceResponse verified: ${deviceResponse.documents.size} document(s)")

            val response = toRetrievalResponse(deviceResponse, decryptedResponse)
            send(ProximityRetrievalEvent.Completed(response))
        } catch (e: TimeoutCancellationException) {
            send(ProximityRetrievalEvent.Error("Session timed out", e))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val errorMsg = e.message
                ?: e.cause?.message
                ?: "${e::class.simpleName ?: "Unknown error"}: ${
                    e.stackTraceToString().lines().firstOrNull() ?: ""
                }"
            Logger.error("Proximity retrieval failed: $errorMsg")
            send(ProximityRetrievalEvent.Error(errorMsg, e))
        } finally {
            eReaderKey?.d?.fill(0)
            terminateTransport()
        }

        awaitClose()
    }

    @Throws(Exception::class)
    suspend fun close() {
        terminateTransport()
    }

    private suspend fun terminateTransport() {
        transportMutex.withLock {
            transport?.let { t ->
                runCatching {
                    t.sendMessage(
                        SessionEncryption.encodeStatus(Constants.SESSION_DATA_STATUS_SESSION_TERMINATION)
                    )
                }
                runCatching { t.close() }
                transport = null
            }
        }
    }

    // §9.1.3.4: verify the device key is authorized for all namespaces/elements in DeviceNameSpaces
    private fun verifyKeyAuthorizations(doc: MdocDocument) {
        val deviceNamespaces = doc.deviceNamespaces.data
        if (deviceNamespaces.isEmpty()) return

        val mso = doc.mso
        val authorizedNamespaces = mso.deviceKeyAuthorizedNamespaces
        val authorizedElements = mso.deviceKeyAuthorizedDataElements

        // If neither authorizedNamespaces nor authorizedElements are present in the MSO,
        // the device key is implicitly authorized for everything (per spec, both are optional).
        if (authorizedNamespaces.isEmpty() && authorizedElements.isEmpty()) return

        for ((namespace, elements) in deviceNamespaces) {
            if (authorizedNamespaces.contains(namespace)) continue

            val allowedElements = authorizedElements[namespace] ?: throw Exception(
                "Document ${doc.docType}: device key is not authorized for namespace '$namespace'"
            )

            for (elementName in elements.keys) {
                if (!allowedElements.contains(elementName)) {
                    throw Exception(
                        "Document ${doc.docType}: device key is not authorized for element '$elementName' in namespace '$namespace'"
                    )
                }
            }
        }
    }

    // §9.1.2.4: DigestID shall be unique per namespace; no duplicate DataElementIdentifiers
    private fun verifyNoDuplicateDigestIds(doc: MdocDocument) {
        for ((namespace, elements) in doc.issuerNamespaces.data) {
            val seenDigestIds = mutableSetOf<Long>()
            for ((elementName, item) in elements) {
                if (!seenDigestIds.add(item.digestId)) {
                    throw Exception(
                        "Document ${doc.docType}: duplicate digestID ${item.digestId} in namespace '$namespace' (element '$elementName')"
                    )
                }
            }
        }
    }

    private fun toRetrievalResponse(
        deviceResponse: DeviceResponse,
        rawResponseBytes: ByteArray,
    ): ProximityRetrievalResponse {
        return ProximityRetrievalResponse(
            documents = deviceResponse.documents.map { it.toReceivedCredential(trust) },
            documentErrors = deviceResponse.documentErrors.flatMap { errorMap ->
                errorMap.entries.map { (docType, errorCode) ->
                    DocumentError(docType, errorCode)
                }
            },
            rawResponse = rawResponseBytes,
        )
    }
}

class ProximityRetrievalException(message: String) : Exception(message)

/**
 * ISO 18013-5 §9.3.1 for a received document. Call it only after multipaz's `DeviceResponse.verify`, which
 * requires each document's docType to equal its MSO's, so the signed MSO docType picks the trust rule.
 */
internal suspend fun verifyReceivedIssuer(chain: List<X509Cert>, mso: MobileSecurityObject, trust: TrustConfiguration) {
    val context = "Document ${mso.docType}"
    // §9.3.1 step 5a authenticates the MSO itself, so it applies whatever the trust policy.
    chain.firstOrNull()?.let { CertTrust.verifySignedAtWithinValidity(it, mso.signedAt, context) }
    val issuerTrust = trust.issuerTrustFor(mso.docType)
    if (issuerTrust !is IssuerTrustPolicy.TrustedCertificates) return
    CertTrust.verifyIssuerTrust(chain = chain, signedAt = mso.signedAt, trust = issuerTrust, context = context)
}

/** A verified [MdocDocument] as the app sees it. Its status is only fetched when the app asks for it. */
internal fun MdocDocument.toReceivedCredential(
    trust: TrustConfiguration,
    verifier: StatusListVerifier = StatusListVerifier.shared,
): ReceivedMDocCredential {
    return ReceivedMDocCredential(
        docType = docType,
        nameSpaces = issuerNamespaces.data.entries.associate { (namespace, claims) ->
            namespace to claims.entries.associate { (claimName, item) ->
                claimName to item.dataElementValue.toNativeTypes()
            }
        },
        issuerCertificateChain = issuerCertChain.certificates.map {
            it.encoded.toByteArray()
        },
        issuerCountry = runCatching {
            issuerCertChain.certificates.firstOrNull()
                ?.subject?.components?.get(OID.COUNTRY_NAME.oid)?.value
        }.getOrNull(),
        validFrom = mso.validFrom.toString(),
        validUntil = mso.validUntil.toString(),
        deviceAuthType = when (deviceAuth) {
            is DeviceAuth.Ecdsa -> DeviceAuthType.Signature
            is DeviceAuth.Mac -> DeviceAuthType.Mac
        },
        errors = errors,
        issuerSigned = IssuerSignedMdoc.received(issuerAuth),
        trust = trust,
        verifier = verifier,
    )
}
