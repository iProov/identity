package com.iproov.identity.models

import kotlinx.serialization.Serializable

/**
 * A record that is stored for each of the credentials issued to the wallet.
 *
 * The credentials themselves are built when loaded via the wallet, only raw data issued
 * to the wallet is stored.
 */
@Serializable
data class CredentialRecord(
    /**
     * The format of the credential (this will be used to serialize it)
     */
    val format: String,

    /**
     * The raw credential as it was received by the issuer.
     */
    val data: String,
)