package com.iproov.identity.cryptography


// --- Constants ---
const val AES_KEY_SIZE_BYTES = 32 // 32 bytes = 256 bits for AES-256
const val AES_BLOCK_SIZE_BYTES = 16 // AES block size is always 16 bytes (128 bits)

/** Generates cryptographically secure random bytes. */
internal expect fun generateSecureRandomBytes(size: Int): ByteArray

/**
 * Represents a symmetric encryption key for AES-256/CBC/PKCS7Padding.
 *
 * Keys can be created in two ways:
 * 1. Using the primary constructor with existing raw key bytes (`SymmetricKey(keyBytes: ByteArray)`).
 * 2. Using the secondary constructor with a string, which derives the key via SHA-256
 * (`SymmetricKey(keyString: String)`). **Warning:** This is less secure if the string is weak.
 * 3. Using the companion factory `SymmetricKey.new()` to generate a new, secure random key.
 *
 * The encryption methods use AES/CBC/PKCS7Padding. A random 16-byte IV is generated
 * for each encryption and prepended to the ciphertext.
 */
expect class SymmetricKey {

    /**
     * Primary constructor: Initializes the key with the provided raw bytes.
     * The key bytes MUST be of the correct length (e.g., 32 bytes for AES-256).
     * @param keyBytes The raw bytes of the symmetric key.
     * @throws IllegalArgumentException if keyBytes has an incorrect length.
     */
    constructor(keyBytes: ByteArray)

    /**
     * Secondary constructor: Derives the key bytes from the provided string using SHA-256.
     * **Warning:** This method is less secure than using a randomly generated key if the
     * input string is guessable or has low entropy. Prefer `SymmetricKey.new()` for generating keys.
     * The resulting key will be 32 bytes (AES-256).
     * @param keyString The string to derive the key from.
     */
    constructor(keyString: String)

    /**
     * Encrypts the given ByteArray data using AES-256/CBC/PKCS7Padding.
     * A random 16-byte IV is generated and prepended to the ciphertext.
     *
     * @param plainData The ByteArray to encrypt.
     * @return The encrypted data (IV + Ciphertext) as a ByteArray, or null on failure.
     */
    fun encrypt(plainData: ByteArray): ByteArray?

    /**
     * Decrypts the given ByteArray data (which must include the 16-byte IV prefix)
     * using AES-256/CBC/PKCS7Padding.
     *
     * @param encryptedData The ByteArray to decrypt (must start with the 16-byte IV).
     * @return The original plaintext data as a ByteArray, or null if decryption fails
     * (e.g., wrong key, corrupted data, invalid padding).
     */
    fun decrypt(encryptedData: ByteArray): ByteArray?

    /**
     * Retrieves the raw bytes of the symmetric key.
     * Useful for storing or transmitting a key generated with `SymmetricKey.new()`.
     *
     * @return A copy of the raw key bytes.
     */
    fun getKeyBytes(): ByteArray

    /**
     * Retrieves the raw bytes of the symmetric key, encoded as a Base64 string.
     * This format is suitable for storing in text-based storage like SharedPreferences or UserDefaults.
     *
     * @return The Base64 encoded string representation of the key bytes.
     */
    fun getKeyString(): String

    /**
     * Companion object for factory methods.
     */
    companion object {
        /**
         * Generates a new `SymmetricKey` instance with a cryptographically secure
         * random key suitable for AES-256 (32 bytes).
         *
         * @return A new SymmetricKey instance with a randomly generated key.
         */
        fun new(): SymmetricKey
    }

}