package com.iproov.identity.trust

/**
 * Verification contexts for trust evaluation, derived from ETSI TS 119 602.
 *
 * Each context corresponds to a specific LoTE (List of Trusted Entities) profile
 * defined in the annexes of ETSI TS 119 602. The LoTE entries are tagged with
 * service type URIs that identify what kind of provider an entry represents.
 * When evaluating trust, the context determines which LoTE entries are consulted.
 *
 * Reference: ETSI TS 119 602 v1.1.1 (2025-11)
 * See: docs/ETSI_LOTE.md
 */
enum class VerificationContext(
    val serviceTypeUri: String?,
) {

    /**
     * PID (Person Identification Data) issuance.
     *
     * Validates that a credential issuer is a registered PID provider — a body
     * notified by an EU Member State as responsible for issuing person identification
     * data and ensuring it is cryptographically bound to a wallet unit.
     *
     * The LoTE entry's ServiceDigitalIdentity contains X.509 certificates that
     * can be used to verify the signature or seal created by the PID provider on
     * the person identification data it issues.
     *
     * Used during: OID4VCI credential issuance when the offered credential is a PID.
     *
     * LoTE profile: Annex D
     * Service type URI: http://uri.etsi.org/19602/SvcType/PID/Issuance
     * LoTE type URI: http://uri.etsi.org/19602/LoTEType/EUPIDProvidersList
     */
    PID("http://uri.etsi.org/19602/SvcType/PID/Issuance"),

    /**
     * PID revocation status.
     *
     * Validates the signer of a Token Status List that provides validity status
     * information on person identification data.
     *
     * Used during: Revocation checks for PID credentials.
     *
     * LoTE profile: Annex D
     * Service type URI: http://uri.etsi.org/19602/SvcType/PID/Revocation
     */
    PIDStatus("http://uri.etsi.org/19602/SvcType/PID/Revocation"),

    /**
     * Qualified Electronic Attestation of Attributes (QEAA) issuance.
     *
     * Validates that a credential issuer is a qualified trust service provider
     * authorized to issue electronic attestations of attributes with qualified
     * legal standing (e.g., a qualified mDL issuer).
     *
     * Used during: OID4VCI credential issuance when the offered credential is a QEAA.
     *
     * Note: QEAA provider lists are not yet profiled in ETSI TS 119 602 but the
     * context is defined here for forward compatibility with the EUDI library.
     */
    QEAA(null),

    /**
     * QEAA revocation status.
     *
     * Validates the signer of a Token Status List that provides validity status
     * information on qualified electronic attestations of attributes.
     *
     * Used during: Revocation checks for QEAA credentials.
     */
    QEAAStatus(null),

    /**
     * Public Electronic Attestation of Attributes (Pub-EAA) issuance.
     *
     * Validates that a credential issuer is a public sector body authorized to
     * issue electronic attestations of attributes (e.g., a government mDL issuer,
     * a public university issuing diplomas).
     *
     * The LoTE entry's ServiceDigitalIdentity contains X.509 certificates that
     * can be used to verify the signature or seal created by the public sector
     * body on the electronic attestation of attributes it issues.
     *
     * Used during: OID4VCI credential issuance when the offered credential is
     * issued by a public sector body.
     *
     * LoTE profile: Annex H
     * Service type URI: http://uri.etsi.org/19602/SvcType/PubEAA/Issuance
     * LoTE type URI: http://uri.etsi.org/19602/LoTEType/EUPubEAAProvidersList
     */
    PubEAA("http://uri.etsi.org/19602/SvcType/PubEAA/Issuance"),

    /**
     * Pub-EAA revocation status.
     *
     * Validates the signer of a Token Status List that provides validity status
     * information on electronic attestations of attributes from public sector bodies.
     *
     * Used during: Revocation checks for Pub-EAA credentials.
     *
     * LoTE profile: Annex H
     * Service type URI: http://uri.etsi.org/19602/SvcType/PubEAA/Revocation
     */
    PubEAAStatus("http://uri.etsi.org/19602/SvcType/PubEAA/Revocation"),

    /**
     * Wallet provider attestation.
     *
     * Validates that a wallet provider is registered — a body notified by an EU
     * Member State whose wallet solution has been certified. The LoTE entry's
     * ServiceDigitalIdentity contains X.509 certificates that can be used to
     * authenticate and validate the components of the wallet unit the provider
     * supplies.
     *
     * Used during: Wallet Instance Attestation (WIA) and Key Attestation
     * signature verification.
     *
     * LoTE profile: Annex E
     * Service type URI: http://uri.etsi.org/19602/SvcType/WalletSolution/Issuance
     * LoTE type URI: http://uri.etsi.org/19602/LoTEType/EUWalletProvidersList
     */
    WalletProviderAttestation("http://uri.etsi.org/19602/SvcType/WalletSolution/Issuance"),

    /**
     * Wallet or key storage revocation status.
     *
     * Validates the signer of a Token Status List that provides validity status
     * information on a wallet solution.
     *
     * Used during: Checking whether a wallet solution has been revoked.
     *
     * LoTE profile: Annex E
     * Service type URI: http://uri.etsi.org/19602/SvcType/WalletSolution/Revocation
     */
    WalletOrKeyStorageStatus("http://uri.etsi.org/19602/SvcType/WalletSolution/Revocation"),

    /**
     * Wallet Relying Party Access Certificate (WRPAC).
     *
     * Validates that a verifier (relying party) holds a valid access certificate
     * issued by a provider mandated by an EU Member State. WRPAC providers are
     * CAs whose certificates appear in the LoTE; the verifier's leaf certificate
     * chains to one of these CAs via PKIX validation.
     *
     * The LoTE entry's ServiceDigitalIdentity contains X.509 CA certificates
     * that can be used to verify the signature or seal created by the WRPAC
     * provider on the access certificates it issues to wallet-relying parties.
     *
     * Used during: OID4VP presentation requests when the verifier uses
     * X509_SAN_DNS or X509_HASH client ID types with a signed authorization
     * request containing an x5c certificate chain. Also used during DC API
     * signed request verification.
     *
     * Validation method: PKIX chain validation (CA certificates in LoTE).
     *
     * LoTE profile: Annex F
     * Service type URI: http://uri.etsi.org/19602/SvcType/WRPAC/Issuance
     * LoTE type URI: http://uri.etsi.org/19602/LoTEType/EUWRPACProvidersList
     */
    WalletRelyingPartyAccessCertificate("http://uri.etsi.org/19602/SvcType/WRPAC/Issuance"),

    /**
     * Wallet Relying Party Registration Certificate (WRPRC).
     *
     * Validates that a verifier holds a valid registration certificate declaring
     * its intended use cases and data access policies, issued by a provider
     * mandated by an EU Member State. Like WRPAC, validation is via PKIX chain
     * to CA certificates in the LoTE.
     *
     * The LoTE entry's ServiceDigitalIdentity contains X.509 CA certificates
     * that can be used to verify the signature or seal created by the WRPRC
     * provider on the registration certificates it issues to wallet-relying parties.
     *
     * Used during: Verifying a relying party's declared data use policies, in
     * addition to WRPAC access validation.
     *
     * Validation method: PKIX chain validation (CA certificates in LoTE).
     *
     * LoTE profile: Annex G
     * Service type URI: http://uri.etsi.org/19602/SvcType/WRPRC/Issuance
     * LoTE type URI: http://uri.etsi.org/19602/LoTEType/EUWRPRCProvidersList
     */
    WalletRelyingPartyRegistrationCertificate("http://uri.etsi.org/19602/SvcType/WRPRC/Issuance"),
}
