package com.iproov.identity.trust

/**
 * Maps credential identifiers (docType for mDoc, vct for SD-JWT-VC) to the
 * [VerificationContext]s they should be evaluated against.
 *
 * Used by [RespondableCredentialOffer.verifyIssuer] (no-arg form) to
 * auto-detect which ETSI context applies to the offered credentials.
 *
 * The ETSI standard (TS 119 602) does not define a mapping from credential
 * types to verification contexts — the LoTE entries are organized by service
 * type, not by credential format. This resolver bridges that gap.
 *
 * The built-in [default] resolver maps known EUDI credential identifiers:
 * - `eu.europa.ec.eudi.pid.1` (mDoc PID) → [VerificationContext.PID]
 * - `urn:eu.europa.ec.eudi:pid:1` (SD-JWT PID) → [VerificationContext.PID]
 * - `org.iso.18013.5.1.mDL` (mDoc mDL) → [VerificationContext.QEAA], [VerificationContext.PubEAA]
 *
 * For mDL, both QEAA and PubEAA are returned because the docType alone
 * does not indicate the issuer's qualification level. The evaluator tries
 * both — the LoTE's service type filtering ensures only the correct anchors
 * match.
 *
 * Unknown identifiers return an empty set, which causes
 * [TrustResult.Indeterminate] from `verifyIssuer()`.
 *
 * @see TrustEvaluator
 */
fun interface CredentialContextResolver {

    /**
     * Resolve a credential identifier to the verification contexts it should
     * be evaluated against.
     *
     * @param credentialIdentifier The docType (mDoc) or vct (SD-JWT-VC) of the credential.
     * @return The set of contexts to try, or empty if no mapping exists.
     */
    fun resolve(credentialIdentifier: String): Set<VerificationContext>

    /**
     * Add or override a mapping for a specific credential identifier.
     * Returns a new resolver that checks the override first, then falls
     * through to this resolver for other identifiers.
     *
     * @param credentialIdentifier The docType or vct to map.
     * @param contexts The verification contexts to associate with it.
     */
    fun withMapping(
        credentialIdentifier: String,
        vararg contexts: VerificationContext,
    ): CredentialContextResolver {
        val override = contexts.toSet()
        val parent = this
        return CredentialContextResolver { identifier ->
            if (identifier == credentialIdentifier) override else parent.resolve(identifier)
        }
    }

    companion object {

        private val DEFAULT_MAPPINGS = mapOf(
            "eu.europa.ec.eudi.pid.1" to setOf(VerificationContext.PID),
            "urn:eu.europa.ec.eudi:pid:1" to setOf(VerificationContext.PID),
            "org.iso.18013.5.1.mDL" to setOf(VerificationContext.QEAA, VerificationContext.PubEAA),
        )

        private val DEFAULT = CredentialContextResolver { identifier ->
            DEFAULT_MAPPINGS[identifier] ?: emptySet()
        }

        /**
         * Default resolver with built-in mappings for known EUDI credential types.
         * Use [withMapping] to extend or override.
         */
        fun default(): CredentialContextResolver = DEFAULT
    }
}
