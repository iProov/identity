package com.iproov.identity.proximity

import com.iproov.identity.TrustConfiguration
import com.iproov.identity.api.StatusListVerifier
import com.iproov.identity.models.CredentialStatus
import com.iproov.identity.models.CredentialStatusException
import com.iproov.identity.models.VerificationResult
import com.iproov.identity.models.VerificationStatus
import com.iproov.identity.models.VerificationSummary
import com.iproov.identity.persistence.IssuerSignedMdoc
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC
import kotlin.time.Clock

enum class DeviceAuthType { Signature, Mac }

@OptIn(ExperimentalObjCRefinement::class)
class ReceivedMDocCredential internal constructor(
    val docType: String,
    val nameSpaces: Map<String, Map<String, Any?>>,
    @HiddenFromObjC val issuerCertificateChain: List<ByteArray>,
    val issuerCountry: String?,
    val validFrom: String?,
    val validUntil: String?,
    val deviceAuthType: DeviceAuthType,
    val errors: Map<String, Map<String, Int>>,
    private val issuerSigned: IssuerSignedMdoc?,
    private val trust: TrustConfiguration,
    private val verifier: StatusListVerifier,
) {
    constructor(
        docType: String,
        nameSpaces: Map<String, Map<String, Any?>>,
        issuerCertificateChain: List<ByteArray>,
        issuerCountry: String?,
        validFrom: String?,
        validUntil: String?,
        deviceAuthType: DeviceAuthType,
        errors: Map<String, Map<String, Int>>,
    ) : this(
        docType, nameSpaces, issuerCertificateChain, issuerCountry, validFrom, validUntil, deviceAuthType, errors,
        issuerSigned = null,
        trust = TrustConfiguration(),
        verifier = StatusListVerifier.shared,
    )

    /**
     * The document's status in its IETF Token Status List (draft-ietf-oauth-status-list-21), as
     * [com.iproov.identity.Wallet.resolveStatus] reports a held credential's. The reader authenticated the
     * document when it arrived, under the wallet's [TrustConfiguration]; this checks its validity period
     * again, then fetches the status list. Nothing is fetched during the session.
     *
     * Throws [CredentialStatusException] when no status can be established, which never means valid. A
     * document built with the public constructor has no status reference.
     */
    @Throws(Exception::class)
    suspend fun resolveStatus(): CredentialStatus =
        issuerSigned?.resolveStatus(trust, verifier, Clock.System.now())
            ?: throw CredentialStatusException.NoStatusReference()

    /**
     * The same checks as [com.iproov.identity.models.Credential.getVerificationSummary] reports for a held
     * mDL: validity period, issuer trust and the `status_list` result. Under `TrustAll` it never concludes
     * `VALID`. A document built with the public constructor was never verified, so it concludes
     * `INDETERMINATE`.
     */
    @Throws(Exception::class)
    suspend fun getVerificationSummary(): VerificationSummary =
        issuerSigned?.verificationSummary(trust, verifier, Clock.System.now()) ?: VerificationSummary(
            listOf(VerificationResult("issuer_signature", VerificationStatus.INDETERMINATE, "Document was not received by the reader"))
        )
}
