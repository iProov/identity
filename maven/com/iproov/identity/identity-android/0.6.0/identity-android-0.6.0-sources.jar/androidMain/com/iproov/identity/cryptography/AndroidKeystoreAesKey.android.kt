package com.iproov.identity.cryptography

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AES-256-GCM storage key held in the AndroidKeyStore.
 *
 * The default storage key's ECIES needs ECDH inside the AndroidKeyStore to decrypt, which only exists from API 31, so
 * below that the wallet uses this key instead. Ciphertext is the 12-byte IV followed by the GCM output.
 */
internal class AndroidKeystoreAesKey(
    private val alias: String,
    private val accessPolicy: KeyPairAccessPolicy,
) : EncryptionKey, ResettableKey {

    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    // Engines build a key object per access; generating twice would replace the key under data already written.
    private val key: SecretKey
        get() = synchronized(AndroidKeystoreAesKey) { keyStore.getKey(alias, null) as SecretKey? ?: generate() }

    private fun generate(): SecretKey = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
        val spec = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .apply { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) setUnlockedDeviceRequired(true) }
            .apply(accessPolicy.options)
            .build()
        init(spec)
        generateKey()
    }

    override fun encrypt(data: ByteArray): ByteArray = Cipher.getInstance(TRANSFORMATION).run {
        init(Cipher.ENCRYPT_MODE, key)
        iv + doFinal(data)
    }

    override fun decrypt(data: ByteArray): ByteArray = Cipher.getInstance(TRANSFORMATION).run {
        init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_LENGTH_BITS, data, 0, IV_LENGTH))
        doFinal(data, IV_LENGTH, data.size - IV_LENGTH)
    }

    override fun reset() = keyStore.deleteEntry(alias)

    companion object {
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_LENGTH = 12
        private const val TAG_LENGTH_BITS = 128

        fun exists(alias: String): Boolean =
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.containsAlias(alias)
    }
}
