package com.iproov.identity.proximity

import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.nfc.NfcManager
import com.iproov.identity.AppContext
import com.iproov.identity.Logger


/**
 * Android implementation of proximity platform availability.
 *
 * Returns true when the device can in principle present mdoc credentials over BLE per
 * ISO/IEC 18013-5:2021. Runtime concerns — Bluetooth toggled off, permissions not yet
 * granted — are NOT gated here; they surface as Failure events at session start.
 *
 * Checks (all required):
 * 1. Hardware supports BLE (PackageManager.FEATURE_BLUETOOTH_LE)
 * 2. Bluetooth adapter exists
 * 3. Radio supports BLE peripheral mode (isMultipleAdvertisementSupported) —
 *    the decisive check; many real-world Android devices have BLE central but
 *    not BLE peripheral. Known quirk: this can return false when Bluetooth is
 *    currently off, which is the accepted false-negative for static availability.
 *
 * Note: the SDK's minSdk is 26, so a `Build.VERSION.SDK_INT` check is unnecessary
 * — the OS install guarantees we're on a supported API level.
 */
actual fun isProximityPlatformAvailable(): Boolean = withAppContext(false) { context ->
    if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
        return false
    }

    val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    val adapter = bluetoothManager?.adapter ?: return false

    return adapter.isMultipleAdvertisementSupported
}

/**
 * Android implementation of NFC engagement availability.
 *
 * Returns true when the device can in principle perform NFC static handover for
 * mdoc engagement per ISO/IEC 18013-5:2021 §8.2.2.1. As with BLE, runtime concerns
 * (NFC currently disabled in system settings, app not foregrounded) are NOT gated
 * here; they surface as Failure events when NfcEngagement.enable() is called.
 *
 * Checks (all required):
 * 1. Hardware has an NFC radio (PackageManager.FEATURE_NFC)
 * 2. Hardware supports Host Card Emulation (PackageManager.FEATURE_NFC_HOST_CARD_EMULATION) —
 *    the decisive check; many devices have NFC reader-only mode without HCE.
 * 3. NFC adapter is exposed by the OS (defaultAdapter != null)
 */
actual fun isNfcHceAvailable(): Boolean = withAppContext(false) { context ->
    val pm = context.packageManager
    pm.hasSystemFeature(PackageManager.FEATURE_NFC) &&
            pm.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION) &&
            (context.getSystemService(Context.NFC_SERVICE) as? NfcManager)?.defaultAdapter != null
}

/**
 * Android implementation of reader-side NFC availability.
 *
 * Combined check: NFC hardware present AND adapter currently enabled. No HCE
 * requirement — the reader side just needs an NFC radio that can power up and
 * scan tags. This is the right gate for [startProximityRetrieval] over NFC.
 */
actual fun isNfcReaderAvailable(): Boolean = withAppContext(false) { context ->
    val pm = context.packageManager
    if (!pm.hasSystemFeature(PackageManager.FEATURE_NFC)) return@withAppContext false
    val nfcManager = context.getSystemService(Context.NFC_SERVICE) as? NfcManager
    nfcManager?.defaultAdapter?.isEnabled == true
}

internal actual fun createPlatformNfcEngagement(): NfcEngagement = AndroidNfcEngagement()

/**
 * Android implementation of NFC adapter runtime state check.
 *
 * Returns true only when the user has NFC currently turned on in system settings.
 * Returns false if NFC is toggled off, hardware is missing, or AppContext isn't available.
 */

actual fun isNfcAdapterEnabled(): Boolean = withAppContext(false) { context ->
    val nfcManager = context.getSystemService(Context.NFC_SERVICE) as? NfcManager
    return nfcManager?.defaultAdapter?.isEnabled == true
}

private inline fun <T> withAppContext(unavailable: T, block: (Context) -> T): T {
    val context = try {
        AppContext.get()
    } catch (e: Exception) {
        Logger.debug("AppContext not initialised: ${e.message}")
        return unavailable
    }
    return block(context)
}
