package com.iproov.identity.proximity

import com.iproov.identity.proximity.CertTrust.verifyCaConstraints
import kotlinx.io.bytestring.ByteString
import org.multipaz.asn1.ASN1
import org.multipaz.asn1.ASN1Boolean
import org.multipaz.asn1.ASN1ObjectIdentifier
import org.multipaz.asn1.ASN1Sequence
import org.multipaz.asn1.OID
import org.multipaz.crypto.X509Cert
import org.multipaz.crypto.X509KeyUsage
import kotlin.time.Clock
import kotlin.time.Duration.Companion.days
import kotlin.time.Instant

/**
 * Shared X.509 certificate chain validation
 *
 * Used by issuer trust ([verifyIssuerTrust], for received and stored mdocs alike)
 * and reader trust ([ReaderAuthVerifier]).
 */
internal object CertTrust {

    /** ISO 18013-5 Table B.3: a Document Signer certificate is valid for at most 457 days. */
    val MAX_DOCUMENT_SIGNER_VALIDITY = 457.days

    /** A certificate outside its validity period, so callers can tell it from an untrusted chain. */
    class CertificateValidityException(message: String) : Exception(message)

    /**
     * ISO 18013-5 §9.3 issuer authentication: the Document Signer [chain] must reach one of [trust]'s
     * IACA roots under the DS profile (§B.1.4) and naming rules (§9.3.3).
     */
    suspend fun verifyIssuerTrust(
        chain: List<X509Cert>,
        signedAt: Instant,
        trust: IssuerTrustPolicy.TrustedCertificates,
        context: String,
        now: Instant = Clock.System.now(),
    ) {
        val leafCert = chain.firstOrNull() ?: throw Exception("$context: no issuer certificate present")
        val trustedCertificates = trust.certificates
        if (trustedCertificates.isEmpty()) {
            throw Exception("$context: no trusted IACA certificates configured for this docType")
        }

        // §B.1.4 / Table B.3 — DS certificate validity period must not exceed 457 days
        val maxValidity = leafCert.validityNotBefore.plus(MAX_DOCUMENT_SIGNER_VALIDITY)
        if (leafCert.validityNotAfter > maxValidity) {
            throw Exception("$context: DS certificate validity period exceeds ${MAX_DOCUMENT_SIGNER_VALIDITY.inWholeDays} days ")
        }

        verifySignedAtWithinValidity(leafCert, signedAt, context)

        // RFC 5280 §6.1 chain checks
        verifyCertValidityPeriods(chain, context, now)
        verifyCaConstraints(chain, context)
        verifyChainSignatures(chain, context)

        // §9.3.1 step 1: chain must root to a trusted IACA certificate
        val trustedRoots = trustedCertificates.map { X509Cert(ByteString(it)) }
        val topOfChain = chain.last()
        val rootMatch = trustedRoots.find { trusted ->
            try {
                topOfChain.verify(trusted.ecPublicKey)
                true
            } catch (_: Exception) {
                false
            }
        }
        if (rootMatch == null) {
            throw Exception(
                "$context: issuer certificate chain is not trusted — " +
                        "no matching IACA root found"
            )
        }

        // §9.3.3: countryName in IACA root must match countryName in DS certificate
        val rootCountry =
            rootMatch.subject.components[OID.COUNTRY_NAME.oid]?.value ?: throw Exception(
                "$context: Root certificate country name is not present and must be"
            )
        val leafCountry =
            leafCert.subject.components[OID.COUNTRY_NAME.oid]?.value ?: throw Exception(
                "$context: DS certificate country name is not present and must be"
            )

        if (rootCountry != leafCountry) throw Exception(
            "$context: countryName mismatch — IACA root '$rootCountry' vs DS certificate '$leafCountry'"
        )

        // §9.3.3: stateOrProvinceName must also match if present in both
        val rootState = rootMatch.subject.components[OID.STATE_OR_PROVINCE_NAME.oid]?.value
        val leafState = leafCert.subject.components[OID.STATE_OR_PROVINCE_NAME.oid]?.value
        if (rootState != null && leafState != null && rootState != leafState) {
            throw Exception(
                "$context: stateOrProvinceName mismatch — IACA root '$rootState' vs DS certificate '$leafState'"
            )
        }

        // §B.1.4 / Table B.3 — DS leaf: EKU = mdlDS (1.0.18013.5.1.2) by default, keyUsage = digitalSignature (critical).
        // Checked after the root so a wrong issuer is reported as one. The integrator picks the policy per docType,
        // so the MSO's signer can't pick a weaker one.
        trust.documentSignerKeyUsage?.let { requireExtendedKeyUsage(leafCert, it, context) }
        requireKeyUsage(leafCert, X509KeyUsage.DIGITAL_SIGNATURE, context)
    }

    /** ISO 18013-5 §9.3.1 step 5a: the MSO must have been signed while its Document Signer was valid. */
    fun verifySignedAtWithinValidity(documentSigner: X509Cert, signedAt: Instant, context: String) {
        if (signedAt < documentSigner.validityNotBefore || signedAt > documentSigner.validityNotAfter) {
            throw Exception(
                "$context: MSO signedAt $signedAt " +
                        "is outside DS certificate validity (${documentSigner.validityNotBefore} - ${documentSigner.validityNotAfter})"
            )
        }
    }

    /** Whether [certificate] is signed by one of [trustedCertificates] (DER). */
    suspend fun isIssuedByAny(certificate: X509Cert, trustedCertificates: List<ByteArray>): Boolean =
        trustedCertificates.any { trusted ->
            try {
                certificate.verify(X509Cert(ByteString(trusted)).ecPublicKey)
                true
            } catch (_: Exception) {
                false
            }
        }

    fun verifyCertValidityPeriods(chain: List<X509Cert>, context: String, now: Instant = Clock.System.now()) {
        for ((i, cert) in chain.withIndex()) {
            if (now < cert.validityNotBefore || now > cert.validityNotAfter) {
                throw CertificateValidityException(
                    "$context: certificate at index $i has expired " +
                            "(valid ${cert.validityNotBefore} - ${cert.validityNotAfter})"
                )
            }
        }
    }

    fun verifyCaConstraints(chain: List<X509Cert>, context: String) {
        for (i in 1 until chain.size) {
            val caCert = chain[i]
            verifyBasicConstraintsCA(context, caCert, i)
            if (!caCert.keyUsage.contains(X509KeyUsage.KEY_CERT_SIGN)) {
                throw Exception(
                    "$context: certificate at index $i missing keyCertSign key usage"
                )
            }
        }
    }

    suspend fun verifyChainSignatures(chain: List<X509Cert>, context: String) {
        for (i in 0 until chain.size - 1) {
            try {
                chain[i].verify(chain[i + 1].ecPublicKey)
            } catch (e: Exception) {
                throw Exception(
                    "$context: certificate chain signature failed at index $i", e
                )
            }
        }
    }

    /**
     * Require a leaf/end-entity certificate to carry a specific keyUsage bit.
     * ISO 18013-5 Table B.3 (DS) and Table B.6 (reader auth) both mandate
     * keyUsage = digitalSignature (critical) on the leaf. Presence check —
     * mirrors the KEY_CERT_SIGN check in [verifyCaConstraints].
     */
    fun requireKeyUsage(cert: X509Cert, required: X509KeyUsage, context: String) {
        if (!cert.keyUsage.contains(required)) {
            throw Exception(
                "$context: certificate missing required keyUsage $required " +
                        "(found: ${cert.keyUsage.joinToString().ifEmpty { "none" }})"
            )
        }
    }

    private fun verifyBasicConstraintsCA(context: String, cert: X509Cert, index: Int) {
        val bcBytes = cert.getExtensionValue(OID.X509_EXTENSION_BASIC_CONSTRAINTS.oid)
            ?: throw Exception("$context: certificate at index $index missing basicConstraints")
        val bcSeq = ASN1.decode(bcBytes) as? ASN1Sequence
            ?: throw Exception("$context: certificate at index $index has malformed basicConstraints")
        val caFlag = (bcSeq.elements.firstOrNull() as? ASN1Boolean)?.value ?: false
        if (!caFlag) {
            throw Exception("$context: certificate at index $index has basicConstraints CA=false")
        }
    }

    fun requireExtendedKeyUsage(cert: X509Cert, requiredOid: String, context: String) {
        val ekuBytes = cert.getExtensionValue("2.5.29.37")
            ?: throw Exception("$context: missing extendedKeyUsage extension")
        val ekuSeq = ASN1.decode(ekuBytes) as? ASN1Sequence
            ?: throw Exception("$context: malformed extendedKeyUsage")
        val oids = ekuSeq.elements.mapNotNull { (it as? ASN1ObjectIdentifier)?.oid }
        if (requiredOid !in oids) {
            throw Exception(
                "$context: extendedKeyUsage does not include required OID $requiredOid " +
                        "(found: ${oids.joinToString()})"
            )
        }
    }
}
