package com.iproov.identity.persistence

import com.iproov.identity.Logger
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialFormat
import com.iproov.identity.models.SdJwt
import com.iproov.identity.models.SdJwtVcCredential
import com.iproov.identity.models.VerificationResult
import com.iproov.identity.models.VerificationStatus
import com.iproov.identity.models.VerificationSummary

/**
 * Factory for creating [SdJwtVcCredential] instances from OID4VCI credential responses.
 *
 * Parses the SD-JWT-VC format as defined in:
 * https://datatracker.ietf.org/doc/html/draft-ietf-oauth-sd-jwt-vc
 *
 * Expected format: <Issuer-JWT>~<Disclosure1>~<Disclosure2>~...~
 */
class SdJwtVcCredentialFactory : CredentialFactory {

    override val format: String = CredentialFormat.SD_JWT_VC.value

    override fun createCredential(raw: String): Credential {
        Logger.debug("Parsing SD-JWT-VC credential")

        // Parse the SD-JWT structure
        val sdJwt = try {
            SdJwt.parse(raw)
        } catch (e: Exception) {
            throw IllegalArgumentException("Failed to parse SD-JWT: ${e.message}", e)
        }

        // Verify it's an SD-JWT-VC (must have vct claim)
        val vct = sdJwt.vct
            ?: throw IllegalArgumentException("SD-JWT-VC must contain 'vct' claim")

        Logger.debug("Parsed SD-JWT-VC with vct: $vct")
        Logger.debug("Disclosures: ${sdJwt.disclosures.map { it.claimName }}")
        Logger.debug("Requires key binding: ${sdJwt.requiresKeyBinding}")

        // Resolve all claims (combine payload with disclosures)
        val allClaims = sdJwt.getAllClaims()

        return SdJwtVcCredential(
            raw = raw,
            body = allClaims,
            vct = vct,
            issuer = sdJwt.issuer,
            subject = sdJwt.subject,
            requiresKeyBinding = sdJwt.requiresKeyBinding,
            confirmationKey = sdJwt.confirmationKey,
            expiration = sdJwt.expiration,
            issuedAt = sdJwt.issuedAt,
            onCheckVerificationStatus = { createVerificationSummary(sdJwt) }
        )
    }

    /**
     * Create a verification summary for the SD-JWT-VC.
     * This performs basic structural and temporal validation.
     */
    private fun createVerificationSummary(sdJwt: SdJwt): VerificationSummary {
        val summary = VerificationSummary.start()

        // Check expiration
        sdJwt.expiration?.let { exp ->
            val now = kotlin.time.Clock.System.now().epochSeconds
            if (now > exp) {
                Logger.error("SD-JWT-VC has expired")
                summary + VerificationResult("expiry", VerificationStatus.EXPIRED, "Credential has expired")
            }
        }

        // Additional checks could be added:
        // - Signature verification against issuer's public key
        // - Revocation status check
        // - Issuer trust validation

        return summary
    }
}
