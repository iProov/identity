package com.iproov.identity.proximity

import com.iproov.identity.Logger
import kotlinx.cinterop.ExperimentalForeignApi
import platform.CoreBluetooth.CBManager
import platform.CoreBluetooth.CBManagerAuthorizationDenied
import platform.CoreBluetooth.CBManagerAuthorizationRestricted

/**
 * Apple/iOS implementation of proximity platform availability.
 *
 * iPhone hardware always supports BLE; the SDK's iOS minimum (16) already exceeds
 * the modern CoreBluetooth APIs required (iOS 13.1+ for `CBManager.authorization`).
 * The only static signal worth checking is whether the user has already denied or
 * restricted Bluetooth permission for this app.
 *
 * `CBManager.authorization` is a class property — reading it does NOT trigger the
 * system permission prompt. The prompt fires later when `CBPeripheralManager` is
 * instantiated inside `startBleSession()`. We treat `.notDetermined` as available
 * because the user simply hasn't been asked yet.
 *
 * Note: this check does not verify presence of `NSBluetoothAlwaysUsageDescription`
 * in the consumer app's Info.plist. The OS will crash the app at `CBPeripheralManager`
 * instantiation if missing; the requirement is documented in §12.5 of the breakdown.
 */
@OptIn(ExperimentalForeignApi::class)
actual fun isProximityPlatformAvailable(): Boolean {
    return try {
        val auth = CBManager.authorization
        auth != CBManagerAuthorizationDenied && auth != CBManagerAuthorizationRestricted
    } catch (e: Throwable) {
        Logger.debug("CoreBluetooth authorization check failed; proximity unavailable: ${e.message}")
        false
    }
}

/**
 * Apple/iOS implementation of NFC engagement availability.
 *
 * Returns false today. Apple restricts third-party apps from emulating NFC mdoc
 * cards: CoreNFC supports reader operations only, and the Card Session API
 * (iOS 17+) requires tightly-scoped entitlements that don't realistically extend
 * to ISO/IEC 18013-5 holder-side engagement. From iOS 26, mdoc NFC presentation
 * is mediated by Apple's IdentityDocumentServices framework via the DC API path,
 * which the SDK already handles separately in the `dcapi/` package.
 *
 * Revisit if Apple opens a usable API for wallet-owned NFC engagement.
 */
actual fun isNfcEngagementAvailable(): Boolean {
    Logger.debug("NFC engagement is not available on iOS; route via DC API on iOS 26+ instead")
    return false
}

/**
 * Apple/iOS implementation of the platform NFC engagement factory.
 *
 * Throws because Apple does not expose third-party mdoc NFC emulation; see the
 * doc on [isNfcEngagementAvailable]. On iOS 26+, mdoc NFC presentation routes
 * through the DC API path (`dcapi/` package), not through this orchestrator.
 * Revisit if Apple ever opens a usable API for wallet-side NFC engagement.
 */
internal actual fun createPlatformNfcEngagement(): NfcEngagement {
    throw NfcEngagementUnavailableException(
        "NFC engagement is not available on iOS: Apple restricts third-party " +
            "mdoc NFC emulation. Use the DC API path on iOS 26+ instead."
    )
}
