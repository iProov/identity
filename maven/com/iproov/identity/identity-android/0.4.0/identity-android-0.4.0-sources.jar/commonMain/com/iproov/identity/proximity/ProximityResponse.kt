package com.iproov.identity.proximity

import com.iproov.identity.models.MDocCredential


data class DisclosedDocument(
    val credential: MDocCredential,
    val disclosedItems: Map<String, Set<String>>? = null,
)

sealed class ProximityResponseOutcome {

    /**
     * The signed and encrypted DeviceResponse left the transport. The reader will
     * typically close the BLE channel shortly after receipt.
     *
     * @property redirectUri optional URI the consumer should open after presentation;
     *   used by some readers to drive the user back into a web flow. Null for most
     *   in-person presentations.
     */
    data class Sent(val redirectUri: String? = null) : ProximityResponseOutcome()

    /** An unrecoverable error occurred while building, encrypting, or sending the response. */
    data class Failure(val cause: Throwable) : ProximityResponseOutcome()
}
