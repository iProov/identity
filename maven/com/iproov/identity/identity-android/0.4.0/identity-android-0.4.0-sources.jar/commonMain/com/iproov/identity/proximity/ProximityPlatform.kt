package com.iproov.identity.proximity

/**
 * Plain English: What does this device support?
 *
 * Static platform-capability checks for proximity transports.
 *
 * These answer "can this device, in principle, ever perform <transport>?" — pure
 * hardware/capability introspection with no side effects. They do NOT prompt the
 * user, request runtime permissions, or check whether the relevant radio is
 * currently powered on. Those concerns surface as Failure events at session start.
 *
 * Cheap enough to call repeatedly; safe to call from any thread.
 */

/** True if the device can advertise as a BLE peripheral (ISO 18013-5 §8.3.3.1.1). */
expect fun isProximityPlatformAvailable(): Boolean

/** True if the device supports NFC Host Card Emulation (ISO 18013-5 §8.2.2.1). */
expect fun isNfcEngagementAvailable(): Boolean

/**
 * Returns the platform's [NfcEngagement] implementation.
 *
 * Lazily invoked inside [DefaultProximityOrchestrator] when consumers call
 * `nfcEngagement()`. Consumers don't call this directly.
 *
 * Mirrors the role that `createPlatformDCApiRegistrar()` plays for DC API.
 *
 * @throws NfcEngagementUnavailableException when NFC HCE isn't supported on the
 *   current platform (today: always on iOS; on Android while the real
 *   implementation is still being built in PR 7).
 */
internal expect fun createPlatformNfcEngagement(): NfcEngagement
