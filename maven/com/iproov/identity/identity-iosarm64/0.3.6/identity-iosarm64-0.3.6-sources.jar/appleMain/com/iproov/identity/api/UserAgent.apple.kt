package com.iproov.identity.api

import platform.UIKit.UIDevice

actual fun getUserAgent(): UserAgent = UserAgent(
    sdkVersion = "0.3.6",
    operatingSystem = "iOS",
    operatingSystemVersion = UIDevice.currentDevice.systemVersion,
    deviceModel = UIDevice.currentDevice.model
)