package com.iproov.identity.api

import com.iproov.identity.Base64Utils.decodeFromBase64Url
import com.iproov.identity.CLOCK_SKEW_SECONDS
import com.iproov.identity.Logger
import com.iproov.identity.models.CredentialStatus
import com.iproov.identity.models.CredentialStatusException
import com.iproov.identity.models.VerificationResult
import com.iproov.identity.models.VerificationStatus
import com.iproov.identity.models.looksLikeJwt
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpRequestTimeoutException
import io.ktor.client.request.accept
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.URLBuilder
import io.ktor.http.URLProtocol
import io.ktor.http.Url
import io.ktor.http.encodedPath
import io.ktor.http.isSuccess
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.io.IOException
import kotlinx.io.bytestring.ByteString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import org.multipaz.cbor.CborMap
import org.multipaz.crypto.EcPublicKey
import org.multipaz.crypto.X509Cert
import org.multipaz.revocation.RevocationStatus
import org.multipaz.revocation.StatusList
import org.multipaz.util.adler32
import org.multipaz.util.inflate
import org.multipaz.webtoken.WebTokenCheck
import org.multipaz.webtoken.validateJwt
import kotlin.time.Clock
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import kotlin.time.Instant

/**
 * Reads an mdoc's entry in its IETF Token Status List (draft-ietf-oauth-status-list-21), served as
 * `statuslist+jwt`, following the validation rules of §8.3.
 *
 * The list must be signed by the certificate the caller expects: the one the mdoc's MSO names for its
 * status list, or else its Document Signer, which is §11.3's "same key as the Referenced Token". For a
 * host in the caller's JWKS hosts it must instead be signed by the key named by `kid` in that host's
 * `/.well-known/jwks.json`, an ecosystem convention that relies on TLS to the host alone.
 *
 * Anything short of a verified list entry throws a [CredentialStatusException] with a fixed message and
 * machine-readable `details`. A list whose token carries `ttl` is cached in memory for that long, never
 * beyond its `exp`. CWT status lists and identifier lists are not supported yet.
 */
internal class StatusListVerifier(
    clientFactory: () -> HttpClient,
    private val clock: Clock = Clock.System,
    private val timeout: Duration = 10.seconds,
) {
    private val client: HttpClient by lazy(clientFactory)
    private val cache = LinkedHashMap<CacheKey, VerifiedList>()
    private val cacheMutex = Mutex()
    private val skewedClock = object : Clock {
        override fun now(): Instant = clock.now() - CLOCK_SKEW_SECONDS.seconds
    }

    /** The credential's status. Throws [CredentialStatusException] when it cannot be established. */
    suspend fun status(
        status: RevocationStatus,
        signer: X509Cert?,
        jwksHosts: Set<String>,
        docType: String,
    ): CredentialStatus {
        val result = try {
            when (status) {
                is RevocationStatus.StatusList -> statusListEntry(status, signer, jwksHosts, docType)
                is RevocationStatus.IdentifierList -> throw unsupported("identifier_list")
                // Token Status List §8.3 step 1: a status_list that doesn't parse is invalid, not unsupported.
                is RevocationStatus.UnknownCbor -> if ((status.dataItem as? CborMap)?.hasKey("status_list") == true) {
                    throw CredentialStatusException.VerificationFailed(
                        "Status list could not be verified",
                        details(Cause.INVALID, STEP to STEP_STATUS_LIST),
                    )
                } else {
                    throw unsupported("unknown")
                }
                is RevocationStatus.UnknownJson -> throw unsupported("unknown")
            }
        } catch (e: CredentialStatusException) {
            Logger.error("[StatusList] $docType: INDETERMINATE - ${e.message} ${e.details}")
            throw e
        }
        Logger.info("[StatusList] $docType: $result")
        return result
    }

    private suspend fun statusListEntry(
        status: RevocationStatus.StatusList,
        signer: X509Cert?,
        jwksHosts: Set<String>,
        docType: String,
    ): CredentialStatus {
        var step = STEP_STATUS_LIST
        val list = withTimeoutOrNull(timeout) {
            try {
                cached(status.uri, signer, jwksHosts, docType) ?: fetchVerifiedList(status, signer, jwksHosts, docType) { step = it }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                currentCoroutineContext().ensureActive()
                Logger.error("[StatusList] $docType: $step step failed for ${status.uri}: $e")
                throw failure(e, status.uri, step)
            }
        } ?: run {
            Logger.error("[StatusList] $docType: $step step timed out after $timeout for ${status.uri}")
            throw CredentialStatusException.RetrievalFailed(
                "Status list request timed out",
                details(Cause.TIMEOUT, URI to status.uri, STEP to step),
            )
        }
        return list.statusAt(status.idx, status.uri)
    }

    private suspend fun fetchVerifiedList(
        status: RevocationStatus.StatusList,
        signer: X509Cert?,
        jwksHosts: Set<String>,
        docType: String,
        onStep: (String) -> Unit,
    ): VerifiedList {
        val uri = Url(status.uri)
        require(uri.protocol == URLProtocol.HTTPS) { "status list URI is not https" }

        Logger.debug("[StatusList] $docType: fetching ${status.uri}")
        val token = client.fetch(status.uri, ContentType("application", STATUS_LIST_JWT)).trim()
        require(looksLikeJwt(token)) { "status list response is not a JWT" }

        val publicKey = if (usesJwks(status.uri, jwksHosts)) {
            onStep(STEP_JWKS)
            jwksKey(uri, token, docType)
        } else {
            signer?.ecPublicKey ?: error("no certificate to verify the status list with")
        }

        onStep(STEP_VERIFICATION)
        val body = validateJwt(
            jwt = token,
            jwtName = "Status List",
            publicKey = publicKey,
            checks = mapOf(WebTokenCheck.TYP to STATUS_LIST_JWT, WebTokenCheck.SUB to status.uri),
            // Token Status List §5.1 sets no maximum lifetime; exp itself is still enforced.
            maxValidity = Duration.INFINITE,
            clock = skewedClock,
        )
        // Token Status List §5.1: iat is REQUIRED. validateJwt reads it only to bound a finite lifetime, and
        // ignores nbf, which RFC 7519 §4.1.5 says must not be accepted before.
        val latest = clock.now() + CLOCK_SKEW_SECONDS.seconds
        val issuedAt = body.numericDate("iat") ?: error("missing iat claim")
        check(issuedAt <= latest.epochSeconds) { "iat is in the future" }
        body.numericDate("nbf")?.let { check(it <= latest.epochSeconds) { "token is not yet valid (nbf)" } }
        val claim = body["status_list"]?.jsonObject ?: error("missing status_list claim")
        val bits = claim["bits"]?.jsonPrimitive?.int ?: error("missing status_list.bits")
        require(bits in listOf(1, 2, 4, 8)) { "unsupported status_list.bits $bits" }
        val entries = claim["lst"]?.jsonPrimitive?.content?.decodeFromBase64Url()?.zlibInflateAnyLevel()
            ?: error("missing status_list.lst")

        val ttl = body["ttl"]?.jsonPrimitive?.longOrNull?.takeIf { it > 0 }
        // validateJwt has already rejected an exp that isn't an integer.
        val exp = body["exp"]?.jsonPrimitive?.longOrNull?.let { Instant.fromEpochSeconds(it) }
        val cacheUntil = ttl?.let { minOf(clock.now() + it.seconds, exp ?: Instant.DISTANT_FUTURE) }
        val list = VerifiedList(StatusList(bits, entries), entries.size.toLong() * (8 / bits), cacheUntil)
        Logger.debug(
            "[StatusList] $docType: verified ${status.uri}, bits=$bits, entries=${list.capacity}, " +
                    (cacheUntil?.let { "cached until $it" } ?: "not cached (no ttl)")
        )
        if (cacheUntil != null) store(cacheKey(status.uri, signer, jwksHosts), list)
        return list
    }

    /** The key named by the token's `kid` in `/.well-known/jwks.json` on the list's own host. */
    private suspend fun jwksKey(uri: Url, token: String, docType: String): EcPublicKey {
        val kid = Json.parseToJsonElement(token.substringBefore('.').decodeFromBase64Url().decodeToString())
            .jsonObject["kid"]?.jsonPrimitive?.content
            ?: error("status list token has no kid")
        val jwksUrl = URLBuilder(uri).apply {
            encodedPath = "/.well-known/jwks.json"
            encodedParameters.clear()
            fragment = ""
        }.buildString()
        Logger.debug("[StatusList] $docType: fetching $jwksUrl for kid $kid")
        val jwk = Json.parseToJsonElement(client.fetch(jwksUrl, ContentType.Application.Json))
            .jsonObject["keys"]?.jsonArray
            ?.mapNotNull { it as? JsonObject }
            ?.firstOrNull { it["kid"]?.jsonPrimitive?.content == kid }
            ?: error("kid $kid not found in $jwksUrl")
        return EcPublicKey.fromJwk(jwk)
    }

    private suspend fun cached(uri: String, signer: X509Cert?, jwksHosts: Set<String>, docType: String): VerifiedList? {
        val key = cacheKey(uri, signer, jwksHosts)
        return cacheMutex.withLock {
            val entry = cache[key] ?: return@withLock null
            if (entry.cacheUntil == null || clock.now() >= entry.cacheUntil) {
                cache.remove(key)
                return@withLock null
            }
            Logger.debug("[StatusList] $docType: using cached $uri until ${entry.cacheUntil}")
            entry
        }
    }

    private suspend fun store(key: CacheKey, list: VerifiedList) = cacheMutex.withLock {
        cache.remove(key)
        if (cache.size >= MAX_CACHED_LISTS) cache.remove(cache.keys.first())
        cache[key] = list
    }

    /** A list verified against one signer must never answer for a credential that expects another. */
    private data class CacheKey(val uri: String, val signer: ByteString?)

    private fun cacheKey(uri: String, signer: X509Cert?, jwksHosts: Set<String>) =
        CacheKey(uri, if (usesJwks(uri, jwksHosts)) null else signer?.encoded)

    private class VerifiedList(val statusList: StatusList, val capacity: Long, val cacheUntil: Instant?) {
        fun statusAt(idx: Int, uri: String): CredentialStatus {
            // Token Status List §8.3 step 6: out of bounds makes no statement. multipaz would read it as VALID.
            if (idx < 0 || idx >= capacity) {
                throw CredentialStatusException.IndexOutOfBounds(details(Cause.OUT_OF_BOUNDS, URI to uri))
            }
            return when (val value = statusList[idx]) {
                0 -> CredentialStatus.Valid
                1 -> CredentialStatus.Invalid
                2 -> CredentialStatus.Suspended
                // Token Status List §7.1: 0x03 and 0x0C to 0x0F are application specific, the rest reserved.
                3, in 0x0C..0x0F -> CredentialStatus.ApplicationSpecific(value.toUByte())
                else -> CredentialStatus.Reserved(value.toUByte())
            }
        }
    }

    /** The categories a caller can act on, carried as `details["cause"]`; raw exception text goes to the log only. */
    private enum class Cause(val value: String) {
        UNSUPPORTED("unsupported"),
        NETWORK("network"),
        TIMEOUT("timeout"),
        HTTP("http"),
        INVALID("invalid"),
        OUT_OF_BOUNDS("out_of_bounds"),
        UNRECOGNISED_VALUE("unrecognised_value"),
    }

    companion object {
        const val CHECK = "status_list"
        private const val STATUS_LIST_JWT = "statuslist+jwt"
        private const val MAX_CACHED_LISTS = 16
        private const val MAX_LOGGED_BODY = 200
        private const val CAUSE = "cause"
        private const val URI = "uri"
        private const val VALUE = "value"
        private const val HTTP_STATUS = "httpStatus"
        private const val MECHANISM = "mechanism"
        private const val STEP = "step"
        private const val STEP_STATUS_LIST = "status_list"
        private const val STEP_JWKS = "jwks"
        private const val STEP_VERIFICATION = "verification"
        private const val STEP_SIGNER = "signer"

        /** One client and one cache for the process; the client is created on first use. */
        val shared = StatusListVerifier({ httpClient })

        private fun details(cause: Cause, vararg details: Pair<String, String>) = mapOf(CAUSE to cause.value, *details)

        private fun unsupported(mechanism: String) = CredentialStatusException.Unsupported(
            "Status mechanism is not supported",
            details(Cause.UNSUPPORTED, MECHANISM to mechanism),
        )

        /**
         * Whether [uri]'s host is opted in to JWKS key lookup. Host names compare case-insensitively. A [uri] that
         * doesn't parse isn't, and the fetch then reports it as an invalid status list.
         */
        fun usesJwks(uri: String, jwksHosts: Set<String>): Boolean =
            runCatching { Url(uri).host.lowercase() in jwksHosts }.getOrDefault(false)

        /** The certificate the MSO names to sign its status list is unusable. */
        fun signerRejected(uri: String) = CredentialStatusException.VerificationFailed(
            "Status list could not be verified",
            details(Cause.INVALID, URI to uri, STEP to STEP_SIGNER),
        )

        /** [status] as the `status_list` result of a verification summary. */
        fun result(status: CredentialStatus, uri: String): VerificationResult {
            val base = mapOf(URI to uri)
            return when (status) {
                CredentialStatus.Valid -> VerificationResult(CHECK, VerificationStatus.VALID, details = base)
                CredentialStatus.Invalid ->
                    VerificationResult(CHECK, VerificationStatus.REVOKED, "Credential has been revoked", base + (VALUE to "1"))
                CredentialStatus.Suspended ->
                    VerificationResult(CHECK, VerificationStatus.REVOKED, "Credential is suspended", base + (VALUE to "2"))
                is CredentialStatus.ApplicationSpecific -> unrecognised(base, status.value)
                is CredentialStatus.Reserved -> unrecognised(base, status.value)
            }
        }

        /** [e] as the `status_list` result of a verification summary. */
        fun result(e: CredentialStatusException) =
            VerificationResult(CHECK, VerificationStatus.INDETERMINATE, e.message, e.details)

        private fun unrecognised(base: Map<String, String>, value: UByte) = VerificationResult(
            CHECK,
            VerificationStatus.INDETERMINATE,
            "Unrecognised status value",
            base + details(Cause.UNRECOGNISED_VALUE, VALUE to "$value"),
        )

        private fun failure(e: Exception, uri: String, step: String): CredentialStatusException = when (e) {
            is ApiException.NetworkError -> CredentialStatusException.RetrievalFailed(
                "Status list could not be reached", details(Cause.NETWORK, URI to uri, STEP to step), e,
            )
            is ApiException.TimeoutError -> CredentialStatusException.RetrievalFailed(
                "Status list request timed out", details(Cause.TIMEOUT, URI to uri, STEP to step), e,
            )
            is ApiException.HttpError -> CredentialStatusException.RetrievalFailed(
                "Status list request failed",
                details(Cause.HTTP, URI to uri, STEP to step, HTTP_STATUS to "${e.statusCode.value}"),
                e,
            )
            else -> CredentialStatusException.VerificationFailed(
                "Status list could not be verified", details(Cause.INVALID, URI to uri, STEP to step), e,
            )
        }

        /** A RFC 7519 NumericDate claim, or null when absent; a claim that isn't a JSON number is rejected. */
        private fun JsonObject.numericDate(name: String): Double? = this[name]?.let {
            (it as? JsonPrimitive)?.takeUnless { claim -> claim.isString }?.doubleOrNull ?: error("$name is not a NumericDate")
        }

        /** Maps transport failures to the SDK's [ApiException] types, as [ApiClient] does, and logs error bodies. */
        private suspend fun HttpClient.fetch(url: String, type: ContentType): String {
            val response = try {
                get(url) { accept(type) }
            } catch (e: HttpRequestTimeoutException) {
                throw ApiException.TimeoutError(e)
            } catch (e: IOException) {
                throw ApiException.NetworkError(e)
            }
            if (!response.status.isSuccess()) {
                val body = response.bodyAsText().take(MAX_LOGGED_BODY)
                Logger.error("[StatusList] HTTP ${response.status.value} from $url: ${body.ifEmpty { "no body" }}")
                throw ApiException.HttpError(response.status, body, errorCode = null, recoveryMessage = null)
            }
            return response.bodyAsText()
        }

        /**
         * Token Status List §4.1 only recommends the highest compression level, but multipaz's zlibInflate
         * accepts only that level's header (78 DA). This accepts any valid RFC 1950 header.
         */
        private suspend fun ByteArray.zlibInflateAnyLevel(): ByteArray {
            require(size > 6) { "status_list.lst is not zlib data" }
            val cmf = this[0].toInt() and 0xFF
            val flg = this[1].toInt() and 0xFF
            // RFC 1950: deflate method, no preset dictionary, valid check bits.
            require((cmf and 0x0F) == 8 && (flg and 0x20) == 0 && (cmf * 256 + flg) % 31 == 0) {
                "status_list.lst is not zlib data"
            }
            val data = sliceArray(2 until size - 4).inflate()
            require(data.adler32() contentEquals sliceArray(size - 4 until size)) { "status_list.lst checksum mismatch" }
            return data
        }
    }
}
