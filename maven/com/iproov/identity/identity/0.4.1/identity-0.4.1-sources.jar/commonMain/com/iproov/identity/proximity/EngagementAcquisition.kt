package com.iproov.identity.proximity

import com.iproov.identity.Logger
import com.iproov.identity.proximity.ProximityRetrievalSession.EngagementOutcome
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.Simple
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethodBle
import org.multipaz.mdoc.engagement.DeviceEngagement
import org.multipaz.mdoc.nfc.scanMdocReader
import org.multipaz.mdoc.role.MdocRole
import org.multipaz.mdoc.transport.MdocTransportFactory
import org.multipaz.nfc.NfcTagReader
import org.multipaz.util.UUID

object EngagementAcquisition {

    internal suspend fun acquireFromUri(
        uri: String,
        config: ProximityConfig,
        orchestrator: ProximityOrchestrator
    ): EngagementOutcome = withTimeout(config.engagementTimeout) {
        val deviceEngagement = orchestrator.retrieveProximityEngagement(uri)

        Logger.debug("Retrieved device engagement (${deviceEngagement.connectionMethods.size} connection method(s))")

        val ble = deviceEngagement.connectionMethods
            .filterIsInstance<MdocConnectionMethodBle>()
            .firstOrNull()
            ?: throw ProximityRetrievalException("Only Bluetooth proximity sessions are supported")

        if (!orchestrator.isBleAvailable()) {
            throw ProximityRetrievalException("BLE is not available and required for this proximity session")
        }

        val mdocTransport = MdocTransportFactory.Default.createTransport(
            connectionMethod = ble,
            role = MdocRole.MDOC_READER,
            options = MDOC_TRANSPORT_OPTIONS,
        )

        EngagementOutcome(deviceEngagement, mdocTransport, Simple.NULL)
    }


    internal suspend fun acquireFromNfc(
        dialogMessage: String?,
        orchestrator: ProximityOrchestrator,
    ): EngagementOutcome {
        val reader = NfcTagReader.getReaders().firstOrNull()
            ?: throw ProximityRetrievalException("No NFC reader available on this device")
        if (!orchestrator.isBleAvailable()) {
            throw ProximityRetrievalException("BLE is required after NFC engagement but unavailable")
        }
        val sharedUuid = UUID.randomUUID()
        val negotiated = listOf(
            MdocConnectionMethodBle(true, false, sharedUuid, sharedUuid),
            MdocConnectionMethodBle(false, true, sharedUuid, sharedUuid),
        )
        val result = withContext(context = Dispatchers.Main) {
            reader.scanMdocReader(
                message = dialogMessage,
                options = MDOC_TRANSPORT_OPTIONS,
                negotiatedHandoverConnectionMethods = negotiated,
                selectConnectionMethod = { offered ->
                    offered.firstOrNull { it is MdocConnectionMethodBle }
                },
            ) ?: throw ProximityRetrievalException("NFC scan cancelled before handover completed")
        }
        val deviceEngagement = DeviceEngagement.fromDataItem(
            Cbor.decode(result.encodedDeviceEngagement.toByteArray())
        )
        return EngagementOutcome(
            deviceEngagement, result.transport, result.handover,
        )
    }


}