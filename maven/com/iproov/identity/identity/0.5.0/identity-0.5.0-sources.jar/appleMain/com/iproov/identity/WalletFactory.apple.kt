package com.iproov.identity

import com.iproov.identity.persistence.StorageEngine

// These are functions for the apple platform

fun WalletFactory.getInstance(
    baseUrl: String,
) = getInstance(
    baseUrl = baseUrl,
)

fun WalletFactory.getInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean = false,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled
)

fun WalletFactory.getInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
)

fun WalletFactory.getInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
    signingKeyPairFactory = signingKeyPairFactory,
)
