package com.iproov.identity.models

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

internal fun JsonObject.credentialConfigurationIds(): List<String> =
    (this["credential_configuration_ids"] as? JsonArray)
        ?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
        ?: emptyList()

internal fun resolveOfferedCredentials(
    offeredConfigurationIds: List<String>,
    availableCredentials: List<CredentialDescriptor>,
): List<CredentialDescriptor> {
    if (offeredConfigurationIds.isEmpty()) {
        val message = "Credential offer did not contain any credential_configuration_ids."
        throw OID4VCIException.RetrievingOfferedCredentialFormats(
            error = "missing_credential_configuration_ids",
            description = message,
            cause = IllegalArgumentException(message),
        )
    }

    val availableCredentialsById = availableCredentials.associateBy { it.id }
    val missingIds = mutableListOf<String>()

    val resolvedCredentials = offeredConfigurationIds.mapNotNull { configurationId ->
        availableCredentialsById[configurationId] ?: run {
            missingIds += configurationId
            null
        }
    }

    if (missingIds.isNotEmpty()) {
        val message = "Credential offer referenced configuration IDs not present in issuer metadata: ${
            missingIds.joinToString(", ")
        }"
        throw OID4VCIException.RetrievingOfferedCredentialFormats(
            error = "invalid_configuration",
            description = message,
            cause = IllegalArgumentException(message),
        )
    }

    return resolvedCredentials
}

internal fun validateRequestedCredentials(
    offeredCredentials: List<CredentialDescriptor>,
    requestedCredentials: List<CredentialDescriptor>,
) {
    if (requestedCredentials.isEmpty()) return

    val offeredIds = offeredCredentials.map { it.id }.toSet()
    val invalidIds = requestedCredentials.map { it.id }.filterNot(offeredIds::contains).distinct()

    if (invalidIds.isNotEmpty()) {
        throw OID4VCIException.CreatingAccessToken(
            error = "invalid_configuration",
            description = "Selected credential configurations were not found in the resolved offer: ${
                invalidIds.joinToString(", ")
            }",
        )
    }
}
