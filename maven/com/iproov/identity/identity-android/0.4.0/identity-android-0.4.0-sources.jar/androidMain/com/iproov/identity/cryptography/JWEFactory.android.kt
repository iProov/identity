package com.iproov.identity.cryptography

import com.iproov.identity.Logger
import com.iproov.identity.models.Jwk
import com.nimbusds.jose.EncryptionMethod
import com.nimbusds.jose.JWEAlgorithm
import com.nimbusds.jose.JWEHeader
import com.nimbusds.jose.JWEObject
import com.nimbusds.jose.Payload
import com.nimbusds.jose.jwk.ECKey
import com.nimbusds.jose.util.Base64URL
import kotlinx.serialization.json.Json

private val json = Json { ignoreUnknownKeys = true; prettyPrint = true; }

internal val platformSupportedEncryptionAlgorithms = mapOf<String, EncryptionMethod>(
    "A128GCM" to EncryptionMethod.A128GCM,
    "A192GCM" to EncryptionMethod.A192GCM,
    "A256GCM" to EncryptionMethod.A256GCM,
    "A128CBC-HS256" to EncryptionMethod.A128CBC_HS256,
    "A192CBC-HS384" to EncryptionMethod.A192CBC_HS384,
    "A256CBC-HS512" to EncryptionMethod.A256CBC_HS512
)

internal val platformSupportedEncryptionJWEAlgorithms = mapOf<String, JWEAlgorithm>(
    "A128GCM" to JWEAlgorithm.ECDH_ES_A128KW,
    "A192GCM" to JWEAlgorithm.ECDH_ES_A192KW,
    "A256GCM" to JWEAlgorithm.ECDH_ES_A256KW,
)

private val platformSupportedKeyManagementAlgorithms = mapOf<String, JWEAlgorithm>(
    "ECDH-ES" to JWEAlgorithm.ECDH_ES,
    "RSA1_5" to JWEAlgorithm.RSA1_5,
    "RSA-OAEP" to JWEAlgorithm.RSA_OAEP,
    "RSA-OAEP-256" to JWEAlgorithm.RSA_OAEP_256,
    "A128KW" to JWEAlgorithm.A128KW,
    "A192KW" to JWEAlgorithm.A192KW,
    "A256KW" to JWEAlgorithm.A256KW,
    "dir" to JWEAlgorithm.DIR,
)

class AndroidJWEFactory : JWEFactory {
    override val supportedKeyManagementAlgorithms: List<String> by lazy {
        platformSupportedKeyManagementAlgorithms.keys.toList()
    }

    override val supportedEncryptionAlgorithms: List<String> by lazy {
        platformSupportedEncryptionAlgorithms.keys.toList()
    }

    override suspend fun create(
        payload: ByteArray,
        recipientPublicKey: Jwk,
        alg: String,
        encToUse: String,
        apu: ByteArray?,
    ): String {
        val recipientPublicJWKString = json.encodeToString(recipientPublicKey)
        val recipientPublicJWK: ECKey = ECKey.parse(recipientPublicJWKString)

        val keyManagementAlg =
            platformSupportedKeyManagementAlgorithms[alg] ?: throw JWECreationException(
                "JWK algorithm $alg is not supported. Supported algorithms: $supportedKeyManagementAlgorithms"
            )
        Logger.debug("Key management algorithm being used: $keyManagementAlg")

        val encryptionAlg =
            platformSupportedEncryptionAlgorithms[encToUse] ?: throw JWECreationException(
                "Encryption algorithm $encToUse is not supported. Supported algorithms: $supportedEncryptionAlgorithms"
            )
        Logger.debug("Encryption algorithm being used: $encryptionAlg")

        val builder = JWEHeader.Builder(keyManagementAlg, encryptionAlg)
            .contentType("application/octet-stream") // Set content type for raw bytes

        // Check and use the kid from the parsed Nimbus ECKey object
        recipientPublicJWK.keyID?.let { nonNullKid ->
            builder.keyID(nonNullKid) // Include the key ID as a hint
        }

        // Add Agreement PartyUInfo (apu) for OID4VP direct_post.jwt mode
        // This is the mdoc_generated_nonce that must match the session transcript
        apu?.let { apuBytes ->
            builder.agreementPartyUInfo(Base64URL.encode(apuBytes))
            Logger.debug("Added apu (mdoc_generated_nonce) to JWE header: ${Base64URL.encode(apuBytes)}")
        }

        val header = builder.build()
        Logger.debug("JWE Header: $header")

        val jwe = JWEObject(header, Payload(payload))
        val encrypter = com.nimbusds.jose.crypto.ECDHEncrypter(recipientPublicJWK)

        jwe.encrypt(encrypter)
        return jwe.serialize()
    }
}

actual fun getPlatformJWEFactory(): JWEFactory = AndroidJWEFactory()