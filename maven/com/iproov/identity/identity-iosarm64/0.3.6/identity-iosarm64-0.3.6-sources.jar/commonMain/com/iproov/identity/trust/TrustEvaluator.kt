package com.iproov.identity.trust

import com.iproov.identity.Logger

/**
 * Evaluates whether a certificate chain is trusted for a given [VerificationContext].
 *
 * Configured at wallet creation via [WalletFactory.getInstance] and used internally
 * by the SDK to validate verifiers (OID4VP, DC API) and by consumers to validate
 * issuers (via `RespondableCredentialOffer.verifyIssuer()`).
 *
 * The evaluator holds a list of [TrustMaterial] sources, each scoped to specific
 * verification contexts. During evaluation, only materials whose contexts include
 * the requested context are consulted, using a first-trusted-wins strategy.
 *
 * ```kotlin
 * // Development
 * TrustEvaluator.trustAll()
 *
 * // Production
 * TrustEvaluator.evaluateUsing(
 *     TrustMaterial.lote(url = "https://...", contexts = setOf(VerificationContext.PID)),
 * )
 * ```
 *
 * @see TrustMaterial
 * @see VerificationContext
 * @see CredentialContextResolver
 */
class TrustEvaluator private constructor(
    private val materials: List<TrustMaterial>,
    private val contextResolver: CredentialContextResolver,
    private val trustAll: Boolean,
) {

    companion object {

        /**
         * Trust all entities regardless of context. **For development only.**
         *
         * All calls to [evaluate] return [TrustResult.Trusted]. A warning is
         * logged on creation to flag accidental use in production.
         */
        fun trustAll(): TrustEvaluator {
            return TrustEvaluator(
                materials = emptyList(),
                contextResolver = CredentialContextResolver.default(),
                trustAll = true,
            )
        }

        /**
         * Evaluate trust using the provided [TrustMaterial] sources.
         *
         * @param materials One or more trust materials, each scoped to specific
         *   [VerificationContext]s.
         * @param contextResolver Maps credential identifiers (docType/vct) to
         *   verification contexts for auto-detection in `verifyIssuer()`.
         *   Defaults to [CredentialContextResolver.default] which handles known
         *   EUDI credential types.
         */
        fun evaluateUsing(
            vararg materials: TrustMaterial,
            contextResolver: CredentialContextResolver = CredentialContextResolver.default(),
        ): TrustEvaluator = evaluateUsing(materials.toList(), contextResolver)

        /**
         * Evaluate trust using the provided [TrustMaterial] sources.
         *
         * @param materials One or more trust materials, each scoped to specific
         *   [VerificationContext]s.
         * @param contextResolver Maps credential identifiers (docType/vct) to
         *   verification contexts for auto-detection in `verifyIssuer()`.
         *   Defaults to [CredentialContextResolver.default] which handles known
         *   EUDI credential types.
         */
        fun evaluateUsing(
            materials: List<TrustMaterial>,
            contextResolver: CredentialContextResolver = CredentialContextResolver.default(),
        ): TrustEvaluator {
            require(materials.isNotEmpty()) { "At least one TrustMaterial must be provided. Use trustAll() for development." }
            return TrustEvaluator(
                materials = materials,
                contextResolver = contextResolver,
                trustAll = false,
            )
        }
    }

    /** The credential context resolver configured on this evaluator. */
    val credentialContextResolver: CredentialContextResolver get() = contextResolver

    /**
     * Evaluate whether a certificate chain is trusted for the given context.
     *
     * Materials whose [TrustMaterial.contexts] include [context] are checked
     * in order. Returns [TrustResult.Trusted] as soon as any material trusts
     * the chain. If all matching materials return [TrustResult.Untrusted],
     * returns [TrustResult.Untrusted]. If any returns [TrustResult.Indeterminate]
     * and none returns [TrustResult.Trusted], returns [TrustResult.Indeterminate].
     *
     * @param chain The DER-encoded X.509 certificate chain to evaluate, leaf first.
     * @param context The ETSI verification context to evaluate against.
     */
    suspend fun evaluate(
        chain: CertificateChain,
        context: VerificationContext,
    ): TrustResult {
        if (trustAll) {
            Logger.info("TrustEvaluator.trustAll() bypassing trust check for context $context")
            return TrustResult.Trusted(details = "TrustEvaluator.trustAll()")
        }

        val matchingMaterials = materials.filter { context in it.contexts }
        if (matchingMaterials.isEmpty()) {
            return TrustResult.Indeterminate(
                reason = "No trust materials configured for context $context"
            )
        }

        var lastIndeterminate: TrustResult.Indeterminate? = null

        for (material in matchingMaterials) {
            val result = evaluateMaterial(material, chain, context)
            when (result) {
                is TrustResult.Trusted -> return result
                is TrustResult.Indeterminate -> lastIndeterminate = result
                is TrustResult.Untrusted -> { /* continue to next material */ }
            }
        }

        return lastIndeterminate
            ?: TrustResult.Untrusted("Certificate chain not trusted by any configured trust material for context $context")
    }

    private suspend fun evaluateMaterial(
        material: TrustMaterial,
        chain: CertificateChain,
        context: VerificationContext,
    ): TrustResult {
        return when (material) {
            is PredicateTrustMaterial -> evaluatePredicate(material, chain)
            is X509TrustMaterial -> evaluateX509(material, chain)
            is LoteTrustMaterial -> evaluateLote(material, chain, context)
            is EudiWalletTrustMaterial -> evaluateEudiWallet(material, chain, context)
        }
    }

    private suspend fun evaluatePredicate(
        material: PredicateTrustMaterial,
        chain: CertificateChain,
    ): TrustResult {
        return try {
            if (material.evaluate(chain)) {
                TrustResult.Trusted(details = "Predicate trust material")
            } else {
                TrustResult.Untrusted(reason = "Predicate trust material returned false")
            }
        } catch (e: Exception) {
            TrustResult.Indeterminate(
                reason = "Predicate trust material threw an exception: ${e.message}",
                cause = e,
            )
        }
    }

    private fun evaluateX509(
        material: X509TrustMaterial,
        chain: CertificateChain,
    ): TrustResult {
        val leafDer = chain.leaf
        val directMatch = material.certificates.any { anchor -> anchor.contentEquals(leafDer) }
        if (directMatch) {
            return TrustResult.Trusted(details = "X.509 direct trust match")
        }
        // TODO: PKIX chain validation — currently only direct trust is supported
        return TrustResult.Indeterminate(
            reason = "X.509 PKIX chain validation not yet implemented; direct trust did not match"
        )
    }

    private suspend fun evaluateLote(
        material: LoteTrustMaterial,
        chain: CertificateChain,
        context: VerificationContext,
    ): TrustResult {
        // TODO: Integrate with EUDI eudi-lib-kmp-etsi-1196x2 library
        return TrustResult.Indeterminate(
            reason = "LoTE trust material not yet implemented — pending EUDI library integration"
        )
    }

    private suspend fun evaluateEudiWallet(
        material: EudiWalletTrustMaterial,
        chain: CertificateChain,
        context: VerificationContext,
    ): TrustResult {
        // TODO: Integrate with EUDI eudi-lib-kmp-etsi-1196x2 library using eudiw() preset
        return TrustResult.Indeterminate(
            reason = "EUDIW trust material not yet implemented — pending EUDI library integration"
        )
    }
}
