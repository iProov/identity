package com.iproov.identity.models

import com.iproov.identity.attestation.toNSData
import com.iproov.identity.persistence.toByteArray
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import platform.Foundation.NSData
import platform.Foundation.NSDataBase64DecodingIgnoreUnknownCharacters
import platform.Foundation.create
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

@OptIn(ExperimentalEncodingApi::class)
object DataAsBase64Serializer : KSerializer<platform.Foundation.NSData> {
    private val base64 = Base64.Default

    override val descriptor: SerialDescriptor
        get() = PrimitiveSerialDescriptor(
            "DataAsBase64Serializer",
            PrimitiveKind.STRING
        )

    override fun serialize(encoder: Encoder, value: platform.Foundation.NSData) {
        val base64Encoded = base64.encode(value.toByteArray())
        encoder.encodeString(base64Encoded)
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    override fun deserialize(decoder: Decoder): NSData {
        val base64Decoded = decoder.decodeString()
        return NSData.Companion.create(
            base64EncodedString = base64Decoded,
            options = NSDataBase64DecodingIgnoreUnknownCharacters
        )!!
    }
}

typealias Base64Data = @Serializable(with = DataAsBase64Serializer::class) NSData

@OptIn(ExperimentalObjCRefinement::class)
@Serializable
class Mrtd : MrtdData {

    private constructor(
        sod: ByteArray,
        dg1: ByteArray,
        dg2: ByteArray,
        dg3: ByteArray? = null,
        dg4: ByteArray? = null,
        dg5: ByteArray? = null,
        dg6: ByteArray? = null,
        dg7: ByteArray? = null,
        dg8: ByteArray? = null,
        dg9: ByteArray? = null,
        dg10: ByteArray? = null,
        dg11: ByteArray? = null,
        dg12: ByteArray? = null,
        dg13: ByteArray? = null,
        dg14: ByteArray? = null,
        dg15: ByteArray? = null,
        dg16: ByteArray? = null,
        dg17: ByteArray? = null,
        dg18: ByteArray? = null,
        dg19: ByteArray? = null,
        com: ByteArray? = null,
        cvca: ByteArray? = null,
    ) : super(
        sod,
        dg1,
        dg2,
        dg3,
        dg4,
        dg5,
        dg6,
        dg7,
        dg8,
        dg9,
        dg10,
        dg11,
        dg12,
        dg13,
        dg14,
        dg15,
        dg16,
        dg17,
        dg18,
        dg19,
        com,
        cvca,
    )

    constructor(
        sod: Base64Data,
        dg1: Base64Data,
        dg2: Base64Data,
        dg3: Base64Data? = null,
        dg4: Base64Data? = null,
        dg5: Base64Data? = null,
        dg6: Base64Data? = null,
        dg7: Base64Data? = null,
        dg8: Base64Data? = null,
        dg9: Base64Data? = null,
        dg10: Base64Data? = null,
        dg11: Base64Data? = null,
        dg12: Base64Data? = null,
        dg13: Base64Data? = null,
        dg14: Base64Data? = null,
        dg15: Base64Data? = null,
        dg16: Base64Data? = null,
        dg17: Base64Data? = null,
        dg18: Base64Data? = null,
        dg19: Base64Data? = null,
        com: Base64Data? = null,
        cvca: Base64Data? = null,
    ) : this(
        sod.toByteArray(),
        dg1.toByteArray(),
        dg2.toByteArray(),
        dg3?.toByteArray(),
        dg4?.toByteArray(),
        dg5?.toByteArray(),
        dg6?.toByteArray(),
        dg7?.toByteArray(),
        dg8?.toByteArray(),
        dg9?.toByteArray(),
        dg10?.toByteArray(),
        dg11?.toByteArray(),
        dg12?.toByteArray(),
        dg13?.toByteArray(),
        dg14?.toByteArray(),
        dg15?.toByteArray(),
        dg16?.toByteArray(),
        dg17?.toByteArray(),
        dg18?.toByteArray(),
        dg19?.toByteArray(),
        com?.toByteArray(),
        cvca?.toByteArray()
    )

    companion object {
        fun fromDtcVc(dtcVc: NSData) = decodeDtc(dtcVc.toByteArray())
    }
}

// Provides NSData access for the 'sod' property
val MrtdData.sod: NSData
    get() = this.sod.toNSData()

// Provides NSData access for the 'dg1' property
val MrtdData.dg1: NSData
    get() = this.dg1.toNSData()

// Provides NSData access for the 'dg2' property
val MrtdData.dg2: NSData
    get() = this.dg2.toNSData()

// Example for optional properties: returns NSData?
val MrtdData.dg3: NSData?
    get() = this.dg3?.toNSData()

// Add similar extension properties for all other ByteArray properties (dg4-dg16, com, cvca)
val MrtdData.dg4: NSData? get() = this.dg4?.toNSData()
val MrtdData.dg5: NSData? get() = this.dg5?.toNSData()
val MrtdData.dg6: NSData? get() = this.dg6?.toNSData()
val MrtdData.dg7: NSData? get() = this.dg7?.toNSData()
val MrtdData.dg8: NSData? get() = this.dg8?.toNSData()
val MrtdData.dg9: NSData? get() = this.dg9?.toNSData()
val MrtdData.dg10: NSData? get() = this.dg10?.toNSData()
val MrtdData.dg11: NSData? get() = this.dg11?.toNSData()
val MrtdData.dg12: NSData? get() = this.dg12?.toNSData()
val MrtdData.dg13: NSData? get() = this.dg13?.toNSData()
val MrtdData.dg14: NSData? get() = this.dg14?.toNSData()
val MrtdData.dg15: NSData? get() = this.dg15?.toNSData()
val MrtdData.dg16: NSData? get() = this.dg16?.toNSData()

// ... DG17, DG18, DG19 if they exist in your model ...
val MrtdData.com: NSData? get() = this.com?.toNSData()
val MrtdData.cvca: NSData? get() = this.cvca?.toNSData()
