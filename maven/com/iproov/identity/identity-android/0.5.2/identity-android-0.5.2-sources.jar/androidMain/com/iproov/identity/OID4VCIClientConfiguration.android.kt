package com.iproov.identity

import java.net.URI
import java.net.URISyntaxException

internal actual fun isParsableUri(redirectUri: String): Boolean = try {
    URI(redirectUri)
    true
} catch (e: URISyntaxException) {
    false
}
