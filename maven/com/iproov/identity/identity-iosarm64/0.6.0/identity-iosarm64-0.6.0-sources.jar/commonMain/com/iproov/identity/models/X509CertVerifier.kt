package com.iproov.identity.models

import com.iproov.identity.Base64Utils.encodeToBase64Url
import com.iproov.identity.Logger
import com.iproov.identity.api.sha256
import com.iproov.identity.proximity.CertTrust
import kotlinx.io.bytestring.ByteString
import org.multipaz.asn1.ASN1
import org.multipaz.asn1.ASN1Sequence
import org.multipaz.asn1.ASN1TaggedObject
import org.multipaz.asn1.OID
import org.multipaz.crypto.JsonWebSignature
import org.multipaz.crypto.X509Cert
import org.multipaz.crypto.X509KeyUsage

internal expect object PlatformX509CertVerifier {
    /**
     * Evaluates [chain] (leaf first) against the platform trust store, plus any
     * [additionalAnchors] Allows consumer to add their own roots.
     */
    suspend fun verifyCertTrustChain(
        chain: List<ByteArray>,
        additionalAnchors: List<ByteArray>,
    ): Boolean
}

internal object X509CertVerifier {

    /** GeneralName [2] dNSName, RFC 5280 (4.2.1.6) */
    private const val TAG_DNS_NAME = 2

    suspend fun verifyCertTrustChain(
        chain: List<ByteArray>,
        additionalAnchors: List<ByteArray> = emptyList(),
    ): Boolean = PlatformX509CertVerifier.verifyCertTrustChain(chain, additionalAnchors)

    /**
     * Verifies JWS Signing input from header using pub key extracted from the leaf cert
     *
     * Required to ensure PoP, and prevent against Replay attacks
     */
    suspend fun verifySignature(jws: String, leafCertDer: ByteArray): Boolean =
        try {
            val leaf = X509Cert(ByteString(leafCertDer))
            // RFC 5280 §4.2.1.3: a present KeyUsage restricts the key; an absent one is left to the profile.
            if (leaf.getExtensionValue(OID.X509_EXTENSION_KEY_USAGE.oid) != null) {
                CertTrust.requireKeyUsage(leaf, X509KeyUsage.DIGITAL_SIGNATURE, "Request signing certificate")
            }
            JsonWebSignature.verify(jws, leaf.ecPublicKey)
            true
        } catch (e: Exception) {
            Logger.error("JWS signature verification failed: ${e.message}")
            false
        }

    /**
     * Checks to prevent Certification Substitution (Identity Impersonation) + Verifying the SAN binds to claimed client_Id
     * (client_id must match a dNSName SAN in the leaf)
     * */
    fun verifySanDns(leafCertDer: ByteArray, expectedDns: String): Boolean {
        val sanBytes = X509Cert(ByteString(leafCertDer))
            // Globally unique doted Identifier for an ASN.1 Object -> 2.5.29.17 is id-ce-subjectAltName:
            .getExtensionValue(OID.X509_EXTENSION_SUBJECT_ALT_NAME.oid) ?: return false

        val dnsNames = (ASN1.decode(sanBytes) as? ASN1Sequence)?.elements
            ?.filterIsInstance<ASN1TaggedObject>()
            ?.filter { it.tag == TAG_DNS_NAME }
            ?.map { it.content.decodeToString() }
            ?: return false

        return dnsNames.any { it.equals(expectedDns, ignoreCase = true) }
    }

    /** OID4VP .5 x509_hash: client_id must be base64url(SHA-256(DER leaf)). */
    fun verifyCertHash(leafCertDer: ByteArray, expectedHash: String): Boolean =
        sha256(leafCertDer).encodeToBase64Url() == expectedHash
}
