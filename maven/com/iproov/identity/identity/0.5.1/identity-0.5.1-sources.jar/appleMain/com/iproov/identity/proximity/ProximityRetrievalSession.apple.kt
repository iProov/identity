package com.iproov.identity.proximity

import com.iproov.identity.wrap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

val ProximityRetrievalSession.events get() = events.wrap(CoroutineScope(SupervisorJob() + Dispatchers.Default))

val ProximityPresentationSession.events get() = events.wrap(CoroutineScope(SupervisorJob() + Dispatchers.Default))
