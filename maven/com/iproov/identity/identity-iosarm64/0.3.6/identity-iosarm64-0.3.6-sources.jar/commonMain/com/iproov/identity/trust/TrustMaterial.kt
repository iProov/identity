package com.iproov.identity.trust

/**
 * A source of trust anchors scoped to specific [VerificationContext]s.
 *
 * Trust materials are configured on [TrustEvaluator.evaluateUsing] and declare
 * which ETSI verification contexts they cover. During evaluation, only materials
 * whose [contexts] contain the requested context are consulted.
 *
 * Multiple materials can cover the same context — the evaluator uses a
 * first-trusted-wins strategy across them.
 *
 * @see TrustEvaluator
 */
sealed class TrustMaterial {

    /** The ETSI verification contexts this material can evaluate. */
    abstract val contexts: Set<VerificationContext>

    companion object {

        /**
         * ETSI TS 119 602 List of Trusted Entities fetched from a URL.
         *
         * The LoTE is a signed JSON/JWT document published by EU Member States
         * containing trust anchors (X.509 certificates) for registered providers.
         * The [contexts] parameter determines which service type entries in the
         * LoTE are consulted during evaluation.
         *
         * Results are cached locally by default. Set [cached] to false for
         * single-use or low-concurrency scenarios.
         *
         * @param url The URL of the LoTE document.
         * @param contexts The verification contexts this LoTE covers.
         * @param cached Whether to cache the fetched LoTE locally. Defaults to true.
         */
        fun lote(
            url: String,
            contexts: Set<VerificationContext>,
            cached: Boolean = true,
        ): TrustMaterial = LoteTrustMaterial(url, contexts, cached)

        /**
         * EU Digital Identity Wallet preset.
         *
         * Uses the official EUDIW trust list endpoints with all verification
         * contexts pre-configured. This is a convenience for production deployments
         * targeting the EU trust framework.
         */
        fun eudiWallet(): TrustMaterial = EudiWalletTrustMaterial()

        /**
         * Direct X.509 trust anchors.
         *
         * Provide DER-encoded X.509 certificates to use as trust anchors for
         * the specified contexts. The evaluator checks whether the leaf certificate
         * in a chain matches one of the provided anchors (direct trust) or whether
         * the chain builds to one of them (PKIX).
         *
         * Use this for pinning specific CAs or for non-ETSI trust scenarios.
         *
         * @param certificates DER-encoded X.509 certificates to trust.
         * @param contexts The verification contexts these anchors cover.
         */
        fun x509(
            certificates: List<ByteArray>,
            contexts: Set<VerificationContext>,
        ): TrustMaterial = X509TrustMaterial(certificates, contexts)

        /**
         * Custom trust evaluation via a user-supplied predicate.
         *
         * The predicate receives the [CertificateChain] and returns true if
         * trusted, false otherwise. Use this for non-standard trust scenarios
         * (e.g., checking against an internal allowlist).
         *
         * @param contexts The verification contexts this predicate covers.
         * @param evaluate Suspend function that returns true if the chain is trusted.
         */
        fun predicate(
            contexts: Set<VerificationContext>,
            evaluate: suspend (CertificateChain) -> Boolean,
        ): TrustMaterial = PredicateTrustMaterial(contexts, evaluate)
    }
}

internal class LoteTrustMaterial(
    val url: String,
    override val contexts: Set<VerificationContext>,
    val cached: Boolean,
) : TrustMaterial()

internal class EudiWalletTrustMaterial : TrustMaterial() {
    override val contexts: Set<VerificationContext> = VerificationContext.entries.toSet()
}

internal class X509TrustMaterial(
    val certificates: List<ByteArray>,
    override val contexts: Set<VerificationContext>,
) : TrustMaterial()

internal class PredicateTrustMaterial(
    override val contexts: Set<VerificationContext>,
    val evaluate: suspend (CertificateChain) -> Boolean,
) : TrustMaterial()
