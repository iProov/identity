package com.iproov.identity.models

import com.iproov.identity.trust.CertificateChain
import com.iproov.identity.trust.CredentialContextResolver
import com.iproov.identity.trust.TrustEvaluator
import com.iproov.identity.trust.TrustResult
import com.iproov.identity.trust.VerificationContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC


@Serializable
data class GrantDetails(
    @SerialName("issuer_state") val issuerState: String? = null,
    @SerialName("pre-authorized_code") val preAuthorizedCode: String? = null,
    @SerialName("tx_code") val txCode: TxCode? = null,
    @SerialName("authorization_server") val authorizationServer: String? = null,
    @SerialName("interval") val interval: Int? = null,
    @SerialName("user_pin_required") val userPinRequired: Boolean? = null,
)

/**
 * Represents an available grant type in a credential offer.
 */
sealed class AvailableGrant {
    data class PreAuthorizedCode(val txCodeRequired: Boolean = false) : AvailableGrant()
    data class AuthorizationCode(val issuerState: String? = null) : AvailableGrant()
}

@OptIn(ExperimentalObjCRefinement::class)
@Serializable
open class CredentialOffer(
    @HiddenFromObjC
    open val raw: JsonObject,

    /**
     * Preauthorized code that should be used to get an access token.
     * Null when only the authorization code grant is available.
     */
    @Deprecated(
        "Use availableGrants to determine supported grant types. preAuthorizedCode is null for authorization_code-only offers."
    )
    open val preAuthorizedCode: String?,

    /**
     * If a transaction code is required for the issuance of the credentials
     * this will be populated.
     */
    open val transactionCodeDetails: TxCode?,

    /**
     * Grants for this offer
     */
    open val grants: Map<String, GrantDetails>,

    /**
     * A description of the credentials being offered by the issuer
     */
    open val credentials: List<CredentialDescriptor>,

    /**
     * Details about the issuer of the credentials
     */
    open val issuer: CredentialIssuer,
) {
    /**
     * Available grant types for this offer, derived from the grants map.
     */
    val availableGrants: List<AvailableGrant>
        get() = buildList {
            val preAuthKey = "urn:ietf:params:oauth:grant-type:pre-authorized_code"
            if (grants.containsKey(preAuthKey)) {
                add(AvailableGrant.PreAuthorizedCode(txCodeRequired = transactionCodeDetails != null))
            }
            if (grants.containsKey("authorization_code")) {
                add(AvailableGrant.AuthorizationCode(issuerState = grants["authorization_code"]?.issuerState))
            }
        }
}

/**
 * When a credential offer is accepted there are 4 types of results that can come next
 *
 * [IssuanceResult.Empty] - No credentials were requested, so none were fetched
 * [IssuanceResult.TransactionCodeRequired] - An OTP / transaction code is required to fetch the credentials
 * [IssuanceResult.Immediate] - The requested credentials were immediately returned by the issuer.
 * [IssuanceResult.AuthorizationRequired] - The user must authenticate via browser before credentials can be issued.
 */
sealed interface IssuanceResult {
    data object Empty : IssuanceResult

    data class TransactionCodeRequired(val challenge: TransactionCodeChallenge) : IssuanceResult
    data class Immediate(val summary: IssuanceSummary) : IssuanceResult

    /**
     * Authorization code flow: the user must be directed to the [authorizationUrl] to authenticate.
     * After authentication, the redirect will contain an authorization code that should be passed
     * to [respond] to complete credential issuance.
     */
    data class AuthorizationRequired(
        val authorizationUrl: String,
        private val onAuthorizationCode: suspend (authorizationCode: String) -> IssuanceSummary,
    ) : IssuanceResult {

        suspend fun respond(authorizationCode: String): IssuanceSummary =
            onAuthorizationCode(authorizationCode)
    }
}

/**
 * Representation of a credential offer from an issuer with ability to accept this offer
 * to prompt the issuer to issue the credentials that have been accepted
 */
class RespondableCredentialOffer(
    raw: JsonObject,
    credentials: List<CredentialDescriptor>,
    issuer: CredentialIssuer,
    preAuthorizedCode: String?,
    grants: Map<String, GrantDetails>,
    transactionCodeDetails: TxCode?,
    private val trustEvaluator: TrustEvaluator? = null,
    private val onAccept: suspend (List<CredentialDescriptor>) -> IssuanceResult = { IssuanceResult.Empty },
    private val onAuthorize: suspend (List<CredentialDescriptor>) -> IssuanceResult = { IssuanceResult.Empty },
) : CredentialOffer(
    raw,
    preAuthorizedCode,
    transactionCodeDetails,
    grants,
    credentials,
    issuer,
) {
    companion object {
        fun fromCredentialOffer(
            offer: CredentialOffer,
            trustEvaluator: TrustEvaluator? = null,
            onAccept: suspend (List<CredentialDescriptor>) -> IssuanceResult = { IssuanceResult.Empty },
            onAuthorize: suspend (List<CredentialDescriptor>) -> IssuanceResult = { IssuanceResult.Empty },
        ) = RespondableCredentialOffer(
            raw = offer.raw,
            credentials = offer.credentials,
            issuer = offer.issuer,
            preAuthorizedCode = offer.preAuthorizedCode,
            grants = offer.grants,
            transactionCodeDetails = offer.transactionCodeDetails,
            trustEvaluator = trustEvaluator,
            onAccept = onAccept,
            onAuthorize = onAuthorize,
        )
    }

    /**
     * Accept the credential offer using the **pre-authorized code** flow.
     *
     * Use this when [availableGrants] contains [AvailableGrant.PreAuthorizedCode].
     * Returns [IssuanceResult.Immediate] or [IssuanceResult.TransactionCodeRequired]
     * depending on the offer.
     *
     * For the authorization code flow, use [authorize] instead.
     */
    @Throws(Exception::class)
    suspend fun accept(credentials: List<CredentialDescriptor>): IssuanceResult {
        validateRequestedCredentials(
            offeredCredentials = this.credentials,
            requestedCredentials = credentials,
        )
        return onAccept(credentials)
    }

    /**
     * Begin the **authorization code** flow for this credential offer.
     *
     * Use this when [availableGrants] contains [AvailableGrant.AuthorizationCode].
     * Returns [IssuanceResult.AuthorizationRequired] with the URL to direct the user to
     * in a browser. After the user authenticates, extract the authorization code from the
     * redirect callback and pass it to [IssuanceResult.AuthorizationRequired.respond].
     *
     * For the pre-authorized code flow, use [accept] instead.
     */
    @Throws(Exception::class)
    suspend fun authorize(credentials: List<CredentialDescriptor>): IssuanceResult {
        validateRequestedCredentials(
            offeredCredentials = this.credentials,
            requestedCredentials = credentials,
        )
        return onAuthorize(credentials)
    }

    /**
     * Verify issuer trust by auto-detecting the verification context from the
     * offered credentials' type identifiers (docType for mDoc, vct for SD-JWT-VC).
     *
     * The credential identifiers are resolved to [VerificationContext]s using the
     * [CredentialContextResolver] configured on the [TrustEvaluator]. The issuer's
     * certificate chain is then evaluated against each resolved context.
     *
     * Returns [TrustResult.Trusted] if any context matches, [TrustResult.Untrusted]
     * if all contexts reject, or [TrustResult.Indeterminate] if no context mapping
     * exists for the offered credential types.
     *
     * This method is optional — you can call [accept] without verifying issuer trust.
     *
     * @see verifyIssuer(VerificationContext) for explicit context override.
     */
    @Throws(Exception::class)
    suspend fun verifyIssuer(): TrustResult {
        val evaluator = trustEvaluator
            ?: return TrustResult.Indeterminate(reason = "No TrustEvaluator configured")

        val contexts = resolveContextsFromOffer(evaluator.credentialContextResolver)
        if (contexts.isEmpty()) {
            return TrustResult.Indeterminate(
                reason = "No verification context mapping found for offered credential types"
            )
        }

        val chain = extractIssuerCertificateChain()
            ?: return TrustResult.Indeterminate(
                reason = "Could not extract issuer certificate chain from offer"
            )

        var lastIndeterminate: TrustResult.Indeterminate? = null
        for (context in contexts) {
            val result = evaluator.evaluate(chain, context)
            when (result) {
                is TrustResult.Trusted -> return result
                is TrustResult.Indeterminate -> lastIndeterminate = result
                is TrustResult.Untrusted -> { /* try next context */ }
            }
        }

        return lastIndeterminate
            ?: TrustResult.Untrusted(reason = "Issuer not trusted for any resolved context: $contexts")
    }

    /**
     * Verify issuer trust against an explicit [VerificationContext].
     *
     * Use this when you know exactly which ETSI context the issuer should be
     * validated against, bypassing auto-detection from credential types.
     *
     * This method is optional — you can call [accept] without verifying issuer trust.
     *
     * @param context The ETSI verification context to evaluate against.
     * @see verifyIssuer() for auto-detection from the offer's credential types.
     */
    @Throws(Exception::class)
    suspend fun verifyIssuer(context: VerificationContext): TrustResult {
        val evaluator = trustEvaluator
            ?: return TrustResult.Indeterminate(reason = "No TrustEvaluator configured")

        val chain = extractIssuerCertificateChain()
            ?: return TrustResult.Indeterminate(
                reason = "Could not extract issuer certificate chain from offer"
            )

        return evaluator.evaluate(chain, context)
    }

    private fun resolveContextsFromOffer(
        resolver: CredentialContextResolver,
    ): Set<VerificationContext> {
        return credentials.flatMap { descriptor ->
            val identifier = extractCredentialIdentifier(descriptor)
            if (identifier != null) resolver.resolve(identifier) else emptySet()
        }.toSet()
    }

    private fun extractCredentialIdentifier(descriptor: CredentialDescriptor): String? {
        return when (descriptor.format) {
            CredentialFormat.MDOC.value -> descriptor.raw["doctype"]?.jsonPrimitive?.content
            CredentialFormat.SD_JWT_VC.value -> descriptor.raw["vct"]?.jsonPrimitive?.content
            else -> null
        }
    }

    private fun extractIssuerCertificateChain(): CertificateChain? {
        // TODO: Extract x5c from issuer's JWKS endpoint or from the credential offer metadata.
        // For SD-JWT-VC: the issuer's JWKS contains keys with x5c headers.
        // For mDoc: the IACA certificate is in the MSO.
        // This requires network access to fetch the issuer's JWKS, which will be
        // implemented when wiring into the OID4VCI flow.
        return null
    }
}
