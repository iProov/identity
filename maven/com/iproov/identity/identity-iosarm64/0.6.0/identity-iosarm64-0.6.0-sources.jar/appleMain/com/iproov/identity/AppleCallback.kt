package com.iproov.identity

import kotlinx.coroutines.CancellableContinuation

/** Apple completion blocks cannot propagate Kotlin exceptions through @Throws. */
internal inline fun <T> CancellableContinuation<T>.resumeFromAppleCallback(result: () -> T) {
    if (!isActive) return
    resumeWith(runCatching(result))
}
