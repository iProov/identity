package com.iproov.identity.persistence

import com.iproov.identity.TrustConfiguration
import com.iproov.identity.WalletFactory
import com.iproov.identity.api.StatusListVerifier
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialFormat
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.toJsonElement
import com.iproov.identity.models.toNativeTypes
import kotlinx.serialization.json.JsonObject
import org.multipaz.mdoc.issuersigned.IssuerNamespaces
import kotlin.time.Clock

/**
 * Factory for creating [MDocCredential] instances from OID4VCI credential responses.
 *
 * Parses the IssuerSigned CBOR structure as defined in ISO 18013-5:
 * ```
 * IssuerSigned = {
 *   "nameSpaces": IssuerNameSpaces,
 *   "issuerAuth": COSE_Sign1  ; Contains the Mobile Security Object (MSO)
 * }
 * ```
 */
class MDocCredentialFactory internal constructor(
    private val statusListVerifier: StatusListVerifier,
    private val clock: Clock,
    private val trustConfiguration: () -> TrustConfiguration,
) : CredentialFactory {

    // Factories are built before any wallet exists, so the summary reads the wallet's trust when it runs.
    constructor() : this(
        StatusListVerifier.shared,
        Clock.System,
        { WalletFactory.instance?.trustConfiguration ?: TrustConfiguration() },
    )

    override val format: String = CredentialFormat.MDOC.value

    override fun createCredential(raw: String): Credential {
        val mdoc = IssuerSignedMdoc.parse(raw)
        val issuerNamespaces = IssuerNamespaces.fromDataItem(checkNotNull(mdoc.nameSpaces))

        val nameSpaces = issuerNamespaces.data.entries.associate { (namespace, claims) ->
            namespace to claims.entries.associate { (claimName, item) ->
                claimName to item.dataElementValue.toNativeTypes()
            }
        }

        return MDocCredential(
            raw = raw,
            body = nameSpaces.toJsonElement() as JsonObject,
            docType = mdoc.mso.docType,
            nameSpaces = nameSpaces,
            validUntil = mdoc.mso.validUntil.toEpochMilliseconds(),
            onCheckVerificationStatus = {
                mdoc.verificationSummary(trustConfiguration(), statusListVerifier, clock.now())
            }
        )
    }
}
