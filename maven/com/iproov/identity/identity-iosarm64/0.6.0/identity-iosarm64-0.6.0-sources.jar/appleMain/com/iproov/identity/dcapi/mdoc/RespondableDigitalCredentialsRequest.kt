package com.iproov.identity.dcapi.mdoc

import com.iproov.identity.attestation.toNSData
import com.iproov.identity.proximity.DisclosedDocument
import com.iproov.identity.proximity.DocRequest
import com.iproov.identity.proximity.ReaderAuth
import platform.Foundation.NSData

/** An Annex C (Browser) request, parsed and awaiting the user's decision. */
class RespondableDigitalCredentialsRequest internal constructor(
    private val session: MdocDcApiSession,
) {
    /** The original complete request-JSON String */
    val raw: String get() = session.raw

    /** Bound into the transcript so the response is only valid for a particular origin.*/
    val origin: String get() = session.origin

    val docRequests: List<DocRequest> get() = session.docRequests
    
    val readerAuth: ReaderAuth get() = session.readerAuth

    /** Helper function to resolve which locally stored credentials can satisfy the [DocRequest] **/
    @Throws(Exception::class)
    suspend fun match(): Map<DocRequest, List<DisclosedDocument>> = session.match()

    /** Returns bytes for `ISO18013MobileDocumentResponse(responseData:)` */
    @Throws(Exception::class)
    suspend fun respond(disclosed: Map<DocRequest, DisclosedDocument>): NSData {
        val inputs = session.prepare(disclosed)
        val sealed = hpkeSealP256(
            readerPublicKey = inputs.readerPublicKey,
            plaintext = inputs.deviceResponse,
            info = inputs.sessionTranscript,
        )
        return encodeMdocDcApiEncryptedResponse(sealed.enc, sealed.cipherText).toNSData()
    }
}