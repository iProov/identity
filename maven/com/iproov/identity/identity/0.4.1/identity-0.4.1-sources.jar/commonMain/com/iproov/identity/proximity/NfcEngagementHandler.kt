package com.iproov.identity.proximity

import kotlinx.coroutines.CompletableDeferred
import kotlinx.io.bytestring.ByteString
import org.multipaz.cbor.DataItem
import org.multipaz.crypto.EcPrivateKey
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethod

internal sealed class NfcHandoverResult {
    data class Complete(
        val methods: List<MdocConnectionMethod>,
        val encodedDeviceEngagement: ByteString,
        val handover: DataItem
    ) : NfcHandoverResult()

    data class Error(val cause: Exception) : NfcHandoverResult()
}

/**
 * Single-shot handle for one in-flight NFC engagement (ISO 18013-5 §8.2.2.1).
 * Bridges the wallet session (commonMain) and the HCE service (androidMain) via [CompletableDeferred].
 */
internal class NfcEngagementHandler(
    val eDeviceKey: EcPrivateKey,
    val negotiatedPicker: (List<MdocConnectionMethod>) -> MdocConnectionMethod
) {
    private val deferred = CompletableDeferred<NfcHandoverResult>()

    suspend fun awaitHandover(): NfcHandoverResult = deferred.await()

    fun completeHandover(
        methods: List<MdocConnectionMethod>,
        encodedDeviceEngagement: ByteString,
        handover: DataItem
    ) = deferred.complete(
        NfcHandoverResult.Complete(methods, encodedDeviceEngagement, handover)
    )

    /** Settle the handover with an error — timeout, cancellation, or session teardown. */
    fun abort(cause: Throwable) =
        deferred.complete(
            NfcHandoverResult.Error(
                cause as? Exception
                    ?: NfcEngagementAbortedException(
                        cause.message ?: "NFC engagement aborted",
                        cause
                    )
            )
        )

    val isComplete: Boolean get() = deferred.isCompleted
}

class NfcEngagementAbortedException(message: String, cause: Throwable) : Exception(message, cause)