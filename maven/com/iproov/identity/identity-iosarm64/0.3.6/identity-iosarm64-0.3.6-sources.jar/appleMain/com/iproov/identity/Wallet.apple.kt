package com.iproov.identity

import com.benasher44.uuid.uuid5Of
import com.benasher44.uuid.uuidFrom
import com.iproov.identity.api.ApiClient
import com.iproov.identity.api.ApiException
import com.iproov.identity.api.AppleIdentityPlatformInterface
import com.iproov.identity.attestation.AppleAttestationService
import com.iproov.identity.models.LegacyCredential
import com.iproov.identity.models.LoginRequest
import com.iproov.identity.persistence.CredentialDeserializer
import com.iproov.identity.persistence.Keychain
import com.iproov.identity.persistence.LegacyCredentialDeserializer
import com.iproov.identity.persistence.LocalStorage
import com.iproov.identity.persistence.Repository
import com.iproov.identity.persistence.StorageEngine
import com.iproov.identity.persistence.toByteArray
import com.iproov.identity.trust.TrustEvaluator
import com.iproov.kmp.api.IproovOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.runBlocking
import platform.Foundation.NSBundle
import platform.Foundation.NSData
import platform.Foundation.NSDate
import platform.Foundation.NSUUID.Companion.UUID
import platform.Foundation.now
import platform.Foundation.timeIntervalSince1970
import kotlin.coroutines.cancellation.CancellationException
import kotlin.experimental.ExperimentalObjCName
import kotlin.time.Duration.Companion.seconds
import kotlin.time.DurationUnit

actual fun getWalletInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
    trustEvaluator: TrustEvaluator,
    legacyCredentialDeserializer: LegacyCredentialDeserializer, // Remove when when legacy credentials have been removed
    credentialDeserializer: CredentialDeserializer
): Wallet {
    val instanceId = getInstanceId()
    val platform = ApplePlatform(instanceId)

    val apiClient = ApiClient(baseUrl, signingKeyPairFactory, platform, instanceId)
    val identityPlatformInterface =
        AppleIdentityPlatformInterface(signingKeyPairFactory, platform, apiClient)
    val attestationService =
        AppleAttestationService(identityPlatformInterface, signingKeyPairFactory)
    val localStorage = LocalStorage(storageEngine)
    val repository = Repository(localStorage, legacyCredentialDeserializer, credentialDeserializer)
    Logger.isEnabled = isLoggingEnabled

    return Wallet(
        attestationService,
        identityPlatformInterface,
        localStorage,
        repository,
        signingKeyPairFactory,
        trustEvaluator,
    )
}

private fun getInstanceId(): String {
    val sdkNamespace =
        uuid5Of(uuidFrom("00000000-0000-0000-0000-000000000000"), "com.iproov.identity")
    val appId = NSBundle.mainBundle.bundleIdentifier!!
    val deviceId = getDeviceId()

    val appNamespace = uuid5Of(sdkNamespace, appId)
    return uuid5Of(appNamespace, deviceId).toString()
}

private fun getDeviceId(): String {
    val keychain = Keychain("com.iproov.identity")
    var deviceID = keychain.get("deviceID")
    if (deviceID == null) {
        deviceID = UUID().UUIDString
        keychain.set("deviceID", deviceID)
    }
    return deviceID
}

@OptIn(ExperimentalObjCName::class)
@Throws(
    WalletNotRegisteredException::class,
    RequiredClaimNotPresent::class,
    ApiException::class,
    CancellationException::class,
    Exception::class,
)
@ObjCName("addFaceVerification")
fun Wallet.addFaceVerificationToCredential(
    credential: LegacyCredential,
    loginRequest: LoginRequest? = null,
    options: IproovOptions? = null,
) = addFaceVerification(
    credential,
    loginRequest,
    options
).wrap(scope = CoroutineScope(SupervisorJob() + Dispatchers.Default))

@Throws(
    WalletNotRegisteredException::class,
    ApiException::class,
    CancellationException::class,
    Exception::class,
)
fun Wallet.addDocumentWithReference(
    reference: String,
    demoReferencePhoto: NSData? = null,
    loginRequest: LoginRequest? = null,
    options: IproovOptions? = null,
    addLegacyCredential: Boolean = true,
) = addDocumentWithReference(
    reference,
    demoReferencePhoto?.toByteArray(),
    loginRequest,
    options,
    addLegacyCredential
).wrap(scope = CoroutineScope(SupervisorJob() + Dispatchers.Default))

@OptIn(ExperimentalObjCName::class)
@Throws(Exception::class)
@ObjCName("isRegistered")
fun Wallet.isRegisteredBlocking(): Boolean = runBlocking(Dispatchers.Default) { isRegistered() }

@Throws(Exception::class)
suspend fun Wallet.refreshExpiredCredentials() =
    refreshExpiredCredentials(
        isExpiredFromEpochSecondsOverride = NSDate.now().timeIntervalSince1970.seconds.toLong(
            DurationUnit.SECONDS
        )
    )
