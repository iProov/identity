package com.iproov.identity.proximity

import kotlinx.io.bytestring.ByteString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import org.multipaz.crypto.EcCurve
import org.multipaz.crypto.EcPrivateKey
import org.multipaz.crypto.EcPublicKey
import org.multipaz.crypto.X509Cert
import org.multipaz.crypto.X509CertChain

/**
 * Reader authentication credentials for signing proximity DeviceRequests.
 *
 * Proves the reader's organizational identity to the mdoc holder. The holder's
 * device uses the certificate chain to display who is requesting data and may
 * restrict which data elements are released based on reader trust.
 *
 * Use the companion factory methods to construct from PEM, JWK, or PKCS#12.
 */
class ReaderSigningData private constructor(
    val privateKey: PrivateKeyData,
    val certificateChain: CertificateChainData,
) {

    sealed class PrivateKeyData {
        /** PKCS#8 PEM-encoded EC private key. */
        data class Pem(
            val privateKeyPem: String,
            val publicKeyPem: String,
            val curve: EcCurve = EcCurve.P256,
        ) : PrivateKeyData()

        /** JWK-encoded EC private key (JSON string containing "d", "x", "y"). */
        data class Jwk(val jwkString: String) : PrivateKeyData()

        /** PKCS#12 / PFX archive containing the private key. */
        data class Pkcs12(val data: ByteArray, val password: String) : PrivateKeyData()
    }

    sealed class CertificateChainData {
        /** PEM-encoded certificate chain (concatenated PEM blocks, leaf first). */
        data class Pem(val pemString: String) : CertificateChainData()

        /** DER-encoded certificates (leaf first). */
        data class Der(val certificates: List<ByteArray>) : CertificateChainData()

        /** Certificate chain is embedded inside the PKCS#12 archive. */
        data object FromKeystore : CertificateChainData()
    }

    internal fun toEcPrivateKey(): EcPrivateKey = when (privateKey) {
        is PrivateKeyData.Pem -> {
            val publicKey = EcPublicKey.fromPem(privateKey.publicKeyPem)
            EcPrivateKey.fromPem(privateKey.privateKeyPem, publicKey)
        }

        is PrivateKeyData.Jwk -> {
            val jwk = Json.parseToJsonElement(privateKey.jwkString).jsonObject
            EcPrivateKey.fromJwk(jwk)
        }

        is PrivateKeyData.Pkcs12 -> {
            TODO("PKCS#12 private key extraction")
        }
    }

    internal fun toX509CertChain(): X509CertChain = when (certificateChain) {
        is CertificateChainData.Pem -> {
            val certs = PEM_CERT_REGEX.findAll(certificateChain.pemString)
                .map { X509Cert.fromPem(it.value) }
                .toList()
            require(certs.isNotEmpty()) { "No certificates found in PEM string" }
            X509CertChain(certs)
        }

        is CertificateChainData.Der -> {
            val certs = certificateChain.certificates.map { X509Cert(ByteString(it)) }
            require(certs.isNotEmpty()) { "Certificate list must not be empty" }
            X509CertChain(certs)
        }

        is CertificateChainData.FromKeystore -> {
            TODO("PKCS#12 certificate chain extraction")
        }
    }

    companion object {
        private val PEM_CERT_REGEX = Regex(
            "-----BEGIN CERTIFICATE-----[\\s\\S]*?-----END CERTIFICATE-----"
        )

        /**
         * Create from PEM-encoded private key, public key, and certificate chain.
         *
         * @param privateKeyPem PKCS#8 PEM string (-----BEGIN PRIVATE KEY-----)
         * @param publicKeyPem PEM string for the corresponding EC public key
         * @param certificateChainPem concatenated PEM certificates, leaf first
         * @param curve the EC curve of the key pair, defaults to P-256
         */
        fun fromPem(
            privateKeyPem: String,
            publicKeyPem: String,
            certificateChainPem: String,
            curve: EcCurve = EcCurve.P256,
        ) = ReaderSigningData(
            privateKey = PrivateKeyData.Pem(privateKeyPem, publicKeyPem, curve),
            certificateChain = CertificateChainData.Pem(certificateChainPem),
        )

        /**
         * Create from a JWK-encoded private key and PEM certificate chain.
         *
         * @param jwkString JSON string of the EC JWK (must include "d", "x", "y" parameters)
         * @param certificateChainPem concatenated PEM certificates, leaf first
         */
        fun fromJwk(jwkString: String, certificateChainPem: String) = ReaderSigningData(
            privateKey = PrivateKeyData.Jwk(jwkString),
            certificateChain = CertificateChainData.Pem(certificateChainPem),
        )

        /**
         * Create from a PKCS#12 / PFX archive.
         *
         * The archive must contain exactly one private key entry with its
         * associated certificate chain.
         *
         * @param data raw bytes of the .p12 / .pfx file
         * @param password password protecting the archive
         */
        @Deprecated(
            "PKCS#12 support is not implemented yet — use fromPem or fromJwk.",
            level = DeprecationLevel.ERROR,
        )
        fun fromPkcs12(data: ByteArray, password: String) = ReaderSigningData(
            privateKey = PrivateKeyData.Pkcs12(data, password),
            certificateChain = CertificateChainData.FromKeystore,
        )
    }
}
