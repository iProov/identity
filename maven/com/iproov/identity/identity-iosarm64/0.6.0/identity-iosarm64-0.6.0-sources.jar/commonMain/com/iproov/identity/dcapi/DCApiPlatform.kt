package com.iproov.identity.dcapi

/**
 * Create a platform-specific DC API registrar.
 *
 * Returns null on platforms that don't support DC API:
 * - Android < 14 (API 34)
 * - iOS < 26
 */
internal expect fun createPlatformDCApiRegistrar(
    currentCredentials: suspend () -> List<CredentialRegistrationInfo>,
): DCApiRegistrar?

/**
 * Check if DC API is available on this platform without creating a registrar.
 */
expect fun isDCApiPlatformAvailable(): Boolean
