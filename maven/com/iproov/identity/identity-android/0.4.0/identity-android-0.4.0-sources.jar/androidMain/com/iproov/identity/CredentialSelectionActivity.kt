package com.iproov.identity

import android.os.Build
import android.os.Bundle
import androidx.annotation.RequiresApi
import androidx.fragment.app.FragmentActivity
import com.iproov.identity.dcapi.DCApiActivityHelper
import com.iproov.identity.dcapi.DCApiMatchResult
import com.iproov.identity.dcapi.DCApiResult
import com.iproov.identity.models.CredentialQuery
import com.iproov.identity.models.id
import com.iproov.identity.persistence.CredentialSubmission
import com.iproov.identity.persistence.DisclosedCredential
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class CredentialSelectionActivity : FragmentActivity() {
    private lateinit var dcApiHelper: DCApiActivityHelper

    private val scope = CoroutineScope(Dispatchers.Main)

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Logger.debug("CredentialSelectionActivity onCreate called, action=${intent?.action}")

        dcApiHelper = DCApiActivityHelper(this)

        if (!dcApiHelper.isValidRequest()) {
            Logger.error("Invalid request: PendingIntentHandler could not retrieve ProviderGetCredentialRequest from intent (extras=${intent?.extras?.keySet()})")
            finish()
            return
        }
        Logger.debug("CredentialSelectionActivity calling package: ${dcApiHelper.getCallingPackageName()}")

        val callingOrigin = dcApiHelper.getCallingOrigin()
        Logger.debug("CredentialSelectionActivity called from origin: $callingOrigin")

        if (callingOrigin == null) {
            Logger.error("Could not determine calling origin")
            dcApiHelper.returnError(
                DCApiResult.Error(
                    code = "origin_unavailable",
                    message = "Cannot determine the origin of the calling browser",
                )
            )
            finish()
            return
        }

        // Or just extract the credential request JSON (what you usually need)
        val credentialRequestJson = dcApiHelper.extractRequestJson() ?: run {
            Logger.error("Failed to extract credential request JSON")
            dcApiHelper.returnError(
                DCApiResult.Error(
                    code = "invalid_request",
                    message = "No credential request JSON found",
                )
            )
            finish()
            return
        }

        // Get the selected credential ID from the system picker
        val selectedCredentialId = dcApiHelper.getSelectedEntryId()
        scope.launch {

            val wallet = WalletFactory.instance ?: run {
                dcApiHelper.returnError(
                    DCApiResult.Error(
                        code = "wallet_not_initialized",
                        message = "Wallet is not initialized",
                    )
                )
                return@launch
            }
            // Process with your wallet SDK
            when (val matchResult = wallet.processDCApiRequest(credentialRequestJson, callingOrigin)) {
                is DCApiMatchResult.InvalidRequest -> {
                    dcApiHelper.returnError(
                        DCApiResult.Error(matchResult.code, matchResult.message)
                    )
                }


                is DCApiMatchResult.NoMatch -> {
                    Logger.debug("No matching credentials found")
                    dcApiHelper.returnNoCredentials()
                }

                is DCApiMatchResult.Success -> {
                    // Build credential submission from the match result
                    val submission = buildCredentialSubmission(
                        matchResult = matchResult,
                        selectedCredentialId = selectedCredentialId,
                        wallet = wallet,
                    )

                    if (submission == null) {
                        Logger.debug("Selected credential not found in matching credentials")
                        dcApiHelper.returnError(
                            DCApiResult.Error(
                                code = "credential_not_found",
                                message = "Selected credential not found in matching credentials",
                            )
                        )
                        return@launch
                    }

                    // Build and return the DC API response
                    when (val response = wallet.buildDCApiResponse(matchResult, submission)) {
                        is DCApiResult.Success -> dcApiHelper.returnSuccess(response)
                        is DCApiResult.Error -> dcApiHelper.returnError(response)
                        is DCApiResult.UserDeclined -> dcApiHelper.returnCancelled()
                        is DCApiResult.NoMatchingCredentials -> dcApiHelper.returnNoCredentials()
                    }
                }
            }
        }
    }

    /**
     * Build a CredentialSubmission from the match result and selected credential.
     *
     * With the registry-based DC API, the user has already selected a credential
     * from the system picker, so we use that selection.
     */
    private suspend fun buildCredentialSubmission(
        matchResult: DCApiMatchResult.Success,
        selectedCredentialId: String?,
        wallet: Wallet,
    ): CredentialSubmission? {
        val disclosedCredentials = mutableMapOf<CredentialQuery, DisclosedCredential>()

        for ((query, matchingMetadataList) in matchResult.matchResult.credentials) {
            // Find the credential that matches the selected ID, or use the first one
            val selectedMetadata = if (selectedCredentialId != null) {
                matchingMetadataList.find { it.metadata.id == selectedCredentialId }
            } else {
                matchingMetadataList.firstOrNull()
            } ?: continue

            // Load the actual credential
            val credential = wallet.getCredential(selectedMetadata.metadata)

            // Get the claims requested for this query
            val requestedClaims = query.claims?.toSet() ?: emptySet()

            disclosedCredentials[query] = DisclosedCredential(
                credential = credential,
                claims = requestedClaims,
            )
        }

        if (disclosedCredentials.isEmpty()) {
            return null
        }


        return CredentialSubmission(
            disclosedCredentials = disclosedCredentials,
            matchResult = matchResult.matchResult
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
