package com.iproov.identity.models

// Define the exception class
class InvalidMrzException(message: String) : Exception(message)

// BacKey class with factory methods
class BacKey private constructor(val key: String) {

    companion object {
        fun fromFields(
            documentNumber: String,
            dateOfBirth: String,
            dateOfExpiry: String
        ): BacKey {
            val paddedDocumentNumber = documentNumber.padEnd(9, '<')

            val documentNumberField = MrzField.fromValue(paddedDocumentNumber)
            val dateOfBirthField = MrzField.fromValue(dateOfBirth)
            val dateOfExpiryField = MrzField.fromValue(dateOfExpiry)

            val key = documentNumberField.valueWithChecksum +
                    dateOfBirthField.valueWithChecksum +
                    dateOfExpiryField.valueWithChecksum

            return BacKey(key)
        }

        fun fromMrz(mrz: String): BacKey {
            val sanitizedMrz = mrz.replace("\n", "").replace(" ", "")

            val documentNumberWithChecksum: String
            val dateOfBirthWithChecksum: String
            val dateOfExpiryWithChecksum: String

            when (sanitizedMrz.length) {
                88 -> {
                    // TD3 (passport) - 2 rows of 44 characters
                    documentNumberWithChecksum = sanitizedMrz.substring(44, 54)
                    dateOfBirthWithChecksum = sanitizedMrz.substring(57, 64)
                    dateOfExpiryWithChecksum = sanitizedMrz.substring(65, 72)
                }

                90 -> {
                    // TD1 (ID card) - 3 rows of 30 characters
                    documentNumberWithChecksum = sanitizedMrz.substring(5, 15)
                    dateOfBirthWithChecksum = sanitizedMrz.substring(30, 37)
                    dateOfExpiryWithChecksum = sanitizedMrz.substring(38, 45)
                }

                72 -> {
                    // TD2 (ID card) - 2 rows of 36 characters
                    documentNumberWithChecksum = sanitizedMrz.substring(36, 46)
                    dateOfBirthWithChecksum = sanitizedMrz.substring(49, 56)
                    dateOfExpiryWithChecksum = sanitizedMrz.substring(57, 64)
                }

                else -> {
                    throw InvalidMrzException("Invalid MRZ length (${sanitizedMrz.length} characters)")
                }
            }

            val documentNumberField = MrzField.fromStringWithChecksum(documentNumberWithChecksum)
            val dateOfBirthField = MrzField.fromStringWithChecksum(dateOfBirthWithChecksum)
            val dateOfExpiryField = MrzField.fromStringWithChecksum(dateOfExpiryWithChecksum)

            if (!documentNumberField.isValid || !dateOfBirthField.isValid || !dateOfExpiryField.isValid) {
                throw InvalidMrzException("Checksum validation failed")
            }

            val key = documentNumberWithChecksum +
                    dateOfBirthWithChecksum +
                    dateOfExpiryWithChecksum

            return BacKey(key)
        }
    }
}

// MrzField class with checksum computation
class MrzField private constructor(val value: String, val checksum: Int) {

    companion object {
        private const val CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        private val WEIGHTS = listOf(7, 3, 1)

        fun fromValue(value: String): MrzField {
            val checksum = computeChecksum(value)
            return MrzField(value, checksum)
        }

        fun fromStringWithChecksum(valueWithChecksum: String): MrzField {
            val value = valueWithChecksum.substring(0, valueWithChecksum.length - 1)
            val checksumChar = valueWithChecksum.substring(valueWithChecksum.length - 1)
            val checksum = checksumChar.toIntOrNull()
                ?: throw InvalidMrzException("Invalid checksum character: $checksumChar")
            return MrzField(value, checksum)
        }

        private fun computeChecksum(value: String): Int {
            var sum = 0
            for (i in value.indices) {
                val char = value[i]
                val weight = WEIGHTS[i % WEIGHTS.size]
                val charIndex = when (char) {
                    '<' -> 0
                    else -> CHARS.indexOf(char).takeIf { it >= 0 } ?: 0
                }
                sum += charIndex * weight
            }
            return sum % 10
        }
    }

    val isValid: Boolean
        get() = checksum == Companion.computeChecksum(value)

    val valueWithChecksum: String
        get() = value + checksum.toString()
}
