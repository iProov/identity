package com.iproov.identity.cryptography

import com.iproov.identity.models.Jwk
import kotlinx.serialization.json.Json

// --- Exceptions ---

class JWECreationException(message: String, cause: Throwable? = null) : Exception(message, cause)


// --- Encryption Engine Interface ---

/**
 * Interface for a JWE Encryption Engine capable of handling both key management ('alg')
 * and content encryption ('enc') for specific algorithm combinations.
 */
interface JWEFactory {

    val supportedKeyManagementAlgorithms: List<String>
    val supportedEncryptionAlgorithms: List<String>


    /**
     * Performs JWE encryption.
     * Handles key agreement/wrapping based on `supportedKeyManagementAlg` and
     * content encryption using the specified `encToUse`.
     *
     * @param payload The raw data (e.g., JSON response) to encrypt.
     * @param recipientPublicKey The public key (JWK) of the recipient.
     * @param encToUse The specific content encryption algorithm to use (must be in `supportedContentEncryptionEncs`).
     * @param apu Agreement PartyUInfo - for OID4VP direct_post.jwt, this is the mdoc_generated_nonce
     *            (random 32 bytes) that must also be included in the session transcript.
     * @return The JWE Compact Serialization string.
     * @throws JWECreationException if encryption fails or algorithms are incompatible.
     */
    suspend fun create(
        payload: ByteArray,
        recipientPublicKey: Jwk,
        alg: String,
        encToUse: String,
        apu: ByteArray? = null,
    ): String
}

private val jsonParser = Json { ignoreUnknownKeys = true }
//
//class DefaultJWEFactory : JWEFactory {
//
//    companion object {
//
//    }
//
//    override val supportedKeyManagementAlgorithms: List<String> by lazy {
//        JweAlgorithm.entries.map { it.identifier }
//    }
//    override val supportedEncryptionAlgorithms: List<String> by lazy {
//        JweEncryption.entries.map { it.text }
//    }
//
//    override suspend fun create(
//        payload: ByteArray,
//        recipientPublicKey: Jwk,
//        alg: String,
//        encToUse: String
//    ): String {
//        val keyManagementAlg = runCatching {
//            jsonParser.decodeFromString<JweAlgorithm>(alg.uppercase())
//        }.getOrNull()
//
//        if (keyManagementAlg is JweAlgorithm.UNKNOWN || keyManagementAlg == null) {
//            throw JWECreationException("Unsupported JWK alg: $alg. Supported: $supportedKeyManagementAlgorithms")
//        }
//
//        val encryptionAlgorithm = runCatching {
//            jsonParser.decodeFromString<JweEncryption>(encToUse)
//        }.getOrNull()
//            ?: throw JWECreationException("Unsupported encryption alg: ${encToUse}. Supported: $supportedEncryptionAlgorithms")
//
//        val header = JweHeader(
//            algorithm = keyManagementAlg,
//            encryption = encryptionAlgorithm,
//            contentType = "application/octet-stream",
//            keyId = recipientPublicKey.kid
//        )
//
//        // 5. Encrypt using the appropriate key
//        val compactSerialized: String = when (keyManagementAlg) {
//            // Asymmetric Key Management (ECDH-ES, RSA)
//            JweAlgorithm.ECDH_ES, JweAlgorithm.RSA_OAEP_256, JweAlgorithm.RSA_OAEP_512, JweAlgorithm.RSA_OAEP_384 -> {
//
//
//                val publicKey: CryptoPublicKey = CryptoPublicKey.EC.fromUncompressed(
//                    x=recipientPublicKey.x
//
//                ).
//                    ?: throw JWECreationException("Failed to parse JWK string into a public key for alg $alg")
//
//                jweObject.encrypt(publicKey).getOrThrow()
//
//            }
//
//
//            // Symmetric Key Management (AES-KW, dir)
//            JweAlgorithm.A128KW, JweAlgorithm.A192KW, JweAlgorithm.A256KW, JweAlgorithm.DIR -> {
//                val symmetricKey: ByteArray = parsedJwk.getSymmetricKey()
//                    ?: throw JWECreationException("Expected 'oct' JWK with 'k' member for alg $alg")
//
//                jweObject.encrypt(symmetricKey).getOrThrow()
//            }
//
//            else -> throw JWECreationException("Algorithm $alg not implemented in this utility")
//        }
//
//    }
//
//
//}

expect fun getPlatformJWEFactory(): JWEFactory