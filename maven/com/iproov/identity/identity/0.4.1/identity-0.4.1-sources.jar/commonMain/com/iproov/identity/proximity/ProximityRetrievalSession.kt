package com.iproov.identity.proximity

import com.iproov.identity.Logger
import com.iproov.identity.models.toNativeTypes
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.ProducerScope
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.io.bytestring.ByteString
import org.multipaz.asn1.OID
import org.multipaz.cbor.Bstr
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.DataItem
import org.multipaz.cbor.Tagged
import org.multipaz.cbor.buildCborArray
import org.multipaz.crypto.Algorithm
import org.multipaz.crypto.AsymmetricKey
import org.multipaz.crypto.Crypto
import org.multipaz.crypto.EcPrivateKey
import org.multipaz.crypto.X509Cert
import org.multipaz.crypto.X509KeyUsage
import org.multipaz.mdoc.devicesigned.DeviceAuth
import org.multipaz.mdoc.engagement.DeviceEngagement
import org.multipaz.mdoc.request.DeviceRequestGenerator
import org.multipaz.mdoc.response.DeviceResponse
import org.multipaz.mdoc.response.MdocDocument
import org.multipaz.mdoc.role.MdocRole
import org.multipaz.mdoc.sessionencryption.SessionEncryption
import org.multipaz.mdoc.transport.MdocTransport
import org.multipaz.util.Constants
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC
import kotlin.time.Duration.Companion.days

class ProximityRetrievalSession internal constructor(

    private val engagementSource: suspend ProducerScope<ProximityRetrievalEvent>.() -> EngagementOutcome,
    private val requestedDocuments: List<DocumentRequest>,
    private val createSigningData: (suspend () -> ReaderSigningData)?,
    private val orchestrator: ProximityOrchestrator,
    private val config: ProximityConfig,
) {


    companion object {
        // Documented in Annex B.1.4
        val MAX_CERTIFICATE_EXPIRATION_DURATION = 457.days
    }

    internal data class EngagementOutcome(
        val deviceEngagement: DeviceEngagement,
        val mdocTransport: MdocTransport,
        val handover: DataItem,
    )

    private var transport: MdocTransport? = null
    private val transportMutex = Mutex()

    @OptIn(ExperimentalObjCRefinement::class)
    @HiddenFromObjC
    val events: Flow<ProximityRetrievalEvent> = channelFlow {
        var eReaderKey: EcPrivateKey? = null
        lateinit var sessionEncryption: SessionEncryption
        lateinit var sessionTranscript: DataItem

        try {

            if (config.issuerTrust is IssuerTrustPolicy.TrustAll) {
                Logger.info(
                    "ProximityConfig.issuerTrust = TrustAll: any DS certificate will be accepted. " +
                            "This is development-only — production must use TrustedCertificates."
                )
            }

            val engagementOutcome = engagementSource.invoke(this)

            transportMutex.withLock { transport = engagementOutcome.mdocTransport }

            val signingData = createSigningData?.invoke()
            val readerKey = signingData?.toEcPrivateKey()
            val readerCertChain = signingData?.toX509CertChain()

            withTimeout(config.engagementTimeout) {
                send(ProximityRetrievalEvent.Connecting)

                engagementOutcome.mdocTransport.open(engagementOutcome.deviceEngagement.eDeviceKey)
                Logger.debug("Transport session opened")

                send(ProximityRetrievalEvent.SendingRequest)

                eReaderKey =
                    Crypto.createEcPrivateKey(engagementOutcome.deviceEngagement.eDeviceKey.curve)

                val encodedDeviceEngagement =
                    Cbor.encode(engagementOutcome.deviceEngagement.toDataItem())
                val encodedEReaderKey = Cbor.encode(eReaderKey.publicKey.toCoseKey().toDataItem())

                sessionTranscript = buildCborArray {
                    add(Tagged(Tagged.ENCODED_CBOR, Bstr(encodedDeviceEngagement)))
                    add(Tagged(Tagged.ENCODED_CBOR, Bstr(encodedEReaderKey)))
                    add(engagementOutcome.handover)
                }
                val encodedSessionTranscript = Cbor.encode(sessionTranscript)

                sessionEncryption = SessionEncryption(
                    role = MdocRole.MDOC_READER,
                    eSelfKey = eReaderKey,
                    remotePublicKey = engagementOutcome.deviceEngagement.eDeviceKey,
                    encodedSessionTranscript = encodedSessionTranscript,
                )

                val deviceRequestGenerator = DeviceRequestGenerator(encodedSessionTranscript)

                for (doc in requestedDocuments) {
                    deviceRequestGenerator.addDocumentRequest(
                        docType = doc.docType,
                        itemsToRequest = doc.toItemsMap(),
                        requestInfo = null,
                        readerKey = readerKey,
                        signatureAlgorithm = readerKey?.curve?.defaultSigningAlgorithmFullySpecified
                            ?: Algorithm.UNSET,
                        readerKeyCertificateChain = readerCertChain,
                    )
                }

                val encodedDeviceRequest = deviceRequestGenerator.generate()
                val message = sessionEncryption.encryptMessage(
                    messagePlaintext = encodedDeviceRequest,
                    statusCode = null,
                )

                engagementOutcome.mdocTransport.sendMessage(message)
                Logger.debug("DeviceRequest sent")
            }

            send(ProximityRetrievalEvent.WaitingForResponse)

            val responseBytes = withTimeout(config.sessionInactivityTimeout) {
                engagementOutcome.mdocTransport.waitForMessage()
            }

            if (responseBytes.isEmpty()) {
                throw ProximityRetrievalException("Presenter terminated the session before responding")
            }

            val (decryptedResponse, status) = sessionEncryption.decryptMessage(responseBytes)

            if (status != null && status != Constants.SESSION_DATA_STATUS_SESSION_TERMINATION) {
                throw ProximityRetrievalException("Presenter reported error (status=$status)")
            }

            if (status == Constants.SESSION_DATA_STATUS_SESSION_TERMINATION && decryptedResponse == null) {
                throw ProximityRetrievalException("Presenter terminated the session without responding")
            }

            if (decryptedResponse == null) {
                throw ProximityRetrievalException("Received empty response from presenter")
            }

            send(ProximityRetrievalEvent.ProcessingResponse)

            val deviceResponse = DeviceResponse.fromDataItem(Cbor.decode(decryptedResponse))

            if (deviceResponse.version != "1.0") {
                throw ProximityRetrievalException("Unsupported DeviceResponse version: ${deviceResponse.version}")
            }

            if (deviceResponse.status != DeviceResponse.STATUS_OK) {
                throw ProximityRetrievalException("Presenter returned error status: ${deviceResponse.status}")
            }

            deviceResponse.verify(
                sessionTranscript = sessionTranscript,
                eReaderKey = eReaderKey?.let { AsymmetricKey.anonymous(it) },
            )

            if (deviceResponse.documents.isEmpty()) {
                throw ProximityRetrievalException("Presenter did not disclose any documents")
            }

            for (doc in deviceResponse.documents) {
                verifyIssuerTrust(doc, config.issuerTrust)
                verifyKeyAuthorizations(doc)
                verifyNoDuplicateDigestIds(doc)
            }

            Logger.debug("DeviceResponse verified: ${deviceResponse.documents.size} document(s)")

            val response = toRetrievalResponse(deviceResponse, decryptedResponse)
            send(ProximityRetrievalEvent.Completed(response))
        } catch (e: TimeoutCancellationException) {
            send(ProximityRetrievalEvent.Error("Session timed out", e))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val errorMsg = e.message
                ?: e.cause?.message
                ?: "${e::class.simpleName ?: "Unknown error"}: ${
                    e.stackTraceToString().lines().firstOrNull() ?: ""
                }"
            send(ProximityRetrievalEvent.Error(errorMsg, e))
        } finally {
            eReaderKey?.d?.fill(0)
            terminateTransport()
        }

        awaitClose()
    }

    suspend fun close() {
        terminateTransport()
    }

    private suspend fun terminateTransport() {
        transportMutex.withLock {
            transport?.let { t ->
                runCatching {
                    t.sendMessage(
                        SessionEncryption.encodeStatus(Constants.SESSION_DATA_STATUS_SESSION_TERMINATION)
                    )
                }
                runCatching { t.close() }
                transport = null
            }
        }
    }

    private suspend fun verifyIssuerTrust(doc: MdocDocument, issuerTrust: IssuerTrustPolicy) {
        val trustedCerts = when (issuerTrust) {
            is IssuerTrustPolicy.TrustAll -> return
            is IssuerTrustPolicy.TrustedCertificates -> issuerTrust.certificates
        }

        val chain = doc.issuerCertChain.certificates
        val leafCert = chain.firstOrNull()
            ?: throw Exception("Document ${doc.docType}: no issuer certificate present")
        val mso = doc.mso
        val context = "Document ${doc.docType}"

        // §B.1.4 / Table B.3 — DS certificate validity period must not exceed 457 days
        val maxValidity = leafCert.validityNotBefore.plus(MAX_CERTIFICATE_EXPIRATION_DURATION)
        if (leafCert.validityNotAfter > maxValidity) {
            throw Exception("$context: DS certificate validity period exceeds ${MAX_CERTIFICATE_EXPIRATION_DURATION.inWholeDays} days ")
        }

        // §9.3.1 step 5a: MSO signed date must fall within DS certificate validity
        if (mso.signedAt < leafCert.validityNotBefore || mso.signedAt > leafCert.validityNotAfter) {
            throw Exception(
                "$context: MSO signedAt ${mso.signedAt} " +
                        "is outside DS certificate validity (${leafCert.validityNotBefore} - ${leafCert.validityNotAfter})"
            )
        }

        // RFC 5280 §6.1 chain checks — delegated to shared helpers
        CertTrust.verifyCertValidityPeriods(chain, context)
        CertTrust.verifyCaConstraints(chain, context)
        CertTrust.verifyChainSignatures(chain, context)

        // §B.1.4 / Table B.3 — DS leaf: EKU = mdlDS (1.0.18013.5.1.2), keyUsage = digitalSignature (critical)
        CertTrust.requireExtendedKeyUsage(leafCert, "1.0.18013.5.1.2", context)
        CertTrust.requireKeyUsage(leafCert, X509KeyUsage.DIGITAL_SIGNATURE, context)

        // §9.3.1 step 1: chain must root to a trusted IACA certificate
        val trustedRoots = trustedCerts.map { X509Cert(ByteString(it)) }
        val topOfChain = chain.last()
        val rootMatch = trustedRoots.find { trusted ->
            try {
                topOfChain.verify(trusted.ecPublicKey)
                true
            } catch (_: Exception) {
                false
            }
        }
        if (rootMatch == null) {
            throw Exception(
                "$context: issuer certificate chain is not trusted — " +
                        "no matching IACA root found"
            )
        }

        // §9.3.3: countryName in IACA root must match countryName in DS certificate
        val rootCountry =
            rootMatch.subject.components[OID.COUNTRY_NAME.oid]?.value ?: throw Exception(
                "$context: Root certificate country name is not present and must be"
            )
        val leafCountry =
            leafCert.subject.components[OID.COUNTRY_NAME.oid]?.value ?: throw Exception(
                "$context: DS certificate country name is not present and must be"
            )

        if (rootCountry != leafCountry) throw Exception(
            "$context: countryName mismatch — IACA root '$rootCountry' vs DS certificate '$leafCountry'"
        )

        // §9.3.3: stateOrProvinceName must also match if present in both
        val rootState = rootMatch.subject.components[OID.STATE_OR_PROVINCE_NAME.oid]?.value
        val leafState = leafCert.subject.components[OID.STATE_OR_PROVINCE_NAME.oid]?.value
        if (rootState != null && leafState != null && rootState != leafState) {
            throw Exception(
                "$context: stateOrProvinceName mismatch — IACA root '$rootState' vs DS certificate '$leafState'"
            )
        }
    }

    // §9.1.3.4: verify the device key is authorized for all namespaces/elements in DeviceNameSpaces
    private fun verifyKeyAuthorizations(doc: MdocDocument) {
        val deviceNamespaces = doc.deviceNamespaces.data
        if (deviceNamespaces.isEmpty()) return

        val mso = doc.mso
        val authorizedNamespaces = mso.deviceKeyAuthorizedNamespaces
        val authorizedElements = mso.deviceKeyAuthorizedDataElements

        // If neither authorizedNamespaces nor authorizedElements are present in the MSO,
        // the device key is implicitly authorized for everything (per spec, both are optional).
        if (authorizedNamespaces.isEmpty() && authorizedElements.isEmpty()) return

        for ((namespace, elements) in deviceNamespaces) {
            if (authorizedNamespaces.contains(namespace)) continue

            val allowedElements = authorizedElements[namespace] ?: throw Exception(
                "Document ${doc.docType}: device key is not authorized for namespace '$namespace'"
            )

            for (elementName in elements.keys) {
                if (!allowedElements.contains(elementName)) {
                    throw Exception(
                        "Document ${doc.docType}: device key is not authorized for element '$elementName' in namespace '$namespace'"
                    )
                }
            }
        }
    }

    // §9.1.2.4: DigestID shall be unique per namespace; no duplicate DataElementIdentifiers
    private fun verifyNoDuplicateDigestIds(doc: MdocDocument) {
        for ((namespace, elements) in doc.issuerNamespaces.data) {
            val seenDigestIds = mutableSetOf<Long>()
            for ((elementName, item) in elements) {
                if (!seenDigestIds.add(item.digestId)) {
                    throw Exception(
                        "Document ${doc.docType}: duplicate digestID ${item.digestId} in namespace '$namespace' (element '$elementName')"
                    )
                }
            }
        }
    }

    private fun toRetrievalResponse(
        deviceResponse: DeviceResponse,
        rawResponseBytes: ByteArray,
    ): ProximityRetrievalResponse {
        return ProximityRetrievalResponse(
            documents = deviceResponse.documents.map { doc ->
                ReceivedMDocCredential(
                    docType = doc.docType,
                    nameSpaces = doc.issuerNamespaces.data.entries.associate { (namespace, claims) ->
                        namespace to claims.entries.associate { (claimName, item) ->
                            claimName to item.dataElementValue.toNativeTypes()
                        }
                    },
                    issuerCertificateChain = doc.issuerCertChain.certificates.map {
                        it.encoded.toByteArray()
                    },
                    issuerCountry = runCatching {
                        doc.issuerCertChain.certificates.firstOrNull()
                            ?.subject?.components?.get(OID.COUNTRY_NAME.oid)?.value
                    }.getOrNull(),
                    validFrom = doc.mso.validFrom.toString(),
                    validUntil = doc.mso.validUntil.toString(),
                    deviceAuthType = when (doc.deviceAuth) {
                        is DeviceAuth.Ecdsa -> DeviceAuthType.Signature
                        is DeviceAuth.Mac -> DeviceAuthType.Mac
                    },
                    errors = doc.errors,
                )
            },
            documentErrors = deviceResponse.documentErrors.flatMap { errorMap ->
                errorMap.entries.map { (docType, errorCode) ->
                    DocumentError(docType, errorCode)
                }
            },
            rawResponse = rawResponseBytes,
        )
    }
}

class ProximityRetrievalException(message: String) : Exception(message)
