package com.iproov.identity.models

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC


@OptIn(ExperimentalObjCRefinement::class)
@Serializable
data class CredentialIssuer(
    val name: String,

    /**
     * Endpoint that will be used to fetch a single credential.
     */
    val credentialEndpoint: String? = null,

    /**
     * Endpoint that will be used to fetch multiple credentials.
     */
    val batchCredentialEndpoint: String? = null,

    /**
     * Endpoint that will be used to get an access token to request credentials.
     */
    val tokenEndpoint: String,

    /**
     * The methods of authentication to retrieve an access token that are supported by the issuer
     */
    val tokenSupportedAuthenticationMethods: Set<String>? = null,

    /**
     * The algorithms supporter
     */
    val tokenSupportedSigningAlgorithms: Set<String>? = null,

    /**
     * Endpoint that will be used to retrieve the JWKs used for signing credentials.
     */
    val jwksEndpoint: String? = null,

    /**
     * Display properties to use when displaying credentials offered by the issuer.
     */
    val display: Map<String?, DisplayProperties>? = null,


    /**
     * Raw JSON object representing the issuer metadata
     */
    @HiddenFromObjC
    val raw: JsonObject,
)