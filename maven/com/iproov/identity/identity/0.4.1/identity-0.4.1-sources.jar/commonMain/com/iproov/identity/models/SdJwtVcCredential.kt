package com.iproov.identity.models

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC
import io.ktor.util.sha1

/**
 * SD-JWT-VC (Selective Disclosure JWT Verifiable Credential) implementation.
 *
 * This credential format allows selective disclosure of claims during presentation,
 * meaning the holder can choose which claims to reveal to a verifier.
 *
 * Structure: <Issuer-JWT>~<Disclosure1>~<Disclosure2>~...~[<KB-JWT>]
 *
 * References:
 * - SD-JWT-VC spec: https://datatracker.ietf.org/doc/html/draft-ietf-oauth-sd-jwt-vc
 */
@OptIn(ExperimentalObjCRefinement::class)
@Serializable
data class SdJwtVcCredential(
    /**
     * The raw SD-JWT string as received from the issuer.
     * Format: <Issuer-JWT>~<Disclosure1>~<Disclosure2>~...~
     */
    override val raw: String,

    /**
     * All claims from the credential (disclosed + always-visible).
     * This is the fully resolved JSON representation with all disclosures applied.
     */
    override val body: JsonObject,

    /**
     * Verifiable Credential Type (vct claim).
     * Identifies the type of credential, e.g., "IdentityCredential", "DriverLicense".
     */
    val vct: String,

    /**
     * Issuer identifier (iss claim).
     */
    val issuer: String?,

    /**
     * Subject identifier (sub claim).
     */
    val subject: String?,

    /**
     * Whether this credential requires key binding for presentation.
     * If true, presentations must include a KB-JWT signed by the holder.
     */
    val requiresKeyBinding: Boolean,

    /**
     * The confirmation key (cnf claim) if present.
     * Contains the holder's public key for key binding verification.
     */
    @HiddenFromObjC
    val confirmationKey: JsonObject?,

    /**
     * Expiration timestamp in seconds since epoch (exp claim).
     */
    val expiration: Long?,

    /**
     * Issued at timestamp in seconds since epoch (iat claim).
     */
    val issuedAt: Long?,

    /**
     * Callback to check verification status of the credential.
     */
    private val onCheckVerificationStatus: () -> VerificationSummary = { VerificationSummary.start() }
) : Credential {

    override val uuid: String by lazy {
        // Generate a deterministic UUID based on the credential content
        sha1(raw.encodeToByteArray()).decodeToString()
    }

    override val format: CredentialFormat = CredentialFormat.SD_JWT_VC

    override fun getVerificationSummary(): VerificationSummary = onCheckVerificationStatus()

    /**
     * Get the parsed SD-JWT for advanced operations.
     */
    @HiddenFromObjC
    val sdJwt: SdJwt by lazy {
        SdJwt.parse(raw)
    }

    /**
     * Get the list of all available claim names that can be disclosed.
     */
    val disclosableClaimNames: Set<String> by lazy {
        sdJwt.disclosures.map { it.claimName }.toSet()
    }

    /**
     * Get claim value by name from the resolved body.
     */
    fun getClaim(name: String): Any? {
        return body[name]?.toNativeTypes()
    }

    /**
     * Check if a specific claim is available for disclosure.
     */
    fun hasDisclosableClaim(name: String): Boolean {
        return name in disclosableClaimNames
    }

    /**
     * Create a presentation of this credential with only specified claims.
     *
     * @param claimNames The claims to disclose
     * @param nonce The nonce from the verifier (for key binding)
     * @param audience The audience (verifier) for the presentation (for key binding)
     * @param keyBindingJwtFactory Factory to create the KB-JWT signature
     * @return The SD-JWT presentation string
     */
    fun createPresentation(
        claimNames: Set<String>,
        nonce: String? = null,
        audience: String? = null,
        keyBindingJwtFactory: ((nonce: String, audience: String, sdJwtHash: String) -> String)? = null
    ): String {
        return sdJwt.createPresentation(
            claimNames = claimNames,
            nonce = nonce,
            audience = audience,
            keyBindingJwtFactory = keyBindingJwtFactory
        )
    }
}
