@file:OptIn(ExperimentalTime::class)

package com.iproov.identity.api

import com.iproov.identity.DeviceInfo
import com.iproov.identity.cryptography.EllipticCurvePublicKey
import com.iproov.identity.cryptography.OnDeviceKeyPairJwk
import com.iproov.identity.models.LegacyCredential
import com.iproov.identity.models.Jwt
import com.iproov.identity.models.LoginRequest
import com.iproov.identity.models.MrtdData
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.time.Duration
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

internal object Requests {
    @Serializable
    data class GetChallenge(@SerialName("key_identifier") val keyIdentifier: String? = null)

    @Serializable
    data class InitUriCredential(val uri: String)

    @Serializable
    data class InitDocumentReference(
        val reference: String,
        @SerialName("auth_verification_token") val verificationToken: String? = null,
        @SerialName("demo_reference_photo") val demoReferencePhoto: String? = null,
    )

    @Serializable
    data class VerifyUriCredential(val uri: String, val token: String)

    @Serializable
    data class InitDoc(
        @SerialName("challengekey") val challenge: String,
        @SerialName("auth_reverification_token") val reverificationToken: String? = null,
    )

    @Serializable
    data class DocumentVerification(
        val challenge: String,
        @SerialName("aa_signature") val signature: String? = null,
        val secret: String,
        @SerialName("access_control") val accessControl: String
    )

    @Serializable
    data class ReadIdVerification(
        @SerialName("sessionid") val session: String,
        val secret: String
    )

    @Serializable
    data class VerifyMrtd(
        val device: DeviceInfo,
        @Contextual val doc: MrtdData,
        val verification: DocumentVerification,
    )

    @Serializable
    data class DemoMrtd(
        val gender: String,
        @SerialName("rformat") val format: String,
    )

    @Serializable
    data class SharedClaimsPayload(
        val state: String,
        val nonce: String,
        @SerialName("client_id") val clientId: String,
        @SerialName("transaction_id") val transactionId: String,
        @SerialName("signing_request") val signingRequest: String,
        val claims: Map<String, String>,
        val iat: Int,
        val sub: String?,
        @SerialName("sub_jwk") val subJwk: OnDeviceKeyPairJwk,
        val exp: Int,
        val aud: List<String>,
        val iss: String
    ) {
        companion object {
            fun fromLoginRequest(
                jwts: List<Jwt>,
                loginRequest: LoginRequest,
                publicKey: EllipticCurvePublicKey,
                appId: String
            ): SharedClaimsPayload =
                SharedClaimsPayload(
                    state = loginRequest.json["state"]!!.jsonPrimitive.content,
                    nonce = loginRequest.json["nonce"]!!.jsonPrimitive.content,
                    clientId = loginRequest.json["client_id"]!!.jsonPrimitive.content,
                    transactionId = loginRequest.json["transaction_id"]!!.jsonPrimitive.content,
                    signingRequest = loginRequest.jwt.compactString,
                    claims = jwts.associate {
                        it.name to it.compactString
                    },
                    iat = Clock.System.now().epochSeconds.toInt(),
                    sub = publicKey.jwk.keyId,
                    subJwk = publicKey.jwk,
                    exp = Clock.System.now().plus(Duration.parse("5m")).epochSeconds.toInt(),
                    aud = listOf(loginRequest.json["client_id"]!!.jsonPrimitive.content),
                    iss = appId,
                )

        }
    }

    @Serializable
    data class RefreshClaims(
        @SerialName("doc") val document: DocumentDtc? = null,
        val reference: String? = null,
        @SerialName("uri") val uris: List<String> = emptyList()
    ) {
        @Serializable
        data class DocumentDtc(val claim: String) {
            companion object {
                fun fromMrtdCredential(credential: LegacyCredential.IdentityCredential.Mrtd): DocumentDtc {
                    return DocumentDtc(
                        credential.dtc.jwt.compactString
                    )
                }

            }
        }
    }

    @Serializable
    data class VerifyFace(val token: String)

    @Serializable
    data class Dtc(val claim: String)

    @Serializable
    data class InitFace(
        val doc: Dtc,
        @SerialName("auth_reverification_token") val reverificationToken: String? = null
    )
}

object Responses {

    /**
     * @param expiry is milliseconds since epoch
     */
    @Serializable
    data class Expires(
        @SerialName("expires_at") val expiry: Int,
    )

    @Serializable
    data class GetChallenge(
        @SerialName("expires_at") val expiry: Int,
        val challenge: String,
    ) {
        val challengeAsBytes: ByteArray by lazy {
            challenge.chunked(2)
                .map { it.toInt(16).toByte() }
                .toByteArray()
        }
    }

    @Serializable
    data class OfferedCredentialResponse(
        @SerialName("oid4vci_offers") val oidcVCIOffers: Map<Float, JsonObject> = mapOf(),
        val claims: JsonArray = JsonArray(listOf())
    ) {
        val jwts by lazy {
            claims.map { Jwt((it as JsonArray)[1].jsonPrimitive.content) }
        }
    }
}