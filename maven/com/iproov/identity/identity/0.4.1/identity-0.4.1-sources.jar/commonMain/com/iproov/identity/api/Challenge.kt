package com.iproov.identity.api

import com.iproov.identity.models.AccessControl
import com.iproov.identity.models.MrtdData
import com.iproov.identity.models.RespondableCredentialOffer
import kotlinx.coroutines.Deferred
import kotlin.time.Instant
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC
import kotlin.time.ExperimentalTime

@OptIn(ExperimentalObjCRefinement::class, ExperimentalTime::class)
open class Challenge(
    @HiddenFromObjC
    val challenge: ByteArray? = null,

    @HiddenFromObjC
    val expires: Instant,
)

@OptIn(ExperimentalTime::class)
open class RespondableChallenge<T>(
    val respond: T,
    challenge: Challenge,
) : Challenge(challenge = challenge.challenge, expires = challenge.expires) {

    companion object {
        fun <T> fromChallenge(challenge: Challenge, respond: T): RespondableChallenge<T> {
            return RespondableChallenge(respond, challenge)
        }
    }
}

class UriCredentialChallenge(
    challenge: Challenge,
    respond: UriCredentialChallengeResponder
) : RespondableChallenge<UriCredentialChallengeResponder>(challenge = challenge, respond = respond)

class UriCredentialChallengeResponder(
    private val usingToken: UriCredentialChallengeResponse,
) {
    @Throws(Exception::class)
    suspend fun withToken(token: String) = usingToken(token).await()
}

typealias UriCredentialChallengeResponse = (token: String) -> Deferred<Nothing?>

// Type aliases for function types
typealias ReadIdDocumentChallengeResponse = (sessionId: String) -> Deferred<RespondableCredentialOffer>

typealias MrtdChallengeResponse = (
    mrtd: MrtdData,
    accessControl: AccessControl,
    signature: ByteArray?
) -> Deferred<RespondableCredentialOffer>

@OptIn(ExperimentalObjCRefinement::class)
class DocumentChallengeResponder(
    @HiddenFromObjC
    private val usingMrtd: MrtdChallengeResponse,
) {

    @Throws(Exception::class)
    @HiddenFromObjC
    suspend fun withMrtd(
        mrtd: MrtdData,
        accessControl: AccessControl,
        signature: ByteArray?
    ) = usingMrtd(mrtd, accessControl, signature).await()
}

class DocumentChallenge(
    val bacKey: String,
    respond: DocumentChallengeResponder,
    challenge: Challenge
) : RespondableChallenge<DocumentChallengeResponder>(respond, challenge) {

    companion object {
        fun fromChallenge(
            challenge: Challenge,
            bacKey: String,
            respond: DocumentChallengeResponder
        ) = DocumentChallenge(bacKey, respond, challenge)
    }
}
