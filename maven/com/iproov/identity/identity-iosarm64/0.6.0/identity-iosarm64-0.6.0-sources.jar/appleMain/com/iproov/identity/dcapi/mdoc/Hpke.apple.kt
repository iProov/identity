package com.iproov.identity.dcapi.mdoc

import com.iproov.identity.HpkeBridge
import com.iproov.identity.attestation.toNSData
import com.iproov.identity.persistence.toByteArray
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCObjectVar
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.value
import platform.Foundation.NSError

/** Outputs of an HPKE seal, `EncryptedResponseData`. */
internal class HpkeSealed(
    val enc: ByteArray,
    val cipherText: ByteArray,
)

internal class HpkeException(message: String) : Exception(message)

/**
 * The suite is fixed in the Swift bridge, not here. Apple-only by design — Android's DC-API path uses OID4VP with JWE.
 *
 * @param readerPublicKey uncompressed P-256 point (`0x04 || X || Y`) from §C.2.
 * @param info the §C.5 SessionTranscript — must be byte-identical to what the device key signed, or
 *   the reader fails to decrypt with no other symptom.
 */
@OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
internal fun hpkeSealP256(
    readerPublicKey: ByteArray,
    plaintext: ByteArray,
    info: ByteArray,
): HpkeSealed = memScoped {
    val error = alloc<ObjCObjectVar<NSError?>>()
    val sealed = HpkeBridge.sealWithReaderPublicKey(
        readerPublicKey = readerPublicKey.toNSData(),
        plaintext = plaintext.toNSData(),
        info = info.toNSData(),
        error = error.ptr,
    )
    error.value?.let { throw HpkeException(it.localizedDescription) }
    val result = sealed ?: throw HpkeException("HPKE seal returned neither a result nor an error")

    // cinterop exposes the bridge's readonly properties as getter functions.
    HpkeSealed(
        enc = result.enc().toByteArray(),
        cipherText = result.cipherText().toByteArray(),
    )
}
