package com.iproov.identity.dcapi

import com.iproov.identity.DCApiAvailabilityBridge
import com.iproov.identity.Logger
import kotlinx.cinterop.ExperimentalForeignApi

/**
 * Apple/iOS implementation of DC API platform functions.
 *
 * DC API is available on iOS 26+ via IdentityDocumentServices framework.
 * Note: Production deployment requires Apple entitlement approval.
 */

actual fun createPlatformDCApiRegistrar(): DCApiRegistrar? {
    return if (isDCApiPlatformAvailable()) {
        AppleDCApiRegistrar()
    } else {
        Logger.debug("DC API not available on this iOS version")
        null
    }
}

@OptIn(ExperimentalForeignApi::class)
actual fun isDCApiPlatformAvailable(): Boolean {
    // Check iOS version via Swift bridge
    return try {
        DCApiAvailabilityBridge.isAvailable()
    } catch (e: Exception) {
        // If bridge isn't available (older SDK), DC API is not available
        false
    }
}
