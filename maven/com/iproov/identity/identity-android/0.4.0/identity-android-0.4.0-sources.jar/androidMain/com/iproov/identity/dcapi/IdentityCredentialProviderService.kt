package com.iproov.identity.dcapi

import android.os.Build
import android.os.CancellationSignal
import android.os.OutcomeReceiver
import androidx.annotation.RequiresApi
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.ClearCredentialUnknownException
import androidx.credentials.exceptions.CreateCredentialException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.provider.BeginCreateCredentialRequest
import androidx.credentials.provider.BeginCreateCredentialResponse
import androidx.credentials.provider.BeginGetCredentialRequest
import androidx.credentials.provider.BeginGetCredentialResponse
import androidx.credentials.provider.CredentialProviderService
import androidx.credentials.provider.ProviderClearCredentialStateRequest
import com.iproov.identity.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Android CredentialProviderService implementation for Digital Credentials API.
 *
 * This service is invoked by the Android system when apps/browsers request credentials
 * via the Digital Credentials API (navigator.credentials.get() or equivalent).
 *
 * Note: With the registry-based approach using DigitalCredentialRegistry and the OpenID4VP
 * WASM matcher, credential matching is handled by the system. This service primarily handles:
 * - Credential state clearing (logout scenarios)
 * - Fallback for non-registry credential requests
 *
 * To use this service, the consumer app must add to their AndroidManifest.xml:
 * ```xml
 * <service android:name="com.iproov.identity.dcapi.IdentityCredentialProviderService"
 *          android:exported="true"
 *          android:label="@string/app_name"
 *          android:permission="android.permission.BIND_CREDENTIAL_PROVIDER_SERVICE">
 *     <intent-filter>
 *         <action android:name="android.service.credentials.CredentialProviderService"/>
 *     </intent-filter>
 *     <meta-data
 *         android:name="android.credentials.provider"
 *         android:resource="@xml/credential_provider"/>
 * </service>
 * ```
 *
 * And create res/xml/credential_provider.xml:
 * ```xml
 * <credential-provider xmlns:android="http://schemas.android.com/apk/res/android">
 *     <capabilities>
 *         <capability name="androidx.credentials.TYPE_PUBLIC_KEY_CREDENTIAL"/>
 *     </capabilities>
 * </credential-provider>
 * ```
 *
 * Note: This service requires Android 14+ (API 34).
 */
@RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
class IdentityCredentialProviderService : CredentialProviderService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val registrar by lazy {
        AndroidDCApiRegistrar(applicationContext)
    }

    /**
     * Called when an app begins a credential request (query phase).
     *
     * With the registry-based approach, credential matching is handled by the system
     * using the WASM matcher registered with DigitalCredentialRegistry. This callback
     * returns an empty response since the registry handles discovery.
     */
    override fun onBeginGetCredentialRequest(
        request: BeginGetCredentialRequest,
        cancellationSignal: CancellationSignal,
        callback: OutcomeReceiver<BeginGetCredentialResponse, GetCredentialException>
    ) {
        Logger.debug("DC API: onBeginGetCredentialRequest called")

        // With registry-based DC API, the WASM matcher handles credential discovery.
        // This service callback is for non-registry providers or fallback scenarios.
        // Return empty response - credentials are discovered via the registry.
        callback.onResult(BeginGetCredentialResponse())
    }

    /**
     * Called when an app begins a credential creation request.
     *
     * For digital credentials, creation is typically done via OID4VCI,
     * so this returns an empty response.
     */
    override fun onBeginCreateCredentialRequest(
        request: BeginCreateCredentialRequest,
        cancellationSignal: CancellationSignal,
        callback: OutcomeReceiver<BeginCreateCredentialResponse, CreateCredentialException>
    ) {
        Logger.debug("DC API: onBeginCreateCredentialRequest called - not supported for digital credentials")

        // Digital credentials are created via OID4VCI, not through Credential Manager
        // Return empty response indicating no creation entries
        callback.onResult(BeginCreateCredentialResponse())
    }

    /**
     * Called to clear any credential state (e.g., on logout).
     */
    override fun onClearCredentialStateRequest(
        request: ProviderClearCredentialStateRequest,
        cancellationSignal: CancellationSignal,
        callback: OutcomeReceiver<Void?, ClearCredentialException>
    ) {
        Logger.debug("DC API: onClearCredentialStateRequest called")

        serviceScope.launch {
            try {
                // Clear the credential registry
                registrar.clearRegistry()
                callback.onResult(null)
            } catch (e: Exception) {
                Logger.error("DC API: Error in onClearCredentialStateRequest: ${e.message}")
                callback.onError(ClearCredentialUnknownException(e.message))
            }
        }
    }

    companion object {
        /**
         * Intent action for credential selection.
         * Consumer apps should handle this in their Activity.
         */
        const val ACTION_CREDENTIAL_SELECTION = "com.iproov.identity.dcapi.CREDENTIAL_SELECTION"

        /**
         * Extra key for the credential ID.
         */
        const val EXTRA_CREDENTIAL_ID = "credential_id"

        /**
         * Extra key for the DC API request JSON.
         */
        const val EXTRA_REQUEST_JSON = "request_json"

        /**
         * Extra key for the DC API response JSON (in result).
         */
        const val EXTRA_RESPONSE_JSON = "response_json"
    }
}
