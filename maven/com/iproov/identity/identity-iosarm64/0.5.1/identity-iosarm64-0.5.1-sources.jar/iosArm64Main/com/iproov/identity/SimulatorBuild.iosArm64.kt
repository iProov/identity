package com.iproov.identity

// Physical device slice — see the expect declaration in Platform.apple.kt.
internal actual val isSimulatorBuild: Boolean = false
