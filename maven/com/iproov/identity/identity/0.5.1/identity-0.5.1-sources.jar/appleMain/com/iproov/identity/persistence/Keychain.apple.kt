package com.iproov.identity.persistence

import kotlinx.cinterop.*
import platform.CoreFoundation.CFDataCreate
import platform.CoreFoundation.CFDataGetBytePtr
import platform.CoreFoundation.CFDataGetLength
import platform.CoreFoundation.CFDataRef
import platform.CoreFoundation.CFDictionaryCreate
import platform.CoreFoundation.CFDictionaryCreateMutable
import platform.CoreFoundation.CFDictionaryKeyCallBacks
import platform.CoreFoundation.CFDictionaryRef
import platform.CoreFoundation.CFNumberCreate
import platform.CoreFoundation.CFNumberGetType
import platform.CoreFoundation.CFNumberGetValue
import platform.CoreFoundation.CFNumberRef
import platform.CoreFoundation.CFNumberRefVar
import platform.CoreFoundation.CFStringCreateWithCString
import platform.CoreFoundation.CFStringRef
import platform.CoreFoundation.CFTypeRef

import platform.CoreFoundation.CFTypeRefVar
import platform.CoreFoundation.kCFAllocatorDefault
import platform.CoreFoundation.kCFBooleanTrue
import platform.CoreFoundation.kCFCopyStringDictionaryKeyCallBacks
import platform.CoreFoundation.kCFNumberFloat32Type
import platform.CoreFoundation.kCFNumberIntType
import platform.CoreFoundation.kCFStringEncodingUTF8
import platform.CoreFoundation.kCFTypeDictionaryValueCallBacks
import platform.Foundation.*
import platform.Security.*
import platform.posix.memcpy


class Keychain(private val namespace: String) {

    @OptIn(ExperimentalForeignApi::class)
    fun set(key: String, value: String) {
        val data = value.encodeToByteArray()

        val query = createCFDictionary(
            mapOf(
                kSecClass to kSecClassGenericPassword,
                kSecAttrAccount to "$namespace.$key".toCFString(),
                kSecValueData to data.toCFData()
            )
        )

        // Delete any existing entry for the key
        SecItemDelete(query)

        // Add the new key-value pair
        val status = SecItemAdd(query, null)
        if (status != errSecSuccess) {
            throw IllegalStateException("Failed to save data to Keychain: $status")
        }
    }

    @OptIn(ExperimentalForeignApi::class)
    fun get(key: String): String? {
        val query = createCFDictionary(
            mapOf(
                kSecClass to kSecClassGenericPassword,
                kSecAttrAccount to "$namespace.$key".toCFString(),
                kSecReturnData to kCFBooleanTrue!!,
                kSecMatchLimit to kSecMatchLimitOne
            )
        )

        memScoped {
            val result = alloc<CFTypeRefVar>()
            val status = SecItemCopyMatching(query, result.ptr)

            if (status == errSecSuccess) {
                val cfData = result.value as CFDataRef
                return cfData.toByteArray().decodeToString()
            }
        }
        return null
    }

    @OptIn(ExperimentalForeignApi::class)
    fun delete(key: String) {
        val query = createCFDictionary(
            mapOf(
                kSecClass to kSecClassGenericPassword,
                kSecAttrAccount to "$namespace.$key".toCFString()
            )
        )

        SecItemDelete(query)
    }
}

// Helper to convert NSData to ByteArray
@OptIn(ExperimentalForeignApi::class)
fun NSData.toByteArray(): ByteArray {
    val size = this.length.toInt()
    val byteArray = ByteArray(size)
    memcpy(byteArray.refTo(0), this.bytes, size.convert())
    return byteArray
}

@OptIn(ExperimentalForeignApi::class)
fun createCFDictionary(map: Map<CFStringRef?, CFTypeRef?>): CFDictionaryRef = memScoped {
    val keys = allocArray<CFTypeRefVar>(map.size)
    val values = allocArray<CFTypeRefVar>(map.size)

    map.keys.forEachIndexed { index, key -> keys[index] = key }
    map.values.forEachIndexed { index, value -> values[index] = value }

    return CFDictionaryCreate(
        kCFAllocatorDefault,
        keys,
        values,
        map.size.toLong(),
        kCFCopyStringDictionaryKeyCallBacks.ptr,
        kCFTypeDictionaryValueCallBacks.ptr,
    ) ?: throw IllegalArgumentException("Unable to create CFDictionaryRef")
}

@OptIn(ExperimentalForeignApi::class)
fun String.toCFString(): CFStringRef? = CFStringCreateWithCString(
    kCFAllocatorDefault,
    this,
    kCFStringEncodingUTF8
)

@OptIn(ExperimentalForeignApi::class)
fun Int.toCFNumber(): CFNumberRef? = CFNumberCreate(
    kCFAllocatorDefault,
    kCFNumberIntType,
    cValuesOf(this@toCFNumber)
)

@OptIn(ExperimentalForeignApi::class)
fun ByteArray.toCFData(): CFDataRef? {
    val unsignedData = this.map { it.toUByte() }.toUByteArray()
    return CFDataCreate(
        kCFAllocatorDefault,
        unsignedData.refTo(0),
        unsignedData.size.toLong()
    )
}

/**
 * Converts a CFDataRef to a Kotlin ByteArray.
 * This function creates a copy of the data, so it's safe to release the CFDataRef after calling this.
 */
@OptIn(ExperimentalForeignApi::class)
fun CFDataRef.toByteArray(): ByteArray {
    val length = CFDataGetLength(this).toInt()
    if (length == 0) {
        return ByteArray(0) // Empty ByteArray for zero-length data
    }

    val bytePtr = CFDataGetBytePtr(this)
        ?: throw IllegalStateException("CFDataGetBytePtr returned null")

    return bytePtr.readBytes(length)
}
