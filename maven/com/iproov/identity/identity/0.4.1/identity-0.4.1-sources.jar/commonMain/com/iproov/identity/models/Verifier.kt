package com.iproov.identity.models

import kotlinx.serialization.json.JsonObject

data class VerifierDisplayProperties(
    val displayName: String?,
    val logoUri: String?,
    val userHint: String?
)

data class Verifier(
    val clientId: String?,
    val display: VerifierDisplayProperties,

    /**
     *
     */
    val jwks: JsonObject?,                      // for direct_post.jwt
)