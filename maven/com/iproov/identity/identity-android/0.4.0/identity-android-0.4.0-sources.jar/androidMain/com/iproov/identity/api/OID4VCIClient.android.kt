package com.iproov.identity.api

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.Logger
import com.iproov.identity.cryptography.AndroidDefaultKeyPair
import com.iproov.identity.cryptography.platformSupportedEncryptionJWEAlgorithms
import com.iproov.identity.cryptography.signRs
import com.iproov.identity.models.CredentialDescriptor
import com.iproov.identity.models.CredentialIssuer
import com.iproov.identity.models.CredentialOffer
import com.iproov.identity.models.DisplayProperties
import com.iproov.identity.models.GrantDetails
import com.iproov.identity.models.OID4VCICredentialError
import com.iproov.identity.models.OID4VCIException
import com.iproov.identity.models.TxCode
import com.iproov.identity.models.TxInputMode
import com.iproov.identity.models.resolveOfferedCredentials
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.jwk.Curve
import com.nimbusds.jose.jwk.ECKey
import com.nimbusds.jose.jwk.JWK
import com.nimbusds.jose.util.Base64URL
import eu.europa.ec.eudi.openid4vci.AuthorizationRequestPrepared
import eu.europa.ec.eudi.openid4vci.AuthorizeIssuanceConfig
import eu.europa.ec.eudi.openid4vci.AuthorizedRequest
import eu.europa.ec.eudi.openid4vci.BatchSignOperation
import eu.europa.ec.eudi.openid4vci.BatchSigner
import eu.europa.ec.eudi.openid4vci.ClientAuthentication
import eu.europa.ec.eudi.openid4vci.CredentialConfiguration
import eu.europa.ec.eudi.openid4vci.CredentialConfigurationIdentifier
import eu.europa.ec.eudi.openid4vci.CredentialIssuerMetadata
import eu.europa.ec.eudi.openid4vci.CredentialIssuerMetadataValidationError
import eu.europa.ec.eudi.openid4vci.CredentialOfferRequestError
import eu.europa.ec.eudi.openid4vci.CredentialOfferRequestException
import eu.europa.ec.eudi.openid4vci.CredentialOfferRequestResolver
import eu.europa.ec.eudi.openid4vci.CredentialOfferRequestValidationError
import eu.europa.ec.eudi.openid4vci.CredentialResponseEncryptionPolicy
import eu.europa.ec.eudi.openid4vci.EcConfig
import eu.europa.ec.eudi.openid4vci.EncryptionSupportConfig
import eu.europa.ec.eudi.openid4vci.IssuanceRequestPayload
import eu.europa.ec.eudi.openid4vci.IssuedCredential
import eu.europa.ec.eudi.openid4vci.Issuer
import eu.europa.ec.eudi.openid4vci.IssuerMetadataPolicy
import eu.europa.ec.eudi.openid4vci.JwtBindingKey
import eu.europa.ec.eudi.openid4vci.KeyAttestationJWT
import eu.europa.ec.eudi.openid4vci.KeyAttestationRequirement
import eu.europa.ec.eudi.openid4vci.MsoMdocCredential
import eu.europa.ec.eudi.openid4vci.Nonce
import eu.europa.ec.eudi.openid4vci.OpenId4VCIConfig
import eu.europa.ec.eudi.openid4vci.OpenId4VCISpec
import eu.europa.ec.eudi.openid4vci.ParUsage
import eu.europa.ec.eudi.openid4vci.ProofType
import eu.europa.ec.eudi.openid4vci.ProofTypeMeta
import eu.europa.ec.eudi.openid4vci.ProofsSpecification
import eu.europa.ec.eudi.openid4vci.SdJwtVcCredential
import eu.europa.ec.eudi.openid4vci.SignFunction
import eu.europa.ec.eudi.openid4vci.SignOperation
import eu.europa.ec.eudi.openid4vci.Signer
import eu.europa.ec.eudi.openid4vci.SubmissionOutcome
import eu.europa.ec.eudi.openid4vci.W3CJsonLdDataIntegrityCredential
import eu.europa.ec.eudi.openid4vci.W3CJsonLdSignedJwtCredential
import eu.europa.ec.eudi.openid4vci.W3CSignedJwtCredential
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.net.URI
import java.net.URLEncoder
import java.time.Clock
import com.iproov.identity.cryptography.KeyPair as SdkKeyPair
import eu.europa.ec.eudi.openid4vci.AuthorizationCode as EuAuthorizationCode
import eu.europa.ec.eudi.openid4vci.Credential as EuCredential
import eu.europa.ec.eudi.openid4vci.CredentialOffer as EuCredentialOffer

/**
 * Android platform implementation of OID4VCIClient using the EU Digital Identity library.
 */
internal class AndroidOID4VCIClient(
    private val keyPairFactory: KeyPairFactory,
    private val networkClient: NetworkClient
) : OID4VCIClient {

    // Cache the resolved EU offer for use in issuance
    private var cachedEuOffer: EuCredentialOffer? = null

    // Cached state for authorization code flow (needed across prepare → issue steps)
    private var cachedIssuer: Issuer? = null
    private var cachedKeyPair: SdkKeyPair? = null
    private var cachedRequiresPar: Boolean = false

    // HTTP client for the EU library
    private val httpClient = HttpClient(Android) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
        install(Logging) {
            logger = object : io.ktor.client.plugins.logging.Logger {
                override fun log(message: String) {
                    Logger.debug("HTTP: $message")
                }
            }
            level = LogLevel.INFO
        }
    }

    // Base encryption config (shared across all requests)
    private val encryptionConfig = EncryptionSupportConfig(
        ecConfig = EcConfig(
            ecKeyCurve = Curve.P_256,
            supportedJWEAlgorithms = platformSupportedEncryptionJWEAlgorithms.values.toList()
        ),
        rsaConfig = null,
        credentialResponseEncryptionPolicy = CredentialResponseEncryptionPolicy.SUPPORTED
    )

    /**
     * Create OpenId4VCI configuration with optional DPoP signer.
     * Config is created per-issuance to allow DPoP signer with the correct key pair.
     */
    private fun createConfig(dPoPSigner: Signer<JWK>? = null) = OpenId4VCIConfig(
        clientAuthentication = ClientAuthentication.None("identity-android-wallet"),
        authFlowRedirectionURI = URI.create("com.iproov.identity://callback"),
        authorizeIssuanceConfig = AuthorizeIssuanceConfig.FAVOR_SCOPES, //docs/HAIP_1.0.md:552, docs/HAIP_1.0.md:569 require favouring scopes
        dPoPSigner = dPoPSigner,
        parUsage = if (cachedRequiresPar) ParUsage.Required else ParUsage.IfSupported,
        clock = Clock.systemDefaultZone(),
        issuerMetadataPolicy = IssuerMetadataPolicy.IgnoreSigned,
        encryptionSupportConfig = encryptionConfig
    )

    override suspend fun resolveOffer(uri: String): CredentialOffer {
        Logger.info("Resolving credential offer from URI via EU library")

        try {
            val resolver = CredentialOfferRequestResolver(httpClient, IssuerMetadataPolicy.IgnoreSigned)

            val result = resolver.resolve(uri)
                .getOrElse {
                    Logger.debug("Offer resolution failed - full cause chain: ${buildCauseChain(it)}")
                    throw mapResolverError(it)
                }

            // Cache together so partial state can't leak across sessions
            cachedEuOffer = result
            cachedRequiresPar = isHaipCredentialOfferUri(uri)

            return mapEuOfferToCredentialOffer(result)
        } catch (e: OID4VCIException) {
            throw e
        } catch (e: Exception) {
            Logger.error("Exception resolving offer: ${e.message}")
            throw OID4VCIException.RetrievingCredentialOffer(
                "resolution_error",
                e.message ?: "Unknown error resolving credential offer",
                e
            )
        }
    }

    override suspend fun resolveOffer(json: JsonObject): CredentialOffer {
        Logger.info("Resolving credential offer from JSON via EU library")

        // Construct URI from JSON
        val jsonString = Json.encodeToString(JsonObject.serializer(), json)
        val encodedJson = URLEncoder.encode(jsonString, "UTF-8")
        val uri = "openid-credential-offer://?credential_offer=$encodedJson"

        return resolveOffer(uri)
    }

    private fun isHaipCredentialOfferUri(uri: String): Boolean =
        uri.substringBefore(":", missingDelimiterValue = "").equals("haip-vci", ignoreCase = true)

    override suspend fun issueCredentials(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
        transactionCode: String?
    ): OID4VCIIssuanceResult {
        Logger.info("Issuing ${credentials.size} credentials via EU library")

        val euOffer = cachedEuOffer ?: throw OID4VCIException.RetrievingCredential(
            url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
            error = "invalid_state",
            description = "No cached resolved offer found. Call resolveOffer first."
        )

        try {
            // Get key pair for signing
            val keyPair = keyPairFactory()

            // Create DPoP signer using the key pair
            val dPoPSigner = createDPoPSigner(keyPair)

            // Create config with DPoP signer for this issuance
            val config = createConfig(dPoPSigner)

            // Create issuer from cached offer
            val issuer = Issuer.make(
                config = config,
                credentialOffer = euOffer,
                httpClient = httpClient
            ).getOrElse { throw mapResolverError(it) }

            // Extract pre-authorized code info
            val preAuthGrant = euOffer.grants?.preAuthorizedCode() ?: throw OID4VCIException.RetrievingCredential(
                url = offer.issuer.credentialEndpoint ?: "",
                error = "no_pre_auth_code",
                description = "Pre-authorized code grant not found in offer. Use authorize() for authorization code flow."
            )

            // Validate transaction code if required
            if (preAuthGrant.txCode != null && transactionCode == null) {
                throw OID4VCIException.RetrievingCredential(
                    url = offer.issuer.credentialEndpoint ?: "",
                    error = "tx_code_required",
                    description = "Transaction code is required for this pre-authorized code flow"
                )
            }

            // Authorize with pre-authorized code
            Logger.info("Authorizing with pre-authorized code...")
            val authorizedRequest = with(issuer) {
                authorizeWithPreAuthorizationCode(transactionCode).getOrElse {
                    throw mapAuthorizationError(it)
                }
            }

            Logger.info("Authorization successful, requesting credentials")

            // Request credentials
            return requestCredentials(
                issuer = issuer,
                initialAuthorizedRequest = authorizedRequest,
                credentials = credentials,
                keyPair = keyPair,
                offer = offer
            )

        } catch (e: OID4VCIException) {
            throw e
        } catch (e: Exception) {
            Logger.error("Issuance exception: ${e.message}")
            throw OID4VCIException.RetrievingCredential(
                url = offer.issuer.credentialEndpoint ?: "",
                error = "issuance_error",
                description = e.message ?: "Unknown error during credential issuance"
            )
        }
    }

    override suspend fun prepareAuthorizationRequest(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
    ): AuthorizationPreparation {
        Logger.info("Preparing authorization request via EU library")

        val euOffer = cachedEuOffer ?: throw OID4VCIException.RetrievingCredential(
            url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
            error = "invalid_state",
            description = "No cached resolved offer found. Call resolveOffer first."
        )

        try {
            val selectedConfigIds = credentials.map { CredentialConfigurationIdentifier(it.id) }.toSet()
            val filteredCredentialIds = euOffer.credentialConfigurationIdentifiers.filter { it in selectedConfigIds }
            if (filteredCredentialIds.size != selectedConfigIds.size) {
                val filteredCredentialIdValues = filteredCredentialIds.map { it.value }.toSet()
                val missingIds = credentials.map { it.id }.filter { it !in filteredCredentialIdValues }
                throw OID4VCIException.CreatingAccessToken(
                    "invalid_configuration",
                    "Selected credential configurations were not found in the resolved offer: ${
                        missingIds.joinToString(", ")
                    }"
                )
            }

            val filteredOffer = euOffer.copy(
                credentialConfigurationIdentifiers = filteredCredentialIds
            )

            val keyPair = keyPairFactory()
            val dPoPSigner = createDPoPSigner(keyPair)
            val config = createConfig(dPoPSigner)

            val issuer = Issuer.make(
                config = config,
                credentialOffer = filteredOffer,
                httpClient = httpClient
            ).getOrElse { throw mapResolverError(it) }

            // Cache issuer and key pair for use in issueCredentialsWithAuthCode
            cachedIssuer = issuer
            cachedKeyPair = keyPair

            // Note: The EU library automatically includes issuer_state from the credential offer's
            // authorization_code grant in the authorization URL. Per OID4VCI 1.0 Section 5.1.3,
            // this is a MUST when the Wallet received issuer_state in the Credential Offer.
            val prepared = with(issuer) {
                prepareAuthorizationRequest().getOrElse {
                    throw mapAuthorizationError(it)
                }
            }

            Logger.info("Authorization URL prepared: ${prepared.authorizationCodeURL}")

            return AuthorizationPreparation(
                authorizationUrl = prepared.authorizationCodeURL.toString(),
                platformState = prepared,
            )
        } catch (e: OID4VCIException) {
            throw e
        } catch (e: Exception) {
            Logger.error("Exception preparing authorization request: ${e.message}")
            throw OID4VCIException.CreatingAccessToken(
                "authorization_preparation_error",
                e.message ?: "Unknown error preparing authorization request"
            )
        }
    }

    override suspend fun issueCredentialsWithAuthCode(
        offer: CredentialOffer,
        authorizationCode: String,
        preparation: AuthorizationPreparation,
        credentials: List<CredentialDescriptor>,
    ): OID4VCIIssuanceResult {
        Logger.info("Issuing ${credentials.size} credentials with authorization code via EU library")

        val issuer = cachedIssuer ?: throw OID4VCIException.RetrievingCredential(
            url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
            error = "invalid_state",
            description = "No cached issuer found. Call prepareAuthorizationRequest first."
        )

        val keyPair = cachedKeyPair ?: throw OID4VCIException.RetrievingCredential(
            url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
            error = "invalid_state",
            description = "No cached key pair found. Call prepareAuthorizationRequest first."
        )

        val prepared = preparation.platformState as? AuthorizationRequestPrepared
            ?: throw OID4VCIException.RetrievingCredential(
                url = offer.issuer.credentialEndpoint ?: offer.issuer.tokenEndpoint,
                error = "invalid_state",
                description = "Expected AuthorizationRequestPrepared but got ${
                    preparation.platformState::class.simpleName ?: "unknown"
                }. Ensure the same client instance is used for prepare and issue."
            )

        try {
            // Exchange authorization code for access token
            val authorizedRequest = with(issuer) {
                prepared.authorizeWithAuthorizationCode(
                    authorizationCode = EuAuthorizationCode(authorizationCode),
                    serverState = prepared.state,
                ).getOrElse {
                    throw mapAuthorizationError(it)
                }
            }

            Logger.info("Authorization code exchanged successfully, requesting credentials")

            return requestCredentials(
                issuer = issuer,
                initialAuthorizedRequest = authorizedRequest,
                credentials = credentials,
                keyPair = keyPair,
                offer = offer
            )
        } catch (e: OID4VCIException) {
            throw e
        } catch (e: Exception) {
            Logger.error("Auth code issuance exception: ${e.message}")
            throw OID4VCIException.RetrievingCredential(
                url = offer.issuer.credentialEndpoint ?: "",
                error = "auth_code_issuance_error",
                description = e.message ?: "Unknown error during auth code credential issuance"
            )
        } finally {
            cachedIssuer = null
            cachedKeyPair = null
            cachedRequiresPar = false
        }
    }

    private suspend fun requestCredentials(
        issuer: Issuer,
        initialAuthorizedRequest: AuthorizedRequest,
        credentials: List<CredentialDescriptor>,
        keyPair: SdkKeyPair,
        offer: CredentialOffer
    ): OID4VCIIssuanceResult {
        val issuedCredentials = mutableListOf<IssuedCredentialData>()
        val errors = mutableListOf<IssuanceError>()

        // Track the current authorized request (may be updated with new c_nonce after each request)
        var currentAuthRequest = initialAuthorizedRequest

        // Check if any credential requires key attestation
        val requiresKeyAttestation = credentials.any { credential ->
            checkKeyAttestationRequired(credential.id)
        }

        // Create appropriate proofs specification based on key attestation requirement
        val proofsSpec: ProofsSpecification = if (requiresKeyAttestation && keyPair is AndroidDefaultKeyPair) {
            Logger.info("Key attestation required - creating attested key")
            createKeyAttestationProofsSpec(keyPair, initialAuthorizedRequest)
        } else {
            // Use standard JWT proofs without key attestation
            val batchSigner = createBatchSigner(keyPair)
            ProofsSpecification.JwtProofs.NoKeyAttestation(batchSigner)
        }

        // Per OID4VCI 1.0 Section 6.2 / 8.2: when the Token Response includes authorization_details
        // with credential_identifiers, the Wallet MUST use credential_identifier (not
        // credential_configuration_id) in subsequent Credential Requests.
        val credentialIdentifiersMap = initialAuthorizedRequest.credentialIdentifiers

        for (credential in credentials) {
            val configId = credential.id
            val configIdObject = CredentialConfigurationIdentifier(configId)

            // Check if specific credential_identifiers were returned for this configuration
            val identifiers = credentialIdentifiersMap?.get(configIdObject)

            if (identifiers != null && identifiers.isNotEmpty()) {
                // Use IdentifierBased payloads per spec Section 8.2 (MUST when identifiers present)
                Logger.info("Requesting credential $configId using ${identifiers.size} credential_identifier(s)")
                for (credentialIdentifier in identifiers) {
                    try {
                        val payload = IssuanceRequestPayload.IdentifierBased(
                            credentialConfigurationIdentifier = configIdObject,
                            credentialIdentifier = credentialIdentifier,
                        )

                        val result = with(issuer) {
                            with(currentAuthRequest) {
                                request(payload, proofsSpec)
                            }
                        }.getOrElse { error ->
                            Logger.error("Request failed for $configId/${credentialIdentifier.value}: ${error.message}")
                            errors.add(
                                IssuanceError(
                                    configurationId = configId,
                                    credentialIdentifier = credentialIdentifier.value,
                                    error = OID4VCICredentialError(
                                        error = "request_failed",
                                        description = error.message ?: "Unknown error"
                                    )
                                )
                            )
                            continue
                        }

                        val (updatedAuthRequest, outcome) = result
                        currentAuthRequest = updatedAuthRequest
                        processSubmissionOutcome(
                            outcome,
                            configId,
                            credentialIdentifier.value,
                            credential,
                            issuedCredentials,
                            errors
                        )
                    } catch (e: Exception) {
                        Logger.error("Exception requesting $configId/${credentialIdentifier.value}: ${e.message}")
                        errors.add(
                            IssuanceError(
                                configurationId = configId,
                                credentialIdentifier = credentialIdentifier.value,
                                error = OID4VCICredentialError(
                                    error = "exception",
                                    description = e.message ?: "Unknown error"
                                )
                            )
                        )
                    }
                }
            } else {
                // Fall back to ConfigurationBased when no credential_identifiers present
                Logger.info("Requesting credential $configId using credential_configuration_id")
                try {
                    val payload = IssuanceRequestPayload.ConfigurationBased(
                        credentialConfigurationIdentifier = configIdObject,
                    )

                    val result = with(issuer) {
                        with(currentAuthRequest) {
                            request(payload, proofsSpec)
                        }
                    }.getOrElse { error ->
                        Logger.error("Request failed for $configId: ${error.message}")
                        errors.add(
                            IssuanceError(
                                configurationId = configId,
                                error = OID4VCICredentialError(
                                    error = "request_failed",
                                    description = error.message ?: "Unknown error"
                                )
                            )
                        )
                        continue
                    }

                    val (updatedAuthRequest, outcome) = result
                    currentAuthRequest = updatedAuthRequest
                    processSubmissionOutcome(outcome, configId, null, credential, issuedCredentials, errors)
                } catch (e: Exception) {
                    Logger.error("Exception requesting $configId: ${e.message}")
                    errors.add(
                        IssuanceError(
                            configurationId = configId,
                            error = OID4VCICredentialError(
                                error = "exception",
                                description = e.message ?: "Unknown error"
                            )
                        )
                    )
                }
            }
        }

        return OID4VCIIssuanceResult(
            credentials = issuedCredentials,
            errors = errors,
            cNonce = null // c_nonce is handled internally by the EU library
        )
    }

    /**
     * Process a SubmissionOutcome from a credential request, storing issued credentials
     * or recording errors/deferred status as appropriate.
     */
    private fun processSubmissionOutcome(
        outcome: SubmissionOutcome,
        configId: String,
        credentialIdentifier: String?,
        credential: CredentialDescriptor,
        issuedCredentials: MutableList<IssuedCredentialData>,
        errors: MutableList<IssuanceError>,
    ) {
        when (outcome) {
            is SubmissionOutcome.Success -> {
                Logger.info("Credential issued successfully: $configId" + (credentialIdentifier?.let { "/$it" } ?: ""))
                val issuedCred = outcome.credentials.firstOrNull()
                if (issuedCred != null) {
                    val rawCredential = extractCredentialString(issuedCred)
                    issuedCredentials.add(
                        IssuedCredentialData(
                            configurationId = configId,
                            credentialIdentifier = credentialIdentifier,
                            format = credential.format,
                            rawCredential = rawCredential,
                            isDeferred = false,
                            notificationId = outcome.notificationId?.value
                        )
                    )
                }
            }

            is SubmissionOutcome.Deferred -> {
                Logger.info("Credential $configId is deferred with transaction ID: ${outcome.transactionId.value}, interval: ${outcome.interval}")
                issuedCredentials.add(
                    IssuedCredentialData(
                        configurationId = configId,
                        credentialIdentifier = credentialIdentifier,
                        format = credential.format,
                        rawCredential = "",
                        isDeferred = true,
                        notificationId = null
                    )
                )
            }

            is SubmissionOutcome.Failed -> {
                Logger.error("Request failed for $configId: ${outcome.error}")
                errors.add(
                    IssuanceError(
                        configurationId = configId,
                        credentialIdentifier = credentialIdentifier,
                        error = OID4VCICredentialError(
                            error = "request_failed",
                            description = outcome.error.toString()
                        )
                    )
                )
            }
        }
    }

    /**
     * Build a Nimbus ECKey (JWK) from our SDK's KeyPair.
     */
    private fun buildJwk(keyPair: SdkKeyPair): JWK {
        val ecPublicKey = keyPair.getJwk()
        return ECKey.Builder(
            Curve.P_256,
            Base64URL(ecPublicKey.jwk.x),
            Base64URL(ecPublicKey.jwk.y)
        ).build()
    }

    /**
     * Create a DPoP Signer that uses our SDK's KeyPair for signing DPoP proofs.
     * DPoP (Demonstration of Proof-of-Possession) binds access tokens to the client's key.
     */
    private fun createDPoPSigner(keyPair: SdkKeyPair): Signer<JWK> {
        val ecKey = buildJwk(keyPair)

        return object : Signer<JWK> {
            // EUDI library expects JCA algorithm name, not JOSE name
            // "SHA256withECDSA" maps to ES256 in toJoseAlg()
            override val javaAlgorithm: String = "SHA256withECDSA"

            override suspend fun acquire(): SignOperation<JWK> {
                val signFunction = SignFunction { input ->
                    keyPair.sign(input)  // EUDI library expects ASN.1 DER format
                }

                return SignOperation(
                    function = signFunction,
                    publicMaterial = ecKey
                )
            }

            override suspend fun release(signOperation: SignOperation<JWK>?) {
                // No cleanup needed
            }
        }
    }

    /**
     * Create a BatchSigner that uses our SDK's KeyPair for signing credential proofs.
     */
    private fun createBatchSigner(keyPair: SdkKeyPair): BatchSigner<JwtBindingKey> {
        val ecKey = buildJwk(keyPair)
        val bindingKey = JwtBindingKey.Jwk(ecKey)

        return object : BatchSigner<JwtBindingKey> {
            // EUDI library expects JCA algorithm name, not JOSE name
            // "SHA256withECDSA" maps to ES256 in toJoseAlg()
            override val javaAlgorithm: String = "SHA256withECDSA"

            override suspend fun authenticate(): BatchSignOperation<JwtBindingKey> {
                val signFunction = SignFunction { input ->
                    keyPair.sign(input)  // EUDI library expects ASN.1 DER format
                }

                val signOperation = SignOperation(
                    function = signFunction,
                    publicMaterial = bindingKey
                )

                return BatchSignOperation(listOf(signOperation))
            }

            override suspend fun release(signOps: BatchSignOperation<JwtBindingKey>?) {
                // No cleanup needed
            }
        }
    }

    /**
     * Check if a credential configuration requires key attestation.
     */
    private fun checkKeyAttestationRequired(configId: String): Boolean {
        val euOffer = cachedEuOffer ?: return false
        val credentialConfig = euOffer.credentialIssuerMetadata
            .credentialConfigurationsSupported[CredentialConfigurationIdentifier(configId)]
            ?: return false

        val jwtProofMeta = credentialConfig.proofTypesSupported[ProofType.JWT] as? ProofTypeMeta.Jwt
            ?: return false

        return jwtProofMeta.keyAttestationRequirement !is KeyAttestationRequirement.NotRequired
    }

    /**
     * Create a ProofsSpecification with key attestation for issuers that require it.
     * Uses the attestation certificate chain from the KeyStore (generated at key creation time).
     */
    private fun createKeyAttestationProofsSpec(
        keyPair: AndroidDefaultKeyPair,
        authorizedRequest: AuthorizedRequest
    ): ProofsSpecification {
        // Get the attestation certificate chain (generated when the key was created)
        val certChain = keyPair.getAttestationCertificateChain()
        if (certChain == null || certChain.isEmpty()) {
            Logger.error("Key attestation required but certificate chain not available")
            throw OID4VCIException.RetrievingCredential(
                url = "",
                error = "key_attestation_unavailable",
                description = "This issuer requires key attestation but the signing key was created without attestation. " +
                        "This can happen on devices without hardware-backed keystore or with keys created before attestation was enabled. " +
                        "Try resetting the wallet to generate a new attested key."
            )
        }

        Logger.info("Key attestation certificate chain available: ${certChain.size} certificates")

        // Build the attested key JWK with x5c certificate chain
        val ecPublicKey = keyPair.getJwk()
        val attestedKeyJwk = ECKey.Builder(
            Curve.P_256,
            Base64URL(ecPublicKey.jwk.x),
            Base64URL(ecPublicKey.jwk.y)
        ).x509CertChain(certChain.map { Base64URL.encode(it.encoded) })
            .build()

        // Get issuer identifier for aud claim
        val issuerIdentifier = cachedEuOffer?.credentialIssuerMetadata?.credentialIssuerIdentifier?.toString()

        return ProofsSpecification.JwtProofs.WithKeyAttestation(
            proofSignerProvider = { requestNonce ->
                createKeyAttestationSigner(keyPair, attestedKeyJwk, requestNonce, issuerIdentifier)
            },
            keyIndex = 0
        )
    }

    /**
     * Create a Signer that provides KeyAttestationJWT for credential proofs.
     * The KeyAttestationJWT is a signed JWT containing the attested keys and nonce.
     */
    private fun createKeyAttestationSigner(
        keyPair: AndroidDefaultKeyPair,
        attestedKeyJwk: ECKey,
        nonce: Nonce?,
        issuerIdentifier: String?
    ): Signer<KeyAttestationJWT> {
        return object : Signer<KeyAttestationJWT> {
            override val javaAlgorithm: String = "SHA256withECDSA"

            override suspend fun acquire(): SignOperation<KeyAttestationJWT> {
                // Build the Key Attestation JWT
                // Header: {"alg": "ES256", "typ": "keyattestation+jwt", "x5c": [cert chain]}
                // Payload: {"aud": ..., "iat": ..., "exp": ..., "attested_keys": [jwk], "key_storage": [...], "user_authentication": [...], "nonce": "..."}
                val jwtString = buildKeyAttestationJwt(keyPair, attestedKeyJwk, nonce, issuerIdentifier)
                val keyAttestationJwt = KeyAttestationJWT(jwtString)

                val signFunction = SignFunction { input ->
                    keyPair.sign(input)  // EUDI library expects ASN.1 DER format
                }

                return SignOperation(
                    function = signFunction,
                    publicMaterial = keyAttestationJwt
                )
            }

            override suspend fun release(signOperation: SignOperation<KeyAttestationJWT>?) {
                // No cleanup needed
            }
        }
    }

    /**
     * Build a Key Attestation JWT per OID4VCI 1.0 Appendix D (Key Attestation in JWT format).
     * The JWT contains the attested public keys and is signed by the attested key itself.
     */
    private fun buildKeyAttestationJwt(
        keyPair: AndroidDefaultKeyPair,
        attestedKeyJwk: ECKey,
        nonce: Nonce?,
        issuerIdentifier: String?
    ): String {
        val certChain = keyPair.getAttestationCertificateChain()
            ?: throw IllegalStateException("Attestation certificate chain not available")

        // Build header with x5c certificate chain per RFC 7515 Section 4.1.6 and OID4VCI HAIP:
        //
        // RFC 7515 Section 4.1.6:
        //   - "The certificate containing the public key... MUST be the first certificate"
        //   - "This MAY be followed by additional certificates, with each subsequent
        //      certificate being the one used to certify the previous one"
        //   - Uses standard Base64 (NOT Base64URL)
        //
        // OID4VCI High Assurance Interoperability Profile:
        //   - "The X.509 certificate of the trust anchor MUST NOT be included in x5c"
        //   - "The X.509 certificate signing the key attestation MUST NOT be self-signed"
        //
        // Android attestation chain order: [leaf, intermediate1, intermediate2, ..., root]
        // We include all certificates EXCEPT the root CA (last in chain)
        val certsToInclude = if (certChain.size > 1) {
            certChain.dropLast(1)  // Exclude root CA
        } else {
            certChain.toList()
        }

        val x5cArray = certsToInclude.map { java.util.Base64.getEncoder().encodeToString(it.encoded) }

        val header = buildJsonObject {
            put("alg", "ES256")
            put("typ", OpenId4VCISpec.KEY_ATTESTATION_JWT_TYPE)
            put("x5c", JsonArray(x5cArray.map { JsonPrimitive(it) }))
        }

        // Build payload with attested keys and nonce
        // x5c is in the header for signing key attestation per spec
        val attestedKeyJson = buildJsonObject {
            put("kty", "EC")
            put("crv", "P-256")
            put("x", attestedKeyJwk.x.toString())
            put("y", attestedKeyJwk.y.toString())
        }

        // Map Android security level to ISO 18045 key_storage values per OID4VCI 1.0 spec
        val keyStorageLevel = mapSecurityLevelToIso18045(keyPair.getKeySecurityLevel())
        val userAuthLevel = keyPair.getUserAuthenticationLevel()

        // aud is REQUIRED per OID4VCI spec
        requireNotNull(issuerIdentifier) {
            "Issuer identifier is required for key attestation JWT 'aud' claim"
        }

        val now = System.currentTimeMillis() / 1000
        val payload = buildJsonObject {
            // Standard JWT claims (per OID4VCI 1.0 Appendix D)
            put("aud", issuerIdentifier)  // Audience - REQUIRED - Credential Issuer Identifier
            put("iat", now)  // Issued at - REQUIRED
            put("exp", now + 300)  // Expires in 5 minutes

            // Key attestation specific claims per OID4VCI 1.0 Appendix D
            put("attested_keys", JsonArray(listOf(attestedKeyJson)))

            // key_storage: Attack potential resistance of key storage
            put("key_storage", JsonArray(listOf(JsonPrimitive(keyStorageLevel))))

            // user_authentication: User authentication method resistance
            put("user_authentication", JsonArray(listOf(JsonPrimitive(userAuthLevel))))

            if (nonce != null) {
                put("nonce", nonce.value)
            }
        }

        // Encode header and payload
        val headerB64 = Base64URL.encode(header.toString().toByteArray(Charsets.UTF_8))
        val payloadB64 = Base64URL.encode(payload.toString().toByteArray(Charsets.UTF_8))

        // Sign the JWT and convert to R||S format (consistent with iOS approach)
        val signingInput = "$headerB64.$payloadB64".toByteArray(Charsets.UTF_8)
        val rsSignature = keyPair.signRs(signingInput)
        val signatureB64 = Base64URL.encode(rsSignature)

        return "$headerB64.$payloadB64.$signatureB64"
    }

    /**
     * Map Android security level to ISO 18045 attack potential resistance values.
     * Per OID4VCI 1.0 Appendix D, valid values are:
     * - "iso_18045_high" (VAN.5) - StrongBox
     * - "iso_18045_moderate" (VAN.4) - TEE
     * - "iso_18045_enhanced-basic" (VAN.3)
     * - "iso_18045_basic" (VAN.2) - Software
     */
    private fun mapSecurityLevelToIso18045(securityLevel: String): String {
        return when {
            securityLevel.contains("STRONGBOX", ignoreCase = true) -> "iso_18045_high"
            securityLevel.contains("TRUSTED_ENVIRONMENT", ignoreCase = true) -> "iso_18045_moderate"
            securityLevel.contains("secureElement", ignoreCase = true) -> "iso_18045_moderate"
            securityLevel.contains("UNKNOWN_SECURE", ignoreCase = true) -> "iso_18045_moderate"
            else -> "iso_18045_basic"
        }
    }

    /**
     * Extract the credential string from an IssuedCredential.
     */
    private fun extractCredentialString(issuedCredential: IssuedCredential): String {
        return when (val cred = issuedCredential.credential) {
            is EuCredential.Str -> cred.value
            is EuCredential.Json -> cred.value.toString()
        }
    }

    // MARK: - Mapping Helpers

    private fun mapEuOfferToCredentialOffer(euOffer: EuCredentialOffer): CredentialOffer {
        val issuerMetadata = euOffer.credentialIssuerMetadata
        val authMetadata = euOffer.authorizationServerMetadata

        // Extract token endpoint
        val tokenEndpoint = authMetadata.tokenEndpointURI?.toString()

        // Extract DPoP algorithms
        val dpopAlgs = authMetadata.dPoPJWSAlgs ?: emptyList()

        // Validate token endpoint
        requireNotNull(tokenEndpoint) {
            "Authorization Server does not support the required Token Endpoint for issuance."
        }

        // Map issuer info
        val issuer = mapIssuerInfo(issuerMetadata, tokenEndpoint, dpopAlgs)

        val availableCredentials = issuerMetadata.credentialConfigurationsSupported.map { (id, config) ->
            mapCredentialConfiguration(id.value, config)
        }
        val credentials = resolveOfferedCredentials(
            offeredConfigurationIds = euOffer.credentialConfigurationIdentifiers.map { it.value },
            availableCredentials = availableCredentials,
        )

        // Extract pre-authorized code and tx code details
        var preAuthCode: String? = null
        var txCodeDetails: TxCode? = null

        val preAuthGrant = euOffer.grants?.preAuthorizedCode()
        if (preAuthGrant != null) {
            preAuthCode = preAuthGrant.preAuthorizedCode
            preAuthGrant.txCode?.let { txCode ->
                txCodeDetails = TxCode(
                    inputMode = when (txCode.inputMode.name.lowercase()) {
                        "numeric" -> TxInputMode.numeric
                        "text" -> TxInputMode.text
                        else -> TxInputMode.numeric
                    },
                    length = txCode.length,
                    description = txCode.description
                )
            }
        }

        // Extract authorization code grant
        val authCodeGrant = euOffer.grants?.authorizationCode()

        // At least one grant type must be present
        require(preAuthCode != null || authCodeGrant != null) {
            "Credential offer has no supported grant types (neither pre-authorized code nor authorization code)."
        }

        // Build grants map
        val grants = buildMap {
            if (preAuthCode != null) {
                put(
                    "urn:ietf:params:oauth:grant-type:pre-authorized_code",
                    GrantDetails(preAuthorizedCode = preAuthCode)
                )
            }
            if (authCodeGrant != null) {
                put(
                    "authorization_code",
                    GrantDetails(issuerState = authCodeGrant.issuerState)
                )
            }
        }

        // Build raw JSON representation
        val rawJson = buildJsonObject {
            put("credential_issuer", issuerMetadata.credentialIssuerIdentifier.toString())
            put(
                "credential_configuration_ids", JsonArray(
                    euOffer.credentialConfigurationIdentifiers.map {
                        JsonPrimitive(it.value)
                    }
                ))
        }

        return CredentialOffer(
            raw = rawJson,
            preAuthorizedCode = preAuthCode,  // null when only auth code grant is available
            transactionCodeDetails = txCodeDetails,
            grants = grants,
            credentials = credentials,
            issuer = issuer,
        )
    }

    private fun mapIssuerInfo(
        metadata: CredentialIssuerMetadata,
        tokenEndpoint: String,
        dpopAlgs: List<JWSAlgorithm>
    ): CredentialIssuer {
        // Map display properties
        val displayProps = metadata.display.associate { display ->
            display.locale?.toLanguageTag() to DisplayProperties(
                name = display.name,
                locale = display.locale?.toLanguageTag(),
                description = null,
                backgroundColor = display.backgroundColor,
                textColor = display.textColor,
                logoUrl = display.logo?.uri?.toString(),
                logoAltText = display.logo?.alternativeText,
                additionalData = emptyMap()
            )
        }

        return CredentialIssuer(
            raw = JsonObject(emptyMap()),
            name = metadata.credentialIssuerIdentifier.toString(),
            tokenEndpoint = tokenEndpoint,
            credentialEndpoint = metadata.credentialEndpoint.toString(),
            jwksEndpoint = null,
            display = displayProps,
            tokenSupportedSigningAlgorithms = if (dpopAlgs.isNotEmpty()) {
                dpopAlgs.map { it.name }.toSet()
            } else null,
            tokenSupportedAuthenticationMethods = null
        )
    }

    private fun mapCredentialConfiguration(
        id: String,
        config: CredentialConfiguration
    ): CredentialDescriptor {
        val (format, metadata) = when (config) {
            is MsoMdocCredential -> "mso_mdoc" to config.credentialMetadata
            is SdJwtVcCredential -> "dc+sd-jwt" to config.credentialMetadata
            is W3CSignedJwtCredential -> "jwt_vc_json" to config.credentialMetadata
            is W3CJsonLdSignedJwtCredential -> "jwt_vc_json-ld" to config.credentialMetadata
            is W3CJsonLdDataIntegrityCredential -> "ldp_vc" to config.credentialMetadata
        }

        val displayProps = metadata?.display?.associate { display ->
            display.locale?.toLanguageTag() to DisplayProperties(
                name = display.name,
                locale = display.locale?.toLanguageTag(),
                description = display.description,
                backgroundColor = display.backgroundColor,
                textColor = display.textColor,
                logoUrl = display.logo?.uri?.toString(),
                logoAltText = display.logo?.alternativeText,
                additionalData = emptyMap()
            )
        } ?: emptyMap()

        return CredentialDescriptor(
            id = id,
            raw = JsonObject(emptyMap()),
            format = format,
            scope = config.scope,
            display = displayProps
        )
    }

    // MARK: - Error Mapping

    /**
     * Builds a description from the exception cause chain, including class names
     * for context. Understands the EU EUDI library's [CredentialOfferRequestException]
     * which nests errors in properties instead of the standard cause chain.
     *
     * Example output: "UnableToResolveCredentialIssuerMetadata > InvalidCredentialsSupported > IllegalArgumentException: Failed requirement."
     */
    private fun extractDescription(error: Throwable): String {
        val chain = buildCauseChain(error)
        return chain.ifEmpty { error.toString() }
    }

    /**
     * Walks the full error chain (including EU library's non-standard nesting)
     * and collects "ClassName: message" pairs, joined with " > ".
     */
    private fun buildCauseChain(error: Throwable): String {
        val parts = mutableListOf<String>()
        val visited = mutableSetOf<Int>()
        var current: Throwable? = error

        while (current != null && visited.add(System.identityHashCode(current))) {
            // EU library wraps real errors in CredentialOfferRequestException.error
            // property instead of the standard cause chain — unwrap it.
            if (current is CredentialOfferRequestException) {
                val errorObj = current.error
                val errorName = errorObj::class.simpleName ?: "Unknown"
                parts.add(errorName)
                current = extractReasonFromError(errorObj)
                continue
            }

            val name = current::class.simpleName ?: current::class.qualifiedName ?: "Unknown"
            val msg = current.message
            if (!msg.isNullOrBlank()) {
                parts.add("$name: $msg")
            } else {
                parts.add(name)
            }
            current = current.cause
        }

        return parts.joinToString(" > ")
    }

    /**
     * Extracts the nested `reason` throwable from EU library error types.
     */
    private fun extractReasonFromError(error: CredentialOfferRequestError): Throwable? = when (error) {
        is CredentialOfferRequestError.UnableToResolveCredentialIssuerMetadata -> error.reason
        is CredentialOfferRequestError.UnableToResolveAuthorizationServerMetadata -> error.reason
        is CredentialOfferRequestError.UnableToFetchCredentialOffer -> error.reason
        is CredentialOfferRequestError.NonParsableCredentialOfferEndpointUrl -> error.reason
        is CredentialOfferRequestError.NonParseableCredentialOffer -> error.reason
        is CredentialOfferRequestValidationError.InvalidCredentialOfferUri -> error.reason
        is CredentialOfferRequestValidationError.InvalidCredentialIssuerId -> error.reason
        is CredentialOfferRequestValidationError.InvalidCredentials -> error.reason
        is CredentialOfferRequestValidationError.InvalidGrants -> error.reason
        is CredentialOfferRequestValidationError.OneOfCredentialOfferOrCredentialOfferUri -> null
    }

    private fun mapResolverError(error: Throwable): OID4VCIException {
        val description = extractDescription(error)

        return when {
            hasCauseOfType<CredentialIssuerMetadataValidationError>(error) ->
                OID4VCIException.RetrievingIssuerMetadata(
                    "metadata_error",
                    description,
                    error
                )

            description.contains("metadata", ignoreCase = true) ->
                OID4VCIException.RetrievingIssuerMetadata(
                    "metadata_error",
                    description,
                    error
                )

            description.contains("offer", ignoreCase = true) ->
                OID4VCIException.RetrievingCredentialOffer(
                    "offer_error",
                    description,
                    error
                )

            else -> OID4VCIException.RetrievingCredentialOffer(
                "resolution_error",
                description,
                error
            )
        }
    }

    /**
     * Checks whether any throwable in the error chain is of the given type,
     * including EU library errors nested in [CredentialOfferRequestException.error].
     */
    private inline fun <reified T : Throwable> hasCauseOfType(error: Throwable): Boolean {
        val visited = mutableSetOf<Int>()
        var current: Throwable? = error
        while (current != null && visited.add(System.identityHashCode(current))) {
            if (current is T) return true
            if (current is CredentialOfferRequestException) {
                current = extractReasonFromError(current.error)
                continue
            }
            current = current.cause
        }
        return false
    }

    private fun mapAuthorizationError(error: Throwable): OID4VCIException {
        val description = extractDescription(error)

        return when {
            description.contains("token", ignoreCase = true) ->
                OID4VCIException.CreatingAccessToken(
                    "token_error",
                    description,
                    cause = error,
                )

            else ->
                OID4VCIException.CreatingAccessToken(
                    "authorization_error",
                    description,
                    cause = error,
                )
        }
    }
}

/**
 * Factory function implementation for Android platform.
 */
actual fun createOID4VCIClient(
    keyPairFactory: KeyPairFactory,
    networkClient: NetworkClient
): OID4VCIClient = AndroidOID4VCIClient(keyPairFactory, networkClient)
