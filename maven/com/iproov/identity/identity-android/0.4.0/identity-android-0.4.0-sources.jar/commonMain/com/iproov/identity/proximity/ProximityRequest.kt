package com.iproov.identity.proximity

/**
 *
 * A parsed `DeviceRequest` from the mdoc reader, ready for consent UI.
 *
 * The orchestrator constructs one of these and emits it via
 * [ProximityPresentationEvent.RequestReceived] after decrypting and parsing the reader's
 * `DeviceRequest` CBOR. Inspect [docRequests] to see what was asked for; inspect
 * [readerAuth] to see whether the reader authenticated itself; then call
 * `ProximitySession.respond` with the user's consent.
 *
 * @property docRequests one entry per document the reader is asking for
 * @property readerAuth verification result for the reader's COSE_Sign1, or null
 *   if reader auth was absent and [ProximityConfig.readerTrust] is not
 *   [ReaderTrustPolicy.AlwaysRequire]
 * @property sessionTranscript the CBOR-encoded SessionTranscript bytes; used by
 *   the orchestrator when building the DeviceResponse's DeviceAuthentication
 *   structure (§9.1.3.4). Internal — consumers don't need it.
 */

/**
 * To decline, call session.close() instead of respond(). - To Be Documented
 */
class RespondableProximityRequest internal constructor(
    val docRequests: List<DocRequest>,
    val matchHandler: suspend () -> Map<DocRequest, List<DisclosedDocument>>,
    val readerAuth: ReaderAuth,
    private val responseHandler: suspend (Map<DocRequest, DisclosedDocument>) -> ProximityResponseOutcome,
) {
    /**
     * Send the user's consent back to the running [ProximityPresentationSession].
     * Suspends until the SDK has built, signed, encrypted and sent the DeviceResponse
     * (or failed trying). The corresponding [ProximityPresentationEvent.PresentationSent]
     * or [ProximityPresentationEvent.Failure] also flows on the session's events
     * channel — call sites may use either signal.
     */
    suspend fun respond(disclosed: Map<DocRequest, DisclosedDocument>): ProximityResponseOutcome =
        responseHandler(disclosed)

    suspend fun match(): Map<DocRequest, List<DisclosedDocument>> = matchHandler()

    override fun toString(): String {
        val builder = StringBuilder()

        builder.append("RespondableProximityRequest(")
        builder.append("readerAuth=").append(readerAuth)
        builder.append(", requested documents:")
        for (request in docRequests) {
            builder.append("\n  ").append(request.docType)
            for ((namespace, items) in request.requestedItems) {
                builder.append("\n    ").append(namespace).append(':')
                for (item in items) {
                    builder.append("\n      ").append(item.elementIdentifier)
                    if (item.intentToRetain) builder.append(" (intent to retain)")
                }
            }
        }
        builder.append("\n)")
        return builder.toString()
    }
}

/**
 * A single document the reader requested.
 *
 * @property docType the document type (e.g. "org.iso.18013.5.1.mDL")
 * @property requestedItems namespace → list of requested elements within that namespace
 */
data class DocRequest(
    val docType: String,
    val requestedItems: Map<String, List<RequestedItem>>,
)

/**
 * A single data element the reader is asking for.
 *
 * @property elementIdentifier the data element identifier within its namespace
 *   (e.g. "family_name", "age_over_18")
 * @property intentToRetain the reader's signalled intent to retain this element
 *   after the transaction. Informational; consumers may surface it in consent UI.
 */
data class RequestedItem(
    val elementIdentifier: String,
    val intentToRetain: Boolean,
)

sealed interface ReaderAuth {
    data object Absent : ReaderAuth
    data object SignatureInvalid : ReaderAuth
    data class Untrusted(val commonName: String?) : ReaderAuth   // verified, chain not trusted by policy
    data class Trusted(val commonName: String) : ReaderAuth
}

internal fun List<ReaderAuth>.aggregate(): ReaderAuth {
    val present = filterNot { it == ReaderAuth.Absent }
    if (present.isEmpty()) return ReaderAuth.Absent
    present.firstOrNull { it is ReaderAuth.SignatureInvalid }?.let { return it }
    present.firstOrNull { it is ReaderAuth.Untrusted }?.let { return it }

    return present.first() // all present are Trusted
}