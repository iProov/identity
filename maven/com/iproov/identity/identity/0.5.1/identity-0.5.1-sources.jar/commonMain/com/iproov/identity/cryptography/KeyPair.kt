package com.iproov.identity.cryptography

import at.asitplus.signum.indispensable.asn1.Asn1Element
import at.asitplus.signum.indispensable.asn1.encoding.parseFirst
import com.iproov.identity.Base64Utils.base64UrlDecode
import com.iproov.identity.Logger
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient

enum class AuthenticationAvailability {
    Available,
    DeviceNotSecure,
    BiometricsNotEnrolled,
    BiometricsNotSupported
}

const val DEFAULT_AUTH_VALIDITY_DURATION_SECONDS = 1 * 60 // 1 Minutes
internal const val CUSTOMER_KEY_SECURITY_LEVEL = "SECURITY_LEVEL_CUSTOMER"

data class AuthenticationDisplayProperties(
    val title: String = "Authentication Required",
    val subtitle: String? = "Please authenticate to access your storage",
    val description: String? = null,
    val negativeButtonText: String? = null,
    val confirmationRequired: Boolean = false,
)

expect abstract class KeyPairAccessPolicy {
    companion object {
        val DeviceUnlocked: KeyPairAccessPolicy
    }
}

@Serializable
data class OnDeviceKeyPairJwk(
    val crv: String,
    val kty: String,
    val x: String,
    val y: String,
    @Transient
    val keyId: String? = null
)

@Serializable
data class EllipticCurvePublicKey(
    val alg: String,
    val jwk: OnDeviceKeyPairJwk,
)

/** Base exception for failures raised by an externally supplied cryptographic key. */
open class CryptographyException(message: String) : Exception(message)

/** Raised when a signing key cannot satisfy the cryptographic contract required by the SDK. */
class InvalidSigningKeyException(val reason: String) :
    CryptographyException("Signing key is incompatible with the SDK: $reason")

open class KeyPairException(message: String) : CryptographyException(message)

class KeyPairAuthenticationError(message: String) : KeyPairException(message)

class KeyPairAuthenticationCanceled : KeyPairException("User canceled the authentication")

/**
 * A cryptographic key whose persisted key material can be deleted.
 *
 * Wallet teardown resets SDK-created signing keys only. A caller-supplied signing key remains
 * caller-managed. A caller-supplied storage [EncryptionKey] is reset by device-bound storage only
 * when it also implements this capability.
 */
interface ResettableKey {
    @Throws(Throwable::class)
    fun reset()
}

/**
 * Evidence used to create an OID4VCI key-attestation JWT.
 *
 * [certificateChainDer] contains exactly the certificates to put in the JWT `x5c` header, ordered
 * leaf-first and without the self-signed trust anchor. [keyStorageLevel] and
 * [userAuthenticationLevel] must each be one of `iso_18045_high`, `iso_18045_moderate`,
 * `iso_18045_enhanced-basic`, or `iso_18045_basic`. The certificate list and each certificate
 * must be non-empty.
 */
data class KeyAttestationEvidence(
    val certificateChainDer: List<ByteArray>,
    val keyStorageLevel: String,
    val userAuthenticationLevel: String,
)

/** Implemented by key pairs that can prove hardware backing to an issuer (OID4VCI key attestation). */
interface AttestableKeyPair : KeyPair {
    /**
     * Returns the evidence for this key, or `null` when evidence is currently unavailable.
     *
     * Unavailability is represented by `null` rather than an exception. This keeps the capability
     * implementable from Swift, where an Objective-C protocol requirement cannot be both throwing
     * and nullable without making `nil` ambiguous with an error result.
     */
    fun getKeyAttestationEvidence(): KeyAttestationEvidence?
}

/**
 * The signing-key contract used throughout wallet registration, challenge signing, OID4VCI,
 * OID4VP, and DC API presentation.
 *
 * The key must be an ES256 P-256 key. Factory results are validated before use. Methods are
 * synchronous and must operate on the same underlying key across repeated factory calls.
 */
interface KeyPair : ResettableKey {
    /** Returns an ES256 JWK with EC/P-256 fields and 32-byte Base64URL `x` and `y` coordinates. */
    @Throws(Throwable::class)
    fun getJwk(): EllipticCurvePublicKey

    /** Returns the same P-256 public key as DER-encoded X.509 SubjectPublicKeyInfo. */
    @Throws(Throwable::class)
    fun getPublicKey(): ByteArray

    /**
     * Returns the key classification sent during wallet registration.
     *
     * Caller-supplied keys are always reported as `SECURITY_LEVEL_CUSTOMER`. SDK-managed keys
     * override this with their platform-derived security level.
     */
    @Throws(Throwable::class)
    fun getKeySecurityLevel(): String = CUSTOMER_KEY_SECURITY_LEVEL

    /** Signs [data] using ECDSA with SHA-256 and returns an ASN.1/DER ECDSA signature. */
    @Throws(Throwable::class)
    fun sign(data: ByteArray): ByteArray

}

/** Marker for a signing-key handle whose lifecycle is owned by [com.iproov.identity.Wallet]. */
internal interface SdkManagedKey
internal interface CustomerManagedKey

private class SdkManagedKeyPair(
    private val delegate: KeyPair,
) : KeyPair by delegate, SdkManagedKey

private class SdkManagedAttestableKeyPair(
    private val delegate: AttestableKeyPair,
) : AttestableKeyPair by delegate, SdkManagedKey

private class CustomerManagedKeyPair(
    private val delegate: KeyPair,
) : KeyPair by delegate, CustomerManagedKey {
    override fun getKeySecurityLevel(): String = CUSTOMER_KEY_SECURITY_LEVEL
}

private class CustomerManagedAttestableKeyPair(
    private val delegate: AttestableKeyPair,
) : AttestableKeyPair by delegate, CustomerManagedKey {
    override fun getKeySecurityLevel(): String = CUSTOMER_KEY_SECURITY_LEVEL
}

/** Marks only the key produced by the SDK's default wallet factory as SDK-managed. */
internal fun KeyPair.asSdkManaged(): KeyPair = when (this) {
    is AttestableKeyPair -> SdkManagedAttestableKeyPair(this)
    else -> SdkManagedKeyPair(this)
}

/** Enforces the backend classification for caller-supplied signing keys. */
internal fun KeyPair.asCustomerManaged(): KeyPair = when {
    this is SdkManagedKey -> this
    this is CustomerManagedKey -> this
    this is AttestableKeyPair -> CustomerManagedAttestableKeyPair(this)
    else -> CustomerManagedKeyPair(this)
}

/**
 * Validates the public-key shape relied on by every SDK signing path.
 *
 * ES256 always means ECDSA over P-256. Each affine coordinate must therefore decode to exactly
 * 32 bytes. Validation happens whenever the configured key factory supplies a key, before that
 * key is passed to wallet registration, OID4VCI, OID4VP, or DC API code.
 */
internal fun validateSigningKey(keyPair: KeyPair) {
    val publicKey = keyPair.getJwk()

    if (publicKey.alg != "ES256") {
        throw InvalidSigningKeyException(
            "JWK field 'alg' must be 'ES256'; received '${publicKey.alg}'."
        )
    }
    if (publicKey.jwk.kty != "EC") {
        throw InvalidSigningKeyException(
            "JWK field 'kty' must be 'EC'; received '${publicKey.jwk.kty}'."
        )
    }
    if (publicKey.jwk.crv != "P-256") {
        throw InvalidSigningKeyException(
            "JWK field 'crv' must be 'P-256'; received '${publicKey.jwk.crv}'."
        )
    }

    validateP256Coordinate("x", publicKey.jwk.x)
    validateP256Coordinate("y", publicKey.jwk.y)
}

private fun validateP256Coordinate(name: String, encoded: String) {
    val decoded = try {
        encoded.base64UrlDecode()
    } catch (_: IllegalArgumentException) {
        throw InvalidSigningKeyException(
            "JWK field '$name' must be valid Base64URL containing a 32-byte P-256 coordinate."
        )
    }

    if (decoded.size != 32) {
        val unit = if (decoded.size == 1) "byte" else "bytes"
        throw InvalidSigningKeyException(
            "JWK field '$name' must decode to exactly 32 bytes for P-256; decoded to ${decoded.size} $unit."
        )
    }
}

@Throws(Throwable::class)
fun KeyPair.signRs(data: ByteArray): ByteArray {
    Logger.debug("[KeyPair.signRs] Signing payload")
    val signed = sign(data)
    Logger.debug("[KeyPair.signRs] Payload signed")
    val ans1 = asn1ToRs(signed)
    Logger.debug("[KeyPair.signRs] Converted signed payload to ASN1")
    return ans1
}

fun asn1ToRs(signature: ByteArray): ByteArray {

    val parsed = Asn1Element.parseFirst(signature)
    val sequence = parsed.first.asSequence()
    val r = sequence.children[0].asPrimitive().content
    val s = sequence.children[1].asPrimitive().content

    val rBytes = padTo32Bytes(r)
    val sBytes = padTo32Bytes(s)

    return rBytes + sBytes
}

private fun padTo32Bytes(input: ByteArray): ByteArray {
    return if (input.size >= 32) {
        input.takeLast(32).toByteArray()
    } else {
        ByteArray(32 - input.size) + input
    }
}

/**
 * Function for getting the default key pair that's used for signing, this is bound to the device.
 */
expect fun getDeviceBoundKeyPair(policy: KeyPairAccessPolicy, alias: String): KeyPair
