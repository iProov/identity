package com.iproov.identity

import com.iproov.identity.persistence.DeviceBoundAppleStorageEngine
import com.iproov.identity.persistence.StorageEngine

// These are functions for the apple platform. The appGroupIdentifier overloads build the SDK storage
// engine without Digital Credentials API sharing; to enable it, construct DeviceBoundAppleStorageEngine
// with a keychainAccessGroup and pass it as storageEngine.

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    appGroupIdentifier: String,
) = getInstance(
    baseUrl = baseUrl,
    storageEngine = DeviceBoundAppleStorageEngine(appGroupIdentifier),
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    appGroupIdentifier: String,
    isLoggingEnabled: Boolean = false,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = DeviceBoundAppleStorageEngine(appGroupIdentifier),
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
    signingKeyPairFactory = signingKeyPairFactory,
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration,
    appGroupIdentifier: String,
) = getInstance(
    baseUrl = baseUrl,
    clientConfiguration = clientConfiguration,
    storageEngine = DeviceBoundAppleStorageEngine(appGroupIdentifier),
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration,
    appGroupIdentifier: String,
    isLoggingEnabled: Boolean = false,
) = getInstance(
    baseUrl = baseUrl,
    clientConfiguration = clientConfiguration,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = DeviceBoundAppleStorageEngine(appGroupIdentifier),
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
) = getInstance(
    baseUrl = baseUrl,
    clientConfiguration = clientConfiguration,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
) = getInstance(
    baseUrl = baseUrl,
    clientConfiguration = clientConfiguration,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
    signingKeyPairFactory = signingKeyPairFactory,
)

// The same variants with a TrustConfiguration, since Kotlin default arguments don't reach Swift.

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    appGroupIdentifier: String,
    isLoggingEnabled: Boolean = false,
    trustConfiguration: TrustConfiguration,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = DeviceBoundAppleStorageEngine(appGroupIdentifier),
    trustConfiguration = trustConfiguration,
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    trustConfiguration: TrustConfiguration,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
    trustConfiguration = trustConfiguration,
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
    trustConfiguration: TrustConfiguration,
) = getInstance(
    baseUrl = baseUrl,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
    signingKeyPairFactory = signingKeyPairFactory,
    trustConfiguration = trustConfiguration,
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration,
    appGroupIdentifier: String,
    isLoggingEnabled: Boolean = false,
    trustConfiguration: TrustConfiguration,
) = getInstance(
    baseUrl = baseUrl,
    clientConfiguration = clientConfiguration,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = DeviceBoundAppleStorageEngine(appGroupIdentifier),
    trustConfiguration = trustConfiguration,
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    trustConfiguration: TrustConfiguration,
) = getInstance(
    baseUrl = baseUrl,
    clientConfiguration = clientConfiguration,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
    trustConfiguration = trustConfiguration,
)

@Throws(Exception::class)
fun WalletFactory.getInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
    trustConfiguration: TrustConfiguration,
) = getInstance(
    baseUrl = baseUrl,
    clientConfiguration = clientConfiguration,
    isLoggingEnabled = isLoggingEnabled,
    storageEngine = storageEngine,
    signingKeyPairFactory = signingKeyPairFactory,
    trustConfiguration = trustConfiguration,
)
