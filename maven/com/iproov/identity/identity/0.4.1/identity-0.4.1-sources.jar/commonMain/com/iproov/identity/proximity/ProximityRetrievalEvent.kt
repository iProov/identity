package com.iproov.identity.proximity

/**
 * Lifecycle events emitted by a [ProximityRetrievalSession] (ISO 18013-5 §6 + §8).
 * Collect until [isFinal] is true; terminal states are [Completed] and [Error].
 */
sealed class ProximityRetrievalEvent(val isFinal: Boolean) {
    sealed class Engagement : ProximityRetrievalEvent(false) {

        /** Decoding a QR-delivered `mdoc:<base64url-DeviceEngagement>` URI */
        sealed class Qr : Engagement() {
            data object Decoding : Qr()
        }

        /** Reading an NFC NDEF Type 4 tag from the holder */
        sealed class Nfc : Engagement() {
            /** iOS CoreNFC dialog visible / Android polling for tag — user hasn't tapped yet. */
            data object RequestingTag : Nfc()

            /** Tag in field; NDEF reading + handover APDU exchange in progress. */
            data object ReadingTag : Nfc()

            /** Have a parsed DeviceEngagement; about to open the retrieval transport. */
            data object Completed : Nfc()
        }
    }

    data object Connecting : ProximityRetrievalEvent(false)
    data object SendingRequest : ProximityRetrievalEvent(false)
    data object WaitingForResponse : ProximityRetrievalEvent(false)
    data object ProcessingResponse : ProximityRetrievalEvent(false)
    data class Completed(val response: ProximityRetrievalResponse) : ProximityRetrievalEvent(true)

    data class Error(val message: String, val cause: Throwable? = null) :
        ProximityRetrievalEvent(true)
}
