package com.iproov.identity.persistence

import com.iproov.identity.Base64Utils.decodeFromBase64Url
import com.iproov.identity.Base64Utils.matchesBase64Url
import com.iproov.identity.CLOCK_SKEW_SECONDS
import com.iproov.identity.HexUtils.matchesHex
import com.iproov.identity.Logger
import com.iproov.identity.TrustConfiguration
import com.iproov.identity.api.StatusListVerifier
import com.iproov.identity.models.CredentialStatus
import com.iproov.identity.models.CredentialStatusException
import com.iproov.identity.models.VerificationResult
import com.iproov.identity.models.VerificationStatus
import com.iproov.identity.models.VerificationSummary
import com.iproov.identity.proximity.CertTrust
import com.iproov.identity.proximity.IssuerTrustPolicy
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.io.bytestring.ByteString
import org.multipaz.cbor.Bstr
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.CborMap
import org.multipaz.cbor.DataItem
import org.multipaz.cbor.Tstr
import org.multipaz.cbor.Uint
import org.multipaz.cose.Cose
import org.multipaz.cose.CoseNumberLabel
import org.multipaz.cose.CoseSign1
import org.multipaz.crypto.Algorithm
import org.multipaz.crypto.Crypto
import org.multipaz.crypto.X509Cert
import org.multipaz.mdoc.mso.MobileSecurityObject
import org.multipaz.revocation.RevocationStatus
import kotlin.time.Duration.Companion.seconds
import kotlin.time.Instant

/**
 * A stored mdoc's IssuerSigned structure (ISO 18013-5 §8.3.2.1.2.2), parsed once. Token Status List
 * §8.3 requires the credential itself to be validated before its status is evaluated, and its status
 * list not to be fetched when that fails, so [verificationSummary] and [resolveStatus] both run
 * [validate] first.
 *
 * [nameSpaces] is null for an mdoc the proximity reader received ([received]). The reader has already
 * authenticated it, and holds its namespaces only as multipaz re-encoded them, which needn't match their
 * digests, so [validate] then checks only the validity period.
 */
internal class IssuerSignedMdoc private constructor(
    val nameSpaces: DataItem?,
    val mso: MobileSecurityObject,
    private val issuerAuth: CoseSign1,
    private val revocationStatus: RevocationStatus?,
) {
    /** The `x5chain` from issuerAuth, unprotected first (ISO 18013-5 §9.1.2.4), or null when absent or malformed. */
    private val issuerCertificates: List<X509Cert>? by lazy {
        val label = CoseNumberLabel(Cose.COSE_LABEL_X5CHAIN)
        try {
            (issuerAuth.unprotectedHeaders[label] ?: issuerAuth.protectedHeaders[label])
                ?.asX509CertChain?.certificates?.takeIf { it.isNotEmpty() }
        } catch (e: Exception) {
            Logger.error("mdoc ${mso.docType}: issuer certificate chain could not be parsed: $e")
            null
        }
    }

    /** The checks this mdoc fails: its signature and digests, its issuer under [issuerTrust], and its validity period. */
    suspend fun validate(issuerTrust: IssuerTrustPolicy, now: Instant): List<VerificationResult> = buildList {
        if (nameSpaces != null) authenticate(issuerTrust, now)?.let(::add)
        val skew = CLOCK_SKEW_SECONDS.seconds
        if (now - skew > mso.validUntil) add(VerificationResult(EXPIRY, VerificationStatus.EXPIRED, "Credential has expired"))
        if (now + skew < mso.validFrom) {
            add(VerificationResult(VALID_FROM, VerificationStatus.NOT_YET_VALID, "Credential is not yet valid"))
        }
    }.onEach { Logger.error("mdoc ${mso.docType}: ${it.check} ${it.status} - ${it.reason}") }

    suspend fun verificationSummary(
        trust: TrustConfiguration,
        verifier: StatusListVerifier,
        now: Instant,
    ): VerificationSummary {
        val issuerTrust = trust.issuerTrustFor(mso.docType)
        val failures = validate(issuerTrust, now)
        // Under TrustAll nothing ties the mdoc to a real issuer, so the summary must not conclude VALID.
        val trustNotConfigured = if (issuerTrust is IssuerTrustPolicy.TrustAll) {
            listOf(VerificationResult(ISSUER_TRUST, VerificationStatus.INDETERMINATE, "Issuer trust is not configured"))
        } else {
            emptyList()
        }
        val status = revocationStatus
        if (failures.isNotEmpty() || status == null) {
            if (status == null) Logger.debug("[StatusList] ${mso.docType}: MSO has no status reference")
            return VerificationSummary(failures + trustNotConfigured)
        }
        val statusResult = try {
            StatusListVerifier.result(checkStatus(status, trust, verifier, now), (status as? RevocationStatus.StatusList)?.uri.orEmpty())
        } catch (e: CredentialStatusException) {
            StatusListVerifier.result(e)
        }
        return VerificationSummary(trustNotConfigured + statusResult)
    }

    suspend fun resolveStatus(trust: TrustConfiguration, verifier: StatusListVerifier, now: Instant): CredentialStatus {
        validate(trust.issuerTrustFor(mso.docType), now).firstOrNull()?.let {
            throw CredentialStatusException.InvalidCredential(it.status, it.reason.orEmpty(), it.check)
        }
        val status = revocationStatus ?: run {
            Logger.debug("[StatusList] ${mso.docType}: MSO has no status reference")
            throw CredentialStatusException.NoStatusReference()
        }
        return checkStatus(status, trust, verifier, now)
    }

    private suspend fun checkStatus(
        status: RevocationStatus,
        trust: TrustConfiguration,
        verifier: StatusListVerifier,
        now: Instant,
    ): CredentialStatus = verifier.status(status, statusListSigner(status, trust, now), trust.jwksStatusListHosts, mso.docType)

    /**
     * The certificate that must sign the status list (Token Status List §11.3): the one the MSO names,
     * once it is inside its validity period and, under trusted certificates, issued by a trusted IACA;
     * otherwise the Document Signer. Not needed for a host opted in to JWKS lookup.
     */
    private suspend fun statusListSigner(status: RevocationStatus, trust: TrustConfiguration, now: Instant): X509Cert? {
        val documentSigner = issuerCertificates?.first()
        val statusList = status as? RevocationStatus.StatusList ?: return documentSigner
        val named = statusList.certificate ?: return documentSigner
        if (StatusListVerifier.usesJwks(statusList.uri, trust.jwksStatusListHosts)) return documentSigner
        val skew = CLOCK_SKEW_SECONDS.seconds
        val issuerTrust = trust.issuerTrustFor(mso.docType)
        // multipaz parses the certificate lazily, so a malformed one first fails here.
        val rejection = try {
            when {
                now + skew < named.validityNotBefore || now - skew > named.validityNotAfter ->
                    "is outside its validity (${named.validityNotBefore} - ${named.validityNotAfter})"
                issuerTrust is IssuerTrustPolicy.TrustedCertificates && !CertTrust.isIssuedByAny(named, issuerTrust.certificates) ->
                    "is not issued by a trusted IACA"
                else -> null
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            "could not be parsed: $e"
        }
        if (rejection != null) {
            Logger.error("[StatusList] ${mso.docType}: status list certificate named by the MSO $rejection")
            throw StatusListVerifier.signerRejected(statusList.uri)
        }
        return named
    }

    /** ISO 18013-5 §9.3.1: the MSO signature, the element digests and, under trusted certificates, the IACA chain. */
    suspend fun authenticate(issuerTrust: IssuerTrustPolicy, now: Instant): VerificationResult? {
        val chain = issuerCertificates ?: return VerificationResult(
            ISSUER_SIGNATURE,
            VerificationStatus.MALFORMED,
            "Credential issuer certificate is missing or malformed",
        )
        val context = "Document ${mso.docType}"
        try {
            val algorithm = Algorithm.fromCoseAlgorithmIdentifier(
                issuerAuth.protectedHeaders[CoseNumberLabel(Cose.COSE_LABEL_ALG)]!!.asNumber.toInt()
            )
            Cose.coseSign1Check(chain.first().ecPublicKey, null, issuerAuth, algorithm)
            verifyDigests()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            Logger.error("mdoc ${mso.docType}: issuer signature check failed: $e")
            return VerificationResult(ISSUER_SIGNATURE, VerificationStatus.SIGNATURE_INVALID, "Credential signature is invalid")
        }
        try {
            CertTrust.verifySignedAtWithinValidity(chain.first(), mso.signedAt, context)
        } catch (e: Exception) {
            Logger.error("mdoc ${mso.docType}: ${e.message}")
            return VerificationResult(
                ISSUER_SIGNATURE,
                VerificationStatus.SIGNATURE_INVALID,
                "Credential was signed outside its issuer certificate's validity",
            )
        }
        if (issuerTrust is IssuerTrustPolicy.TrustedCertificates) {
            try {
                CertTrust.verifyIssuerTrust(chain, mso.signedAt, issuerTrust, context, now)
            } catch (e: CancellationException) {
                throw e
            } catch (e: CertTrust.CertificateValidityException) {
                Logger.error("mdoc ${mso.docType}: issuer trust check failed: ${e.message}")
                return VerificationResult(
                    ISSUER_TRUST,
                    VerificationStatus.ISSUER_UNTRUSTED,
                    "Credential issuer certificate is outside its validity period",
                )
            } catch (e: Exception) {
                currentCoroutineContext().ensureActive()
                Logger.error("mdoc ${mso.docType}: issuer trust check failed: ${e.message}")
                return VerificationResult(ISSUER_TRUST, VerificationStatus.ISSUER_UNTRUSTED, "Credential issuer is not trusted")
            }
        }
        return null
    }

    /** ISO 18013-5 §9.1.2.5: each element's digest is taken over its encoded IssuerSignedItemBytes as issued. */
    private suspend fun verifyDigests() {
        for ((namespaceItem, items) in checkNotNull(nameSpaces) { "no namespaces to verify" }.asMap) {
            val namespace = namespaceItem.asTstr
            val digests = mso.valueDigests[namespace] ?: error("no digests for namespace $namespace")
            for (item in items.asArray) {
                val digestId = item.asTaggedEncodedCbor["digestID"].asNumber
                val expected = digests[digestId] ?: error("no digest $digestId in namespace $namespace")
                check(ByteString(Crypto.digest(mso.digestAlgorithm, Cbor.encode(item))) == expected) {
                    "digest mismatch for digestID $digestId in namespace $namespace"
                }
            }
        }
    }

    companion object {
        private const val ISSUER_SIGNATURE = "issuer_signature"
        private const val ISSUER_TRUST = "issuer_trust"
        private const val EXPIRY = "expiry"
        private const val VALID_FROM = "valid_from"

        /** Parses a raw (hex or base64url) IssuerSigned structure; throws when it is malformed. */
        fun parse(raw: String): IssuerSignedMdoc {
            val isHex = raw.matchesHex()
            require(isHex || raw.matchesBase64Url()) { "Credential data is neither hex nor base64url encoded" }
            val issuerSigned = Cbor.decode(if (isHex) raw.hexToByteArray() else raw.decodeFromBase64Url()).asMap

            val nameSpaces = issuerSigned.getByKey("nameSpaces") ?: error("IssuerSigned missing 'nameSpaces' field")
            val issuerAuth = CoseSign1.fromDataItem(
                issuerSigned.getByKey("issuerAuth") ?: error("IssuerSigned missing 'issuerAuth' field")
            )
            // issuerAuth's payload is Tag 24 wrapping the encoded MSO
            val msoDataItem = Cbor.decode(issuerAuth.payload ?: error("IssuerAuth COSE_Sign1 has no payload"))
                .asTaggedEncodedCbor
            return IssuerSignedMdoc(
                nameSpaces = nameSpaces,
                mso = MobileSecurityObject.fromDataItem(msoDataItem),
                issuerAuth = issuerAuth,
                revocationStatus = msoDataItem.revocationStatus(),
            )
        }

        /**
         * An mdoc the proximity reader received and has authenticated: its MSO signature and digests in
         * multipaz's `DeviceResponse.verify`, its issuer in `verifyReceivedIssuer`.
         */
        fun received(issuerAuth: CoseSign1): IssuerSignedMdoc {
            // Decoded as multipaz's verify decoded it, which accepts any tag, so this can't fail.
            val msoDataItem = Cbor.decode(Cbor.decode(issuerAuth.payload!!).asTagged.asBstr)
            return IssuerSignedMdoc(
                nameSpaces = null,
                mso = MobileSecurityObject.fromDataItem(msoDataItem),
                issuerAuth = issuerAuth,
                revocationStatus = msoDataItem.revocationStatus(),
            )
        }

        /** [parse] for a status check, where a credential that can't be parsed is an invalid credential. */
        fun parseForStatus(raw: String): IssuerSignedMdoc = try {
            parse(raw)
        } catch (e: Exception) {
            Logger.error("mdoc could not be parsed for a status check: $e")
            throw CredentialStatusException.InvalidCredential(
                VerificationStatus.MALFORMED,
                "Credential could not be parsed",
                ISSUER_SIGNATURE,
            )
        }

        /**
         * The MSO `status`, or null when it has none. A status multipaz cannot parse is kept as
         * [RevocationStatus.UnknownCbor]: its MSO parser drops it, which would read as having no status.
         * So is an `idx` beyond `Int`, which multipaz would truncate to another credential's entry, and a
         * `certificate` that isn't a bstr, which multipaz would drop in favour of the Document Signer.
         */
        private fun DataItem.revocationStatus(): RevocationStatus? {
            if (!hasKey("status")) return null
            val status = this["status"]
            val statusList = (status as? CborMap)?.items?.get(Tstr("status_list")) as? CborMap
            val idx = statusList?.items?.get(Tstr("idx"))
            val certificate = statusList?.items?.get(Tstr("certificate"))
            if (idx is Uint && idx.value > Int.MAX_VALUE.toULong() || certificate != null && certificate !is Bstr) {
                return RevocationStatus.UnknownCbor(status)
            }
            return try {
                RevocationStatus.fromDataItem(status)
            } catch (e: Exception) {
                RevocationStatus.UnknownCbor(status)
            }
        }

        /** Helper to find a value in a CBOR map by its text string key */
        private fun Map<DataItem, DataItem>.getByKey(key: String): DataItem? =
            entries.find { (k, _) -> k.asTstr == key }?.value
    }
}
