package com.iproov.identity

import com.iproov.identity.proximity.IssuerTrustPolicy
import com.iproov.identity.proximity.ReaderTrustPolicy
import kotlinx.io.bytestring.ByteString
import org.multipaz.crypto.X509Cert

/**
 * Which credential issuers the wallet trusts, applied wherever it validates an mdoc: when one is
 * issued, when its status is checked, and when one is received over proximity. Set once per wallet;
 * summaries of stored credentials use the most recently created wallet's configuration.
 *
 * [issuerTrust] is the policy for every credential type. [issuerTrustByType] gives a credential type,
 * an mdoc `docType`, its own policy instead, for example the IACA roots of a photo ID issuer. An entry
 * replaces [issuerTrust] for that type, so a credential matched by it is never checked against
 * [issuerTrust], and a credential of any other type is never checked against it.
 *
 * With [IssuerTrustPolicy.TrustedCertificates], an mdoc whose Document Signer does not chain to one of
 * its roots is refused at issuance, reported as `ISSUER_UNTRUSTED`, and its status is never fetched.
 * [IssuerTrustPolicy.TrustAll] skips that check and is for development only: an mdoc's own signature
 * is still verified, but its summary never concludes `VALID`.
 *
 * A Token Status List is trusted when it is signed by the certificate the mdoc's MSO names for it, or
 * else by the mdoc's Document Signer. [jwksStatusListHosts] opts in hosts, by name and on any port,
 * whose lists are instead signed by a key published, by `kid`, in `/.well-known/jwks.json` on the same
 * host. That lookup is an ecosystem convention rather than part of the Token Status List
 * specification, and it trusts the key on the strength of TLS to that host alone.
 *
 * [readerTrust] says which mdoc readers the holder presents to: over proximity on both platforms, and
 * through the Digital Credentials API on iOS (ISO/IEC 18013-7 Annex C), where the extension builds its
 * own wallet and so needs the same configuration as the app. The Android Digital Credentials API is
 * not covered: its signed OpenID4VP requests keep the per-call `trustedVerifierCertificates` of
 * [Wallet.processDCApiRequest], and an Android `org.iso.mdoc` request carries no reader authentication
 * check at all. See [ReaderTrustPolicy].
 *
 * Throws when an [issuerTrustByType] key is blank or has surrounding spaces, a trusted issuer or reader
 * certificate isn't a DER X.509 certificate with an EC key, [readerTrust] is an
 * [ReaderTrustPolicy.AlwaysRequire] with no certificates, a `documentSignerKeyUsage` isn't a dotted OID,
 * or a [jwksStatusListHosts] entry is not a bare host name.
 */
class TrustConfiguration @Throws(Exception::class) constructor(
    val issuerTrust: IssuerTrustPolicy = IssuerTrustPolicy.TrustAll,
    issuerTrustByType: Map<String, IssuerTrustPolicy> = emptyMap(),
    jwksStatusListHosts: Set<String> = emptySet(),
    val readerTrust: ReaderTrustPolicy = ReaderTrustPolicy.EnforceIfPresent(),
) {
    constructor() : this(IssuerTrustPolicy.TrustAll, emptyMap(), emptySet(), ReaderTrustPolicy.EnforceIfPresent())

    /** The three-argument form Swift had before [readerTrust] existed; Kotlin default arguments don't reach Swift. */
    @Throws(Exception::class)
    constructor(
        issuerTrust: IssuerTrustPolicy,
        issuerTrustByType: Map<String, IssuerTrustPolicy>,
        jwksStatusListHosts: Set<String>,
    ) : this(issuerTrust, issuerTrustByType, jwksStatusListHosts, ReaderTrustPolicy.EnforceIfPresent())

    val issuerTrustByType: Map<String, IssuerTrustPolicy> = issuerTrustByType.toMap()

    val jwksStatusListHosts: Set<String> = jwksStatusListHosts.map { it.lowercase() }.toSet()

    init {
        this.issuerTrustByType.keys.forEach { type ->
            require(type.isNotBlank() && type == type.trim()) {
                "issuerTrustByType keys must be docTypes without surrounding spaces: '$type'"
            }
        }
        (this.issuerTrustByType.values + issuerTrust).filterIsInstance<IssuerTrustPolicy.TrustedCertificates>().forEach { policy ->
            policy.certificates.forEachIndexed { index, der -> requireDerCertificate(der, "Trusted certificate $index") }
            policy.documentSignerKeyUsage?.let { oid ->
                require(OID.matches(oid)) { "documentSignerKeyUsage must be a dotted OID such as 1.0.18013.5.1.2: '$oid'" }
            }
        }
        readerTrust.certificates.forEachIndexed { index, der -> requireDerCertificate(der, "Trusted reader certificate $index") }
        require(readerTrust !is ReaderTrustPolicy.AlwaysRequire || readerTrust.certificates.isNotEmpty()) {
            "readerTrust AlwaysRequire needs at least one reader CA root certificate; with none, no reader could ever be accepted"
        }
        this.jwksStatusListHosts.forEach { host ->
            require(host.isNotEmpty() && host.all { it.isLetterOrDigit() || it == '.' || it == '-' }) {
                "jwksStatusListHosts entries must be host names without a scheme, port or path: '$host'"
            }
        }
    }

    /** The policy for credentials of [type]: its [issuerTrustByType] entry, or else [issuerTrust]. */
    internal fun issuerTrustFor(type: String): IssuerTrustPolicy {
        val entry = issuerTrustByType[type]
        if (entry != null) {
            Logger.debug("[IssuerTrust] $type: using its issuerTrustByType entry")
        } else if (issuerTrustByType.isNotEmpty()) {
            Logger.debug("[IssuerTrust] $type: no issuerTrustByType entry, using the default issuerTrust")
        }
        return entry ?: issuerTrust
    }

    /** The credentials whose issuers aren't checked, for the development-only log; null when every rule checks. */
    internal val uncheckedIssuers: String?
        get() = listOfNotNull(
            "docTypes without an issuerTrustByType entry".takeIf { issuerTrust is IssuerTrustPolicy.TrustAll },
            issuerTrustByType.filterValues { it is IssuerTrustPolicy.TrustAll }.keys.takeIf { it.isNotEmpty() }?.joinToString(),
        ).joinToString(" and ").ifEmpty { null }

    private fun requireDerCertificate(der: ByteArray, what: String) {
        require(runCatching { X509Cert(ByteString(der)).ecPublicKey }.isSuccess) {
            "$what is not a DER X.509 certificate with an EC key. " +
                    "Convert a PEM file with: openssl x509 -in root.pem -outform DER -out root.der"
        }
    }

    private companion object {
        val OID = Regex("[0-9]+(\\.[0-9]+)+")
    }
}
