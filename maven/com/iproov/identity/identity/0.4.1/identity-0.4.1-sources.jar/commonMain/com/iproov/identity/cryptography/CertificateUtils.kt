package com.iproov.identity.cryptography


/**
 * Converts a DER-encoded ECDSA signature (SEQUENCE { INTEGER r, INTEGER s })
 * into the raw concatenated r||s format required by COSE.
 *
 * Handles definite-length DER encoding and pads/truncates r and s
 * to the specified size. Correctly handles the DER INTEGER format,
 * including potential leading zero bytes for positive numbers.
 *
 * @param der The byte array containing the DER-encoded signature.
 * @param sizeBytes The exact number of bytes expected for each of r and s (e.g., 32 for P-256/ES256).
 * @return A ByteArray containing r concatenated with s, each padded/truncated to sizeBytes.
 * @throws IllegalArgumentException if the input is not valid DER or integers are too large.
 */
fun derEcdsaToConcat(der: ByteArray, sizeBytes: Int): ByteArray {
    var i = 0 // Current parsing index

    // 1. Check for SEQUENCE tag (0x30)
    require(der.isNotEmpty() && der[i++] == 0x30.toByte()) {
        "DER signature must start with SEQUENCE tag (0x30)."
    }

    // 2. Read the *length* of the sequence, and advance the index
    //    by the *number of bytes* used to encode that length.
    val seqLen = readDerLength(der, i)
    val seqLenBytes = countDerLengthBytes(der, i)
    i += seqLenBytes
    // Optional stricter check: Ensure reported sequence length matches remaining bytes
    // require(seqLen == der.size - i) { "DER Sequence length ($seqLen) mismatch, remaining bytes=${der.size - i}" }


    // --- Parse Integer r ---
    // 3. Check for INTEGER tag (0x02) for r
    require(i < der.size && der[i++] == 0x02.toByte()) {
        "Expected INTEGER tag (0x02) for r at index ${i - 1}, but got ${
            der.getOrNull(i - 1) ?: "EOF"
        }"
    }

    // 4. Read r's length and advance index
    val rLen = readDerLength(der, i)
    i += countDerLengthBytes(der, i)
    val rStartIndex = i

    // 5. Bounds check before copying r's content bytes
    require(rStartIndex + rLen <= der.size) {
        "Reported length for r ($rLen bytes starting at $rStartIndex) exceeds signature size (${der.size})."
    }
    val rBytesDer = der.copyOfRange(rStartIndex, rStartIndex + rLen)
    i += rLen // Advance past r's content bytes

    // --- Parse Integer s ---
    // 6. Check for INTEGER tag (0x02) for s
    require(i < der.size && der[i++] == 0x02.toByte()) {
        "Expected INTEGER tag (0x02) for s at index ${i - 1}, but got ${
            der.getOrNull(i - 1) ?: "EOF"
        }"
    }

    // 7. Read s's length and advance index
    val sLen = readDerLength(der, i)
    i += countDerLengthBytes(der, i)
    val sStartIndex = i

    // 8. Bounds check before copying s's content bytes
    require(sStartIndex + sLen <= der.size) {
        "Reported length for s ($sLen bytes starting at $sStartIndex) exceeds signature size (${der.size})."
    }
    val sBytesDer = der.copyOfRange(sStartIndex, sStartIndex + sLen)
    // Optional stricter check: Ensure all sequence bytes were consumed
    // require(i + sLen == der.size) { "Signature parsing finished at index ${i+sLen}, but signature size is ${der.size}" }


    // --- Convert r and s to fixed size, handling DER INTEGER format ---
    /**
     * Converts the content bytes of a DER INTEGER to a fixed-size byte array.
     * Removes unnecessary leading zeros according to DER rules, then pads
     * with leading zeros or throws error if too large.
     */
    fun toFixedSize(derIntBytes: ByteArray): ByteArray {
        // Find the start of the actual value bytes by skipping DER's leading 0x00 if present AND unnecessary
        var valueStart = 0
        if (derIntBytes.size > 1 && derIntBytes[0] == 0x00.toByte() && (derIntBytes[1].toInt() and 0x80) == 0) {
            // Skip unnecessary leading 0x00 (value doesn't start with MSB set)
            valueStart = 1
            // Skip multiple leading zeros if present (although non-minimal DER is unusual)
            while (valueStart < derIntBytes.size - 1 && derIntBytes[valueStart] == 0x00.toByte() && (derIntBytes[valueStart + 1].toInt() and 0x80) == 0) {
                valueStart++
            }
        } else if (derIntBytes.size > 1 && derIntBytes[0] == 0x00.toByte() && (derIntBytes[1].toInt() and 0x80) != 0) {
            // Leading 0x00 was *necessary* for DER positivity rule, but we still skip it for R||S format
            valueStart = 1
        }
        // If derIntBytes is just [0x00], valueStart remains 0, correct.

        val valueBytes = derIntBytes.copyOfRange(valueStart, derIntBytes.size)
        val valueSize = valueBytes.size

        // Check size against target
        require(valueSize <= sizeBytes) {
            "DER INTEGER value requires $valueSize bytes after processing, which is larger than target size $sizeBytes. " +
                    "Original DER Int: ${derIntBytes.toHexString()}, Processed Value: ${valueBytes.toHexString()}"
        }

        // Pad with leading zeros if smaller
        return if (valueSize == sizeBytes) {
            valueBytes
        } else {
            ByteArray(sizeBytes - valueSize).plus(valueBytes)
        }
    }

    val rFixed = toFixedSize(rBytesDer)
    val sFixed = toFixedSize(sBytesDer)

    // 9. Concatenate fixed-size r and s
    return rFixed + sFixed
}


/**
 * Reads the length field of a DER-encoded element. Supports short form
 * and long form (up to 4 length bytes).
 * @param der The DER data.
 * @param at The index where the length byte starts.
 * @return The decoded length value.
 * @throws IllegalArgumentException for invalid length encoding.
 */
private fun readDerLength(der: ByteArray, at: Int): Int {
    require(at < der.size) { "Attempting to read DER length past end of data." }
    var i = at
    var len = der[i++].toInt() and 0xff

    if ((len and 0x80) != 0) { // Long form
        val lengthBytesCount = len and 0x7f
        require(lengthBytesCount in 1..4) { "DER long-form length encoding uses unsupported byte count: $lengthBytesCount" }
        require(at + 1 + lengthBytesCount <= der.size) { "DER long-form length encoding truncated." }

        len = 0
        repeat(lengthBytesCount) {
            len = (len shl 8) or (der[i++].toInt() and 0xff)
        }
        // Add check for excessive length (e.g., len > remaining bytes) if stricter parsing needed
    }
    // Else: Short form, len is the length itself.

    require(len >= 0) { "DER length cannot be negative." }
    return len
}

/**
 * Counts the number of bytes used to encode the DER length at a given index.
 * @param der The DER data.
 * @param at The index where the length byte starts.
 * @return 1 for short form, 1 + N for long form (where N is number of length bytes).
 * @throws IllegalArgumentException for invalid length encoding.
 */
private fun countDerLengthBytes(der: ByteArray, at: Int): Int {
    require(at < der.size) { "Attempting to count DER length bytes past end of data." }
    val firstByte = der[at].toInt() and 0xff

    return if ((firstByte and 0x80) == 0) {
        1 // Short form uses 1 byte
    } else { // Long form
        val lengthBytesCount = firstByte and 0x7f
        require(lengthBytesCount in 1..4) { "DER long-form length encoding uses unsupported byte count: $lengthBytesCount" }
        // Ensure the claimed length bytes actually exist in the input array
        require(at + 1 + lengthBytesCount <= der.size) { "DER long-form length encoding truncated (during byte count)." }
        1 + lengthBytesCount // 1 byte for 0x8N + N bytes for length
    }
}