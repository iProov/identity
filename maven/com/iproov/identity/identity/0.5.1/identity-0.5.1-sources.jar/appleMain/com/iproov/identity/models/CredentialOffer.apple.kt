package com.iproov.identity.models

val CredentialOffer.raw get() = this.raw.toNativeTypes()