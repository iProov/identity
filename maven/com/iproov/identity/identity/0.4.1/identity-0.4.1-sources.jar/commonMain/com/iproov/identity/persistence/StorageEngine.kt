package com.iproov.identity.persistence

import com.iproov.identity.cryptography.KeyPairAccessPolicy

class StorageException(message: String) : Exception(message)
interface StorageEngine {
    @Throws(Exception::class)
    suspend fun read(key: String): String?

    @Throws(Exception::class)
    suspend fun write(key: String, value: String?)
    suspend fun deleteAll()
}

/**
 * The credentials are encrypted using the public / private key pair in the secure enclave.
 *
 * They are stored in a file in the NSApplicationSupport directory on apple and stored using encrypted shared preferences on Android.
 *
 */
expect fun getDeviceBoundStorageEngine(accessPolicy: KeyPairAccessPolicy): StorageEngine

class InMemoryStorageEngine() : StorageEngine {
    private var data = mutableMapOf<String, String?>()

    override suspend fun read(key: String): String? = data[key]

    override suspend fun write(key: String, value: String?) {
        data[key] = value
    }

    override suspend fun deleteAll() {
        data = mutableMapOf()
    }
}