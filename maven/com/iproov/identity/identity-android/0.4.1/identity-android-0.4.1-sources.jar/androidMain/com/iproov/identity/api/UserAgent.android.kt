package com.iproov.identity.api

import android.os.Build

actual fun getUserAgent(): UserAgent = UserAgent(
    sdkVersion = "0.4.1",
    operatingSystem = "Android",
    operatingSystemVersion = Build.VERSION.RELEASE,
    deviceModel = Build.MODEL
)