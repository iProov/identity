@file:OptIn(ExperimentalTime::class)

package com.iproov.identity.models

import kotlinx.serialization.Serializable
import kotlin.time.ExperimentalTime

@Serializable
data class Claim(val jwt: Jwt, val displayName: String?) {

    companion object {
        fun fromJwt(jwt: Jwt, translations: Map<String, String?>): Claim {
            val displayName = translations[jwt.name]
            return Claim(jwt, displayName)
        }
    }

    // Quick access method
    val name: String by lazy { jwt.name }

    // Quick access method
    val source: String by lazy { jwt.source }

    val value: Any? by lazy { jwt.value }

    /**
     * When the claim expires (seconds since epoch)
     */
    val expires: Long by lazy { jwt.expires }

    override fun toString(): String {
        return "Claim(displayName=$displayName, jwt=$jwt)"
    }
}

