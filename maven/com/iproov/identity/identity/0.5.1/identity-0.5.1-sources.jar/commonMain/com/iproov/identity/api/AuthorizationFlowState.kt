package com.iproov.identity.api

/**
 * Holds an [OID4VCIClient]'s one in-flight authorization-code request.
 *
 * The browser round trip splits the flow across two calls, so the issuer and the key pair used for
 * DPoP and proof-of-possession have to survive between
 * [OID4VCIClient.prepareAuthorizationRequest] and [OID4VCIClient.issueCredentialsWithAuthCode].
 *
 * One request at a time. A second [start] supersedes the first, and resolving a superseded or
 * never-started request returns null — the caller then fails with a clear error rather than
 * finishing it with another request's key pair.
 *
 * Memory only: kill the process mid-round-trip and the user starts again.
 */
internal class AuthorizationFlowState<T : Any> {

    private var active: Active<T>? = null

    /** Makes [state] the active request, keyed on [platformState]. */
    fun start(platformState: Any, state: T) {
        active = Active(platformState, state)
    }

    /** The state started for [platformState], or null if that request is not the active one. */
    fun resolveOrNull(platformState: Any): T? =
        active?.takeIf { it.platformState === platformState }?.state

    /** Drops the active request, finished or not. */
    fun clear() {
        active = null
    }

    private class Active<T : Any>(val platformState: Any, val state: T)
}
