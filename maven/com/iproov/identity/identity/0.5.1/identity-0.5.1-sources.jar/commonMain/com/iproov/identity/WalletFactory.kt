package com.iproov.identity

import com.iproov.identity.cryptography.KeyPairAccessPolicy
import com.iproov.identity.cryptography.asCustomerManaged
import com.iproov.identity.cryptography.asSdkManaged
import com.iproov.identity.cryptography.getDeviceBoundKeyPair
import com.iproov.identity.cryptography.validateSigningKey
import com.iproov.identity.persistence.CredentialDeserializer
import com.iproov.identity.persistence.LegacyCredentialDeserializer
import com.iproov.identity.persistence.StorageEngine
import com.iproov.identity.persistence.getDeviceBoundStorageEngine

object WalletFactory {
    var instance: Wallet? = null

    /**
     * Creates a wallet with no OID4VCI client configuration.
     *
     * Pre-authorized issuance still works, sending the SDK's own client ID. Calling
     * [com.iproov.identity.models.RespondableCredentialOffer.authorize] throws
     * [AuthorizationCodeFlowNotConfiguredException].
     */
    fun getInstance(
        baseUrl: String,
        isLoggingEnabled: Boolean = false, // Keep default for Boolean here too for consistency if called from Kotlin
        storageEngine: StorageEngine = getDeviceBoundStorageEngine(KeyPairAccessPolicy.DeviceUnlocked),
        signingKeyPairFactory: KeyPairFactory = {
            getDeviceBoundKeyPair(
                KeyPairAccessPolicy.DeviceUnlocked, "com.iproov.identity"
            ).asSdkManaged()
        },
        credentialDeserializer: CredentialDeserializer = CredentialDeserializer(),
        legacyCredentialDeserializer: LegacyCredentialDeserializer = LegacyCredentialDeserializer()
    ): Wallet = createInstance(
        baseUrl = baseUrl,
        clientConfiguration = null,
        isLoggingEnabled = isLoggingEnabled,
        storageEngine = storageEngine,
        signingKeyPairFactory = signingKeyPairFactory,
        credentialDeserializer = credentialDeserializer,
        legacyCredentialDeserializer = legacyCredentialDeserializer,
    )

    /**
     * Creates a wallet that issues credentials as the app's own OAuth client.
     *
     * [clientConfiguration] enables authorization-code issuance, and its client ID is what
     * pre-authorized issuance sends too.
     */
    fun getInstance(
        baseUrl: String,
        clientConfiguration: OID4VCIClientConfiguration,
        isLoggingEnabled: Boolean = false,
        storageEngine: StorageEngine = getDeviceBoundStorageEngine(KeyPairAccessPolicy.DeviceUnlocked),
        signingKeyPairFactory: KeyPairFactory = {
            getDeviceBoundKeyPair(
                KeyPairAccessPolicy.DeviceUnlocked, "com.iproov.identity"
            ).asSdkManaged()
        },
        credentialDeserializer: CredentialDeserializer = CredentialDeserializer(),
        legacyCredentialDeserializer: LegacyCredentialDeserializer = LegacyCredentialDeserializer()
    ): Wallet = createInstance(
        baseUrl = baseUrl,
        clientConfiguration = clientConfiguration,
        isLoggingEnabled = isLoggingEnabled,
        storageEngine = storageEngine,
        signingKeyPairFactory = signingKeyPairFactory,
        credentialDeserializer = credentialDeserializer,
        legacyCredentialDeserializer = legacyCredentialDeserializer,
    )

    private fun createInstance(
        baseUrl: String,
        clientConfiguration: OID4VCIClientConfiguration?,
        isLoggingEnabled: Boolean,
        storageEngine: StorageEngine,
        signingKeyPairFactory: KeyPairFactory,
        credentialDeserializer: CredentialDeserializer,
        legacyCredentialDeserializer: LegacyCredentialDeserializer,
    ): Wallet {
        val validatedSigningKeyPairFactory: KeyPairFactory = {
            signingKeyPairFactory()
                .asCustomerManaged()
                .also(::validateSigningKey)
        }

        // This is the main implementation function where the instance is created
        val actualInstance = getWalletInstance(
            baseUrl,
            clientConfiguration,
            isLoggingEnabled,
            storageEngine,
            validatedSigningKeyPairFactory,
            legacyCredentialDeserializer,
            credentialDeserializer,
        )

        instance = actualInstance
        return actualInstance
    }
}

internal expect fun getWalletInstance(
    baseUrl: String,
    clientConfiguration: OID4VCIClientConfiguration?,
    isLoggingEnabled: Boolean = false,
    storageEngine: StorageEngine,
    signingKeyPairFactory: KeyPairFactory,
    legacyCredentialDeserializer: LegacyCredentialDeserializer, // Remove when when legacy credentials have been removed
    credentialDeserializer: CredentialDeserializer,
): Wallet
