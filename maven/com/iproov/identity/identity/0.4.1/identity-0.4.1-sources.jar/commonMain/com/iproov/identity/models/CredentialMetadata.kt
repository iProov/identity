package com.iproov.identity.models

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC
import kotlin.time.Clock
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

@OptIn(ExperimentalUuidApi::class, ExperimentalObjCRefinement::class)
@Serializable
data class CredentialMetadata(

    /**
     * UUID that maps this metadata to the stored credential
     */
    val uuid: String = Uuid.random().toHexString(),

    /**
     * The raw JSON OIDC offer that was used to retrieve the credential
     */
    @HiddenFromObjC
    val offer: JsonObject,

    /**
     * When the credential was added to the wallet. (Milliseconds since epoch)
     */
    val addedAt: Long = Clock.System.now().toEpochMilliseconds(),

    /**
     * The OID4VCI compliant format identifier that represents the format the credential conforms to.
     */
    val format: String,

    /**
     * Display properties of the credential according provided by the issuer. Each being for a
     * different locale.
     */
    val display: List<DisplayProperties>,

    /**
     * Details about the the issuer.
     */
    val issuer: CredentialIssuer,
)

/**
 * An abstraction of the display properties of a credential provided by an issuer when the credential
 * is offered.
 */
@Serializable
data class DisplayProperties(
    val name: String? = null,
    val locale: String? = null,
    val description: String? = null,
    val textColor: String? = null,
    val backgroundColor: String? = null,
    val logoUrl: String? = null,
    val logoAltText: String? = null,
    val additionalData: Map<String, JsonElement> = mapOf(),
)

/**
 * Extension property to get a unique identifier for this credential metadata.
 * Uses the uuid field.
 */
val CredentialMetadata.id: String
    get() = uuid

/**
 * Extension property to get the docType for mDoc credentials.
 * Returns null for non-mDoc credentials.
 */
val CredentialMetadata.docType: String?
    get() = if (format == "mso_mdoc") {
        // Try to extract doctype from the offer
        offer["doctype"]?.toString()?.trim('"')
            ?: offer["credential_configuration"]?.let { config ->
                (config as? JsonObject)?.get("doctype")?.toString()?.trim('"')
            }
    } else null

/**
 * Extension property to get the vct (verifiable credential type) for SD-JWT-VC credentials.
 * Returns null for non-SD-JWT-VC credentials.
 */
val CredentialMetadata.vct: String?
    get() = if (format == "vc+sd-jwt" || format == "dc+sd-jwt") {
        // Try to extract vct from the offer
        offer["vct"]?.toString()?.trim('"')
            ?: offer["credential_configuration"]?.let { config ->
                (config as? JsonObject)?.get("vct")?.toString()?.trim('"')
            }
    } else null