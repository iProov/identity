package com.iproov.identity.cryptography

import com.iproov.identity.Logger
import kotlinx.cinterop.ByteVar
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.alloc
import kotlinx.cinterop.allocArray
import kotlinx.cinterop.convert
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.pin
import kotlinx.cinterop.ptr
import kotlinx.cinterop.refTo
import kotlinx.cinterop.value
import platform.CoreCrypto.CCCrypt
import platform.CoreCrypto.CCCryptorStatus
import platform.CoreCrypto.CCOperation
import platform.CoreCrypto.kCCAlgorithmAES
import platform.CoreCrypto.kCCBlockSizeAES128
import platform.CoreCrypto.kCCDecrypt
import platform.CoreCrypto.kCCEncrypt
import platform.CoreCrypto.kCCOptionPKCS7Padding
import platform.CoreCrypto.kCCSuccess
import platform.Foundation.NSData
import platform.Foundation.create
import platform.Security.SecRandomCopyBytes
import platform.Security.errSecSuccess
import platform.Security.kSecRandomDefault
import platform.darwin.OSStatus
import platform.posix.memcpy
import platform.posix.size_tVar
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

// --- NSData <-> ByteArray Conversion Helpers (Keep as before) ---
@OptIn(ExperimentalForeignApi::class)
internal fun NSData.toByteArray(): ByteArray {
    val dataLength = this.length.toInt(); if (dataLength == 0) return ByteArray(0)
    val bytes = this.bytes ?: throw IllegalStateException("Failed to get bytes from NSData")
    return ByteArray(dataLength).apply { memcpy(this.refTo(0), bytes, dataLength.convert()) }
}

@OptIn(ExperimentalForeignApi::class)
internal fun ByteArray.toNSData(): NSData {
    if (this.isEmpty()) return NSData(); return memScoped {
        val pinned = this@toNSData.pin(); NSData.create(
        bytes = pinned.addressOf(0),
        length = this@toNSData.size.convert()
    ).also { pinned.unpin() }
    }
}

// --- Actual Platform Helper Implementations for Apple ---
@OptIn(ExperimentalForeignApi::class)
internal actual fun generateSecureRandomBytes(size: Int): ByteArray {
    val bytes = ByteArray(size)
    val status: OSStatus = SecRandomCopyBytes(kSecRandomDefault, size.convert(), bytes.refTo(0))
    if (status != errSecSuccess) {
        throw Error("Failed to generate secure random bytes. Status: $status")
    }
    return bytes
}


// --- Actual SymmetricKey Implementation for Apple ---
@OptIn(ExperimentalForeignApi::class, ExperimentalEncodingApi::class)
actual class SymmetricKey {
    private val actualKeyBytes: ByteArray // Renamed to avoid conflict

    // Actual primary constructor
    actual constructor(keyBytes: ByteArray) {
        require(keyBytes.size == AES_KEY_SIZE_BYTES) {
            "Invalid key size. Expected $AES_KEY_SIZE_BYTES bytes for AES-256, got ${keyBytes.size}."
        }
        this.actualKeyBytes = keyBytes.copyOf() // Store a copy defensively
    }

    // Actual secondary constructor (delegates to primary)
    actual constructor(keyString: String) : this(Base64.decode(keyString))

    actual fun encrypt(plainData: ByteArray): ByteArray? {
        return try {
            val ivBytes = generateSecureRandomBytes(AES_BLOCK_SIZE_BYTES)
            val outputBytes = performCryptoOperation(
                data = plainData,
                key = actualKeyBytes, // Use stored key bytes
                iv = ivBytes,
                operation = kCCEncrypt
            ) ?: return null
            ivBytes + outputBytes // Prepend IV
        } catch (e: Exception) {
            Logger.info("Encryption failed: ${e.message}")
            null
        }
    }

    actual fun decrypt(encryptedData: ByteArray): ByteArray? {
        return try {
            if (encryptedData.size < AES_BLOCK_SIZE_BYTES) return null // Data too short for IV

            val ivBytes = encryptedData.copyOfRange(0, AES_BLOCK_SIZE_BYTES)
            val ciphertextBytes = encryptedData.copyOfRange(AES_BLOCK_SIZE_BYTES, encryptedData.size)

            performCryptoOperation(
                data = ciphertextBytes,
                key = actualKeyBytes, // Use stored key bytes
                iv = ivBytes,
                operation = kCCDecrypt
            )
        } catch (e: Exception) {
            Logger.info("Decryption failed: ${e.message}")
            null
        }
    }

    actual fun getKeyBytes(): ByteArray = actualKeyBytes.copyOf()

    actual fun getKeyString(): String = Base64.encode(actualKeyBytes)


    // Helper for CommonCrypto Operation (Keep as before, just use actualKeyBytes)
    private fun performCryptoOperation(
        data: ByteArray,
        key: ByteArray, // Parameter name kept for clarity, uses actualKeyBytes
        iv: ByteArray,
        operation: CCOperation
    ): ByteArray? = memScoped {
        val dataToProcess = data.toNSData()
        // Key and IV bytes are already ByteArray, convert them
        val keyData = key.toNSData()
        val ivData = iv.toNSData()

        val outputBufferSize = dataToProcess.length + kCCBlockSizeAES128 // Use CommonCrypto constant
        val outputBuffer = allocArray<ByteVar>(outputBufferSize.toInt())
        val dataOutMoved = alloc<size_tVar>()

        val status: CCCryptorStatus = CCCrypt(
            operation, kCCAlgorithmAES, kCCOptionPKCS7Padding,
            keyData.bytes, keyData.length, // Use kCCKeySizeAES256 or keyData.length
            ivData.bytes,
            dataToProcess.bytes, dataToProcess.length,
            outputBuffer, outputBufferSize, dataOutMoved.ptr
        )

        if (status == kCCSuccess) {
            ByteArray(dataOutMoved.value.toInt()).apply {
                memcpy(this.refTo(0), outputBuffer, dataOutMoved.value)
            }
        } else {
            Logger.info("CommonCrypto operation failed with status: $status")
            null
        }
    }

    // Actual companion object implementation
    actual companion object {
        actual fun new(): SymmetricKey {
            val randomBytes = generateSecureRandomBytes(AES_KEY_SIZE_BYTES)
            return SymmetricKey(randomBytes) // Calls primary constructor
        }
    }
}