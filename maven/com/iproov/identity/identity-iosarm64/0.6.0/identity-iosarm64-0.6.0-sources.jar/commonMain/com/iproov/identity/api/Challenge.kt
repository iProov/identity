package com.iproov.identity.api

import com.iproov.identity.models.AccessControl
import com.iproov.identity.models.MrtdData
import com.iproov.identity.models.RespondableCredentialOffer
import kotlinx.coroutines.Deferred
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Instant
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC
import kotlin.time.ExperimentalTime

@OptIn(ExperimentalObjCRefinement::class, ExperimentalTime::class)
open class Challenge(
    @HiddenFromObjC
    val challenge: ByteArray? = null,

    @HiddenFromObjC
    val expires: Instant,
)

@OptIn(ExperimentalTime::class)
open class RespondableChallenge<T>(
    val respond: T,
    challenge: Challenge,
) : Challenge(challenge = challenge.challenge, expires = challenge.expires) {

    companion object {
        fun <T> fromChallenge(challenge: Challenge, respond: T): RespondableChallenge<T> {
            return RespondableChallenge(respond, challenge)
        }
    }
}

class UriCredentialChallenge(
    challenge: Challenge,
    respond: UriCredentialChallengeResponder
) : RespondableChallenge<UriCredentialChallengeResponder>(challenge = challenge, respond = respond)

class UriCredentialChallengeResponder(
    private val usingToken: UriCredentialChallengeResponse,
) {
    @Throws(Exception::class)
    suspend fun withToken(token: String) = usingToken(token).awaitOrCancel()
}

/**
 * Awaits work the wallet started in GlobalScope, cancelling it if the caller is cancelled first: otherwise it
 * finishes unseen and stores claims, and a retry then fails as a duplicate.
 */
internal suspend fun <T> Deferred<T>.awaitOrCancel(): T = try {
    await()
} catch (e: CancellationException) {
    cancel()
    throw e
}

typealias UriCredentialChallengeResponse = (token: String) -> Deferred<Nothing?>

// Type aliases for function types
typealias ReadIdDocumentChallengeResponse = (sessionId: String) -> Deferred<RespondableCredentialOffer>

// Suspend rather than Deferred like its public siblings, which keep that type for compatibility and use awaitOrCancel.
internal typealias NfcServiceReadChallengeResponse = suspend (completionCode: String) -> RespondableCredentialOffer

typealias MrtdChallengeResponse = (
    mrtd: MrtdData,
    accessControl: AccessControl,
    signature: ByteArray?
) -> Deferred<RespondableCredentialOffer>

@OptIn(ExperimentalObjCRefinement::class)
class DocumentChallengeResponder(
    @HiddenFromObjC
    private val usingMrtd: MrtdChallengeResponse,
) {

    @Throws(Exception::class)
    @HiddenFromObjC
    suspend fun withMrtd(
        mrtd: MrtdData,
        accessControl: AccessControl,
        signature: ByteArray?
    ) = usingMrtd(mrtd, accessControl, signature).awaitOrCancel()

    internal var usingNfcServiceRead: NfcServiceReadChallengeResponse? = null

    /**
     * Finishes a read done through the iProov NFC service, with the completion code the NFC reader SDK
     * returned. Only for a [DocumentChallenge] whose `nfcServiceReadToken` is set.
     */
    @Throws(Throwable::class)
    suspend fun withNfcServiceRead(completionCode: String): RespondableCredentialOffer {
        val respond = usingNfcServiceRead
            ?: throw IllegalStateException("This challenge has no NFC-service read: read the chip on the device and use withMrtd")
        return respond(completionCode)
    }
}

class DocumentChallenge(
    val bacKey: String,
    respond: DocumentChallengeResponder,
    challenge: Challenge
) : RespondableChallenge<DocumentChallengeResponder>(respond, challenge) {

    /**
     * Set when the chip is to be read through the iProov NFC service: pass it unchanged to the NFC reader
     * SDK, and never log it. Null means read the chip on the device, as before.
     */
    var nfcServiceReadToken: String? = null
        internal set

    companion object {
        fun fromChallenge(
            challenge: Challenge,
            bacKey: String,
            respond: DocumentChallengeResponder
        ) = DocumentChallenge(bacKey, respond, challenge)
    }
}
