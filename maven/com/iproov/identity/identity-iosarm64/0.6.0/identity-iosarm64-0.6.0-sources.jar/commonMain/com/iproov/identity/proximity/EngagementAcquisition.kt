package com.iproov.identity.proximity

import com.iproov.identity.Logger
import com.iproov.identity.proximity.ProximityRetrievalSession.EngagementOutcome
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.multipaz.cbor.Cbor
import org.multipaz.cbor.Simple
import org.multipaz.mdoc.connectionmethod.MdocConnectionMethodBle
import org.multipaz.mdoc.engagement.DeviceEngagement
import org.multipaz.mdoc.nfc.MdocReaderNfcHandoverOptions
import org.multipaz.mdoc.nfc.scanMdocReader
import org.multipaz.mdoc.role.MdocRole
import org.multipaz.mdoc.transport.MdocTransportFactory
import org.multipaz.nfc.NfcTagReader
import org.multipaz.util.UUID

object EngagementAcquisition {

    internal suspend fun acquireFromUri(
        uri: String,
        config: ProximityConfig.Reader,
        orchestrator: ProximityOrchestrator
    ): EngagementOutcome = withTimeout(config.engagementTimeout) {
        val deviceEngagement = orchestrator.retrieveProximityEngagement(uri)

        Logger.debug("Retrieved device engagement (${deviceEngagement.connectionMethods.size} connection method(s))")

        val ble = config.selectBleMethod(deviceEngagement.connectionMethods)
            ?: throw ProximityRetrievalException(config.noUsableBleModeMessage)

        if (!orchestrator.isBleAvailable()) {
            throw ProximityRetrievalException("BLE is not available and required for this proximity session")
        }

        val mdocTransport = MdocTransportFactory.Default.createTransport(
            connectionMethod = ble,
            role = MdocRole.MDOC_READER,
            options = MDOC_TRANSPORT_OPTIONS,
        )

        EngagementOutcome(deviceEngagement, mdocTransport, Simple.NULL)
    }


    internal suspend fun acquireFromNfc(
        dialogMessage: String?,
        config: ProximityConfig.Reader,
        orchestrator: ProximityOrchestrator,
    ): EngagementOutcome {
        val reader = NfcTagReader.getReaders().firstOrNull()
            ?: throw ProximityRetrievalException("No NFC reader available on this device")
        if (!orchestrator.isBleAvailable()) {
            throw ProximityRetrievalException("BLE is required after NFC engagement but unavailable")
        }
        val result = withContext(context = Dispatchers.Main) {
            reader.scanMdocReader(
                message = dialogMessage,
                options = MDOC_TRANSPORT_OPTIONS,
                handoverOptions = MdocReaderNfcHandoverOptions(),
                negotiatedHandoverConnectionMethods = config.negotiatedHandoverMethods(UUID.randomUUID()),
                // multipaz keeps the sheet polling when this returns null, so an offer with no usable
                // carrier has to throw; multipaz then closes the sheet with the message and rethrows.
                selectConnectionMethod = { offered ->
                    config.selectBleMethod(offered)
                        ?: throw ProximityRetrievalException(config.noUsableBleModeMessage)
                },
            ) ?: throw ProximityRetrievalException("NFC scan cancelled before handover completed")
        }
        // multipaz takes a lone carrier without consulting selectConnectionMethod, so it is checked
        // here. Only BLE carries the transfer, as on QR and Android NFC.
        val method = result.transport.connectionMethod
        if (method !is MdocConnectionMethodBle || !config.allows(method)) {
            result.transport.close()
            throw ProximityRetrievalException(config.noUsableBleModeMessage)
        }
        val deviceEngagement = DeviceEngagement.fromDataItem(
            Cbor.decode(result.encodedDeviceEngagement.toByteArray())
        )
        return EngagementOutcome(
            deviceEngagement, result.transport, result.handover,
        )
    }


}