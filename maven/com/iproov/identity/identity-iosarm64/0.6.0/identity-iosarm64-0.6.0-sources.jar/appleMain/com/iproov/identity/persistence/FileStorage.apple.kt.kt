package com.iproov.identity.persistence

import com.iproov.identity.Logger
import com.iproov.identity.attestation.toNSData
import com.iproov.identity.isAppExtension
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCObjectVar
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.value
import platform.Foundation.NSApplicationSupportDirectory
import platform.Foundation.NSBundle
import platform.Foundation.NSData
import platform.Foundation.NSDataWritingAtomic
import platform.Foundation.NSDate
import platform.Foundation.NSDictionary
import platform.Foundation.NSError
import platform.Foundation.NSFileManager
import platform.Foundation.NSFileModificationDate
import platform.Foundation.NSFileSize
import platform.Foundation.NSKeyedArchiver
import platform.Foundation.NSKeyedUnarchiver
import platform.Foundation.NSNull
import platform.Foundation.NSNumber
import platform.Foundation.NSString
import platform.Foundation.NSURL
import platform.Foundation.NSURLIsExcludedFromBackupKey
import platform.Foundation.NSUserDomainMask
import platform.Foundation.dataWithContentsOfURL
import platform.Foundation.writeToURL

/** The wallet file name, shared by the engine and the DC API registrar. */
internal const val WALLET_FILE_NAME = "com.iproov.identity"

class FileStorage internal constructor(
    private val fileName: String,
    private val appGroupIdentifier: String,
    // Test seams: the Kotlin test binary has no entitlements, bundle identifier or sandbox of its own.
    private val containerFor: (String) -> NSURL?,
    private val bundleIdentifier: String?,
    private val inExtension: Boolean,
    private val localContainer: NSURL,
) {
    @Throws(Exception::class)
    constructor(fileName: String, appGroupIdentifier: String) : this(
        fileName,
        appGroupIdentifier,
        containerFor = { NSFileManager.defaultManager.containerURLForSecurityApplicationGroupIdentifier(it) },
        bundleIdentifier = NSBundle.mainBundle.bundleIdentifier,
        inExtension = isAppExtension,
        localContainer = (NSFileManager.defaultManager.URLsForDirectory(
            directory = NSApplicationSupportDirectory,
            inDomains = NSUserDomainMask,
        ) as List<NSURL>).first(),
    )

    private val fileManager = NSFileManager.defaultManager

    /** Null until the app is entitled to the group; the wallet then stays in the sandbox. */
    private val sharedContainer: NSURL? = containerFor(appGroupIdentifier)

    private val fileUrl: NSURL
        get() = (sharedContainer ?: localContainer).URLByAppendingPathComponent(fileName)!!

    /** The sandbox file while the container is in use: a wallet created before the entitlement. */
    private val legacyFileUrl: NSURL?
        get() = if (sharedContainer == null) null else localContainer.URLByAppendingPathComponent(
            fileName
        )

    /** Sandbox record of the group holding the wallet, so it is never reopened elsewhere silently. */
    private val locationMarkerUrl: NSURL
        get() = localContainer.URLByAppendingPathComponent("$fileName.location")!!

    /** Container record of the app that owns it, so a second app sharing the group is refused. */
    private fun ownerMarkerUrl(container: NSURL): NSURL =
        container.URLByAppendingPathComponent("$fileName.owner")!!

    internal val hasSharedContainer: Boolean
        get() = sharedContainer != null

    /** Modification date and size of the wallet file, so a cached engine can tell when another writer moved it on. */
    @OptIn(ExperimentalForeignApi::class)
    internal fun stamp(): String? {
        val attributes = fileManager.attributesOfItemAtPath(fileUrl.path!!, null) ?: return null
        val modified =
            (attributes[NSFileModificationDate] as? NSDate)?.timeIntervalSinceReferenceDate
        val size = (attributes[NSFileSize] as? NSNumber)?.longLongValue
        return "$modified:$size"
    }

    /**
     * Confirms the wallet is where this instance will look. Another app's container, a recorded group
     * this build cannot reach, or a recorded group still holding data all surface as exceptions rather
     * than an empty wallet; a recorded group that is empty just drops the record.
     */
    @OptIn(ExperimentalForeignApi::class)
    internal fun checkLocation() {
        if (sharedContainer == null && inExtension) {
            throw StorageException(
                "App Group container unavailable for '$appGroupIdentifier' inside the extension. " +
                        "Add the App Groups entitlement to the extension target."
            )
        }
        checkOwner()
        val recorded = readMarker(locationMarkerUrl) ?: return
        val recordedContainer =
            if (recorded == appGroupIdentifier) sharedContainer
            else containerFor(recorded)
        when {
            recordedContainer == null -> throw StorageLocationException(
                "Credential storage was moved into App Group '$recorded', which this app is no longer " +
                        "entitled to. Restore that entitlement, or call deleteAll() to start empty."
            )

            recorded == appGroupIdentifier -> return
            fileManager.fileExistsAtPath(recordedContainer.URLByAppendingPathComponent(fileName)!!.path!!) ->
                throw StorageLocationException(
                    "Credential storage lives in App Group '$recorded' but this engine is configured with " +
                            "'$appGroupIdentifier'. Keep the original group, or call deleteAll() to start empty."
                )

            else -> fileManager.removeItemAtURL(locationMarkerUrl, null)
        }
    }

    /**
     * The app itself, or one of its extensions: Apple requires an extension's identifier to extend the
     * app's. A separate app may share that prefix, so the prefix rule applies to extensions only.
     */
    private fun isMine(owner: String): Boolean =
        bundleIdentifier?.let { it == owner || (inExtension && it.startsWith("$owner.")) } ?: true

    /** A shared container is used or cleared only by the app that owns it. */
    private fun mayUse(container: NSURL): Boolean =
        readMarker(ownerMarkerUrl(container))?.let(::isMine) ?: true

    private fun checkOwner() {
        val owner = sharedContainer?.let { readMarker(ownerMarkerUrl(it)) } ?: return
        if (!isMine(owner)) {
            throw StorageLocationException(
                "App Group '$appGroupIdentifier' already holds a wallet owned by '$owner'. Use an App Group " +
                        "dedicated to this app and its extension."
            )
        }
    }

    /** Records the location and, for the containing app, claims the container before any data lands there. */
    private fun claim() {
        val container = sharedContainer ?: return
        checkOwner()
        if (readMarker(locationMarkerUrl) != appGroupIdentifier) writeMarker(
            locationMarkerUrl,
            appGroupIdentifier
        )
        val me = bundleIdentifier ?: return
        if (!inExtension && readMarker(ownerMarkerUrl(container)) == null) writeMarker(
            ownerMarkerUrl(container),
            me
        )
    }

    @OptIn(ExperimentalForeignApi::class)
    private fun readMarker(url: NSURL): String? =
        NSData.dataWithContentsOfURL(url, 0uL, null)?.toByteArray()?.decodeToString()?.trim()
            ?.takeIf { it.isNotEmpty() }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    private fun writeMarker(url: NSURL, value: String): Unit = memScoped {
        fileManager.createDirectoryAtURL(
            url = url.URLByDeletingLastPathComponent!!,
            withIntermediateDirectories = true,
            attributes = null,
            error = null,
        )
        val error = alloc<ObjCObjectVar<NSError?>>()
        if (!value.encodeToByteArray().toNSData()
                .writeToURL(url = url, options = NSDataWritingAtomic, error = error.ptr)
        ) {
            throw StorageLocationException("Could not record '${url.lastPathComponent}': ${error.value?.localizedDescription}")
        }
        url.setResourceValues(mapOf(NSURLIsExcludedFromBackupKey to true), error.ptr)
        if (error.value != null) throw StorageException("Failed to prevent backup of '${url.lastPathComponent}': ${error.value}")
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(Exception::class)
    fun read(): NSData = memScoped {
        // Only an absent file means "not moved yet". A failed read of an existing file must surface:
        // serving the pre-sharing copy would resurrect deleted credentials.
        if (!fileManager.fileExistsAtPath(fileUrl.path!!)) {
            return migrateLegacyFile() ?: NSData()
        }
        claim() // Both copies exist only after a crash mid-move; the shared file is the live one.
        preventBackup() // On every open: files saved before the backup key was corrected were never excluded.
        removeLegacyCopy()
        val error = alloc<ObjCObjectVar<NSError?>>()
        return NSData.dataWithContentsOfURL(fileUrl, 0uL, error.ptr)
            ?: throw StorageException("Failed to read '$fileName': ${error.value?.localizedDescription}")
    }

    /** Moves the pre-sharing file into the App Group container: claim, copy, read back and compare, delete. */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    private fun migrateLegacyFile(): NSData? = memScoped {
        val legacy = legacyFileUrl ?: return null
        if (!fileManager.fileExistsAtPath(legacy.path!!)) return null
        val error = alloc<ObjCObjectVar<NSError?>>()
        val legacyData = NSData.dataWithContentsOfURL(legacy, 0uL, error.ptr)
            ?: throw StorageException("Failed to read pre-sharing '$fileName': ${error.value?.localizedDescription}")

        Logger.info("Moving credential storage into the App Group container.")
        claim()
        ensureDirectoryExists()
        val verified =
            legacyData.writeToURL(url = fileUrl, options = NSDataWritingAtomic, error = null) &&
                    NSData.dataWithContentsOfURL(fileUrl, 0uL, null)?.toByteArray()
                        ?.contentEquals(legacyData.toByteArray()) == true
        if (!verified) {
            fileManager.removeItemAtURL(fileUrl, null)
            throw StorageLocationException(
                "Credential storage could not be moved into App Group '$appGroupIdentifier'. The wallet " +
                        "stays in the app sandbox and the move is retried on the next open."
            )
        }
        preventBackup() // Before the source goes: a session that only reads never reaches saveToDisk.
        removeLegacyCopy()
        return legacyData
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    private fun removeLegacyCopy(): Unit = memScoped {
        val legacy = legacyFileUrl ?: return
        if (!fileManager.fileExistsAtPath(legacy.path!!)) return
        val error = alloc<ObjCObjectVar<NSError?>>()
        if (!fileManager.removeItemAtURL(legacy, error.ptr)) {
            throw StorageLocationException(
                "The pre-sharing copy of '$fileName' could not be removed: " +
                        "${error.value?.localizedDescription}. Retried on the next open."
            )
        }
    }

    /**
     * Archives the provided NSDictionary into NSData using NSKeyedArchiver with secure coding.
     *
     * It enforces secure coding (`requiringSecureCoding = true`)
     * and wraps potential `NSError` results or `nil` returns in a `StorageException`.
     * Primarily used to serialize data before encryption or persistence.
     *
     * @param data The NSDictionary instance originating from or bridged for iOS.
     * @return NSData containing the securely archived representation of the input dictionary.
     * @throws StorageException if `NSKeyedArchiver` fails during serialization.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(Exception::class)
    fun archiveDictionary(data: NSDictionary): NSData = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>() // For NSError** pattern

        // Call Foundation's keyed archiver via interop
        val archivedData = NSKeyedArchiver.archivedDataWithRootObject(
            data,
            requiringSecureCoding = true, // Enforce NSSecureCoding conformance
            error = error.ptr
        )
        // Handle nil return from the archiver method
            ?: throw StorageException("NSKeyedArchiver returned nil data during encoding.")

        // Check for NSError population
        error.value?.let { nsError ->
            throw StorageException("NSKeyedArchiver failed during encoding: $nsError")
        }

        return@memScoped archivedData
    }

    /**
     * Unarchives NSData into an NSDictionary using the secure NSKeyedUnarchiver.
     *
     * Includes checks for `NSError` population (specifically if the result is nil) and
     * explicitly verifies the returned root object is non-null and of the expected
     * `NSDictionary` type. Wraps various failure conditions in a `StorageException`.
     *
     * @param data The NSData containing the output of a corresponding NSKeyedArchiver process
     * (using compatible classes and secure coding).
     * @return The successfully unarchived NSDictionary.
     * @throws StorageException If unarchiving fails due to decoding errors, nil return,
     * `NSError` being set, or the root object having an unexpected type.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(Exception::class)
    fun unarchiveData(data: NSData): NSDictionary = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>() // For NSError** pattern

        // Use secure un-archiving, specifying allowed classes.
        val result: Any? = NSKeyedUnarchiver.unarchivedObjectOfClasses(
            // Explicitly list allowed classes for security.
            classes = setOf(NSDictionary, NSString, NSNull),
            fromData = data,
            error = error.ptr
        )

        if (result == null) {
            // If null, check the NSError for a specific reason.
            val errorDetails = error.value?.let { ": $it" } ?: ": Reason unknown (result was nil)"
            throw StorageException("Failed to unarchive data${errorDetails}")
        }

        if (result !is NSDictionary) {
            throw StorageException("Expected unarchived data to be NSDictionary but was ${result::class.simpleName ?: "Unknown Type"}")
        }

        return@memScoped result
    }

    /**
     * Ensures the parent directory for the member `fileUrl` exists, creating it if necessary.
     *
     * Uses `NSFileManager.createDirectoryAtURL` with `withIntermediateDirectories = true`
     *
     * Handles potential `NSError` and wraps failures in a `StorageException`.
     * Assumes `fileUrl` is initialized and has a parent path.
     *
     * @throws StorageException if the parent directory cannot be determined or created.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(Exception::class)
    internal fun ensureDirectoryExists() = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>()

        // Safely get the parent directory URL from the member fileUrl
        val directoryUrl = fileUrl.URLByDeletingLastPathComponent
            ?: throw StorageException("Cannot determine parent directory for URL: $fileUrl")

        NSFileManager.defaultManager.createDirectoryAtURL(
            url = directoryUrl,
            withIntermediateDirectories = true, // Create missing parent directories recursively
            attributes = null, // Use default directory attributes
            error = error.ptr // Capture potential NSError
        )

        // Check for NSError population after the directory creation attempt
        error.value?.let { nsError ->
            throw StorageException("Failed to create directory $directoryUrl: $nsError")
        }
    }


    /**
     * Writes the provided NSData to the member `fileUrl` atomically.
     *
     * Ensures the target directory exists by calling `ensureDirectoryExists()` first.
     * Uses `NSData.writeToURL` with the `NSDataWritingAtomic` option for safer writes
     * (writes to a temporary file then renames).
     *
     * Handles potential `NSError` and wraps failures in a `StorageException`.
     * Assumes `fileUrl` is an initialized member variable.
     *
     * @param data The NSData to write to disk.
     * @throws StorageException if the directory cannot be created or the file write fails.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(Exception::class)
    fun write(data: NSData): Unit = memScoped {
        claim()
        // Ensure the parent directory exists before attempting to write the file.
        ensureDirectoryExists()

        val error = alloc<ObjCObjectVar<NSError?>>()

        // NSDataWritingAtomic ensures the original file isn't corrupted if the write fails mid-way.
        val success =
            data.writeToURL(url = fileUrl, options = NSDataWritingAtomic, error = error.ptr)

        // Check for failure (either writeToURL returned false or NSError was populated)
        if (!success || error.value != null) {
            val errorDetails = error.value?.let { ": $it" } ?: ""
            // Improved error message for write failure
            throw StorageException("Failed to write data to URL ${fileUrl}${errorDetails}")
        }
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(Exception::class)
    fun delete() = memScoped {
        // The wallet may still live in a recorded group; a container owned by another app is left alone.
        val recorded = readMarker(locationMarkerUrl)?.takeIf { it != appGroupIdentifier }
            ?.let(containerFor)
            ?.takeIf(::mayUse)
        val shared = sharedContainer?.takeIf(::mayUse)
        listOfNotNull(
            recorded?.URLByAppendingPathComponent(fileName),
            legacyFileUrl,
            if (sharedContainer == null) fileUrl else shared?.URLByAppendingPathComponent(fileName),
            shared?.let(::ownerMarkerUrl),
            locationMarkerUrl,
        ).forEach { url ->
            if (!fileManager.fileExistsAtPath(url.path!!)) return@forEach
            val error = alloc<ObjCObjectVar<NSError?>>()
            fileManager.removeItemAtURL(url, error.ptr)
            error.value?.let { throw StorageException("Failed to delete '${url.lastPathComponent}': ${it.localizedDescription}") }
        }
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    val fileHasBeenCreated: Boolean = memScoped {
        // Checks the legacy location too: a wallet whose file predates App Group sharing must not
        // look absent, or loadFromDisk() returns empty and read() never migrates it forward.
        val fileManager = NSFileManager.defaultManager
        fileManager.fileExistsAtPath(fileUrl.path!!) ||
                (legacyFileUrl?.path?.let { fileManager.fileExistsAtPath(it) } == true)
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    @Throws(Exception::class)
    fun preventBackup() = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>()
        fileUrl.setResourceValues(mapOf(NSURLIsExcludedFromBackupKey to true), error.ptr)

        if (error.value != null) throw StorageException("Failed to prevent backup: ${error.value}")
    }
}
