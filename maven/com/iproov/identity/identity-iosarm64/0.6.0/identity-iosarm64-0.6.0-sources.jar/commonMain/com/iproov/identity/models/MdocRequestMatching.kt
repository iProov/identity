package com.iproov.identity.models

import com.iproov.identity.Logger
import com.iproov.identity.persistence.Repository
import com.iproov.identity.proximity.DisclosedDocument
import com.iproov.identity.proximity.DocRequest
import com.iproov.identity.proximity.RequestedItem
import org.multipaz.mdoc.request.DeviceRequest

/**
 * Helper methods for request matching and disclosure planning for the DC-API and Proximity transport.
 */


/**
 * Which stored credentials can satisfy each [DocRequest]
 */
internal suspend fun matchCredentials(
    repository: Repository,
    docRequests: List<DocRequest>,
): Map<DocRequest, List<DisclosedDocument>> {
    val credentialMetadata: List<CredentialMetadata> = repository.getCredentialMetadata()
    if (credentialMetadata.isEmpty()) return docRequests.associateWith { emptyList() }

    val mdocPairs: List<Pair<CredentialMetadata, MDocCredential>> =
        repository.getCredentials(credentialMetadata.filter { it.format == "mso_mdoc" })
            .credentials
            .mapNotNull { (meta, cred) ->
                (cred as? MDocCredential)?.let { meta to it }
            }

    return docRequests.associateWith { request ->
        mdocPairs
            .filter { (_, cred) -> cred.docType == request.docType }
            .map { (meta, cred) -> DisclosedDocument(credential = cred, metadata = meta) }
    }
}

internal fun buildClaims(docRequest: DocRequest, item: DisclosedDocument): List<ClaimQuery> {
    val requested = docRequest.requestedItems.mapValues { (_, items) ->
        items.map { it.elementIdentifier }.toSet()
    }
    val plan = item.disclosedItems?.mapValues { (namespace, elements) ->
        elements.intersect(requested[namespace].orEmpty())
    } ?: requested
    val ignored = item.disclosedItems.orEmpty().flatMap { (namespace, elements) ->
        (elements - requested[namespace].orEmpty()).map { "$namespace/$it" }
    }
    if (ignored.isNotEmpty()) {
        Logger.error("Ignoring disclosure of elements the reader did not request: $ignored")
    }
    return plan.flatMap { (ns, elements) ->
        elements.map { ClaimQuery(path = listOf(ns, it)) }
    }
}

/** Flattens MultiPaz `DeviceRequest` into the SDK's [DocRequest] view. */
internal fun DeviceRequest.toDocRequests(): List<DocRequest> {
    return docRequests.map { req ->
        DocRequest(
            docType = req.docType,
            requestedItems = req.nameSpaces.mapValues { (_, items) ->
                items.map { (id, intentToRetain) -> RequestedItem(id, intentToRetain) }
            },
        )
    }
}