package com.iproov.identity.cryptography

import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCObjectVar
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.value
import platform.Foundation.NSError
import platform.LocalAuthentication.LAContext
import platform.LocalAuthentication.LAErrorDomain
import platform.LocalAuthentication.kLAErrorBiometryNotAvailable
import platform.LocalAuthentication.kLAErrorBiometryNotEnrolled
import platform.LocalAuthentication.kLAErrorPasscodeNotSet
import platform.LocalAuthentication.kLAPolicyDeviceOwnerAuthentication
import platform.LocalAuthentication.kLAPolicyDeviceOwnerAuthenticationWithBiometrics
import platform.Security.kSecAccessControlBiometryAny
import platform.Security.kSecAccessControlBiometryCurrentSet
import platform.Security.kSecAccessControlPrivateKeyUsage
import platform.Security.kSecAccessControlUserPresence


actual abstract class KeyPairAccessPolicy(
    val authenticationValidityDuration: Int,
) {

    abstract val accessControlFlags: ULong

    abstract val laPolicy: Long

    /**
     * No further authentication required
     */
    class DeviceUnlocked(authenticationValidityDuration: Int = DEFAULT_AUTH_VALIDITY_DURATION_SECONDS) :
        KeyPairAccessPolicy(authenticationValidityDuration) {
        override val accessControlFlags = kSecAccessControlPrivateKeyUsage
        override val laPolicy = kLAPolicyDeviceOwnerAuthentication.toLong()
    }

    /**
     * Any form of user presence is required to use the private key (pin or any biometrics)
     */
    class UserPresent(authenticationValidityDuration: Int = DEFAULT_AUTH_VALIDITY_DURATION_SECONDS) :
        KeyPairAccessPolicy(authenticationValidityDuration) {
        override val accessControlFlags = kSecAccessControlPrivateKeyUsage or kSecAccessControlUserPresence
        override val laPolicy = kLAPolicyDeviceOwnerAuthentication.toLong()
    }

    /**
     * Any set of biometrics can be used to access the private key, new biometrics can be enrolled and used to access
     * the private key.
     */
    class AnyBiometrics(authenticationValidityDuration: Int = DEFAULT_AUTH_VALIDITY_DURATION_SECONDS) :
        KeyPairAccessPolicy(authenticationValidityDuration) {
        override val accessControlFlags = kSecAccessControlPrivateKeyUsage or kSecAccessControlBiometryAny
        override val laPolicy = kLAPolicyDeviceOwnerAuthenticationWithBiometrics.toLong()
    }

    /**
     * Only the current set of biometrics enrolled on the device can be used to access the private key, if the biometrics
     * enrolled on the device are changed, the private key is inaccessible.
     */
    class CurrentBiometrics(authenticationValidityDuration: Int = DEFAULT_AUTH_VALIDITY_DURATION_SECONDS) :
        KeyPairAccessPolicy(authenticationValidityDuration) {
        override val accessControlFlags = kSecAccessControlPrivateKeyUsage or kSecAccessControlBiometryCurrentSet
        override val laPolicy = kLAPolicyDeviceOwnerAuthenticationWithBiometrics.toLong()
    }

    actual companion object {
        actual val DeviceUnlocked: KeyPairAccessPolicy = DeviceUnlocked()
    }

    /**
     * Checks if the device is capable of authenticating with the methods required by the current [accessControlPolicy].
     *
     * Assumptions:
     * - [accessControlPolicy.laPolicy] returns a valid LAPolicy for this context.
     */
    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    fun canAuthenticate(): AuthenticationAvailability = memScoped {
        val context = LAContext()

        // NSError**
        val errorVar = alloc<ObjCObjectVar<NSError?>>()
        errorVar.value = null

        val canEvaluate = context.canEvaluatePolicy(laPolicy, errorVar.ptr)

        if (canEvaluate) {
            return AuthenticationAvailability.Available
        }

        val nsError = errorVar.value ?: return AuthenticationAvailability.BiometricsNotSupported

        // No error? Treat as unsupported / unavailable.

        // Only trust LAErrorDomain for LA-related codes
        if (nsError.domain != LAErrorDomain) {
            return AuthenticationAvailability.BiometricsNotSupported
        }

        val code = nsError.code.toInt()

        return when (code) {
            kLAErrorPasscodeNotSet -> AuthenticationAvailability.DeviceNotSecure
            kLAErrorBiometryNotEnrolled -> AuthenticationAvailability.BiometricsNotEnrolled
            kLAErrorBiometryNotAvailable -> AuthenticationAvailability.BiometricsNotSupported
            else -> AuthenticationAvailability.BiometricsNotSupported
        }
    }
}