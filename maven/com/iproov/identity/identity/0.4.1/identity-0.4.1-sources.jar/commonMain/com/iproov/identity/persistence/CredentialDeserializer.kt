package com.iproov.identity.persistence

import com.iproov.identity.Logger
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialFormat
import com.iproov.identity.models.CredentialRecord

/**
 * A deserializer for Credentials that can be extended by registering custom CredentialFactory instances.
 * This allows plugins or other modules to introduce new credential types.
 */
class CredentialDeserializer {

    // Stores custom factories registered by plugins or other parts of the application.
    private val customFactories = mutableMapOf<String, CredentialFactory>()

    companion object Companion {
        const val TAG = "CredentialDeserializer"

        // Default, built-in deserialization logic.
        val defaultDeserializer = mapOf<String, CredentialFactory>(
            CredentialFormat.MDOC.value to MDocCredentialFactory(),
            CredentialFormat.SD_JWT_VC.value to SdJwtVcCredentialFactory(),
        )
    }

    /**
     * Registers a custom CredentialFactory.
     * If a factory for the same format has already been registered (by default or custom)
     * a warning is printed, and the new factory will take precedence over default ones.
     *
     * @param factory The CredentialFactory to register.
     */
    fun registerFactory(factory: CredentialFactory) {
        if (customFactories.containsKey(factory.format)) {
            Logger.info("($TAG) Warning: Custom factory for prefix '${factory.format}' is being overridden.")
        } else if (defaultDeserializer.containsKey(factory.format)) {
            Logger.info("($TAG) Info: Custom factory for prefix '${factory.format}' will shadow a default deserializer.")
        }
        customFactories[factory.format] = factory
    }

    /**
     * Deserializes a Credential from the raw data received after being issued.
     * It first checks registered custom factories, then default deserializers.
     * If no specific handler is found, null is returned.
     *
     * @param record The credential record stored after being issued to the wallet.
     * @return A subtype of Credential or null
     */
    fun deserialize(record: CredentialRecord): Credential? {

        // 1. Try custom factories first
        customFactories[record.format]?.let { factory ->
            return factory.createCredential(record.data)
        }

        // 2. Try default deserializers
        defaultDeserializer[record.format]?.let { deserializer ->
            return deserializer.createCredential(record.data)
        }

        // 3. Fallback to a generic credential
        Logger.info("($TAG) Info: No specific factory found for format '${record.format}'. Returning null")
        return null
    }
}