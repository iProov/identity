package com.iproov.identity.models

import java.security.MessageDigest
import java.security.SecureRandom

actual fun generateRandomBytes(length: Int): ByteArray {
    val random = SecureRandom()
    val bytes = ByteArray(length)
    random.nextBytes(bytes)
    return bytes
}

actual fun hash(data: ByteArray): ByteArray {
    val sha256Digest = MessageDigest.getInstance("SHA-256")
    return sha256Digest.digest(data)
}