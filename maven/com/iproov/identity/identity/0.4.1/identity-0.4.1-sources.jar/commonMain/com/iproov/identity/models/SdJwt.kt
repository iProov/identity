package com.iproov.identity.models

import com.iproov.identity.Logger
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.native.HiddenFromObjC

/**
 * SD-JWT (Selective Disclosure JWT) parser and utilities.
 *
 * SD-JWT structure: <Issuer-JWT>~<Disclosure1>~<Disclosure2>~...~[<KB-JWT>]
 *
 * References:
 * - SD-JWT spec: https://datatracker.ietf.org/doc/html/draft-ietf-oauth-selective-disclosure-jwt
 * - SD-JWT-VC spec: https://datatracker.ietf.org/doc/html/draft-ietf-oauth-sd-jwt-vc
 */
@OptIn(ExperimentalEncodingApi::class, ExperimentalObjCRefinement::class)
class SdJwt private constructor(
    /** The original complete SD-JWT string */
    val raw: String,
    /** The issuer-signed JWT (first component) */
    val issuerJwt: String,
    /** Parsed disclosures as [salt, claim_name, claim_value] */
    val disclosures: List<Disclosure>,
    /** Key Binding JWT if present (last component after final ~) */
    val keyBindingJwt: String?
) {
    companion object {
        private val base64Url = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT_OPTIONAL)
        private val json = Json { ignoreUnknownKeys = true }

        /**
         * Parse an SD-JWT string into its components.
         *
         * @param sdJwtString The complete SD-JWT string
         * @return Parsed SdJwt instance
         * @throws IllegalArgumentException if the format is invalid
         */
        fun parse(sdJwtString: String): SdJwt {
            require(sdJwtString.isNotBlank()) { "SD-JWT string cannot be blank" }

            // Split by ~ delimiter
            val parts = sdJwtString.split("~")
            require(parts.isNotEmpty()) { "Invalid SD-JWT format" }

            val issuerJwt = parts[0]
            require(issuerJwt.count { it == '.' } == 2) {
                "Invalid issuer JWT format - expected 3 parts separated by dots"
            }

            // Parse disclosures (middle parts)
            val disclosureParts = if (parts.size > 1) {
                // Check if last part is a KB-JWT (contains dots) or empty
                val lastPart = parts.last()
                if (lastPart.isEmpty() || lastPart.count { it == '.' } == 2) {
                    // Last part is KB-JWT or trailing ~, disclosures are in between
                    parts.subList(1, parts.size - 1)
                } else {
                    // No KB-JWT, all remaining parts are disclosures
                    parts.subList(1, parts.size)
                }
            } else {
                emptyList()
            }

            val disclosures = disclosureParts
                .filter { it.isNotBlank() }
                .map { Disclosure.parse(it) }

            // Check for KB-JWT (last non-empty part that looks like a JWT)
            val keyBindingJwt = if (parts.size > 1) {
                val lastPart = parts.last()
                if (lastPart.isNotEmpty() && lastPart.count { it == '.' } == 2) {
                    lastPart
                } else {
                    null
                }
            } else {
                null
            }

            return SdJwt(
                raw = sdJwtString,
                issuerJwt = issuerJwt,
                disclosures = disclosures,
                keyBindingJwt = keyBindingJwt
            )
        }
    }

    /** Decoded header of the issuer JWT */
    @HiddenFromObjC
    val header: JsonObject by lazy {
        val headerB64 = issuerJwt.split(".")[0]
        val headerBytes = base64Url.decode(headerB64)
        json.decodeFromString<JsonObject>(headerBytes.decodeToString())
    }

    /** Decoded payload of the issuer JWT (contains _sd arrays and disclosed claims) */
    @HiddenFromObjC
    val payload: JsonObject by lazy {
        val payloadB64 = issuerJwt.split(".")[1]
        val payloadBytes = base64Url.decode(payloadB64)
        json.decodeFromString<JsonObject>(payloadBytes.decodeToString())
    }

    /** The signature of the issuer JWT */
    val signature: String by lazy {
        issuerJwt.split(".")[2]
    }

    /**
     * Verifiable Credential Type (vct) - required for SD-JWT-VC
     * This identifies the type of credential (e.g., "IdentityCredential")
     */
    val vct: String? by lazy {
        payload["vct"]?.jsonPrimitive?.content
    }

    /** Issuer identifier (iss claim) */
    val issuer: String? by lazy {
        payload["iss"]?.jsonPrimitive?.content
    }

    /** Subject identifier (sub claim) */
    val subject: String? by lazy {
        payload["sub"]?.jsonPrimitive?.content
    }

    /** Issued at timestamp (iat claim) */
    val issuedAt: Long? by lazy {
        payload["iat"]?.jsonPrimitive?.content?.toLongOrNull()
    }

    /** Expiration timestamp (exp claim) */
    val expiration: Long? by lazy {
        payload["exp"]?.jsonPrimitive?.content?.toLongOrNull()
    }

    /**
     * Confirmation claim (cnf) - contains holder's public key for key binding.
     * If present, key binding is required during presentation.
     */
    @HiddenFromObjC
    val confirmationKey: JsonObject? by lazy {
        payload["cnf"]?.jsonObject
    }

    /** Whether this SD-JWT requires key binding for presentation */
    val requiresKeyBinding: Boolean by lazy {
        confirmationKey != null
    }

    /**
     * Get all claims by combining the payload with disclosed values.
     * This recursively resolves _sd arrays and replaces them with actual claim values.
     */
    @HiddenFromObjC
    fun getAllClaims(): JsonObject {
        return resolveDisclosures(payload, disclosures)
    }

    /**
     * Create a presentation with only the specified claims disclosed.
     *
     * @param claimNames Set of claim names to include in the presentation
     * @param keyBindingJwtFactory Optional factory to create KB-JWT (required if cnf is present)
     * @return SD-JWT presentation string with only selected disclosures
     */
    fun createPresentation(
        claimNames: Set<String>,
        keyBindingJwtFactory: ((nonce: String, audience: String, sdJwtHash: String) -> String)? = null,
        nonce: String? = null,
        audience: String? = null
    ): String {
        // Filter disclosures to only include requested claims
        val selectedDisclosures = disclosures.filter { it.claimName in claimNames }

        // Build the presentation: issuerJwt~disclosure1~disclosure2~...~
        val presentationBuilder = StringBuilder(issuerJwt)
        selectedDisclosures.forEach { disclosure ->
            presentationBuilder.append("~")
            presentationBuilder.append(disclosure.encoded)
        }
        presentationBuilder.append("~")

        // Add KB-JWT if required
        if (requiresKeyBinding) {
            requireNotNull(keyBindingJwtFactory) {
                "Key binding is required but no KB-JWT factory provided"
            }
            requireNotNull(nonce) { "Nonce is required for key binding" }
            requireNotNull(audience) { "Audience is required for key binding" }

            val sdJwtHash = computeSdJwtHash(presentationBuilder.toString())
            val kbJwt = keyBindingJwtFactory(nonce, audience, sdJwtHash)
            presentationBuilder.append(kbJwt)
        }

        return presentationBuilder.toString()
    }

    /**
     * Compute the SD-JWT hash for key binding.
     * This is SHA-256 hash of the SD-JWT presentation (without KB-JWT), base64url encoded.
     */
    private fun computeSdJwtHash(sdJwtPresentation: String): String {
        val hashBytes = hash(sdJwtPresentation.encodeToByteArray())
        return base64Url.encode(hashBytes)
    }

    /**
     * Resolve _sd arrays in a JSON object by replacing disclosure hashes with actual values.
     */
    private fun resolveDisclosures(obj: JsonObject, disclosures: List<Disclosure>): JsonObject {
        val disclosureMap = disclosures.associateBy { it.hash }
        return resolveObject(obj, disclosureMap)
    }

    private fun resolveObject(obj: JsonObject, disclosureMap: Map<String, Disclosure>): JsonObject {
        val result = mutableMapOf<String, JsonElement>()

        for ((key, value) in obj) {
            if (key == "_sd") {
                // Process _sd array - these are hashes of disclosures
                val sdArray = value.jsonArray
                for (hashElement in sdArray) {
                    val hash = hashElement.jsonPrimitive.content
                    disclosureMap[hash]?.let { disclosure ->
                        result[disclosure.claimName] = disclosure.claimValue
                    }
                }
            } else if (key == "_sd_alg") {
                // Skip the algorithm indicator
                continue
            } else {
                // Recursively resolve nested objects
                result[key] = when (value) {
                    is JsonObject -> resolveObject(value, disclosureMap)
                    is JsonArray -> resolveArray(value, disclosureMap)
                    else -> value
                }
            }
        }

        return JsonObject(result)
    }

    private fun resolveArray(arr: JsonArray, disclosureMap: Map<String, Disclosure>): JsonArray {
        return JsonArray(arr.map { element ->
            when (element) {
                is JsonObject -> {
                    // Check for array element disclosure marker {"...": "<hash>"}
                    if (element.size == 1 && element.containsKey("...")) {
                        val hash = element["..."]?.jsonPrimitive?.content
                        disclosureMap[hash]?.claimValue ?: element
                    } else {
                        resolveObject(element, disclosureMap)
                    }
                }
                is JsonArray -> resolveArray(element, disclosureMap)
                else -> element
            }
        })
    }
}

/**
 * Represents a single disclosure in an SD-JWT.
 *
 * Disclosure format: base64url([salt, claim_name, claim_value])
 */
@OptIn(ExperimentalEncodingApi::class, ExperimentalObjCRefinement::class)
data class Disclosure(
    /** The original base64url-encoded disclosure string */
    val encoded: String,
    /** Random salt value */
    val salt: String,
    /** Name of the disclosed claim */
    val claimName: String,
    /** Value of the disclosed claim */
    @HiddenFromObjC
    val claimValue: JsonElement,
    /** SHA-256 hash of the encoded disclosure (used in _sd arrays) */
    val hash: String
) {
    companion object {
        private val base64Url = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT_OPTIONAL)
        private val json = Json { ignoreUnknownKeys = true }

        /**
         * Parse a base64url-encoded disclosure string.
         */
        fun parse(encoded: String): Disclosure {
            val decoded = base64Url.decode(encoded).decodeToString()
            val array = json.decodeFromString<JsonArray>(decoded)

            require(array.size >= 2) { "Disclosure must have at least salt and claim name" }

            val salt = array[0].jsonPrimitive.content
            val claimName = array[1].jsonPrimitive.content
            val claimValue = if (array.size > 2) array[2] else JsonPrimitive("")

            // Compute hash for matching with _sd array
            val hashBytes = hash(encoded.encodeToByteArray())
            val hashB64 = base64Url.encode(hashBytes)

            return Disclosure(
                encoded = encoded,
                salt = salt,
                claimName = claimName,
                claimValue = claimValue,
                hash = hashB64
            )
        }
    }
}
