package com.iproov.identity.api

import com.iproov.identity.KeyPairFactory
import com.iproov.identity.models.CredentialDescriptor
import com.iproov.identity.models.CredentialOffer
import com.iproov.identity.models.OID4VCICredentialError
import kotlinx.serialization.json.JsonObject

/**
 * Opaque state from the authorization code flow preparation step.
 * Contains platform-specific state (PKCE verifier, issuer reference, etc.)
 * needed to complete authorization after the user authenticates.
 *
 * **Important:** This object must be retained in memory between
 * [OID4VCIClient.prepareAuthorizationRequest] and [OID4VCIClient.issueCredentialsWithAuthCode].
 * It is session-specific and cannot be serialized or recreated.
 */
data class AuthorizationPreparation(
    val authorizationUrl: String,
    internal val platformState: Any,
)

/**
 * Platform-agnostic interface for OID4VCI operations.
 *
 * This interface abstracts the underlying OID4VCI library implementation,
 * allowing different platforms (iOS, Android) to use their native libraries
 * while maintaining a consistent API for the orchestrator.
 */
interface OID4VCIClient {
    /**
     * Resolve a credential offer from a URI.
     *
     * @param uri The credential offer URI (openid-credential-offer://...)
     * @return The resolved credential offer with issuer metadata and available credentials
     * @throws com.iproov.identity.models.OID4VCIException on failure
     */
    @Throws(Exception::class)
    suspend fun resolveOffer(uri: String): CredentialOffer

    /**
     * Resolve a credential offer from a JSON object.
     *
     * @param json The credential offer as a JSON object
     * @return The resolved credential offer with issuer metadata and available credentials
     * @throws com.iproov.identity.models.OID4VCIException on failure
     */
    @Throws(Exception::class)
    suspend fun resolveOffer(json: JsonObject): CredentialOffer

    /**
     * Issue credentials using the pre-authorized code flow.
     *
     * @param offer The resolved credential offer
     * @param credentials The credential configurations to request
     * @param transactionCode Optional PIN/transaction code if required by the offer
     * @return Result containing issued credentials and any per-credential errors
     * @throws com.iproov.identity.models.OID4VCIException on critical failure
     */
    @Throws(Exception::class)
    suspend fun issueCredentials(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
        transactionCode: String? = null
    ): OID4VCIIssuanceResult

    /**
     * Prepare an authorization request for the authorization code flow.
     * Returns the URL to redirect the user to and opaque platform state needed
     * to complete the flow after the user authenticates.
     *
     * @param offer The resolved credential offer (must have authorization_code grant)
     * @param credentials The credential configurations selected by the user
     * @return Preparation containing the authorization URL and platform state
     * @throws com.iproov.identity.models.OID4VCIException on failure
     */
    @Throws(Exception::class)
    suspend fun prepareAuthorizationRequest(
        offer: CredentialOffer,
        credentials: List<CredentialDescriptor>,
    ): AuthorizationPreparation

    /**
     * Issue credentials using the authorization code flow.
     * Call this after the user has authenticated and you have received the authorization code
     * and state from the redirect.
     *
     * @param offer The resolved credential offer
     * @param authorizationCode The authorization code from the redirect
     * @param authorizationState The state from the redirect, used to validate the authorization response
     * @param preparation The preparation from [prepareAuthorizationRequest]
     * @param credentials The credential configurations to request
     * @return Result containing issued credentials and any per-credential errors
     * @throws com.iproov.identity.models.OID4VCIException on critical failure
     */
    @Throws(Exception::class)
    suspend fun issueCredentialsWithAuthCode(
        offer: CredentialOffer,
        authorizationCode: String,
        authorizationState: String,
        preparation: AuthorizationPreparation,
        credentials: List<CredentialDescriptor>,
    ): OID4VCIIssuanceResult
}

/**
 * Result of credential issuance operation.
 */
data class OID4VCIIssuanceResult(
    /**
     * Successfully issued credentials.
     * Each entry represents a single issued credential dataset, potentially
     * multiple per credential configuration when credential_identifiers are used.
     */
    val credentials: List<IssuedCredentialData>,

    /**
     * Errors for credentials that failed to issue.
     */
    val errors: List<IssuanceError>,

    /**
     * c_nonce from the response (for potential retry with new nonce)
     */
    val cNonce: String? = null
)

/**
 * Data for a single issued credential.
 */
data class IssuedCredentialData(
    /**
     * The credential configuration ID this credential was issued for.
     */
    val configurationId: String,

    /**
     * The credential_identifier used to request this credential, if any.
     * Present when the token response included credential_identifiers.
     */
    val credentialIdentifier: String? = null,

    /**
     * The credential format (e.g., "mso_mdoc", "dc+sd-jwt")
     */
    val format: String,

    /**
     * Raw credential data (JWT string, CBOR base64, etc.)
     */
    val rawCredential: String,

    /**
     * Whether this is a deferred credential
     */
    val isDeferred: Boolean = false,

    /**
     * Notification ID for issuer notification endpoint
     */
    val notificationId: String? = null
)

/**
 * Error for a single credential issuance attempt.
 */
data class IssuanceError(
    /**
     * The credential configuration ID this error relates to.
     */
    val configurationId: String,

    /**
     * The credential_identifier that failed, if any.
     */
    val credentialIdentifier: String? = null,

    /**
     * The error details.
     */
    val error: OID4VCICredentialError,
)

/**
 * Factory function to create platform-specific OID4VCIClient.
 */
expect fun createOID4VCIClient(
    keyPairFactory: KeyPairFactory,
    networkClient: NetworkClient
): OID4VCIClient
