package com.iproov.identity.models

val Jwt.name get() = this.name