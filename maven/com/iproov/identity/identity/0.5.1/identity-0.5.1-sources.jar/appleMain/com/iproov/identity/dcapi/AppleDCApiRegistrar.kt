package com.iproov.identity.dcapi

import com.iproov.identity.DCApiRegistrationBridge
import com.iproov.identity.Logger
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.docType
import com.iproov.identity.models.id
import com.iproov.identity.models.vct
import kotlinx.cinterop.ExperimentalForeignApi

/**
 * Apple/iOS implementation of DCApiRegistrar using IdentityDocumentServices framework.
 *
 * This class registers credentials with iOS so they can be discovered and presented
 * when apps/browsers request credentials via the Digital Credentials API.
 *
 * Requirements:
 * - iOS 26+
 * - IdentityDocumentServices framework
 * - Apple entitlement for production use (com.apple.developer.identity-document-provider or similar)
 *
 * Note: The consumer app must create an "Identity Document Provider" app extension.
 * This SDK provides Swift classes the extension can call.
 */
@OptIn(ExperimentalForeignApi::class)
class AppleDCApiRegistrar : DCApiRegistrar {

    val bridge by lazy { DCApiRegistrationBridge() }

    override suspend fun registerCredentials(credentials: List<CredentialRegistrationInfo>) {}

    override suspend fun registerCredential(metadata: CredentialMetadata) {
        if (!isAvailable()) {
            Logger.debug("DC API not available on this iOS version, skipping registration")
            return
        }

        try {
            Logger.debug("Registering credential for DC API: ${metadata.id}")

            // Get display information from the first display entry
            val displayName = metadata.display.firstOrNull()?.name ?: "Credential"

            when {
                metadata.docType != null -> {
                    // mDoc credential
                    DCApiRegistrationBridge.registerMDocCredentialWithCredentialId(
                        credentialId = metadata.id,
                        docType = metadata.docType!!,
                        displayName = displayName
                    )
                }

                metadata.vct != null -> {
                    // SD-JWT-VC credential
                    DCApiRegistrationBridge.registerSdJwtVcCredentialWithCredentialId(
                        credentialId = metadata.id,
                        vct = metadata.vct!!,
                        displayName = displayName
                    )
                }

                else -> {
                    Logger.error("Unknown credential format for DC API registration: ${metadata.id}")
                }
            }

            Logger.info("Successfully registered credential ${metadata.id} for DC API")
        } catch (e: Exception) {
            Logger.error("Failed to register credential for DC API: ${e.message}")
            // Silently fail - DC API registration is optional functionality
        }
    }

    override suspend fun unregisterCredential(credentialId: String) {
        if (!isAvailable()) {
            Logger.debug("DC API not available on this iOS version, skipping unregistration")
            return
        }

        try {
            Logger.debug("Unregistering credential from DC API: $credentialId")
            DCApiRegistrationBridge.unregisterCredentialWithCredentialId(credentialId = credentialId)
            Logger.info("Successfully unregistered credential $credentialId from DC API")
        } catch (e: Exception) {
            Logger.error("Failed to unregister credential from DC API: ${e.message}")
        }
    }

    override fun isAvailable(): Boolean {
        return try {
            DCApiRegistrationBridge.isAvailable()
        } catch (e: Exception) {
            false
        }
    }

    override fun isCredentialRegistered(credentialId: String): Boolean {
        if (!isAvailable()) return false
        return try {
            DCApiRegistrationBridge.isCredentialRegisteredWithCredentialId(credentialId = credentialId)
        } catch (e: Exception) {
            Logger.error("Failed to check DC API registration status: ${e.message}")
            false
        }
    }
}
