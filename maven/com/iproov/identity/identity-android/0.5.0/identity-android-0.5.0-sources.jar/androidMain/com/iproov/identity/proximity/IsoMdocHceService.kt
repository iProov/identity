package com.iproov.identity.proximity

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import com.iproov.identity.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import org.multipaz.mdoc.nfc.MdocNfcEngagementHelper
import org.multipaz.nfc.CommandApdu
import org.multipaz.nfc.Nfc
import org.multipaz.nfc.ResponseApdu
import kotlin.coroutines.cancellation.CancellationException

abstract class IsoMdocHceService : HostApduService() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private sealed class Event {
        data class Apdu(val cmd: CommandApdu) : Event()
        data class Deactivated(val reason: Int) : Event()
    }

    private val channel = Channel<Event>(Channel.UNLIMITED)

    @Volatile
    private var helper: MdocNfcEngagementHelper? = null

    @Volatile
    private var currentHandler: NfcEngagementHandler? = null

    // Tracks the synchronous SELECT APPLICATION fast-path; see processCommandApdu().
    @Volatile
    private var numApdusReceived = 0

    @Volatile
    private var firstCommandApdu: CommandApdu? = null

    override fun onCreate() {
        super.onCreate()
        scope.launch {
            for (event in channel) {
                try {
                    when (event) {
                        is Event.Apdu -> handleApdu(event.cmd)
                        is Event.Deactivated -> handleDeactivated(event.reason)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    Logger.debug("HCE event processing raised: ${e.message}")
                    currentHandler?.takeIf { !it.isComplete }?.abort(e)
                    clearActiveEngagement()
                }
            }
        }
    }

    override fun processCommandApdu(bytes: ByteArray, extras: Bundle?): ByteArray? {
        val cmd = try {
            CommandApdu.decode(bytes)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Logger.error("APDU decode failed ${e.message}")
            return ResponseApdu(Nfc.RESPONSE_STATUS_ERROR_FILE_OR_APPLICATION_NOT_FOUND).encode()
        }

        // Android routes the NDEF AID to the system Wallet Role Owner (e.g. Google/Samsung
        // Wallet) unless the first SELECT APPLICATION gets a synchronous 9000. Replayed
        // through the helper in handleApdu().
        if (numApdusReceived == 0) {
            numApdusReceived = 1
            firstCommandApdu = cmd
            return ResponseApdu(status = Nfc.RESPONSE_STATUS_SUCCESS).encode()
        }
        channel.trySend(Event.Apdu(cmd))
        return null
    }

    override fun onDeactivated(reason: Int) {
        Logger.debug("onDeactivated reason=$reason")

        // Reset per-tap state synchronously so the next tap's fast-path fires even
        // if the channel coroutine is suspended on processApdu().
        numApdusReceived = 0
        firstCommandApdu = null

        val activeHelper = helper
        scope.launch {
            try {
                activeHelper?.processDeactivated(reason)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Logger.debug("Out-of-channel processDeactivated raised: ${e.message}")
            }
        }
        channel.trySend(Event.Deactivated(reason))
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        channel.close()
    }

    private suspend fun handleApdu(cmd: CommandApdu) {
        val activeHelper = helper ?: run {
            val handler = NfcEngagementRegistry.current()
            if (handler == null || handler.isComplete) {
                sendResponseApdu(
                    ResponseApdu(Nfc.RESPONSE_STATUS_ERROR_FILE_OR_APPLICATION_NOT_FOUND).encode()
                )
                return
            }
            currentHandler = handler
            buildHelper(handler).also { newHelper ->
                helper = newHelper
                firstCommandApdu?.let { first ->
                    try {
                        val replayed = newHelper.processApdu(first)
                        if (replayed != ResponseApdu(status = Nfc.RESPONSE_STATUS_SUCCESS)) {
                            Logger.debug(
                                "Expected 9000 from helper for replayed first APDU, got $replayed"
                            )
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        Logger.debug("Replay of first APDU raised: ${e.message}")
                    }
                }
            }
        }
        val response = activeHelper.processApdu(cmd)
        sendResponseApdu(response.encode())
    }

    private suspend fun handleDeactivated(reason: Int) {
        currentHandler?.takeIf { !it.isComplete }?.abort(
            IllegalStateException("NFC reader left the field during handover (reason=$reason)")
        )
        resetEngagementState()
    }

    private fun resetEngagementState() {
        clearActiveEngagement()
        numApdusReceived = 0
    }

    private fun clearActiveEngagement() {
        helper = null
        currentHandler = null
        firstCommandApdu = null
    }

    private fun buildHelper(handle: NfcEngagementHandler): MdocNfcEngagementHelper =
        MdocNfcEngagementHelper(
            eDeviceKey = handle.eDeviceKey.publicKey,
            onHandoverComplete = { methods, engagementBytes, handover ->
                handle.completeHandover(methods, engagementBytes, handover)
            },
            onError = { error ->
                handle.abort(error)
            },
            staticHandoverMethods = null,
            negotiatedHandoverPicker = handle.negotiatedPicker,
        )
}
