package com.iproov.identity

import platform.Foundation.NSBundle
import platform.Foundation.version
import platform.UIKit.UIDevice


/**
 * Whether this binary was compiled for the iOS simulator.
 *
 * Deliberately resolved at compile time from the per-target source sets rather than sniffed at
 * runtime: `isVirtual` gates the attestation fallback, so a device build must not be *able* to
 * report `true`. Because iosArm64 and iosSimulatorArm64 are separate targets shipping as separate
 * xcframework slices, the device slice cannot contain the simulator value at all.
 */
internal expect val isSimulatorBuild: Boolean

class ApplePlatform(instanceId: String) : Platform {

    override val isVirtual: Boolean = isSimulatorBuild

    override val target: Platform.Target by lazy { Platform.Target.IOS }

    override val appInfo: AppInfo = AppInfo(
        NSBundle.mainBundle.bundleIdentifier
            ?: throw IllegalStateException("Failed to get bundle identifier"),
        NSBundle.version().toString(),
    )

    override val deviceInfo: DeviceInfo = DeviceInfo(
        manufacturer = "Apple",
        model = UIDevice.currentDevice.model,
        osversion = UIDevice.currentDevice.systemVersion,
        os = "iOS",
        instanceId = instanceId
    )

}

