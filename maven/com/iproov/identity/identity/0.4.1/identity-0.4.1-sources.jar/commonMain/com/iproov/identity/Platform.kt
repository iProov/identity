package com.iproov.identity

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val os: String,
    val osversion: String,

    @SerialName("id")
    val instanceId: String
)

@Serializable
data class AppInfo(
    val client: String,
    val version: String,
)

interface Platform {
    enum class Target {
        IOS,
        Android
    }

    val target: Target

    val appInfo: AppInfo

    val deviceInfo: DeviceInfo

    val isVirtual: Boolean
}