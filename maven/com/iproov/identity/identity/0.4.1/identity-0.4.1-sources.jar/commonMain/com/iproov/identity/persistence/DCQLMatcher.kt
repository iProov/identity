package com.iproov.identity.persistence

import com.iproov.identity.Logger
import com.iproov.identity.models.ClaimQuery
import com.iproov.identity.models.Credential
import com.iproov.identity.models.CredentialMetadata
import com.iproov.identity.models.CredentialQuery
import com.iproov.identity.models.CredentialQueryMatchResult
import com.iproov.identity.models.CredentialSetQuery
import com.iproov.identity.models.DcqlQuery
import com.iproov.identity.models.MDocCredential
import com.iproov.identity.models.SdJwtVcCredential
import com.iproov.identity.models.toNativeTypes

data class DisclosedCredential(
    val credential: Credential,
    val claims: Set<ClaimQuery>
)

data class CredentialSubmission(
    val disclosedCredentials: Map<CredentialQuery, DisclosedCredential>,
    val matchResult: DCQLMatchResult
)

/**
 * Captures which options within a single CredentialSetQuery are satisfiable
 * given the available credential candidates.
 *
 * @property query The original Credential Set Query from the DCQL request.
 * @property satisfiedOptions The subset of [query].options where every referenced
 *           Credential Query has at least one matching candidate.
 */
data class CredentialSetMatchResult(
    val query: CredentialSetQuery,
    val satisfiedOptions: List<List<String>>
) {
    val isSatisfied: Boolean
        get() = satisfiedOptions.isNotEmpty()
}

data class DCQLMatchResult(
    /** Map from CredentialQuery -> list of credential candidates that fully satisfy that query */
    val credentials: Map<CredentialQuery, List<CredentialQueryMatchResult>>,

    /** Per-CredentialSetQuery match results showing which options are satisfiable */
    val satisfiedSets: List<CredentialSetMatchResult>
) {
    override fun toString(): String {
        val sb = StringBuilder()
        credentials.entries.map {
            sb.append("CredentialQuery id='${it.key.id}' format=${it.key.format} -> ${it.value.size} matching credentials\n")
            it.value.forEach { match ->
                sb.append("    - Credential id='${match.metadata.uuid}'\n")
                match.matchingClaims.entries.forEach { cl ->
                    sb.append("      * Claim id='${cl.key.id}' at path=${cl.key.path} -> value='${cl.value}'\n")
                }
            }
        }
        sb.append("Credential sets: ${satisfiedSets.size}\n")
        satisfiedSets.forEach { result ->
            val status = if (result.isSatisfied) "SATISFIED" else "NOT SATISFIED"
            val requiredLabel = if (result.query.required) "required" else "optional"
            sb.append("  - [$requiredLabel] $status (${result.satisfiedOptions.size}/${result.query.options.size} options)\n")
            result.satisfiedOptions.forEach { option ->
                sb.append("      option: ${option.joinToString(", ")}\n")
            }
        }

        return sb.toString()
    }

    val isEmpty: Boolean
        get() = credentials.isEmpty()

    /**
     * True when every required CredentialSetQuery has at least one satisfiable option.
     * If no credential_sets were present in the query this returns true (per Section 6.4.2,
     * the Verifier requests all credentials in `credentials` to be returned).
     */
    val allRequiredSetsSatisfied: Boolean
        get() = satisfiedSets
            .filter { it.query.required }
            .all { it.isSatisfied }

    /**
     * Whether a given credential query is required for submission.
     *
     * - When [credentialSets] is null/empty, ALL queries are required (Section 6.4.2).
     * - Otherwise, the query is required if it appears in any option of any **required**
     *   credential set that is satisfiable.
     */
    fun isQueryRequired(queryId: String, credentialSets: List<CredentialSetQuery>?): Boolean {
        if (credentialSets.isNullOrEmpty()) return true
        return satisfiedSets
            .filter { it.query.required && it.isSatisfied }
            .any { setResult ->
                setResult.satisfiedOptions.any { option -> queryId in option }
            }
    }

    /**
     * Whether all required credential sets are covered by the user's current selections.
     *
     * - When [credentialSets] is null/empty, all credential query IDs must be selected.
     * - Otherwise, every required set must be satisfiable and, for each required set,
     *   at least one satisfiable option must have all its query IDs in [selectedQueryIds].
     */
    fun allRequiredSetsCoveredBySelections(
        credentialSets: List<CredentialSetQuery>?,
        selectedQueryIds: Set<String>
    ): Boolean {
        if (credentialSets.isNullOrEmpty()) {
            return credentials.keys.all { it.id in selectedQueryIds }
        }
        return satisfiedSets
            .filter { it.query.required }
            .all { setResult ->
                if (!setResult.isSatisfied) return@all false
                setResult.satisfiedOptions.any { option ->
                    option.all { it in selectedQueryIds }
                }
            }
    }

    /**
     * Returns query IDs that still need a credential selection to satisfy required sets.
     *
     * - When [credentialSets] is null/empty, returns all query IDs not yet selected.
     * - Otherwise:
     *   - for an unsatisfied required set, returns the referenced query IDs as blockers
     *   - for a satisfiable but uncovered required set, suggests the first satisfiable
     *     option's missing IDs.
     */
    fun missingSelectionsForRequiredSets(
        credentialSets: List<CredentialSetQuery>?,
        selectedQueryIds: Set<String>
    ): Set<String> {
        if (credentialSets.isNullOrEmpty()) {
            return credentials.keys.map { it.id }.filter { it !in selectedQueryIds }.toSet()
        }
        val missing = mutableSetOf<String>()
        satisfiedSets
            .filter { it.query.required }
            .forEach { setResult ->
                if (!setResult.isSatisfied) {
                    missing += setResult.query.options
                        .flatten()
                        .filter { it !in selectedQueryIds }
                    return@forEach
                }
                val alreadyCovered = setResult.satisfiedOptions.any { option ->
                    option.all { it in selectedQueryIds }
                }
                if (!alreadyCovered) {
                    // Suggest the first satisfiable option's missing IDs
                    val bestOption = setResult.satisfiedOptions.firstOrNull() ?: return@forEach
                    missing += bestOption.filter { it !in selectedQueryIds }
                }
            }
        return missing
    }
}

/**
 * Matches a DCQL query a set of credentials
 */
class DCQLMatcher(
    private val repository: Repository,

    // TODO: Add trust store to verify the verifier / relying party
) {
    suspend fun match(query: DcqlQuery): DCQLMatchResult {
        val credentialsByFormat = getCredentials().entries.groupBy { it.key.format }
        val credentialsForQuery: MutableMap<CredentialQuery, List<CredentialQueryMatchResult>> =
            linkedMapOf()

        for (credentialQuery in query.credentials) {
            val qMeta = credentialQuery.meta?.toNativeTypes()?.let { it as Map<String, Any>? }

            val pool = credentialsByFormat[credentialQuery.format].orEmpty()
                .filter { fmtMetaOk(it.value, qMeta) }
                .filter { authoritiesOk(it.key, credentialQuery.trustedAuthorities) }
                .filter {
                    holderBindingOk(it.value, credentialQuery.requireCryptographicHolderBinding)
                }

            Logger.debug("DCQLMatcher: CredentialQuery id='${credentialQuery.id}' has ${pool.size} candidates after format/meta/trust/PoP filtering")

            val matches = pool.mapNotNull { candidate ->
                val body = candidate.value.body.let { it as Map<String, Any?> }

                val res = claimsSatisfiedBySingleCredential(q = credentialQuery, body = body)

                if (res != null) CredentialQueryMatchResult(
                    metadata = candidate.key,
                    credential = candidate.value,
                    matchingClaims = res,
                ) else null
            }

            // Only include credentials that fully satisfy this query (no cross-credential mixing)
            // Per DCQL, a CredentialQuery’s claims/claim_sets must be satisfied by ONE credential. :contentReference[oaicite:2]{index=2}
            credentialsForQuery[credentialQuery] = matches
        }

        val satisfiedSets =
            computeSatisfiedSets(
                query.credentialSets,
                credentialsForQuery.entries.associate { e -> e.key.id to e.value })

        return DCQLMatchResult(credentialsForQuery, satisfiedSets)
    }


    fun validateSubmission(submission: CredentialSubmission, credentialSets: List<CredentialSetQuery>?) {
        // Check that all the selected credentials are indeed in the match result
        submission.disclosedCredentials.forEach { (query, disclosedCredential) ->
            val matches = submission.matchResult.credentials[query]
                ?: error("No matching credentials for query id='${query.id}' in the match result")
            val selectedCredential = matches.firstOrNull { match ->
                // Find the match that corresponds to the selected credential
                match.metadata.uuid == submission.matchResult.credentials[query]?.firstOrNull()?.metadata?.uuid
            } ?: error("Selected credential for query id='${query.id}' is not in the match result")

            // Check that all selected claims are indeed satisfied by the selected credential
            disclosedCredential.claims.forEach { claim ->
                if (claim !in selectedCredential.matchingClaims.keys) {
                    error("Selected claim id='${claim.id}' for query id='${query.id}' is not satisfied by the selected credential")
                }
            }
        }

        // Check that all required credential sets are covered by the submission
        val submittedQueryIds = submission.disclosedCredentials.keys.map { it.id }.toSet()
        if (!submission.matchResult.allRequiredSetsCoveredBySelections(credentialSets, submittedQueryIds)) {
            error("Submission does not satisfy all required credential sets")
        }
    }


    private fun fmtMetaOk(
        credential: Credential, credentialQueryMetadata: Map<String, Any>?
    ): Boolean {
        if (credentialQueryMetadata.isNullOrEmpty()) return true
        // Minimal pragmatic filters; extend per format:
        // - mso_mdoc: meta["doctype_value"] must be in namespaces or explicit doctype reading
        // - dc+sd-jwt: meta["vct_values"] must match the credential's vct
        // - jwt_vc_json / ldp_vc: meta["type_values"] (list of list) -> at least one array is subset of VC.type
        return when (credential) {
            is MDocCredential -> {
                val doc = credentialQueryMetadata["doctype_value"]?.toString()
                doc == null || credential.nameSpaces.contains(doc.substringBeforeLast('.')) || credential.nameSpaces.contains(
                    doc
                )
            }

            is SdJwtVcCredential -> {
                // For SD-JWT-VC, check if vct matches any of the requested vct_values
                @Suppress("UNCHECKED_CAST")
                val vctValues = credentialQueryMetadata["vct_values"] as? List<String>
                vctValues == null || credential.vct in vctValues
            }
        }
    }

    /**
     * Checks that the credential was issued by ONE of the trusted issuer authorities.
     */
    private fun authoritiesOk(meta: CredentialMetadata, trusted: List<String>?): Boolean {
        if (trusted.isNullOrEmpty()) return true
        return trusted.any { meta.issuer.name == it }
    }

    /**
     * Checks the credential is bound to the holder.
     */
    private fun holderBindingOk(cred: Credential, required: Boolean?): Boolean {
        if (required != true) return true
        return when (cred) {
            is MDocCredential -> true // mDoc always has device binding via MSO
            is SdJwtVcCredential -> cred.requiresKeyBinding // SD-JWT-VC has cnf claim
        }
    }


    /**
     * Returns a map of ClaimQuery -> concrete value WHEN the single credential satisfies
     * this query (all required claims or one full claim_set). Otherwise null.
     */
    private fun claimsSatisfiedBySingleCredential(
        q: CredentialQuery, body: Map<String, Any?>
    ): Map<ClaimQuery, Any>? {
        val claims = q.claims.orEmpty()

        fun claimOk(cl: ClaimQuery): Pair<Boolean, Any?> {
            val value = valueAtPath(body, cl.path)
            if (value == null) return false to null
            val reqVals = cl.values
            if (!reqVals.isNullOrEmpty() && reqVals.none { it == value }) {
                return false to value
            }
            return true to value
        }

        Logger.debug("DCQLMatcher:   Evaluating ${claims.size} claims for CredentialQuery id='${q.id}'")

        // claim_sets present → must satisfy ANY ONE full set (all claims in that set) with this credential
        q.claimSets?.let { sets ->
            for (option in sets) {
                val map = linkedMapOf<ClaimQuery, Any>()
                var allOk = true
                for (id in option) {
                    val cl = claims.firstOrNull { it.id == id }
                        ?: run { allOk = false; break }
                    val (ok, v) = claimOk(cl)
                    if (!ok || v == null) {
                        allOk = false; break
                    }
                    map[cl] = v
                }
                if (allOk) return map
            }
            return null
        }

        // No claim_sets; if claims present → all are required
        if (claims.isNotEmpty()) {
            val map = linkedMapOf<ClaimQuery, Any>()
            for (cl in claims) {
                val (ok, v) = claimOk(cl)
                Logger.debug("DCQLMatcher:   ClaimQuery id='${cl.id}' at path=${cl.path} -> ok=$ok, value='$v'")
                if (!ok || v == null) return null
                map[cl] = v
            }
            return map
        }

        // No claims at all → accepting the credential based on format/meta/trust/PoP alone
        return emptyMap()
    }

    /** Very small “JSON path” using a list of keys; supports numeric array indices if the segment is an integer. */
    private fun valueAtPath(root: Any?, path: List<String>): Any? {
        var cur: Any? = root
        for (seg in path) {
            cur = when (cur) {
                is Map<*, *> -> cur[seg]
                is List<*> -> seg.toIntOrNull()?.let { idx -> cur.getOrNull(idx) }
                else -> return null
            }
        }
        return cur
    }


    private fun computeSatisfiedSets(
        credentialSets: List<CredentialSetQuery>?,
        perQuery: Map<String, List<CredentialQueryMatchResult>>
    ): List<CredentialSetMatchResult> {
        if (credentialSets.isNullOrEmpty()) return emptyList()
        return credentialSets.map { setQuery ->
            val matched = setQuery.options.filter { option ->
                option.all { qid -> !perQuery[qid].isNullOrEmpty() }
            }
            CredentialSetMatchResult(query = setQuery, satisfiedOptions = matched)
        }
    }

    private suspend fun getCredentials(): Map<CredentialMetadata, Credential> =
        repository.getCredentials(repository.getCredentialMetadata()).credentials
}
