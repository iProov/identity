package com.iproov.identity.persistence

import platform.Foundation.NSUbiquitousKeyValueStore

class ICloudKeyValueStorage : SyncedKeyValueStorage {

    private val keyValueStore = NSUbiquitousKeyValueStore.defaultStore

    init {
        keyValueStore.synchronize()
    }

    override fun read(key: String): String? {

        keyValueStore.synchronize() // Best effort sync request

        return keyValueStore.stringForKey(key)
    }

    override fun write(key: String, value: String?) {
        keyValueStore.setString(value, key)

        keyValueStore.synchronize() // Best effort sync request
    }

}

actual fun getSyncedKeyValueStorage(): SyncedKeyValueStorage = ICloudKeyValueStorage()