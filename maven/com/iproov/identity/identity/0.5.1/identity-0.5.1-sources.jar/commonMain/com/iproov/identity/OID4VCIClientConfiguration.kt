package com.iproov.identity

import com.iproov.identity.models.OID4VCIException

/**
 * Your app's OAuth client for OID4VCI issuance.
 *
 * [clientId] is sent as `client_id` by both grant types. [redirectUri] is only used by the
 * authorization code flow — the pre-authorized code flow makes no authorization request. Without
 * this configuration the SDK sends its own client ID (`identity-android-wallet` on Android,
 * `identity-ios-wallet` on iOS) for pre-authorized issuance, and `authorize()` throws.
 *
 * [redirectUri] must match a redirect URI registered for [clientId] at the authorization server,
 * and your app must be able to receive it: a `CFBundleURLSchemes` entry on iOS, an intent filter on
 * Android.
 *
 * The SDK only checks that [redirectUri] is a valid absolute URI. Pick the form yourself — RFC 8252
 * covers app-claimed HTTPS URIs, private-use schemes like `com.example.wallet:/oauth2redirect`, and
 * loopback URIs — based on what the issuer accepts.
 *
 * Both values are fixed for the life of the wallet. That is what the specs ask for: [clientId]
 * identifies your wallet build, not a registration with one authorization server. HAIP 1.0 Section
 * 4.4 requires it to be the `sub` of the Wallet Attestation, and OID4VCI 1.0 Section 15.4.4
 * requires that `sub` to be "a value that is shared by all Wallet instances using this type of
 * wallet implementation". The attestation changes per issuer; this string does not. Client
 * registration itself is out of scope of OID4VCI 1.0 Section 12.1.1, so if you pre-register
 * separately with independent authorization servers you need one wallet per registration.
 *
 * Values are checked when issuance starts, not here. A Kotlin exception thrown from the generated
 * Swift initializer would kill the app, so a bad value throws
 * [com.iproov.identity.models.OID4VCIException.CreatingAccessToken] from
 * [com.iproov.identity.models.RespondableCredentialOffer.authorize] instead.
 */
class OID4VCIClientConfiguration(
    val clientId: String,
    val redirectUri: String,
)

/** Thrown when `authorize()` is called on a wallet created without an [OID4VCIClientConfiguration]. */
class AuthorizationCodeFlowNotConfiguredException : Exception(
    "Authorization code flow is not configured. Create the wallet with an " +
        "OID4VCIClientConfiguration containing the app's client ID and redirect URI."
)

/** The client ID and redirect URI one grant type sends. */
internal data class OAuthClientSettings(
    val clientId: String,
    val redirectUri: String,
)

/**
 * Checks the app's configuration and returns what the authorization code flow should send.
 *
 * @throws AuthorizationCodeFlowNotConfiguredException when the wallet has no configuration.
 * @throws com.iproov.identity.models.OID4VCIException.CreatingAccessToken with error
 * `invalid_client_id` or `invalid_redirect_uri` when the configuration cannot build an
 * authorization request.
 */
internal fun OID4VCIClientConfiguration?.authorizationCodeFlowSettings(): OAuthClientSettings {
    val configuration = this ?: throw AuthorizationCodeFlowNotConfiguredException()

    if (configuration.clientId.isBlank()) {
        throw OID4VCIException.CreatingAccessToken(
            error = "invalid_client_id",
            description = "OID4VCI clientId must not be blank.",
        )
    }

    val redirectUri = configuration.redirectUri
    val problem = when {
        redirectUri.any(Char::isWhitespace) -> "must not contain whitespace"
        // RFC 6749 Section 3.1.2 forbids a fragment in a redirect URI.
        '#' in redirectUri -> "must not contain a fragment"
        !URI_SCHEME.matches(redirectUri.substringBefore(':', missingDelimiterValue = "")) ->
            "must be an absolute URI with a valid scheme, for example " +
                "\"com.example.wallet:/oauth2redirect\""
        redirectUri.substringAfter(':', missingDelimiterValue = "").isBlank() ->
            "must include an authority or path after its scheme"
        // Checked here rather than left to each platform's parser, which disagree: java.net.URI
        // rejects a bad escape and Foundation accepts it, then the authorization server rejects it.
        INVALID_PERCENT_ESCAPE.containsMatchIn(redirectUri) ->
            "must percent-encode with two hex digits after each \"%\""
        !isParsableUri(redirectUri) -> "must be a URI this platform can parse"
        else -> null
    }
    if (problem != null) {
        throw OID4VCIException.CreatingAccessToken(
            error = "invalid_redirect_uri",
            description = "Authorization code flow redirectUri $problem, but was \"$redirectUri\".",
        )
    }

    return OAuthClientSettings(
        clientId = configuration.clientId,
        redirectUri = redirectUri,
    )
}

/**
 * Returns what the pre-authorized code flow should send: the app's [OID4VCIClientConfiguration.clientId]
 * when it has one, otherwise [platformClientId].
 *
 * Never throws. Pre-authorized issuance must keep working even when the redirect URI configured for
 * the authorization code flow is unusable, so nothing here is validated beyond a blank client ID,
 * which falls back rather than putting an empty `client_id` on the wire.
 *
 * The redirect URI is [UNUSED_REDIRECT_URI]: this flow's token request sends only `client_id`,
 * `grant_type`, `pre-authorized_code` and `tx_code` — OID4VCI 1.0 Section 6.1 defines no
 * `redirect_uri` for it — but both platforms' config types demand a URI.
 */
internal fun OID4VCIClientConfiguration?.preAuthorizedCodeFlowSettings(
    platformClientId: String,
) = OAuthClientSettings(
    clientId = this?.clientId?.takeIf { it.isNotBlank() } ?: platformClientId,
    redirectUri = UNUSED_REDIRECT_URI,
)

/**
 * Placeholder for a flow that never redirects.
 *
 * No app registers this scheme, so it is obvious if it ever shows up in a request.
 */
internal const val UNUSED_REDIRECT_URI = "com.iproov.identity.unused:/no-authorization-request"

/**
 * True when the platform's own URI type can parse [redirectUri].
 *
 * The platform parser has the final say — it is what builds the `redirect_uri` that goes on the
 * wire — so it runs as part of validation, before an offer is resolved or a device-bound key is
 * acquired. Both platforms reject the same malformed authorities (an unterminated IPv6 host, say);
 * where they historically differed, on percent-escapes, the shared check above settles it.
 */
internal expect fun isParsableUri(redirectUri: String): Boolean

/** The scheme rule from RFC 3986 Section 3.1. */
private val URI_SCHEME = Regex("[A-Za-z][A-Za-z0-9+.-]*")

/** A `%` not followed by two hex digits — RFC 3986 Section 2.1 requires both. */
private val INVALID_PERCENT_ESCAPE = Regex("%(?![0-9A-Fa-f]{2})")
