package com.iproov.identity

import android.os.Build
import android.os.Bundle
import androidx.annotation.RequiresApi
import androidx.fragment.app.FragmentActivity
import com.iproov.identity.cryptography.KeyPairAuthenticationCanceled
import com.iproov.identity.dcapi.DCApiErrorCode
import com.iproov.identity.dcapi.DCApiActivityHelper
import com.iproov.identity.dcapi.DCApiMatchResult
import com.iproov.identity.dcapi.DCApiResult
import com.iproov.identity.models.CredentialQuery
import com.iproov.identity.models.id
import com.iproov.identity.persistence.CredentialSubmission
import com.iproov.identity.persistence.DisclosedCredential
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.cancellation.CancellationException

class CredentialSelectionActivity : FragmentActivity() {
    private lateinit var dcApiHelper: DCApiActivityHelper

    private val scope = CoroutineScope(Dispatchers.Main)

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Logger.debug("CredentialSelectionActivity onCreate called, action=${intent?.action}")

        dcApiHelper = DCApiActivityHelper(this)

        if (!dcApiHelper.isValidRequest()) {
            Logger.error("Invalid request: PendingIntentHandler could not retrieve ProviderGetCredentialRequest from intent (extras=${intent?.extras?.keySet()})")
            finish()
            return
        }
        Logger.debug("CredentialSelectionActivity calling package: ${dcApiHelper.getCallingPackageName()}")

        val callingOrigin = try {
            dcApiHelper.getCallingOrigin()
        } catch (e: Exception) {
            null
        }
        Logger.debug("CredentialSelectionActivity called from origin: $callingOrigin")

        if (callingOrigin == null) {
            Logger.error("Could not determine calling origin")
            dcApiHelper.returnError(
                DCApiResult.Error(
                    code = "origin_unavailable",
                    message = "Cannot determine the origin of the calling browser",
                )
            )
            finish()
            return
        }

        // Or just extract the credential request JSON (what you usually need)
        val credentialRequestJson = dcApiHelper.extractRequestJson() ?: run {
            Logger.error("Failed to extract credential request JSON")
            dcApiHelper.returnError(
                DCApiResult.Error(
                    code = "invalid_request",
                    message = "No credential request JSON found",
                )
            )
            finish()
            return
        }

        // Get the selected credential ID from the system picker
        val selectedCredentialId = dcApiHelper.getSelectedEntryId()
        scope.launch {
            try {
                val wallet = WalletFactory.instance ?: run {
                    dcApiHelper.returnError(
                        DCApiResult.Error(
                            code = "wallet_not_initialized",
                            message = "Wallet is not initialized",
                        )
                    )
                    return@launch
                }
                val matchResult = wallet.processDCApiRequest(credentialRequestJson, callingOrigin)
                coroutineContext.ensureActive()
                when (matchResult) {
                    is DCApiMatchResult.InvalidRequest -> {
                        Logger.error("DC API request rejected: ${matchResult.message}")
                        if (matchResult.code == DCApiErrorCode.USER_CANCELLED) {
                            dcApiHelper.returnCancelled()
                        } else {
                            dcApiHelper.returnProtocolError(
                                credentialRequestJson,
                                DCApiResult.Error(matchResult.code, matchResult.message),
                            )
                        }
                    }

                    is DCApiMatchResult.NoMatch -> {
                        Logger.debug("No matching credentials found")
                        dcApiHelper.returnProtocolError(credentialRequestJson, DCApiErrorCode.ACCESS_DENIED)
                    }

                    is DCApiMatchResult.Success -> {
                        // Build credential submission from the match result
                        val submission = buildCredentialSubmission(
                            matchResult = matchResult,
                            selectedCredentialId = selectedCredentialId,
                        )

                        if (submission == null) {
                            Logger.debug("Selected credential not found in matching credentials")
                            dcApiHelper.returnError(
                                DCApiResult.Error(
                                    code = "credential_not_found",
                                    message = "Selected credential not found in matching credentials",
                                )
                            )
                            return@launch
                        }

                        val response = wallet.buildDCApiResponse(matchResult, submission)
                        coroutineContext.ensureActive()
                        when (response) {
                            is DCApiResult.Success -> dcApiHelper.returnSuccess(response)
                            is DCApiResult.Error -> dcApiHelper.returnProtocolError(credentialRequestJson, response)
                            is DCApiResult.UserDeclined -> dcApiHelper.returnCancelled()
                            is DCApiResult.NoMatchingCredentials ->
                                dcApiHelper.returnProtocolError(credentialRequestJson, DCApiErrorCode.ACCESS_DENIED)
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e // the activity is going away; not a failure to report
            } catch (e: KeyPairAuthenticationCanceled) {
                coroutineContext.ensureActive()
                dcApiHelper.returnCancelled()
            } catch (e: Exception) {
                coroutineContext.ensureActive()
                // Exception text can carry decrypted storage contents; keep it out of the response and logs.
                Logger.error("DC API request processing failed")
                dcApiHelper.returnProtocolError(credentialRequestJson, DCApiErrorCode.SERVER_ERROR)
            }
        }
    }

    /**
     * Build a CredentialSubmission from the match result and selected credential.
     *
     * With the registry-based DC API, the user has already selected a credential
     * from the system picker, so we use that selection.
     */
    private fun buildCredentialSubmission(
        matchResult: DCApiMatchResult.Success,
        selectedCredentialId: String?,
    ): CredentialSubmission? {
        val disclosedCredentials = mutableMapOf<CredentialQuery, DisclosedCredential>()

        for ((query, matchingMetadataList) in matchResult.matchResult.credentials) {
            // Find the credential that matches the selected ID, or use the first one
            val selectedMetadata = if (selectedCredentialId != null) {
                matchingMetadataList.find { it.metadata.id == selectedCredentialId }
            } else {
                matchingMetadataList.firstOrNull()
            } ?: continue

            disclosedCredentials[query] = DisclosedCredential(
                credential = selectedMetadata.credential,
                claims = selectedMetadata.matchingClaims.keys,
            )
        }

        if (disclosedCredentials.isEmpty()) {
            return null
        }


        return CredentialSubmission(
            disclosedCredentials = disclosedCredentials,
            matchResult = matchResult.matchResult
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
