package com.iproov.identity.persistence

interface SyncedKeyValueStorage {
    fun read(key: String): String?
    fun write(key: String, value: String?)
}

expect fun getSyncedKeyValueStorage(): SyncedKeyValueStorage