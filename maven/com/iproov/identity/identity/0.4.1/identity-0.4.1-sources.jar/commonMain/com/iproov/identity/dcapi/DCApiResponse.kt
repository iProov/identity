package com.iproov.identity.dcapi

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject

/**
 * Response returned to the OS/browser via Digital Credentials API.
 *
 * This is the structure that the wallet returns through the platform's credential manager
 * back to the requesting website/application.
 */
@Serializable
data class DCApiResponse(
    /**
     * Protocol that was used (matches the requested provider's protocol).
     */
    val protocol: String,

    /**
     * Protocol-specific response data containing the credential presentation.
     */
    val data: JsonElement,
) {
    companion object {
        private val json = Json { prettyPrint = false }

        /**
         * Create a DC API response for OpenID4VP protocol.
         *
         * @param vpToken The VP Token containing the credential presentation(s)
         * @param state Optional state parameter from the original request
         */
        fun forOpenID4VP(
            vpToken: String,
            state: String? = null,
        ): DCApiResponse {
            val data = buildJsonObject {
                put("vp_token", json.parseToJsonElement(vpToken))
                state?.let { put("state", JsonPrimitive(it)) }
            }
            return DCApiResponse(
                protocol = DCApiProtocol.OPENID4VP,
                data = data
            )
        }

        /**
         * Create a DC API response for OpenID4VP with encrypted JWT response.
         *
         * @param jwe The encrypted JWT containing the VP Token
         * @param state Optional state parameter from the original request
         */
        fun forOpenID4VPJWT(
            jwe: String,
            state: String? = null,
        ): DCApiResponse {
            val data = buildJsonObject {
                put("response", JsonPrimitive(jwe))
                state?.let { put("state", JsonPrimitive(it)) }
            }
            return DCApiResponse(
                protocol = DCApiProtocol.OPENID4VP,
                data = data
            )
        }

        /**
         * Create a DC API response for ISO mDoc protocol.
         *
         * @param deviceResponse Base64url-encoded DeviceResponse CBOR
         */
        fun forIsoMDoc(
            deviceResponse: String,
        ): DCApiResponse {
            val data = buildJsonObject {
                put("deviceResponse", JsonPrimitive(deviceResponse))
            }
            return DCApiResponse(
                protocol = DCApiProtocol.ISO_MDOC,
                data = data
            )
        }
    }

    /**
     * Serialize this response to JSON string for returning to the platform.
     */
    fun toJson(): String = json.encodeToString(serializer(), this)
}

/**
 * Result of processing a DC API request.
 */
sealed class DCApiResult {
    /**
     * Successfully processed the request and generated a response.
     */
    data class Success(
        val response: DCApiResponse,
    ) : DCApiResult()

    /**
     * User declined to share credentials.
     */
    data object UserDeclined : DCApiResult()

    /**
     * No matching credentials found for the request.
     */
    data class NoMatchingCredentials(
        val message: String = "No credentials match the request",
    ) : DCApiResult()

    /**
     * Error occurred during processing.
     */
    data class Error(
        val code: String,
        val message: String,
        val cause: Throwable? = null,
    ) : DCApiResult()
}

/**
 * OpenID4VP-specific response structure within DC API response.
 */
@Serializable
data class OpenID4VPResponse(
    /**
     * VP Token containing credential presentation(s).
     * For mDoc: JSON object mapping credential_query_id to base64url(DeviceResponse CBOR)
     * For SD-JWT-VC: JSON object mapping credential_query_id to SD-JWT presentation
     */
    @SerialName("vp_token")
    val vpToken: JsonElement,

    /**
     * Optional state parameter echoed from request.
     */
    val state: String? = null,
)

/**
 * Error codes for DC API error responses.
 */
object DCApiErrorCode {
    const val INVALID_REQUEST = "invalid_request"
    const val UNSUPPORTED_PROTOCOL = "unsupported_protocol"
    const val NO_CREDENTIALS = "no_credentials"
    const val USER_CANCELLED = "user_cancelled"
    const val INTERNAL_ERROR = "internal_error"
    const val SIGNING_FAILED = "signing_failed"
}
