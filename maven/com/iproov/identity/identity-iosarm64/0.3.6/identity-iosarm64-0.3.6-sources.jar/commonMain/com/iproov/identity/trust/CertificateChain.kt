package com.iproov.identity.trust

/**
 * A DER-encoded X.509 certificate chain, ordered leaf-first.
 *
 * Per ETSI TS 119 602, the ServiceDigitalIdentity of a LoTE entry contains
 * X.509 certificates used as trust anchors. During trust evaluation, the
 * certificate chain presented by a verifier or issuer (e.g., from the x5c
 * header of a signed JWT) is validated against these anchors.
 *
 * Validation methods per ETSI TS 119 602:
 * - **Direct Trust**: The [leaf] certificate is found directly in the LoTE.
 *   Used when the LoTE contains end-entity certificates (PID providers,
 *   Wallet providers).
 * - **PKIX Chain Validation**: The chain builds from the leaf through
 *   intermediates to a CA certificate in the LoTE. Used when the LoTE
 *   contains CA certificates (WRPAC providers, WRPRC providers).
 *
 * @param certificates DER-encoded X.509 certificates, leaf first.
 */
class CertificateChain(val certificates: List<ByteArray>) {

    init {
        require(certificates.isNotEmpty()) { "Certificate chain must not be empty" }
    }

    /** The leaf (end-entity) certificate — the first in the chain. */
    val leaf: ByteArray get() = certificates.first()
}
