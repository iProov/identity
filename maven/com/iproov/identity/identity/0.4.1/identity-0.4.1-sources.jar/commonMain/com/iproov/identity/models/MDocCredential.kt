package com.iproov.identity.models

import io.ktor.util.sha1
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement

/**
 * Simplified representation of the usable MDoc data.
 */
@OptIn(ExperimentalObjCRefinement::class)
class MDocCredential(
    override val raw: String,
    override val body: JsonObject,
    val docType: String,
    val nameSpaces: Map<String, Map<String, Any?>>,
    val onCheckVerificationStatus: suspend (Credential) -> VerificationSummary,
) : Credential {
    override val format = CredentialFormat.MDOC

    override val uuid: String by lazy {
        sha1(raw.encodeToByteArray()).decodeToString()
    }
}