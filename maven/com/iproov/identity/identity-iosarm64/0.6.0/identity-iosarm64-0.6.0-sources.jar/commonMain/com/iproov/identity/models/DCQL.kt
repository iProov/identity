package com.iproov.identity.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC


/** DCQL — minimal structure needed for matching. */
@Serializable
data class DcqlQuery @Throws(Exception::class) constructor(
    val credentials: List<CredentialQuery> = emptyList(),
    @SerialName("credential_sets")
    val credentialSets: List<CredentialSetQuery>? = null
) {
    init {
        credentialSets?.let {
            require(it.isNotEmpty()) {
                "credential_sets, when present, must be a non-empty array (Section 6)"
            }
        }

        // Credential ids must be unique within the request (Section 6.1)
        val ids = credentials.map { it.id }
        require(ids.size == ids.toSet().size) {
            "Credential Query id values must be unique within the request (Section 6.1)"
        }
        
        // Every id referenced in credential_sets must exist in credentials (Section 6.2)
        credentialSets?.let { sets ->
            val knownIds = ids.toSet()
            sets.flatMap { it.options.flatten() }.forEach { ref ->
                require(ref in knownIds) {
                    "credential_sets references unknown Credential Query id: $ref (Section 6.2)"
                }
            }
        }
    }
}

/**
 * Represents a Credential Set Query as defined in OpenID for Verifiable Presentations 1.0, Section 6.2.
 *
 * A Credential Set Query specifies constraints on which combination of requested Credentials
 * must be returned to satisfy a particular use case with the Verifier.
 *
 * @property options Non-empty list where each element is a non-empty list of Credential Query
 *                   identifiers (referencing `id` values in the top-level `credentials` array).
 *                   Each inner list represents one acceptable set of Credentials that satisfies
 *                   the use case.
 * @property required Whether this set of Credentials is required. Defaults to true per spec
 *                    when omitted from the serialised form.
 */
@Serializable
data class CredentialSetQuery @Throws(Exception::class) constructor(
    val options: List<List<String>>,
    val required: Boolean = true,
) {
    init {
        require(options.isNotEmpty()) {
            "options must be a non-empty array (Section 6.2)"
        }
        require(options.all { it.isNotEmpty() }) {
            "Each element in options must be a non-empty array of Credential Query identifiers (Section 6.2)"
        }
    }
}

@OptIn(ExperimentalObjCRefinement::class)
@Serializable
data class CredentialQuery @Throws(Exception::class) constructor(
    val id: String,

    /**
     * Format used to identify the credential in the wallet.
     */
    val format: String, // e.g., jwt_vc_json | ldp_vc | mso_mdoc | dc+sd-jwt
    val claims: List<ClaimQuery>? = null,

    @HiddenFromObjC
    val meta: JsonObject? = null, // format-specific tuning: type_values, vct_values, doctype_value...

    /**
     * Whether multiple credentials can be returned for this query
     */
    val multiple: Boolean = false,

    /** Legacy, programmatic issuer-name filter; not the OpenID4VP wire representation. */
    @Deprecated("Use trustedAuthorityQueries for OpenID4VP trusted_authorities")
    @Transient
    val trustedAuthorities: List<String>? = null,
    @SerialName("require_cryptographic_holder_binding")
    val requireCryptographicHolderBinding: Boolean? = null,

    /**
     * Combinations of the claims that can be submitted.
     */
    @SerialName("claim_sets")
    val claimSets: List<List<String>>? = null,
    @SerialName("trusted_authorities")
    val trustedAuthorityQueries: List<TrustedAuthorityQuery>? = null,
) {
    /** Retains the previous constructor for Swift and other direct callers. */
    @Throws(Exception::class)
    constructor(
        id: String, format: String, claims: List<ClaimQuery>?, meta: JsonObject?,
        multiple: Boolean, trustedAuthorities: List<String>?,
        requireCryptographicHolderBinding: Boolean?, claimSets: List<List<String>>?,
    ) : this(id, format, claims, meta, multiple, trustedAuthorities,
        requireCryptographicHolderBinding, claimSets, null)

    init {
        require(trustedAuthorityQueries?.isNotEmpty() != false) {
            "trusted_authorities, when present, must be a non-empty array (OID4VP §6.1)"
        }
        // Per OID4VP § 6.1.1: id is REQUIRED on each ClaimQuery when claim_sets is defined.
        claimSets?.let {
            require(claims?.all { claim -> claim.id != null } != false) {
                "All claims must have an id when claim_sets is defined (OID4VP § 6.1.1)"
            }
        }

        // Per OID4VP § 6.1: claims, when present, is a non-empty array.
        require(claims?.isNotEmpty() != false) {
            "claims, when present, must be a non-empty array (OID4VP § 6.1)"
        }

        // Per OID4VP § 6.4.1: claim_sets MUST NOT be present if claims is absent.
        require(!(claimSets != null && claims == null)) {
            "claim_sets must not be present when claims is absent (OID4VP § 6.4.1)"
        }

        // Per OID4VP § 7.2.1: a claims path pointer into an mdoc is exactly two strings —
        // the namespace and the data element identifier. Anything else must be rejected
        // rather than processed, otherwise the wallet silently presents no data at all.
        if (format == "mso_mdoc") {
            claims?.forEach { claim ->
                require(claim.path.size == 2) {
                    "An mso_mdoc claim path must contain exactly two elements " +
                        "[namespace, data element identifier], but was ${claim.path} " +
                        "for claim id='${claim.id}' (OID4VP § 7.2.1)"
                }
            }
        }
    }
}

/** OpenID4VP §6.1.1: alternatives identifying the issuer's authority or trust framework. */
@Serializable
data class TrustedAuthorityQuery @Throws(Exception::class) constructor(
    val type: String,
    val values: List<String>,
) {
    init {
        require(values.isNotEmpty()) { "Trusted authority values must be non-empty (OID4VP §6.1.1)" }
    }
}

@OptIn(ExperimentalObjCRefinement::class)
@Serializable
data class ClaimQuery @Throws(Exception::class) constructor(
    /**
     * REQUIRED if CredentialQuery has defined [claimSets]
     */
    val id: String? = null,

    /**
     * Where in the VC this can be found
     */
    val path: List<String>,

    /**
     * Accepted values for this requested property.
     */
    @HiddenFromObjC
    val values: List<JsonElement>? = null,

    /**
     * Whether the issuer intends to retain
     */
    @SerialName("intent_to_retain")
    val intentToRetain: Boolean = false
) {
    init {
        // Per OID4VP § 7: a claims path pointer MUST be a non-empty array.
        require(path.isNotEmpty()) {
            "A claim path must be a non-empty array (OID4VP § 7)"
        }
    }
}
