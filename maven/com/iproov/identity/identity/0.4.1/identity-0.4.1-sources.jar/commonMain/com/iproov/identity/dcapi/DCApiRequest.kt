package com.iproov.identity.dcapi

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * DC API Protocol identifiers as defined in W3C Digital Credentials API.
 */
object DCApiProtocol {
    // Standard protocol identifiers
    const val OPENID4VP = "openid4vp"
    const val ISO_MDOC = "org.iso.mdoc"

    // Browser-specific protocol identifiers (Chrome)
    const val OPENID4VP_V1_UNSIGNED = "openid4vp-v1-unsigned"
    const val OPENID4VP_V1_SIGNED = "openid4vp-v1-signed"
}

/**
 * Represents a Digital Credentials API request from navigator.credentials.get().
 *
 * This is the JSON structure received by wallet applications when browsers or native apps
 * invoke the Digital Credentials API to request verifiable credentials.
 *
 * Supports both formats:
 *
 * W3C format (used by browsers like Chrome):
 * ```json
 * {
 *   "requests": [{
 *     "protocol": "openid4vp-v1-unsigned",
 *     "data": {
 *       "nonce": "abc123",
 *       "dcql_query": { ... }
 *     }
 *   }]
 * }
 * ```
 *
 * Legacy/SDK format:
 * ```json
 * {
 *   "providers": [{
 *     "protocol": "openid4vp",
 *     "request": { ... }
 *   }]
 * }
 * ```
 */
@Serializable
data class DCApiRequest(
    /**
     * List of credential providers/protocols being requested.
     * The wallet should process the first protocol it supports.
     */
    val providers: List<DCApiProvider>,
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        /**
         * Parse a DC API request from JSON string.
         * This is the requestJson received from the OS credential manager.
         * Handles both W3C format (requests/data) and SDK format (providers/request).
         */
        fun fromJson(requestJson: String): DCApiRequest {
            val jsonElement = json.parseToJsonElement(requestJson)
            val jsonObject = jsonElement.jsonObject

            // Check if this is W3C format (has "requests" array)
            val requestsArray = jsonObject["requests"]?.jsonArray
            if (requestsArray != null) {
                // Convert W3C format to our internal format
                val providers = requestsArray.map { requestElement ->
                    val requestObj = requestElement.jsonObject
                    val originalProtocol = requestObj["protocol"]?.jsonPrimitive?.content ?: ""
                    val data = requestObj["data"] ?: JsonObject(emptyMap())

                    DCApiProvider(
                        protocol = normalizeProtocol(originalProtocol),
                        originalProtocol = originalProtocol,
                        request = data,
                    )
                }
                return DCApiRequest(providers = providers)
            }

            // Check if this is SDK format (has "providers" array)
            val providersArray = jsonObject["providers"]?.jsonArray
            if (providersArray != null) {
                // Convert SDK format to our internal format with originalProtocol
                val providers = providersArray.map { providerElement ->
                    val providerObj = providerElement.jsonObject
                    val originalProtocol = providerObj["protocol"]?.jsonPrimitive?.content ?: ""
                    val request = providerObj["request"] ?: JsonObject(emptyMap())

                    DCApiProvider(
                        protocol = normalizeProtocol(originalProtocol),
                        originalProtocol = originalProtocol,
                        request = request,
                    )
                }
                return DCApiRequest(providers = providers)
            }

            // If neither, try to parse as a single request object (the data directly)
            // This handles cases where the inner request is passed directly
            throw IllegalArgumentException(
                "Invalid DC API request format. Expected 'requests' or 'providers' array."
            )
        }

        /**
         * Normalize protocol identifiers to standard form.
         */
        private fun normalizeProtocol(protocol: String): String {
            return when (protocol) {
                DCApiProtocol.OPENID4VP_V1_UNSIGNED,
                DCApiProtocol.OPENID4VP_V1_SIGNED -> DCApiProtocol.OPENID4VP

                else -> protocol
            }
        }
    }

    /**
     * Find the first supported provider in the request.
     * Currently supports "openid4vp" and "org.iso.mdoc" protocols.
     */
    fun findSupportedProvider(): DCApiProvider? {
        return providers.firstOrNull { provider ->
            provider.protocol == DCApiProtocol.OPENID4VP ||
                    provider.protocol == DCApiProtocol.ISO_MDOC
        }
    }
}

/**
 * A credential provider specification within the DC API request.
 */
@Serializable
data class DCApiProvider(
    /**
     * Protocol identifier (e.g., "openid4vp", "org.iso.mdoc").
     * This is the normalized protocol for routing purposes.
     */
    val protocol: String,

    /**
     * Original protocol identifier before normalization.
     * Preserved to distinguish between signed and unsigned requests.
     * e.g., "openid4vp-v1-signed" vs "openid4vp-v1-unsigned"
     */
    val originalProtocol: String,

    /**
     * Protocol-specific request data.
     * For OpenID4VP unsigned: contains authorization request parameters directly.
     * For OpenID4VP signed: contains {"request": "<JWT>"} where JWT contains the parameters.
     * For ISO mDoc: contains device request parameters.
     */
    val request: JsonElement,
) {
    /**
     * Check if this is a signed OpenID4VP request (JAR format).
     */
    val isSignedRequest: Boolean
        get() = originalProtocol == DCApiProtocol.OPENID4VP_V1_SIGNED
}

/**
 * OpenID4VP-specific request parameters extracted from DC API request.
 *
 * Per OID4VP DC API profile, this contains a subset of Authorization Request parameters
 * relevant for browser-initiated credential requests.
 */
@Serializable
data class OpenID4VPDCApiRequest(
    /**
     * Client identifier (verifier). Optional in DC API flow.
     */
    @SerialName("client_id")
    val clientId: String? = null,

    /**
     * Fresh random nonce for this request.
     */
    val nonce: String? = null,

    /**
     * DCQL query specifying requested credentials.
     */
    @SerialName("dcql_query")
    val dcqlQuery: JsonObject? = null,

    /**
     * Presentation definition (alternative to DCQL).
     */
    @SerialName("presentation_definition")
    val presentationDefinition: JsonObject? = null,

    /**
     * Response mode: "dc_api" or "dc_api.jwt"
     */
    @SerialName("response_mode")
    val responseMode: String = "dc_api",

    /**
     * Response type: "vp_token"
     */
    @SerialName("response_type")
    val responseType: String? = null,

    /**
     * Client metadata containing verifier information.
     */
    @SerialName("client_metadata")
    val clientMetadata: JsonObject? = null,

    /**
     * Web origin that initiated the request (set by browser).
     */
    val origin: String? = null,
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        fun fromJsonElement(element: JsonElement): OpenID4VPDCApiRequest {
            return json.decodeFromJsonElement(serializer(), element)
        }
    }
}

/**
 * ISO mDoc-specific request parameters for DC API.
 * Used when protocol is "org.iso.mdoc".
 */
@Serializable
data class IsoMDocDCApiRequest(
    /**
     * Document type being requested (e.g., "org.iso.18013.5.1.mDL").
     */
    @SerialName("docType")
    val docType: String,

    /**
     * Namespaces and elements being requested.
     */
    val nameSpaces: Map<String, Map<String, Boolean>>? = null,

    /**
     * Reader authentication data.
     */
    val readerAuth: JsonElement? = null,

    /**
     * Nonce for this request.
     */
    val nonce: String? = null,

    /**
     * Web origin that initiated the request.
     */
    val origin: String? = null,
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        fun fromJsonElement(element: JsonElement): IsoMDocDCApiRequest {
            return json.decodeFromJsonElement(serializer(), element)
        }
    }
}

/**
 * Browser handover information for DC API SessionTranscript.
 * Per ISO 18013-7 Annex C, browser-initiated requests use a different handover structure.
 */
data class BrowserHandoverInfo(
    /**
     * Web origin that initiated the credential request.
     */
    val origin: String,

    /**
     * Nonce provided by the requester.
     */
    val nonce: String,

    /**
     * Hash of the requester's public key (if any).
     */
    val requesterKeyHash: ByteArray? = null,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || this::class != other::class) return false

        other as BrowserHandoverInfo

        if (origin != other.origin) return false
        if (nonce != other.nonce) return false
        if (requesterKeyHash != null) {
            if (other.requesterKeyHash == null) return false
            if (!requesterKeyHash.contentEquals(other.requesterKeyHash)) return false
        } else if (other.requesterKeyHash != null) return false

        return true
    }

    override fun hashCode(): Int {
        var result = origin.hashCode()
        result = 31 * result + nonce.hashCode()
        result = 31 * result + (requesterKeyHash?.contentHashCode() ?: 0)
        return result
    }
}
