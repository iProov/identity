package com.iproov.identity.cryptography

import com.iproov.identity.JOSEUtils
import com.iproov.identity.models.Jwk
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCObjectVar
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.value
import kotlinx.serialization.json.Json
import platform.Foundation.NSError

class AppleJWEFactory : JWEFactory {
    override val supportedKeyManagementAlgorithms: List<String> by lazy {
        listOf("ECDH-ES", "RSA1_5", "RSA-OAEP", "RSA-OAEP-256", "A128KW", "A192KW", "A256KW", "dir")
    }

    override val supportedEncryptionAlgorithms: List<String> by lazy {
        listOf("A128GCM", "A192GCM", "A256GCM", "A128CBC-HS256", "A192CBC-HS384", "A256CBC-HS512")
    }

    @OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)
    override suspend fun create(
        payload: ByteArray,
        recipientPublicKey: Jwk,
        alg: String,
        encToUse: String,
        apu: ByteArray?,
    ): String = memScoped {
        val error = alloc<ObjCObjectVar<NSError?>>()
        val jwe = JOSEUtils.createJweWithPayload(
            payload.toNSData(),
            jwk = json.encodeToString(recipientPublicKey),
            encryptionAlgorithm = encToUse,
            keyManagementAlgorithm = alg,
            error = error.ptr,
            apu = apu?.toNSData()
        )

        error.value?.let {
            throw JWECreationException(it.localizedDescription)
        }

        jwe ?: throw JWECreationException("Failed to create JWE but no error was thrown")
    }

}

actual fun getPlatformJWEFactory(): JWEFactory = AppleJWEFactory()
private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
